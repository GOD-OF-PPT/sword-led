# Web Zip 安全扫描报告

扫描路径: /Users/gordon/githome/sword-led/.git/maintenance/security-20261117-233917/tracked-export
扫描的 HTML 文件数: 15
问题统计: 共 0 项，其中高风险 0 项，中风险 0 项，需人工复核 0 项

## 总体结论

通过。本次扫描未命中本技能定义的安全规则。

默认排除: node_modules, .git, .svn, .hg, dist, build, .cache, .turbo, .next, coverage, Library, Temp, Logs。扫描未执行页面或进行网络请求。

## 高风险

## 中风险

## 需人工复核

## 建议修复顺序

1. 修复当前交付的高风险项。
2. 修复或说明中风险项。
3. 复核动态内容与历史样本，保留证据原始字节。

本次仅静态检查指定规则，不能证明不存在所有安全漏洞。
