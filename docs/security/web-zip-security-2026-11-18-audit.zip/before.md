# Web Zip 安全扫描报告（初扫边界校正版）

扫描路径: /Users/gordon/githome/sword-led
扫描的 HTML 文件数: 337
问题统计: 1795 项，高风险 1758，中风险 37，需人工复核 0。

## 总体结论

需修复。两个dist目录符号链接按技能默认排除移出统计，原始初稿仍保留在before-raw-initial文件。

## 高风险

### H-1 固定资源/导航路径
- 文件: campaign.html
- 行号: 11
- 证据: `src="/src/v7-main.ts"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-2 固定资源/导航路径
- 文件: campaign.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-3 固定资源/导航路径
- 文件: classic.html
- 行号: 11
- 证据: `src="/src/classic-main.ts"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-4 固定资源/导航路径
- 文件: design/b/preview/index.html
- 行号: 61
- 证据: `src="/assets/b/merchant-kit-v1.webp"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-5 固定资源/导航路径
- 文件: design/b/preview/index.html
- 行号: 7
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-6 固定CSS资源路径
- 文件: design/campaign-v1/storyboard.html
- 行号: 16
- 证据: `url('/assets/d/customers-atlas-v2.webp')`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为相对URL。

### H-7 固定资源/导航路径
- 文件: design/campaign-v1/storyboard.html
- 行号: 41
- 证据: `src="/assets/d/reboot/forge-focus-backdrop-v1.webp"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-8 固定资源/导航路径
- 文件: design/campaign-v1/storyboard.html
- 行号: 58
- 证据: `src="/assets/d/v07-chapter3/ending-twelve-lights-v1.webp"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-9 固定资源/导航路径
- 文件: docs/evidence/T11-4-2-3i6-guidance/runtime-delta/index.html
- 行号: 2
- 证据: `src="/assets/main-DhAm8t4z.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-10 固定资源/导航路径
- 文件: docs/evidence/T11-4-2-3i6-guidance/runtime-delta/index.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-11 固定资源/导航路径
- 文件: docs/evidence/T11-4-2-3i6-guidance/runtime-delta/index.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-12 固定资源/导航路径
- 文件: docs/evidence/T11-4-2-3i6-guidance/runtime-delta/index.html
- 行号: 5
- 证据: `href="/assets/main-Cs7wa2SA.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-13 固定资源/导航路径
- 文件: docs/evidence/T11-4-2-3i6-model/reproduction/source/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-14 固定资源/导航路径
- 文件: docs/evidence/T11-4-2-3i6-model/reproduction/source/legacy.html
- 行号: 2
- 证据: `src="/src/main.ts"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-15 固定资源/导航路径
- 文件: docs/evidence/T11-4-2-3i6-model/reproduction/source/v3.html
- 行号: 2
- 证据: `src="/src/v3-main.ts"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-16 固定资源/导航路径
- 文件: docs/evidence/T11-4-2-3l4/initial-source/index.html
- 行号: 2
- 证据: `src="/src/v5-main.ts"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-17 固定资源/导航路径
- 文件: forge.html
- 行号: 11
- 证据: `src="/src/forge-main.ts"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-18 固定资源/导航路径
- 文件: index.html
- 行号: 11
- 证据: `src="/src/v8-main.ts"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-19 固定资源/导航路径
- 文件: index.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-20 固定资源/导航路径
- 文件: legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-21 固定资源/导航路径
- 文件: legacy.html
- 行号: 2
- 证据: `src="/src/main.ts"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-22 动态HTML赋值
- 文件: public/playable-v8.html
- 行号: 4855
- 证据: `elModalBody.innerHTML = html`
- 原因: 动态HTML赋值未在此赋值边界经过指定sanitizer。
- 修复: 在该赋值边界调用真实sanitizer，并限制URL、属性与CSS。

### H-23 动态HTML赋值
- 文件: public/playable-v8.html
- 行号: 5070
- 证据: `elStepper.innerHTML = parts.join('')`
- 原因: 动态HTML赋值未在此赋值边界经过指定sanitizer。
- 修复: 在该赋值边界调用真实sanitizer，并限制URL、属性与CSS。

### H-24 动态HTML赋值
- 文件: public/playable-v8.html
- 行号: 5077
- 证据: `elLampPill.innerHTML = \`<span>🔥 灯火</span><span class="v8-lamp-pips">${pips.join('')}</span><strong>${state.lamp}/${state.lampMax}</strong>\``
- 原因: 动态HTML赋值未在此赋值边界经过指定sanitizer。
- 修复: 在该赋值边界调用真实sanitizer，并限制URL、属性与CSS。

### H-25 动态HTML赋值
- 文件: public/playable-v8.html
- 行号: 5078
- 证据: `elResPill.innerHTML = \`🪙 <b>${state.coins}</b>钱 · 🧱 坯<b>${state.blanks}</b> · ⚡ 技<b>${state.charge}</b>\``
- 原因: 动态HTML赋值未在此赋值边界经过指定sanitizer。
- 修复: 在该赋值边界调用真实sanitizer，并限制URL、属性与CSS。

### H-26 固定资源/导航路径
- 文件: public/playable-v8.html
- 行号: 5105
- 证据: `href="/campaign.html"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-27 动态HTML赋值
- 文件: public/playable-v8.html
- 行号: 5108
- 证据: `elStageBody.innerHTML = \` <div class="v8-title-screen"> <div class="v8-title-hero"> <div class="v8-kicker">锤下求生 · 三章九站铸剑战棋 · V8.2 薪火参赛版</div> <h1>护炉远行</h1> <p class="v8-title-lead"> 绝顶山口的母灯熄了，十二盏山路长灯正一盏盏暗入风雪。<br> 推起小炉车观火铸剑，收集十二传世名剑图鉴，沿途救齐众人`
- 原因: 动态HTML赋值未在此赋值边界经过指定sanitizer。
- 修复: 在该赋值边界调用真实sanitizer，并限制URL、属性与CSS。

### H-28 动态HTML赋值
- 文件: public/playable-v8.html
- 行号: 5160
- 证据: `elStageBody.innerHTML = \` <div class="v8-choice-stage"> <div class="v8-scroll-box"> <h2>📜 护炉立誓 · 三章远行要诀</h2> <p>母灯在绝顶山口熄灭，你们推着唯一灯芯与随行小炉车踏入夜路。出发前只记这三件事：</p> <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));g`
- 原因: 动态HTML赋值未在此赋值边界经过指定sanitizer。
- 修复: 在该赋值边界调用真实sanitizer，并限制URL、属性与CSS。

### H-29 动态HTML赋值
- 文件: public/playable-v8.html
- 行号: 5257
- 证据: `elStageBody.innerHTML = \` <div class="v8-prepare-view"> <div class="v8-companion-stage"> <img class="v8-companion-img" src="${art(comp.fullArt)}" alt="${esc(comp.name)}"> <div class="v8-speech-card"> <b>${esc(comp.name)} · ${esc(comp.role)}`
- 原因: 动态HTML赋值未在此赋值边界经过指定sanitizer。
- 修复: 在该赋值边界调用真实sanitizer，并限制URL、属性与CSS。

### H-30 动态HTML赋值
- 文件: public/playable-v8.html
- 行号: 5383
- 证据: `elStageBody.innerHTML = \` <div class="v8-forge-view"> <div class="v8-heat-hud"> <div class="v8-heat-top"> <span>🔥 <b>柔阻尼炉温仪</b> · ${esc(riskText)}</span> <span class="v8-speed-pills"> <span style="color:var(--v8-muted);font-size:11px;">炉风速`
- 原因: 动态HTML赋值未在此赋值边界经过指定sanitizer。
- 修复: 在该赋值边界调用真实sanitizer，并限制URL、属性与CSS。

### H-31 动态HTML赋值
- 文件: public/playable-v8.html
- 行号: 5550
- 证据: `elStageBody.innerHTML = \` <div class="v8-encounter-view"> ${topBanner} <div class="v8-arena-grid"> <div class="v8-hero-stance ${e.block > 0 ? 'is-guarded' : ''}"> ${ hand && isWeaponUsable(hand) ? \`<img class="v8-hero-blade-img" src="${art(`
- 原因: 动态HTML赋值未在此赋值边界经过指定sanitizer。
- 修复: 在该赋值边界调用真实sanitizer，并限制URL、属性与CSS。

### H-32 动态HTML赋值
- 文件: public/playable-v8.html
- 行号: 5595
- 证据: `elStageBody.innerHTML = \` <div class="v8-choice-stage"> <div class="v8-scroll-box"> <small style="color:#7c582b;font-weight:700;">第${state.node}站 · ${esc(NODES_DATA[state.node].title)} · 因果抉择</small> <h2>${esc(cData.title)}</h2> <p>${esc(cD`
- 原因: 动态HTML赋值未在此赋值边界经过指定sanitizer。
- 修复: 在该赋值边界调用真实sanitizer，并限制URL、属性与CSS。

### H-33 动态HTML赋值
- 文件: public/playable-v8.html
- 行号: 5609
- 证据: `elStageBody.innerHTML = \` <div class="v8-choice-stage"> <div class="v8-scroll-box"> <small style="color:#963d28;font-weight:700;">止步于 第${state.node}站 · ${esc(NODES_DATA[state.node].title)}</small> <h2>炉火受阻 · 先把这口火记在心里</h2> <p>${esc(state.fa`
- 原因: 动态HTML赋值未在此赋值边界经过指定sanitizer。
- 修复: 在该赋值边界调用真实sanitizer，并限制URL、属性与CSS。

### H-34 动态HTML赋值
- 文件: public/playable-v8.html
- 行号: 5712
- 证据: `elStageBody.innerHTML = \` <div class="v8-ending-view"> <div class="v8-ending-left ${end.isSecret ? 'is-celestial' : ''}"> <span class="v8-ch-badge">${esc(end.difficultyName)} · 止于 ${esc(end.stoppedAt)}</span> <h1>${esc(end.title)}</h1> <p s`
- 原因: 动态HTML赋值未在此赋值边界经过指定sanitizer。
- 修复: 在该赋值边界调用真实sanitizer，并限制URL、属性与CSS。

### H-35 动态HTML赋值
- 文件: public/playable-v8.html
- 行号: 5830
- 证据: `elColRack.innerHTML = \`<div class="v8-rack-row">${slotCard(hand, true)}${slotCard(reserve, false)}</div>${toolHtml}\``
- 原因: 动态HTML赋值未在此赋值边界经过指定sanitizer。
- 修复: 在该赋值边界调用真实sanitizer，并限制URL、属性与CSS。

### H-36 动态HTML赋值
- 文件: public/playable-v8.html
- 行号: 5855
- 证据: `elColAssist.innerHTML = \` <div class="v8-assist-row">${assistHtml}</div> <div class="v8-log-box">${logsHtml}</div> \``
- 原因: 动态HTML赋值未在此赋值边界经过指定sanitizer。
- 修复: 在该赋值边界调用真实sanitizer，并限制URL、属性与CSS。

### H-37 动态HTML赋值
- 文件: public/playable-v8.html
- 行号: 5864
- 证据: `elColCmd.innerHTML = \` <div class="v8-ap-row"> <span>📍 当前阶段：<b>炉车整备</b>（阅读、调音与换剑不耗回合）</span> </div> <div class="v8-cmd-buttons"> <button type="button" class="v8-btn ${firstForge ? 'is-primary' : ''}" data-act="begin-forge" ${state.blanks <`
- 原因: 动态HTML赋值未在此赋值边界经过指定sanitizer。
- 修复: 在该赋值边界调用真实sanitizer，并限制URL、属性与CSS。

### H-38 动态HTML赋值
- 文件: public/playable-v8.html
- 行号: 5886
- 证据: `elColCmd.innerHTML = \` <div class="v8-ap-row"> <span>🔥 瞄准上方<b>金焰甜区</b>落锤 · 技火剩余 <b>${state.charge}</b> 次</span> </div> <div class="v8-cmd-buttons"> <button type="button" class="v8-btn is-primary" data-act="anvil-strike" ${!fw || fw.hits >=`
- 原因: 动态HTML赋值未在此赋值边界经过指定sanitizer。
- 修复: 在该赋值边界调用真实sanitizer，并限制URL、属性与CSS。

### H-39 动态HTML赋值
- 文件: public/playable-v8.html
- 行号: 6018
- 证据: `elColCmd.innerHTML = \` <div class="v8-ap-row"> <span>行动火印：<b style="color:var(--v8-gold);letter-spacing:2px;">${'◆'.repeat(e.actions)}${'◇'.repeat(Math.max(0, 2 - e.actions))}</b> (${e.actions}/2)</span> <span style="font-size:12px;color:va`
- 原因: 动态HTML赋值未在此赋值边界经过指定sanitizer。
- 修复: 在该赋值边界调用真实sanitizer，并限制URL、属性与CSS。

### H-40 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-09/index.html
- 行号: 2
- 证据: `src="/assets/main-D8ytS6M_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-41 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-09/index.html
- 行号: 3
- 证据: `href="/assets/dom-BMmK82A4.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-42 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-09/index.html
- 行号: 4
- 证据: `href="/assets/surface-XXG3cUZo.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-43 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-09/index.html
- 行号: 5
- 证据: `href="/assets/collection-mRVMeCl0.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-44 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-09/index.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-45 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-09/index.html
- 行号: 7
- 证据: `href="/assets/main-Z3FS1Ko_.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-46 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-09/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-47 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-09/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-BLyUzLPB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-48 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-09/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-BMmK82A4.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-49 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-09/legacy.html
- 行号: 4
- 证据: `href="/assets/input-BydN_pl3.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-50 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-09/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-51 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-09/v2.html
- 行号: 3
- 证据: `src="/assets/v2-D9wQo31j.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-52 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-09/v2.html
- 行号: 4
- 证据: `href="/assets/dom-BMmK82A4.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-53 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-09/v2.html
- 行号: 5
- 证据: `href="/assets/input-BydN_pl3.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-54 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-09/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-55 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-09/v3.html
- 行号: 2
- 证据: `src="/assets/v3-BZvTOXP5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-56 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-09/v3.html
- 行号: 3
- 证据: `href="/assets/dom-BMmK82A4.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-57 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-09/v3.html
- 行号: 4
- 证据: `href="/assets/surface-XXG3cUZo.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-58 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-09/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-59 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-09/v4.html
- 行号: 2
- 证据: `src="/assets/v4-DyE-Qyav.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-60 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-09/v4.html
- 行号: 3
- 证据: `href="/assets/dom-BMmK82A4.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-61 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-09/v4.html
- 行号: 4
- 证据: `href="/assets/surface-XXG3cUZo.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-62 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-09/v4.html
- 行号: 5
- 证据: `href="/assets/collection-mRVMeCl0.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-63 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-09/v4.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-64 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-10/index.html
- 行号: 2
- 证据: `src="/assets/main-DURGH0hn.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-65 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-10/index.html
- 行号: 3
- 证据: `href="/assets/dom-C0i_fTmf.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-66 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-10/index.html
- 行号: 4
- 证据: `href="/assets/surface-B6_3op8j.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-67 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-10/index.html
- 行号: 5
- 证据: `href="/assets/collection-DzurM0e7.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-68 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-10/index.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-69 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-10/index.html
- 行号: 7
- 证据: `href="/assets/main-Z3FS1Ko_.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-70 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-10/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-71 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-10/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-Dha1a8Ct.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-72 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-10/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-C0i_fTmf.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-73 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-10/legacy.html
- 行号: 4
- 证据: `href="/assets/input-pnx3H50t.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-74 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-10/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-75 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-10/v2.html
- 行号: 3
- 证据: `src="/assets/v2-Butpwi89.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-76 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-10/v2.html
- 行号: 4
- 证据: `href="/assets/dom-C0i_fTmf.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-77 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-10/v2.html
- 行号: 5
- 证据: `href="/assets/input-pnx3H50t.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-78 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-10/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-79 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-10/v3.html
- 行号: 2
- 证据: `src="/assets/v3-DSiMPiQu.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-80 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-10/v3.html
- 行号: 3
- 证据: `href="/assets/dom-C0i_fTmf.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-81 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-10/v3.html
- 行号: 4
- 证据: `href="/assets/surface-B6_3op8j.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-82 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-10/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-83 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-10/v4.html
- 行号: 2
- 证据: `src="/assets/v4-B9u42YKv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-84 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-10/v4.html
- 行号: 3
- 证据: `href="/assets/dom-C0i_fTmf.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-85 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-10/v4.html
- 行号: 4
- 证据: `href="/assets/surface-B6_3op8j.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-86 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-10/v4.html
- 行号: 5
- 证据: `href="/assets/collection-DzurM0e7.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-87 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-10/v4.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-88 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/index.html
- 行号: 2
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-89 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/index.html
- 行号: 2
- 证据: `src="/assets/main-BSPe6SQR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-90 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/index.html
- 行号: 3
- 证据: `href="/assets/dom-CALVLJZ2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-91 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/index.html
- 行号: 4
- 证据: `href="/assets/surface-JcVVblEq.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-92 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/index.html
- 行号: 5
- 证据: `href="/assets/collection-BcAICLAi.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-93 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/index.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-94 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/index.html
- 行号: 7
- 证据: `href="/assets/main-Z3FS1Ko_.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-95 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-96 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-DhXfwDYp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-97 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-CALVLJZ2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-98 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/legacy.html
- 行号: 4
- 证据: `href="/assets/input-DONC996E.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-99 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-100 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/v2.html
- 行号: 3
- 证据: `src="/assets/v2-DFgLbFa2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-101 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/v2.html
- 行号: 4
- 证据: `href="/assets/dom-CALVLJZ2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-102 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/v2.html
- 行号: 5
- 证据: `href="/assets/input-DONC996E.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-103 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-104 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/v3.html
- 行号: 2
- 证据: `src="/assets/v3-BNZjxfmQ.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-105 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/v3.html
- 行号: 3
- 证据: `href="/assets/dom-CALVLJZ2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-106 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/v3.html
- 行号: 4
- 证据: `href="/assets/surface-JcVVblEq.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-107 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-108 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/v4.html
- 行号: 2
- 证据: `src="/assets/v4-BNxlketD.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-109 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/v4.html
- 行号: 3
- 证据: `href="/assets/dom-CALVLJZ2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-110 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/v4.html
- 行号: 4
- 证据: `href="/assets/surface-JcVVblEq.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-111 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/v4.html
- 行号: 5
- 证据: `href="/assets/collection-BcAICLAi.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-112 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-11/v4.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-113 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/index.html
- 行号: 2
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-114 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/index.html
- 行号: 2
- 证据: `src="/assets/main-BZCbRZgG.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-115 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/index.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-116 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/index.html
- 行号: 4
- 证据: `href="/assets/surface-BSZK5ek_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-117 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/index.html
- 行号: 5
- 证据: `href="/assets/collection-DnlLnS-N.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-118 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/index.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-119 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/index.html
- 行号: 7
- 证据: `href="/assets/main-CJ4EDCzA.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-120 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-121 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-6a5ggSZZ.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-122 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-123 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/legacy.html
- 行号: 4
- 证据: `href="/assets/input-Csnfx8WT.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-124 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-125 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/v2.html
- 行号: 3
- 证据: `src="/assets/v2-BZXpUCsX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-126 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/v2.html
- 行号: 4
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-127 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/v2.html
- 行号: 5
- 证据: `href="/assets/input-Csnfx8WT.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-128 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-129 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/v3.html
- 行号: 2
- 证据: `src="/assets/v3-Ckca042P.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-130 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/v3.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-131 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/v3.html
- 行号: 4
- 证据: `href="/assets/surface-BSZK5ek_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-132 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-133 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/v4.html
- 行号: 2
- 证据: `src="/assets/v4-7WN9kuUV.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-134 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/v4.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-135 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/v4.html
- 行号: 4
- 证据: `href="/assets/surface-BSZK5ek_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-136 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/v4.html
- 行号: 5
- 证据: `href="/assets/collection-DnlLnS-N.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-137 固定资源/导航路径
- 文件: tmp/goal4-T03/runtime-build-12/v4.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-138 固定资源/导航路径
- 文件: tmp/previews/G4-T02-source-bound-recovery/index.html
- 行号: 2
- 证据: `src="/assets/main-CjWvlW6A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-139 固定资源/导航路径
- 文件: tmp/previews/G4-T02-source-bound-recovery/index.html
- 行号: 3
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-140 固定资源/导航路径
- 文件: tmp/previews/G4-T02-source-bound-recovery/index.html
- 行号: 4
- 证据: `href="/assets/surface-DGP_7YNM.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-141 固定资源/导航路径
- 文件: tmp/previews/G4-T02-source-bound-recovery/index.html
- 行号: 5
- 证据: `href="/assets/collection-DXo2JrVn.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-142 固定资源/导航路径
- 文件: tmp/previews/G4-T02-source-bound-recovery/index.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-143 固定资源/导航路径
- 文件: tmp/previews/G4-T02-source-bound-recovery/index.html
- 行号: 7
- 证据: `href="/assets/main-B_5dsepO.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-144 固定资源/导航路径
- 文件: tmp/previews/G4-T02-source-bound-recovery/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-145 固定资源/导航路径
- 文件: tmp/previews/G4-T02-source-bound-recovery/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-CIZ29FwY.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-146 固定资源/导航路径
- 文件: tmp/previews/G4-T02-source-bound-recovery/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-147 固定资源/导航路径
- 文件: tmp/previews/G4-T02-source-bound-recovery/legacy.html
- 行号: 4
- 证据: `href="/assets/input-DM7dAKr9.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-148 固定资源/导航路径
- 文件: tmp/previews/G4-T02-source-bound-recovery/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-149 固定资源/导航路径
- 文件: tmp/previews/G4-T02-source-bound-recovery/v2.html
- 行号: 3
- 证据: `src="/assets/v2-fAfB4s3Q.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-150 固定资源/导航路径
- 文件: tmp/previews/G4-T02-source-bound-recovery/v2.html
- 行号: 4
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-151 固定资源/导航路径
- 文件: tmp/previews/G4-T02-source-bound-recovery/v2.html
- 行号: 5
- 证据: `href="/assets/input-DM7dAKr9.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-152 固定资源/导航路径
- 文件: tmp/previews/G4-T02-source-bound-recovery/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-153 固定资源/导航路径
- 文件: tmp/previews/G4-T02-source-bound-recovery/v3.html
- 行号: 2
- 证据: `src="/assets/v3-BvaeENJ_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-154 固定资源/导航路径
- 文件: tmp/previews/G4-T02-source-bound-recovery/v3.html
- 行号: 3
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-155 固定资源/导航路径
- 文件: tmp/previews/G4-T02-source-bound-recovery/v3.html
- 行号: 4
- 证据: `href="/assets/surface-DGP_7YNM.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-156 固定资源/导航路径
- 文件: tmp/previews/G4-T02-source-bound-recovery/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-157 固定资源/导航路径
- 文件: tmp/previews/G4-T02-source-bound-recovery/v4.html
- 行号: 2
- 证据: `src="/assets/v4-0gzyf6sJ.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-158 固定资源/导航路径
- 文件: tmp/previews/G4-T02-source-bound-recovery/v4.html
- 行号: 3
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-159 固定资源/导航路径
- 文件: tmp/previews/G4-T02-source-bound-recovery/v4.html
- 行号: 4
- 证据: `href="/assets/surface-DGP_7YNM.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-160 固定资源/导航路径
- 文件: tmp/previews/G4-T02-source-bound-recovery/v4.html
- 行号: 5
- 证据: `href="/assets/collection-DXo2JrVn.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-161 固定资源/导航路径
- 文件: tmp/previews/G4-T02-source-bound-recovery/v4.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-162 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/index.html
- 行号: 2
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-163 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/index.html
- 行号: 2
- 证据: `src="/assets/main-Cmi36iYD.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-164 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/index.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-165 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/index.html
- 行号: 4
- 证据: `href="/assets/surface-BFcbf2qx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-166 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/index.html
- 行号: 5
- 证据: `href="/assets/collection-DZ4TYJzz.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-167 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/index.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-168 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/index.html
- 行号: 7
- 证据: `href="/assets/main-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-169 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-170 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-6a5ggSZZ.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-171 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-172 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/legacy.html
- 行号: 4
- 证据: `href="/assets/input-Csnfx8WT.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-173 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-174 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/v2.html
- 行号: 3
- 证据: `src="/assets/v2-BZXpUCsX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-175 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/v2.html
- 行号: 4
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-176 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/v2.html
- 行号: 5
- 证据: `href="/assets/input-Csnfx8WT.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-177 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-178 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/v3.html
- 行号: 2
- 证据: `src="/assets/v3-B2PPc-K8.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-179 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/v3.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-180 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/v3.html
- 行号: 4
- 证据: `href="/assets/surface-BFcbf2qx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-181 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-182 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/v4.html
- 行号: 2
- 证据: `src="/assets/v4-Bznm5Iki.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-183 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/v4.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-184 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/v4.html
- 行号: 4
- 证据: `href="/assets/surface-BFcbf2qx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-185 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/v4.html
- 行号: 5
- 证据: `href="/assets/collection-DZ4TYJzz.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-186 固定资源/导航路径
- 文件: tmp/previews/G4-T03-forge-menu/v4.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-187 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/index.html
- 行号: 2
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-188 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/index.html
- 行号: 2
- 证据: `src="/assets/main-DuyWMZKr.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-189 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/index.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-190 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/index.html
- 行号: 4
- 证据: `href="/assets/surface-BSZK5ek_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-191 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/index.html
- 行号: 5
- 证据: `href="/assets/collection-DnlLnS-N.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-192 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/index.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-193 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/index.html
- 行号: 7
- 证据: `href="/assets/main-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-194 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-195 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-6a5ggSZZ.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-196 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-197 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/legacy.html
- 行号: 4
- 证据: `href="/assets/input-Csnfx8WT.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-198 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-199 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/v2.html
- 行号: 3
- 证据: `src="/assets/v2-BZXpUCsX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-200 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/v2.html
- 行号: 4
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-201 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/v2.html
- 行号: 5
- 证据: `href="/assets/input-Csnfx8WT.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-202 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-203 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/v3.html
- 行号: 2
- 证据: `src="/assets/v3-Ckca042P.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-204 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/v3.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-205 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/v3.html
- 行号: 4
- 证据: `href="/assets/surface-BSZK5ek_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-206 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-207 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/v4.html
- 行号: 2
- 证据: `src="/assets/v4-7WN9kuUV.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-208 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/v4.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-209 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/v4.html
- 行号: 4
- 证据: `href="/assets/surface-BSZK5ek_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-210 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/v4.html
- 行号: 5
- 证据: `href="/assets/collection-DnlLnS-N.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-211 固定资源/导航路径
- 文件: tmp/previews/G4-T03-payment-clarity/v4.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-212 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/index.html
- 行号: 2
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-213 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/index.html
- 行号: 2
- 证据: `src="/assets/main-BXg3qz71.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-214 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/index.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-215 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/index.html
- 行号: 4
- 证据: `href="/assets/surface-BSZK5ek_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-216 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/index.html
- 行号: 5
- 证据: `href="/assets/collection-DnlLnS-N.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-217 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/index.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-218 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/index.html
- 行号: 7
- 证据: `href="/assets/main-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-219 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-220 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-6a5ggSZZ.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-221 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-222 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/legacy.html
- 行号: 4
- 证据: `href="/assets/input-Csnfx8WT.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-223 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-224 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/v2.html
- 行号: 3
- 证据: `src="/assets/v2-BZXpUCsX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-225 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/v2.html
- 行号: 4
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-226 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/v2.html
- 行号: 5
- 证据: `href="/assets/input-Csnfx8WT.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-227 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-228 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/v3.html
- 行号: 2
- 证据: `src="/assets/v3-Ckca042P.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-229 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/v3.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-230 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/v3.html
- 行号: 4
- 证据: `href="/assets/surface-BSZK5ek_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-231 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-232 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/v4.html
- 行号: 2
- 证据: `src="/assets/v4-7WN9kuUV.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-233 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/v4.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-234 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/v4.html
- 行号: 4
- 证据: `href="/assets/surface-BSZK5ek_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-235 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/v4.html
- 行号: 5
- 证据: `href="/assets/collection-DnlLnS-N.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-236 固定资源/导航路径
- 文件: tmp/previews/G4-T03-preview-retry/v4.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-237 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/index.html
- 行号: 2
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-238 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/index.html
- 行号: 2
- 证据: `src="/assets/main-Cf9lIxaT.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-239 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/index.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-240 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/index.html
- 行号: 4
- 证据: `href="/assets/surface-BFcbf2qx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-241 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/index.html
- 行号: 5
- 证据: `href="/assets/collection-bmZdep7C.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-242 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/index.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-243 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/index.html
- 行号: 7
- 证据: `href="/assets/main-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-244 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-245 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-6a5ggSZZ.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-246 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-247 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/legacy.html
- 行号: 4
- 证据: `href="/assets/input-Csnfx8WT.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-248 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-249 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/v2.html
- 行号: 3
- 证据: `src="/assets/v2-BZXpUCsX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-250 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/v2.html
- 行号: 4
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-251 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/v2.html
- 行号: 5
- 证据: `href="/assets/input-Csnfx8WT.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-252 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-253 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/v3.html
- 行号: 2
- 证据: `src="/assets/v3-B2PPc-K8.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-254 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/v3.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-255 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/v3.html
- 行号: 4
- 证据: `href="/assets/surface-BFcbf2qx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-256 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-257 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/v4.html
- 行号: 2
- 证据: `src="/assets/v4-CpSVM-H-.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-258 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/v4.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-259 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/v4.html
- 行号: 4
- 证据: `href="/assets/surface-BFcbf2qx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-260 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/v4.html
- 行号: 5
- 证据: `href="/assets/collection-bmZdep7C.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-261 固定资源/导航路径
- 文件: tmp/previews/G4-T04-workshop-copy-01/v4.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-262 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/classic.html
- 行号: 10
- 证据: `href="/assets/surface-BFcbf2qx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-263 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/classic.html
- 行号: 11
- 证据: `href="/assets/collection-bmZdep7C.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-264 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/classic.html
- 行号: 12
- 证据: `href="/assets/readability-CuxfK3ij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-265 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/classic.html
- 行号: 13
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-266 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/classic.html
- 行号: 14
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-267 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/classic.html
- 行号: 8
- 证据: `src="/assets/classic-DbRchElK.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-268 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/classic.html
- 行号: 9
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-269 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/forge.html
- 行号: 10
- 证据: `href="/assets/surface-BFcbf2qx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-270 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/forge.html
- 行号: 11
- 证据: `href="/assets/collection-bmZdep7C.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-271 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/forge.html
- 行号: 12
- 证据: `href="/assets/readability-CuxfK3ij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-272 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/forge.html
- 行号: 13
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-273 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/forge.html
- 行号: 14
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-274 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/forge.html
- 行号: 15
- 证据: `href="/assets/focus-CNLcds0P.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-275 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/forge.html
- 行号: 8
- 证据: `src="/assets/forge-CaBgqH9g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-276 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/forge.html
- 行号: 9
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-277 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/index.html
- 行号: 2
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-278 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/index.html
- 行号: 2
- 证据: `src="/assets/main-CaBgqH9g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-279 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/index.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-280 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/index.html
- 行号: 4
- 证据: `href="/assets/surface-BFcbf2qx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-281 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/index.html
- 行号: 5
- 证据: `href="/assets/collection-bmZdep7C.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-282 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/index.html
- 行号: 6
- 证据: `href="/assets/readability-CuxfK3ij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-283 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/index.html
- 行号: 7
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-284 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/index.html
- 行号: 8
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-285 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/index.html
- 行号: 9
- 证据: `href="/assets/focus-CNLcds0P.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-286 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-287 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-6a5ggSZZ.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-288 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-289 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/legacy.html
- 行号: 4
- 证据: `href="/assets/input-Csnfx8WT.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-290 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-291 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/v2.html
- 行号: 3
- 证据: `src="/assets/v2-BZXpUCsX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-292 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/v2.html
- 行号: 4
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-293 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/v2.html
- 行号: 5
- 证据: `href="/assets/input-Csnfx8WT.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-294 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-295 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/v3.html
- 行号: 2
- 证据: `src="/assets/v3-B2PPc-K8.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-296 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/v3.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-297 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/v3.html
- 行号: 4
- 证据: `href="/assets/surface-BFcbf2qx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-298 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-299 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/v4.html
- 行号: 2
- 证据: `src="/assets/v4-CpSVM-H-.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-300 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/v4.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-301 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/v4.html
- 行号: 4
- 证据: `href="/assets/surface-BFcbf2qx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-302 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/v4.html
- 行号: 5
- 证据: `href="/assets/collection-bmZdep7C.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-303 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-01/v4.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-304 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/classic.html
- 行号: 10
- 证据: `href="/assets/surface-BFcbf2qx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-305 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/classic.html
- 行号: 11
- 证据: `href="/assets/collection-bmZdep7C.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-306 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/classic.html
- 行号: 12
- 证据: `href="/assets/readability-B7mBDtkU.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-307 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/classic.html
- 行号: 13
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-308 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/classic.html
- 行号: 14
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-309 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/classic.html
- 行号: 8
- 证据: `src="/assets/classic-BxGVYVzL.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-310 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/classic.html
- 行号: 9
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-311 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/forge.html
- 行号: 10
- 证据: `href="/assets/surface-BFcbf2qx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-312 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/forge.html
- 行号: 11
- 证据: `href="/assets/collection-bmZdep7C.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-313 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/forge.html
- 行号: 12
- 证据: `href="/assets/readability-B7mBDtkU.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-314 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/forge.html
- 行号: 13
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-315 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/forge.html
- 行号: 14
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-316 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/forge.html
- 行号: 15
- 证据: `href="/assets/focus-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-317 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/forge.html
- 行号: 8
- 证据: `src="/assets/forge-BtdGobtp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-318 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/forge.html
- 行号: 9
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-319 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/index.html
- 行号: 2
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-320 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/index.html
- 行号: 2
- 证据: `src="/assets/main-BtdGobtp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-321 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/index.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-322 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/index.html
- 行号: 4
- 证据: `href="/assets/surface-BFcbf2qx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-323 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/index.html
- 行号: 5
- 证据: `href="/assets/collection-bmZdep7C.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-324 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/index.html
- 行号: 6
- 证据: `href="/assets/readability-B7mBDtkU.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-325 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/index.html
- 行号: 7
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-326 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/index.html
- 行号: 8
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-327 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/index.html
- 行号: 9
- 证据: `href="/assets/focus-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-328 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-329 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-6a5ggSZZ.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-330 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-331 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/legacy.html
- 行号: 4
- 证据: `href="/assets/input-Csnfx8WT.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-332 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-333 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/v2.html
- 行号: 3
- 证据: `src="/assets/v2-BZXpUCsX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-334 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/v2.html
- 行号: 4
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-335 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/v2.html
- 行号: 5
- 证据: `href="/assets/input-Csnfx8WT.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-336 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-337 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/v3.html
- 行号: 2
- 证据: `src="/assets/v3-B2PPc-K8.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-338 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/v3.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-339 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/v3.html
- 行号: 4
- 证据: `href="/assets/surface-BFcbf2qx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-340 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-341 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/v4.html
- 行号: 2
- 证据: `src="/assets/v4-CpSVM-H-.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-342 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/v4.html
- 行号: 3
- 证据: `href="/assets/dom-_Gj4zwRX.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-343 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/v4.html
- 行号: 4
- 证据: `href="/assets/surface-BFcbf2qx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-344 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/v4.html
- 行号: 5
- 证据: `href="/assets/collection-bmZdep7C.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-345 固定资源/导航路径
- 文件: tmp/previews/research-reboot-focus-02/v4.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-346 固定资源/导航路径
- 文件: tmp/previews/T08/index.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-347 固定资源/导航路径
- 文件: tmp/previews/T08/index.html
- 行号: 2
- 证据: `src="/assets/index-DwJG9aNG.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-348 固定资源/导航路径
- 文件: tmp/previews/T08/index.html
- 行号: 3
- 证据: `href="/assets/index-BLSvxncn.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-349 固定资源/导航路径
- 文件: tmp/previews/T09/index.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-350 固定资源/导航路径
- 文件: tmp/previews/T09/index.html
- 行号: 2
- 证据: `src="/assets/index-L7WF6Rcj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-351 固定资源/导航路径
- 文件: tmp/previews/T09/index.html
- 行号: 3
- 证据: `href="/assets/index-BGeMibVx.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-352 固定资源/导航路径
- 文件: tmp/previews/T10/index.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-353 固定资源/导航路径
- 文件: tmp/previews/T10/index.html
- 行号: 2
- 证据: `src="/assets/index-BORxRfY3.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-354 固定资源/导航路径
- 文件: tmp/previews/T10/index.html
- 行号: 3
- 证据: `href="/assets/index-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-355 固定资源/导航路径
- 文件: tmp/previews/T11-2/index.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-356 固定资源/导航路径
- 文件: tmp/previews/T11-2/index.html
- 行号: 2
- 证据: `src="/assets/main-BQF3T5vu.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-357 固定资源/导航路径
- 文件: tmp/previews/T11-2/index.html
- 行号: 3
- 证据: `href="/assets/audio-CeHMkvEG.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-358 固定资源/导航路径
- 文件: tmp/previews/T11-2/index.html
- 行号: 4
- 证据: `href="/assets/main-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-359 固定资源/导航路径
- 文件: tmp/previews/T11-2/v2.html
- 行号: 3
- 证据: `src="/assets/v2-EC09nu3z.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-360 固定资源/导航路径
- 文件: tmp/previews/T11-2/v2.html
- 行号: 4
- 证据: `href="/assets/audio-CeHMkvEG.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-361 固定资源/导航路径
- 文件: tmp/previews/T11-2/v2.html
- 行号: 5
- 证据: `href="/assets/v2-2cDV1PA4.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-362 固定资源/导航路径
- 文件: tmp/previews/T11-3-polish/index.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-363 固定资源/导航路径
- 文件: tmp/previews/T11-3-polish/index.html
- 行号: 2
- 证据: `src="/assets/main-BQF3T5vu.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-364 固定资源/导航路径
- 文件: tmp/previews/T11-3-polish/index.html
- 行号: 3
- 证据: `href="/assets/audio-CeHMkvEG.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-365 固定资源/导航路径
- 文件: tmp/previews/T11-3-polish/index.html
- 行号: 4
- 证据: `href="/assets/main-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-366 固定资源/导航路径
- 文件: tmp/previews/T11-3-polish/v2.html
- 行号: 3
- 证据: `src="/assets/v2-DWDPkjht.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-367 固定资源/导航路径
- 文件: tmp/previews/T11-3-polish/v2.html
- 行号: 4
- 证据: `href="/assets/audio-CeHMkvEG.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-368 固定资源/导航路径
- 文件: tmp/previews/T11-3-polish/v2.html
- 行号: 5
- 证据: `href="/assets/v2-b6VEIRKK.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-369 固定资源/导航路径
- 文件: tmp/previews/T11-3/index.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-370 固定资源/导航路径
- 文件: tmp/previews/T11-3/index.html
- 行号: 2
- 证据: `src="/assets/main-BQF3T5vu.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-371 固定资源/导航路径
- 文件: tmp/previews/T11-3/index.html
- 行号: 3
- 证据: `href="/assets/audio-CeHMkvEG.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-372 固定资源/导航路径
- 文件: tmp/previews/T11-3/index.html
- 行号: 4
- 证据: `href="/assets/main-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-373 固定资源/导航路径
- 文件: tmp/previews/T11-3/v2.html
- 行号: 3
- 证据: `src="/assets/v2-DDYB9JKw.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-374 固定资源/导航路径
- 文件: tmp/previews/T11-3/v2.html
- 行号: 4
- 证据: `href="/assets/audio-CeHMkvEG.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-375 固定资源/导航路径
- 文件: tmp/previews/T11-3/v2.html
- 行号: 5
- 证据: `href="/assets/v2-BRDq1mDn.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-376 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-2/index.html
- 行号: 2
- 证据: `src="/assets/main-DbR1Ds6c.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-377 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-2/index.html
- 行号: 3
- 证据: `href="/assets/dom-Cbs79pC-.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-378 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-2/index.html
- 行号: 4
- 证据: `href="/assets/art-BK57VRqI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-379 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-2/index.html
- 行号: 5
- 证据: `href="/assets/main-Cr6cmaLf.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-380 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-2/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-381 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-2/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-2ySDNTOq.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-382 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-2/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-Cbs79pC-.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-383 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-2/legacy.html
- 行号: 4
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-384 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-2/v2.html
- 行号: 3
- 证据: `src="/assets/v2-C6vIWVOs.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-385 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-2/v2.html
- 行号: 4
- 证据: `href="/assets/dom-Cbs79pC-.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-386 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-2/v2.html
- 行号: 5
- 证据: `href="/assets/art-BK57VRqI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-387 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-2/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-388 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3a/index.html
- 行号: 2
- 证据: `src="/assets/main-CEzTtrbp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-389 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3a/index.html
- 行号: 3
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-390 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3a/index.html
- 行号: 4
- 证据: `href="/assets/art-Cf0ANkZG.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-391 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3a/index.html
- 行号: 5
- 证据: `href="/assets/main-BSCjiYZ_.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-392 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3a/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-393 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3a/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-vxglO3Lj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-394 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3a/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-395 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3a/legacy.html
- 行号: 4
- 证据: `href="/assets/input-T5-CCuNi.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-396 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3a/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-397 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3a/v2.html
- 行号: 3
- 证据: `src="/assets/v2-mWkibaeD.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-398 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3a/v2.html
- 行号: 4
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-399 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3a/v2.html
- 行号: 5
- 证据: `href="/assets/art-Cf0ANkZG.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-400 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3a/v2.html
- 行号: 6
- 证据: `href="/assets/input-T5-CCuNi.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-401 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3a/v2.html
- 行号: 7
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-402 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3b/index.html
- 行号: 2
- 证据: `src="/assets/main-CGBfDS9g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-403 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3b/index.html
- 行号: 3
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-404 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3b/index.html
- 行号: 4
- 证据: `href="/assets/main-DG9B73gN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-405 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3b/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-406 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3b/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-vxglO3Lj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-407 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3b/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-408 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3b/legacy.html
- 行号: 4
- 证据: `href="/assets/input-T5-CCuNi.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-409 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3b/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-410 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3b/v2.html
- 行号: 3
- 证据: `src="/assets/v2-CeYahdmB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-411 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3b/v2.html
- 行号: 4
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-412 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3b/v2.html
- 行号: 5
- 证据: `href="/assets/input-T5-CCuNi.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-413 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3b/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-414 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3c/index.html
- 行号: 2
- 证据: `src="/assets/main-BYG9nf_v.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-415 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3c/index.html
- 行号: 3
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-416 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3c/index.html
- 行号: 4
- 证据: `href="/assets/main-9MXydj35.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-417 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3c/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-418 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3c/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-vxglO3Lj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-419 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3c/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-420 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3c/legacy.html
- 行号: 4
- 证据: `href="/assets/input-T5-CCuNi.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-421 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3c/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-422 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3c/v2.html
- 行号: 3
- 证据: `src="/assets/v2-CeYahdmB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-423 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3c/v2.html
- 行号: 4
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-424 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3c/v2.html
- 行号: 5
- 证据: `href="/assets/input-T5-CCuNi.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-425 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3c/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-426 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3d/index.html
- 行号: 2
- 证据: `src="/assets/main-BijqOCzD.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-427 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3d/index.html
- 行号: 3
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-428 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3d/index.html
- 行号: 4
- 证据: `href="/assets/main-jc7CGFQS.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-429 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3d/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-430 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3d/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-vxglO3Lj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-431 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3d/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-432 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3d/legacy.html
- 行号: 4
- 证据: `href="/assets/input-T5-CCuNi.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-433 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3d/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-434 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3d/v2.html
- 行号: 3
- 证据: `src="/assets/v2-CeYahdmB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-435 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3d/v2.html
- 行号: 4
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-436 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3d/v2.html
- 行号: 5
- 证据: `href="/assets/input-T5-CCuNi.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-437 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3d/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-438 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3e/index.html
- 行号: 2
- 证据: `src="/assets/main-C_iDzeen.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-439 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3e/index.html
- 行号: 3
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-440 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3e/index.html
- 行号: 4
- 证据: `href="/assets/main-BRoht38P.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-441 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3e/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-442 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3e/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-vxglO3Lj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-443 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3e/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-444 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3e/legacy.html
- 行号: 4
- 证据: `href="/assets/input-T5-CCuNi.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-445 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3e/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-446 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3e/v2.html
- 行号: 3
- 证据: `src="/assets/v2-CeYahdmB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-447 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3e/v2.html
- 行号: 4
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-448 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3e/v2.html
- 行号: 5
- 证据: `href="/assets/input-T5-CCuNi.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-449 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3e/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-450 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3g-polish/index.html
- 行号: 2
- 证据: `src="/assets/main-C_CM7SIJ.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-451 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3g-polish/index.html
- 行号: 3
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-452 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3g-polish/index.html
- 行号: 4
- 证据: `href="/assets/main-N6f7wDRQ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-453 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3g-polish/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-454 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3g-polish/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-vxglO3Lj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-455 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3g-polish/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-456 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3g-polish/legacy.html
- 行号: 4
- 证据: `href="/assets/input-T5-CCuNi.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-457 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3g-polish/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-458 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3g-polish/v2.html
- 行号: 3
- 证据: `src="/assets/v2-CeYahdmB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-459 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3g-polish/v2.html
- 行号: 4
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-460 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3g-polish/v2.html
- 行号: 5
- 证据: `href="/assets/input-T5-CCuNi.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-461 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3g-polish/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-462 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3g/index.html
- 行号: 2
- 证据: `src="/assets/main-CA64OPNQ.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-463 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3g/index.html
- 行号: 3
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-464 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3g/index.html
- 行号: 4
- 证据: `href="/assets/main-D9ZvR9wR.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-465 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3g/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-466 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3g/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-vxglO3Lj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-467 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3g/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-468 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3g/legacy.html
- 行号: 4
- 证据: `href="/assets/input-T5-CCuNi.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-469 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3g/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-470 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3g/v2.html
- 行号: 3
- 证据: `src="/assets/v2-CeYahdmB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-471 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3g/v2.html
- 行号: 4
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-472 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3g/v2.html
- 行号: 5
- 证据: `href="/assets/input-T5-CCuNi.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-473 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3g/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-474 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h-coverage/index.html
- 行号: 2
- 证据: `src="/assets/main-A-s3zMHd.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-475 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h-coverage/index.html
- 行号: 3
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-476 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h-coverage/index.html
- 行号: 4
- 证据: `href="/assets/main-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-477 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h-coverage/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-478 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h-coverage/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-vxglO3Lj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-479 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h-coverage/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-480 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h-coverage/legacy.html
- 行号: 4
- 证据: `href="/assets/input-T5-CCuNi.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-481 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h-coverage/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-482 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h-coverage/v2.html
- 行号: 3
- 证据: `src="/assets/v2-CeYahdmB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-483 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h-coverage/v2.html
- 行号: 4
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-484 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h-coverage/v2.html
- 行号: 5
- 证据: `href="/assets/input-T5-CCuNi.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-485 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h-coverage/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-486 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h-events/index.html
- 行号: 2
- 证据: `src="/assets/main-0s0qV7Qa.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-487 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h-events/index.html
- 行号: 3
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-488 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h-events/index.html
- 行号: 4
- 证据: `href="/assets/main-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-489 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h-events/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-490 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h-events/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-vxglO3Lj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-491 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h-events/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-492 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h-events/legacy.html
- 行号: 4
- 证据: `href="/assets/input-T5-CCuNi.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-493 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h-events/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-494 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h-events/v2.html
- 行号: 3
- 证据: `src="/assets/v2-CeYahdmB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-495 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h-events/v2.html
- 行号: 4
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-496 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h-events/v2.html
- 行号: 5
- 证据: `href="/assets/input-T5-CCuNi.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-497 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h-events/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-498 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h/index.html
- 行号: 2
- 证据: `src="/assets/main-B5uu7mba.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-499 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h/index.html
- 行号: 3
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-500 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h/index.html
- 行号: 4
- 证据: `href="/assets/main-Ds3YpmeB.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-501 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-502 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-vxglO3Lj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-503 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-504 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h/legacy.html
- 行号: 4
- 证据: `href="/assets/input-T5-CCuNi.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-505 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-506 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h/v2.html
- 行号: 3
- 证据: `src="/assets/v2-CeYahdmB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-507 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h/v2.html
- 行号: 4
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-508 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h/v2.html
- 行号: 5
- 证据: `href="/assets/input-T5-CCuNi.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-509 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3h/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-510 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-45/index.html
- 行号: 2
- 证据: `src="/assets/main-BaOsMR8b.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-511 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-45/index.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-512 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-45/index.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-513 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-45/index.html
- 行号: 5
- 证据: `href="/assets/main-CLq27GlC.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-514 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-45/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-515 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-45/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-BEbDMbhp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-516 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-45/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-517 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-45/legacy.html
- 行号: 4
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-518 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-45/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-519 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-45/v2.html
- 行号: 3
- 证据: `src="/assets/v2-DiTiUVti.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-520 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-45/v2.html
- 行号: 4
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-521 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-45/v2.html
- 行号: 5
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-522 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-45/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-523 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-45/v3.html
- 行号: 2
- 证据: `src="/assets/v3-DOzLDQhh.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-524 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-45/v3.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-525 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-45/v3.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-526 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-45/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-527 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-first-chapter/index.html
- 行号: 2
- 证据: `src="/assets/main-C_KOA56w.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-528 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-first-chapter/index.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-529 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-first-chapter/index.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-530 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-first-chapter/index.html
- 行号: 5
- 证据: `href="/assets/main-CLq27GlC.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-531 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-first-chapter/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-532 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-first-chapter/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-BEbDMbhp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-533 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-first-chapter/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-534 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-first-chapter/legacy.html
- 行号: 4
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-535 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-first-chapter/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-536 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-first-chapter/v2.html
- 行号: 3
- 证据: `src="/assets/v2-DiTiUVti.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-537 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-first-chapter/v2.html
- 行号: 4
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-538 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-first-chapter/v2.html
- 行号: 5
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-539 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-first-chapter/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-540 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-first-chapter/v3.html
- 行号: 2
- 证据: `src="/assets/v3-DOzLDQhh.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-541 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-first-chapter/v3.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-542 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-first-chapter/v3.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-543 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i3-first-chapter/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-544 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i4-second-chapter/index.html
- 行号: 2
- 证据: `src="/assets/main-DuS8s25z.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-545 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i4-second-chapter/index.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-546 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i4-second-chapter/index.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-547 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i4-second-chapter/index.html
- 行号: 5
- 证据: `href="/assets/main-8l9Mvho7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-548 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i4-second-chapter/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-549 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i4-second-chapter/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-BEbDMbhp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-550 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i4-second-chapter/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-551 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i4-second-chapter/legacy.html
- 行号: 4
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-552 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i4-second-chapter/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-553 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i4-second-chapter/v2.html
- 行号: 3
- 证据: `src="/assets/v2-DiTiUVti.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-554 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i4-second-chapter/v2.html
- 行号: 4
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-555 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i4-second-chapter/v2.html
- 行号: 5
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-556 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i4-second-chapter/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-557 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i4-second-chapter/v3.html
- 行号: 2
- 证据: `src="/assets/v3-DOzLDQhh.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-558 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i4-second-chapter/v3.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-559 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i4-second-chapter/v3.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-560 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i4-second-chapter/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-561 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i5-mountain-pass/index.html
- 行号: 2
- 证据: `src="/assets/main-DYDg36dL.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-562 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i5-mountain-pass/index.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-563 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i5-mountain-pass/index.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-564 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i5-mountain-pass/index.html
- 行号: 5
- 证据: `href="/assets/main-Cs7wa2SA.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-565 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i5-mountain-pass/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-566 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i5-mountain-pass/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-BEbDMbhp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-567 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i5-mountain-pass/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-568 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i5-mountain-pass/legacy.html
- 行号: 4
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-569 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i5-mountain-pass/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-570 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i5-mountain-pass/v2.html
- 行号: 3
- 证据: `src="/assets/v2-DiTiUVti.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-571 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i5-mountain-pass/v2.html
- 行号: 4
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-572 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i5-mountain-pass/v2.html
- 行号: 5
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-573 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i5-mountain-pass/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-574 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i5-mountain-pass/v3.html
- 行号: 2
- 证据: `src="/assets/v3-DOzLDQhh.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-575 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i5-mountain-pass/v3.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-576 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i5-mountain-pass/v3.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-577 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i5-mountain-pass/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-578 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i6-guidance/index.html
- 行号: 2
- 证据: `src="/assets/main-DhAm8t4z.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-579 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i6-guidance/index.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-580 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i6-guidance/index.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-581 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i6-guidance/index.html
- 行号: 5
- 证据: `href="/assets/main-Cs7wa2SA.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-582 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i6-guidance/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-583 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i6-guidance/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-BEbDMbhp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-584 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i6-guidance/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-585 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i6-guidance/legacy.html
- 行号: 4
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-586 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i6-guidance/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-587 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i6-guidance/v2.html
- 行号: 3
- 证据: `src="/assets/v2-DiTiUVti.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-588 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i6-guidance/v2.html
- 行号: 4
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-589 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i6-guidance/v2.html
- 行号: 5
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-590 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i6-guidance/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-591 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i6-guidance/v3.html
- 行号: 2
- 证据: `src="/assets/v3-DOzLDQhh.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-592 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i6-guidance/v3.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-593 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i6-guidance/v3.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-594 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3i6-guidance/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-595 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3j-handoff/index.html
- 行号: 2
- 证据: `src="/assets/main-D2Bq3urG.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-596 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3j-handoff/index.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-597 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3j-handoff/index.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-598 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3j-handoff/index.html
- 行号: 5
- 证据: `href="/assets/main-BJaybto7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-599 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3j-handoff/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-600 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3j-handoff/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-BEbDMbhp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-601 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3j-handoff/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-602 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3j-handoff/legacy.html
- 行号: 4
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-603 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3j-handoff/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-604 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3j-handoff/v2.html
- 行号: 3
- 证据: `src="/assets/v2-DiTiUVti.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-605 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3j-handoff/v2.html
- 行号: 4
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-606 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3j-handoff/v2.html
- 行号: 5
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-607 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3j-handoff/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-608 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3j-handoff/v3.html
- 行号: 2
- 证据: `src="/assets/v3-DOzLDQhh.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-609 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3j-handoff/v3.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-610 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3j-handoff/v3.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-611 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3j-handoff/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-612 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3k-formed/index.html
- 行号: 2
- 证据: `src="/assets/main-DB9Q0RJ4.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-613 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3k-formed/index.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-614 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3k-formed/index.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-615 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3k-formed/index.html
- 行号: 5
- 证据: `href="/assets/main-DCyufW24.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-616 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3k-formed/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-617 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3k-formed/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-BEbDMbhp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-618 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3k-formed/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-619 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3k-formed/legacy.html
- 行号: 4
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-620 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3k-formed/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-621 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3k-formed/v2.html
- 行号: 3
- 证据: `src="/assets/v2-DiTiUVti.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-622 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3k-formed/v2.html
- 行号: 4
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-623 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3k-formed/v2.html
- 行号: 5
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-624 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3k-formed/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-625 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3k-formed/v3.html
- 行号: 2
- 证据: `src="/assets/v3-DOzLDQhh.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-626 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3k-formed/v3.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-627 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3k-formed/v3.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-628 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3k-formed/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-629 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l3-v08-first-chapter/index.html
- 行号: 2
- 证据: `src="/assets/main-CPxlE0a0.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-630 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l3-v08-first-chapter/index.html
- 行号: 3
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-631 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l3-v08-first-chapter/index.html
- 行号: 4
- 证据: `href="/assets/surface-DGP_7YNM.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-632 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l3-v08-first-chapter/index.html
- 行号: 5
- 证据: `href="/assets/collection-DXo2JrVn.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-633 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l3-v08-first-chapter/index.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-634 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l3-v08-first-chapter/index.html
- 行号: 7
- 证据: `href="/assets/main-Ckv4V4w-.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-635 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l3-v08-first-chapter/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-636 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l3-v08-first-chapter/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-CIZ29FwY.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-637 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l3-v08-first-chapter/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-638 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l3-v08-first-chapter/legacy.html
- 行号: 4
- 证据: `href="/assets/input-DM7dAKr9.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-639 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l3-v08-first-chapter/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-640 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l3-v08-first-chapter/v2.html
- 行号: 3
- 证据: `src="/assets/v2-fAfB4s3Q.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-641 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l3-v08-first-chapter/v2.html
- 行号: 4
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-642 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l3-v08-first-chapter/v2.html
- 行号: 5
- 证据: `href="/assets/input-DM7dAKr9.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-643 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l3-v08-first-chapter/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-644 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l3-v08-first-chapter/v3.html
- 行号: 2
- 证据: `src="/assets/v3-BvaeENJ_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-645 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l3-v08-first-chapter/v3.html
- 行号: 3
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-646 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l3-v08-first-chapter/v3.html
- 行号: 4
- 证据: `href="/assets/surface-DGP_7YNM.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-647 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l3-v08-first-chapter/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-648 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l3-v08-first-chapter/v4.html
- 行号: 2
- 证据: `src="/assets/v4-0gzyf6sJ.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-649 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l3-v08-first-chapter/v4.html
- 行号: 3
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-650 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l3-v08-first-chapter/v4.html
- 行号: 4
- 证据: `href="/assets/surface-DGP_7YNM.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-651 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l3-v08-first-chapter/v4.html
- 行号: 5
- 证据: `href="/assets/collection-DXo2JrVn.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-652 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l3-v08-first-chapter/v4.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-653 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l4-v08-twelve-lights/index.html
- 行号: 2
- 证据: `src="/assets/main-BCsDbsVf.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-654 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l4-v08-twelve-lights/index.html
- 行号: 3
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-655 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l4-v08-twelve-lights/index.html
- 行号: 4
- 证据: `href="/assets/surface-DGP_7YNM.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-656 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l4-v08-twelve-lights/index.html
- 行号: 5
- 证据: `href="/assets/collection-DXo2JrVn.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-657 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l4-v08-twelve-lights/index.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-658 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l4-v08-twelve-lights/index.html
- 行号: 7
- 证据: `href="/assets/main-C4HY7atu.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-659 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l4-v08-twelve-lights/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-660 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l4-v08-twelve-lights/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-CIZ29FwY.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-661 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l4-v08-twelve-lights/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-662 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l4-v08-twelve-lights/legacy.html
- 行号: 4
- 证据: `href="/assets/input-DM7dAKr9.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-663 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l4-v08-twelve-lights/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-664 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l4-v08-twelve-lights/v2.html
- 行号: 3
- 证据: `src="/assets/v2-fAfB4s3Q.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-665 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l4-v08-twelve-lights/v2.html
- 行号: 4
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-666 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l4-v08-twelve-lights/v2.html
- 行号: 5
- 证据: `href="/assets/input-DM7dAKr9.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-667 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l4-v08-twelve-lights/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-668 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l4-v08-twelve-lights/v3.html
- 行号: 2
- 证据: `src="/assets/v3-BvaeENJ_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-669 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l4-v08-twelve-lights/v3.html
- 行号: 3
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-670 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l4-v08-twelve-lights/v3.html
- 行号: 4
- 证据: `href="/assets/surface-DGP_7YNM.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-671 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l4-v08-twelve-lights/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-672 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l4-v08-twelve-lights/v4.html
- 行号: 2
- 证据: `src="/assets/v4-0gzyf6sJ.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-673 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l4-v08-twelve-lights/v4.html
- 行号: 3
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-674 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l4-v08-twelve-lights/v4.html
- 行号: 4
- 证据: `href="/assets/surface-DGP_7YNM.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-675 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l4-v08-twelve-lights/v4.html
- 行号: 5
- 证据: `href="/assets/collection-DXo2JrVn.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-676 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l4-v08-twelve-lights/v4.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-677 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l5-v08-trading/index.html
- 行号: 2
- 证据: `src="/assets/main-YRNJhQ5N.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-678 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l5-v08-trading/index.html
- 行号: 3
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-679 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l5-v08-trading/index.html
- 行号: 4
- 证据: `href="/assets/surface-DGP_7YNM.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-680 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l5-v08-trading/index.html
- 行号: 5
- 证据: `href="/assets/collection-DXo2JrVn.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-681 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l5-v08-trading/index.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-682 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l5-v08-trading/index.html
- 行号: 7
- 证据: `href="/assets/main-B_5dsepO.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-683 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l5-v08-trading/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-684 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l5-v08-trading/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-CIZ29FwY.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-685 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l5-v08-trading/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-686 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l5-v08-trading/legacy.html
- 行号: 4
- 证据: `href="/assets/input-DM7dAKr9.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-687 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l5-v08-trading/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-688 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l5-v08-trading/v2.html
- 行号: 3
- 证据: `src="/assets/v2-fAfB4s3Q.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-689 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l5-v08-trading/v2.html
- 行号: 4
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-690 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l5-v08-trading/v2.html
- 行号: 5
- 证据: `href="/assets/input-DM7dAKr9.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-691 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l5-v08-trading/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-692 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l5-v08-trading/v3.html
- 行号: 2
- 证据: `src="/assets/v3-BvaeENJ_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-693 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l5-v08-trading/v3.html
- 行号: 3
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-694 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l5-v08-trading/v3.html
- 行号: 4
- 证据: `href="/assets/surface-DGP_7YNM.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-695 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l5-v08-trading/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-696 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l5-v08-trading/v4.html
- 行号: 2
- 证据: `src="/assets/v4-0gzyf6sJ.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-697 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l5-v08-trading/v4.html
- 行号: 3
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-698 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l5-v08-trading/v4.html
- 行号: 4
- 证据: `href="/assets/surface-DGP_7YNM.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-699 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l5-v08-trading/v4.html
- 行号: 5
- 证据: `href="/assets/collection-DXo2JrVn.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-700 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3l5-v08-trading/v4.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-701 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders-complete/index.html
- 行号: 2
- 证据: `src="/assets/main-CzfxupWP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-702 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders-complete/index.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-703 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders-complete/index.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-704 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders-complete/index.html
- 行号: 5
- 证据: `href="/assets/main-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-705 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders-complete/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-706 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders-complete/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-BEbDMbhp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-707 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders-complete/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-708 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders-complete/legacy.html
- 行号: 4
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-709 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders-complete/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-710 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders-complete/v2.html
- 行号: 3
- 证据: `src="/assets/v2-DiTiUVti.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-711 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders-complete/v2.html
- 行号: 4
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-712 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders-complete/v2.html
- 行号: 5
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-713 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders-complete/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-714 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders-complete/v3.html
- 行号: 2
- 证据: `src="/assets/v3-DOzLDQhh.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-715 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders-complete/v3.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-716 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders-complete/v3.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-717 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders-complete/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-718 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders/index.html
- 行号: 2
- 证据: `src="/assets/main-BItZi8fg.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-719 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders/index.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-720 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders/index.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-721 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders/index.html
- 行号: 5
- 证据: `href="/assets/main-DvXuygGF.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-722 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-723 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-BEbDMbhp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-724 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-725 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders/legacy.html
- 行号: 4
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-726 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-727 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders/v2.html
- 行号: 3
- 证据: `src="/assets/v2-DiTiUVti.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-728 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders/v2.html
- 行号: 4
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-729 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders/v2.html
- 行号: 5
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-730 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-731 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders/v3.html
- 行号: 2
- 证据: `src="/assets/v3-DOzLDQhh.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-732 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders/v3.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-733 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders/v3.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-734 固定资源/导航路径
- 文件: tmp/previews/T11-4-2-3m-orders/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-735 固定资源/导航路径
- 文件: tmp/previews/T11-4-2/index.html
- 行号: 2
- 证据: `src="/assets/dom-Cbs79pC-.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-736 固定资源/导航路径
- 文件: tmp/previews/T11-4-2/index.html
- 行号: 3
- 证据: `src="/assets/v2-main-Bv_W7lw0.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-737 固定资源/导航路径
- 文件: tmp/previews/T11-4-2/index.html
- 行号: 4
- 证据: `href="/assets/v2-main-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-738 固定资源/导航路径
- 文件: tmp/previews/T11-4-2/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-739 固定资源/导航路径
- 文件: tmp/previews/T11-4-2/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-2ySDNTOq.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-740 固定资源/导航路径
- 文件: tmp/previews/T11-4-2/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-Cbs79pC-.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-741 固定资源/导航路径
- 文件: tmp/previews/T11-4-2/legacy.html
- 行号: 4
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-742 固定资源/导航路径
- 文件: tmp/previews/T11-4-2/v2.html
- 行号: 3
- 证据: `src="/assets/dom-Cbs79pC-.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-743 固定资源/导航路径
- 文件: tmp/previews/T11-4-2/v2.html
- 行号: 4
- 证据: `src="/assets/v2-main-Bv_W7lw0.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-744 固定资源/导航路径
- 文件: tmp/previews/T11-4-2/v2.html
- 行号: 5
- 证据: `href="/assets/v2-main-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-745 固定资源/导航路径
- 文件: tmp/previews/T11-4/index.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-746 固定资源/导航路径
- 文件: tmp/previews/T11-4/index.html
- 行号: 2
- 证据: `src="/assets/main-BQF3T5vu.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-747 固定资源/导航路径
- 文件: tmp/previews/T11-4/index.html
- 行号: 3
- 证据: `href="/assets/audio-CeHMkvEG.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-748 固定资源/导航路径
- 文件: tmp/previews/T11-4/index.html
- 行号: 4
- 证据: `href="/assets/main-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-749 固定资源/导航路径
- 文件: tmp/previews/T11-4/v2.html
- 行号: 3
- 证据: `src="/assets/v2-DackGAlI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-750 固定资源/导航路径
- 文件: tmp/previews/T11-4/v2.html
- 行号: 4
- 证据: `href="/assets/audio-CeHMkvEG.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-751 固定资源/导航路径
- 文件: tmp/previews/T11-4/v2.html
- 行号: 5
- 证据: `href="/assets/v2-BrL_rNsN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-752 固定资源/导航路径
- 文件: tmp/previews/T12-recovery/index.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-753 固定资源/导航路径
- 文件: tmp/previews/T12-recovery/index.html
- 行号: 2
- 证据: `src="/assets/main-BQF3T5vu.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-754 固定资源/导航路径
- 文件: tmp/previews/T12-recovery/index.html
- 行号: 3
- 证据: `href="/assets/audio-CeHMkvEG.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-755 固定资源/导航路径
- 文件: tmp/previews/T12-recovery/index.html
- 行号: 4
- 证据: `href="/assets/main-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-756 固定资源/导航路径
- 文件: tmp/previews/T12-recovery/v2.html
- 行号: 3
- 证据: `src="/assets/v2-CMdU4yiC.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-757 固定资源/导航路径
- 文件: tmp/previews/T12-recovery/v2.html
- 行号: 4
- 证据: `href="/assets/audio-CeHMkvEG.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-758 固定资源/导航路径
- 文件: tmp/previews/T12-recovery/v2.html
- 行号: 5
- 证据: `href="/assets/v2-BrL_rNsN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-759 固定资源/导航路径
- 文件: tmp/previews/T12-v5-original-export/index.html
- 行号: 2
- 证据: `src="/assets/main-4ZGtq3MT.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-760 固定资源/导航路径
- 文件: tmp/previews/T12-v5-original-export/index.html
- 行号: 3
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-761 固定资源/导航路径
- 文件: tmp/previews/T12-v5-original-export/index.html
- 行号: 4
- 证据: `href="/assets/surface-DGP_7YNM.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-762 固定资源/导航路径
- 文件: tmp/previews/T12-v5-original-export/index.html
- 行号: 5
- 证据: `href="/assets/collection-DXo2JrVn.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-763 固定资源/导航路径
- 文件: tmp/previews/T12-v5-original-export/index.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-764 固定资源/导航路径
- 文件: tmp/previews/T12-v5-original-export/index.html
- 行号: 7
- 证据: `href="/assets/main-B_5dsepO.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-765 固定资源/导航路径
- 文件: tmp/previews/T12-v5-original-export/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-766 固定资源/导航路径
- 文件: tmp/previews/T12-v5-original-export/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-CIZ29FwY.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-767 固定资源/导航路径
- 文件: tmp/previews/T12-v5-original-export/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-768 固定资源/导航路径
- 文件: tmp/previews/T12-v5-original-export/legacy.html
- 行号: 4
- 证据: `href="/assets/input-DM7dAKr9.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-769 固定资源/导航路径
- 文件: tmp/previews/T12-v5-original-export/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-770 固定资源/导航路径
- 文件: tmp/previews/T12-v5-original-export/v2.html
- 行号: 3
- 证据: `src="/assets/v2-fAfB4s3Q.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-771 固定资源/导航路径
- 文件: tmp/previews/T12-v5-original-export/v2.html
- 行号: 4
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-772 固定资源/导航路径
- 文件: tmp/previews/T12-v5-original-export/v2.html
- 行号: 5
- 证据: `href="/assets/input-DM7dAKr9.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-773 固定资源/导航路径
- 文件: tmp/previews/T12-v5-original-export/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-774 固定资源/导航路径
- 文件: tmp/previews/T12-v5-original-export/v3.html
- 行号: 2
- 证据: `src="/assets/v3-BvaeENJ_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-775 固定资源/导航路径
- 文件: tmp/previews/T12-v5-original-export/v3.html
- 行号: 3
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-776 固定资源/导航路径
- 文件: tmp/previews/T12-v5-original-export/v3.html
- 行号: 4
- 证据: `href="/assets/surface-DGP_7YNM.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-777 固定资源/导航路径
- 文件: tmp/previews/T12-v5-original-export/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-778 固定资源/导航路径
- 文件: tmp/previews/T12-v5-original-export/v4.html
- 行号: 2
- 证据: `src="/assets/v4-0gzyf6sJ.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-779 固定资源/导航路径
- 文件: tmp/previews/T12-v5-original-export/v4.html
- 行号: 3
- 证据: `href="/assets/dom-BaJVJNb2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-780 固定资源/导航路径
- 文件: tmp/previews/T12-v5-original-export/v4.html
- 行号: 4
- 证据: `href="/assets/surface-DGP_7YNM.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-781 固定资源/导航路径
- 文件: tmp/previews/T12-v5-original-export/v4.html
- 行号: 5
- 证据: `href="/assets/collection-DXo2JrVn.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-782 固定资源/导航路径
- 文件: tmp/previews/T12-v5-original-export/v4.html
- 行号: 6
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-783 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/classic.html
- 行号: 10
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-784 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/classic.html
- 行号: 11
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-785 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/classic.html
- 行号: 12
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-786 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/classic.html
- 行号: 13
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-787 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/classic.html
- 行号: 14
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-788 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/classic.html
- 行号: 15
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-789 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/classic.html
- 行号: 8
- 证据: `src="/assets/classic-ColVx1QY.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-790 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/classic.html
- 行号: 9
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-791 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/forge.html
- 行号: 10
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-792 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/forge.html
- 行号: 11
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-793 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/forge.html
- 行号: 12
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-794 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/forge.html
- 行号: 13
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-795 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/forge.html
- 行号: 14
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-796 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/forge.html
- 行号: 15
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-797 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/forge.html
- 行号: 16
- 证据: `href="/assets/focus-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-798 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/forge.html
- 行号: 8
- 证据: `src="/assets/forge-DVgB63mP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-799 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/forge.html
- 行号: 9
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-800 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/index.html
- 行号: 10
- 证据: `href="/assets/focus-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-801 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/index.html
- 行号: 2
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-802 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/index.html
- 行号: 2
- 证据: `src="/assets/main-DVgB63mP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-803 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/index.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-804 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/index.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-805 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/index.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-806 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/index.html
- 行号: 6
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-807 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/index.html
- 行号: 7
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-808 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/index.html
- 行号: 8
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-809 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/index.html
- 行号: 9
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-810 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-811 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-D4RccpBr.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-812 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-813 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/legacy.html
- 行号: 4
- 证据: `href="/assets/input-LyK4YY-i.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-814 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-815 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/v2.html
- 行号: 3
- 证据: `src="/assets/v2-BHxNkAgE.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-816 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/v2.html
- 行号: 4
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-817 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/v2.html
- 行号: 5
- 证据: `href="/assets/input-LyK4YY-i.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-818 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-819 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/v3.html
- 行号: 2
- 证据: `src="/assets/v3-QEYTMH3h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-820 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/v3.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-821 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/v3.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-822 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/v3.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-823 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/v3.html
- 行号: 6
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-824 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/v4.html
- 行号: 2
- 证据: `src="/assets/v4-Di-jHH2m.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-825 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/v4.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-826 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/v4.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-827 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/v4.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-828 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/v4.html
- 行号: 6
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-829 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/v4.html
- 行号: 7
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-830 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/v6.html
- 行号: 10
- 证据: `src="/assets/v6-BFgLnYvY.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-831 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/v6.html
- 行号: 11
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-832 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/v6.html
- 行号: 12
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-833 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/v6.html
- 行号: 13
- 证据: `href="/assets/v6-CqWcmwpl.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-834 固定资源/导航路径
- 文件: tmp/previews/v09-forge-01/v6.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-835 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/classic.html
- 行号: 10
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-836 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/classic.html
- 行号: 11
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-837 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/classic.html
- 行号: 12
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-838 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/classic.html
- 行号: 13
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-839 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/classic.html
- 行号: 14
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-840 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/classic.html
- 行号: 15
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-841 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/classic.html
- 行号: 8
- 证据: `src="/assets/classic-ColVx1QY.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-842 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/classic.html
- 行号: 9
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-843 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/forge.html
- 行号: 10
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-844 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/forge.html
- 行号: 11
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-845 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/forge.html
- 行号: 12
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-846 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/forge.html
- 行号: 13
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-847 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/forge.html
- 行号: 14
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-848 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/forge.html
- 行号: 15
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-849 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/forge.html
- 行号: 16
- 证据: `href="/assets/focus-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-850 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/forge.html
- 行号: 8
- 证据: `src="/assets/forge-DVgB63mP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-851 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/forge.html
- 行号: 9
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-852 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/index.html
- 行号: 10
- 证据: `href="/assets/focus-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-853 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/index.html
- 行号: 2
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-854 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/index.html
- 行号: 2
- 证据: `src="/assets/main-DVgB63mP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-855 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/index.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-856 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/index.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-857 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/index.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-858 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/index.html
- 行号: 6
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-859 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/index.html
- 行号: 7
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-860 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/index.html
- 行号: 8
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-861 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/index.html
- 行号: 9
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-862 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-863 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-D4RccpBr.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-864 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-865 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/legacy.html
- 行号: 4
- 证据: `href="/assets/input-LyK4YY-i.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-866 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-867 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/v2.html
- 行号: 3
- 证据: `src="/assets/v2-BHxNkAgE.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-868 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/v2.html
- 行号: 4
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-869 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/v2.html
- 行号: 5
- 证据: `href="/assets/input-LyK4YY-i.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-870 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-871 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/v3.html
- 行号: 2
- 证据: `src="/assets/v3-QEYTMH3h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-872 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/v3.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-873 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/v3.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-874 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/v3.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-875 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/v3.html
- 行号: 6
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-876 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/v4.html
- 行号: 2
- 证据: `src="/assets/v4-Di-jHH2m.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-877 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/v4.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-878 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/v4.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-879 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/v4.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-880 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/v4.html
- 行号: 6
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-881 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/v4.html
- 行号: 7
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-882 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/v6.html
- 行号: 10
- 证据: `src="/assets/v6-DwxEfWQY.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-883 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/v6.html
- 行号: 11
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-884 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/v6.html
- 行号: 12
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-885 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/v6.html
- 行号: 13
- 证据: `href="/assets/v6-Dup592ZO.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-886 固定资源/导航路径
- 文件: tmp/previews/v09-forge-02/v6.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-887 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/classic.html
- 行号: 10
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-888 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/classic.html
- 行号: 11
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-889 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/classic.html
- 行号: 12
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-890 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/classic.html
- 行号: 13
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-891 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/classic.html
- 行号: 14
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-892 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/classic.html
- 行号: 15
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-893 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/classic.html
- 行号: 8
- 证据: `src="/assets/classic-ColVx1QY.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-894 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/classic.html
- 行号: 9
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-895 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/forge.html
- 行号: 10
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-896 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/forge.html
- 行号: 11
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-897 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/forge.html
- 行号: 12
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-898 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/forge.html
- 行号: 13
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-899 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/forge.html
- 行号: 14
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-900 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/forge.html
- 行号: 15
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-901 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/forge.html
- 行号: 16
- 证据: `href="/assets/focus-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-902 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/forge.html
- 行号: 8
- 证据: `src="/assets/forge-DVgB63mP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-903 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/forge.html
- 行号: 9
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-904 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/index.html
- 行号: 10
- 证据: `href="/assets/focus-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-905 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/index.html
- 行号: 2
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-906 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/index.html
- 行号: 2
- 证据: `src="/assets/main-DVgB63mP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-907 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/index.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-908 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/index.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-909 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/index.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-910 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/index.html
- 行号: 6
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-911 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/index.html
- 行号: 7
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-912 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/index.html
- 行号: 8
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-913 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/index.html
- 行号: 9
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-914 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-915 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-D4RccpBr.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-916 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-917 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/legacy.html
- 行号: 4
- 证据: `href="/assets/input-LyK4YY-i.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-918 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-919 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/v2.html
- 行号: 3
- 证据: `src="/assets/v2-BHxNkAgE.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-920 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/v2.html
- 行号: 4
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-921 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/v2.html
- 行号: 5
- 证据: `href="/assets/input-LyK4YY-i.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-922 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-923 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/v3.html
- 行号: 2
- 证据: `src="/assets/v3-QEYTMH3h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-924 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/v3.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-925 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/v3.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-926 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/v3.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-927 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/v3.html
- 行号: 6
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-928 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/v4.html
- 行号: 2
- 证据: `src="/assets/v4-Di-jHH2m.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-929 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/v4.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-930 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/v4.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-931 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/v4.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-932 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/v4.html
- 行号: 6
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-933 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/v4.html
- 行号: 7
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-934 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/v6.html
- 行号: 10
- 证据: `src="/assets/v6-DeQbkug2.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-935 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/v6.html
- 行号: 11
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-936 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/v6.html
- 行号: 12
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-937 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/v6.html
- 行号: 13
- 证据: `href="/assets/v6-BCoGnu87.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-938 固定资源/导航路径
- 文件: tmp/previews/v09-release-01/v6.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-939 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/classic.html
- 行号: 10
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-940 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/classic.html
- 行号: 11
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-941 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/classic.html
- 行号: 12
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-942 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/classic.html
- 行号: 13
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-943 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/classic.html
- 行号: 14
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-944 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/classic.html
- 行号: 15
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-945 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/classic.html
- 行号: 8
- 证据: `src="/assets/classic-ColVx1QY.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-946 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/classic.html
- 行号: 9
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-947 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/forge.html
- 行号: 10
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-948 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/forge.html
- 行号: 11
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-949 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/forge.html
- 行号: 12
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-950 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/forge.html
- 行号: 13
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-951 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/forge.html
- 行号: 14
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-952 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/forge.html
- 行号: 15
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-953 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/forge.html
- 行号: 16
- 证据: `href="/assets/focus-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-954 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/forge.html
- 行号: 8
- 证据: `src="/assets/forge-DVgB63mP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-955 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/forge.html
- 行号: 9
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-956 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/index.html
- 行号: 10
- 证据: `href="/assets/focus-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-957 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/index.html
- 行号: 2
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-958 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/index.html
- 行号: 2
- 证据: `src="/assets/main-DVgB63mP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-959 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/index.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-960 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/index.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-961 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/index.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-962 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/index.html
- 行号: 6
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-963 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/index.html
- 行号: 7
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-964 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/index.html
- 行号: 8
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-965 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/index.html
- 行号: 9
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-966 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-967 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-D4RccpBr.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-968 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-969 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/legacy.html
- 行号: 4
- 证据: `href="/assets/input-LyK4YY-i.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-970 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-971 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/v2.html
- 行号: 3
- 证据: `src="/assets/v2-BHxNkAgE.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-972 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/v2.html
- 行号: 4
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-973 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/v2.html
- 行号: 5
- 证据: `href="/assets/input-LyK4YY-i.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-974 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-975 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/v3.html
- 行号: 2
- 证据: `src="/assets/v3-QEYTMH3h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-976 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/v3.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-977 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/v3.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-978 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/v3.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-979 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/v3.html
- 行号: 6
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-980 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/v4.html
- 行号: 2
- 证据: `src="/assets/v4-Di-jHH2m.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-981 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/v4.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-982 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/v4.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-983 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/v4.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-984 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/v4.html
- 行号: 6
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-985 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/v4.html
- 行号: 7
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-986 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/v6.html
- 行号: 10
- 证据: `src="/assets/v6-C6vFI86q.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-987 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/v6.html
- 行号: 11
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-988 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/v6.html
- 行号: 12
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-989 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/v6.html
- 行号: 13
- 证据: `href="/assets/v6-COHq0d5y.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-990 固定资源/导航路径
- 文件: tmp/previews/v09-tools-01/v6.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-991 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/classic.html
- 行号: 10
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-992 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/classic.html
- 行号: 11
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-993 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/classic.html
- 行号: 12
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-994 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/classic.html
- 行号: 13
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-995 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/classic.html
- 行号: 14
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-996 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/classic.html
- 行号: 15
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-997 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/classic.html
- 行号: 8
- 证据: `src="/assets/classic-ColVx1QY.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-998 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/classic.html
- 行号: 9
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-999 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/forge.html
- 行号: 10
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1000 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/forge.html
- 行号: 11
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1001 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/forge.html
- 行号: 12
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1002 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/forge.html
- 行号: 13
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1003 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/forge.html
- 行号: 14
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1004 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/forge.html
- 行号: 15
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1005 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/forge.html
- 行号: 16
- 证据: `href="/assets/focus-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1006 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/forge.html
- 行号: 8
- 证据: `src="/assets/forge-DVgB63mP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1007 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/forge.html
- 行号: 9
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1008 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/index.html
- 行号: 10
- 证据: `href="/assets/focus-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1009 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/index.html
- 行号: 2
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1010 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/index.html
- 行号: 2
- 证据: `src="/assets/main-DVgB63mP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1011 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/index.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1012 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/index.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1013 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/index.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1014 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/index.html
- 行号: 6
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1015 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/index.html
- 行号: 7
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1016 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/index.html
- 行号: 8
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1017 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/index.html
- 行号: 9
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1018 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1019 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-D4RccpBr.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1020 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1021 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/legacy.html
- 行号: 4
- 证据: `href="/assets/input-LyK4YY-i.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1022 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1023 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/v2.html
- 行号: 3
- 证据: `src="/assets/v2-BHxNkAgE.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1024 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/v2.html
- 行号: 4
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1025 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/v2.html
- 行号: 5
- 证据: `href="/assets/input-LyK4YY-i.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1026 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1027 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/v3.html
- 行号: 2
- 证据: `src="/assets/v3-QEYTMH3h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1028 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/v3.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1029 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/v3.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1030 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/v3.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1031 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/v3.html
- 行号: 6
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1032 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/v4.html
- 行号: 2
- 证据: `src="/assets/v4-Di-jHH2m.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1033 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/v4.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1034 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/v4.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1035 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/v4.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1036 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/v4.html
- 行号: 6
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1037 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/v4.html
- 行号: 7
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1038 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/v6.html
- 行号: 10
- 证据: `src="/assets/v6-IEFXBChN.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1039 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/v6.html
- 行号: 11
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1040 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/v6.html
- 行号: 12
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1041 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/v6.html
- 行号: 13
- 证据: `href="/assets/v6-BCoGnu87.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1042 固定资源/导航路径
- 文件: tmp/previews/v09-tools-02/v6.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1043 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/classic.html
- 行号: 10
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1044 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/classic.html
- 行号: 11
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1045 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/classic.html
- 行号: 12
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1046 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/classic.html
- 行号: 13
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1047 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/classic.html
- 行号: 14
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1048 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/classic.html
- 行号: 15
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1049 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/classic.html
- 行号: 8
- 证据: `src="/assets/classic-ColVx1QY.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1050 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/classic.html
- 行号: 9
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1051 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/forge.html
- 行号: 10
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1052 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/forge.html
- 行号: 11
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1053 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/forge.html
- 行号: 12
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1054 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/forge.html
- 行号: 13
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1055 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/forge.html
- 行号: 14
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1056 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/forge.html
- 行号: 15
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1057 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/forge.html
- 行号: 16
- 证据: `href="/assets/focus-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1058 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/forge.html
- 行号: 8
- 证据: `src="/assets/forge-DVgB63mP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1059 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/forge.html
- 行号: 9
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1060 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/index.html
- 行号: 10
- 证据: `href="/assets/focus-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1061 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/index.html
- 行号: 2
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1062 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/index.html
- 行号: 2
- 证据: `src="/assets/main-DVgB63mP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1063 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/index.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1064 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/index.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1065 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/index.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1066 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/index.html
- 行号: 6
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1067 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/index.html
- 行号: 7
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1068 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/index.html
- 行号: 8
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1069 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/index.html
- 行号: 9
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1070 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1071 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-D4RccpBr.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1072 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1073 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/legacy.html
- 行号: 4
- 证据: `href="/assets/input-LyK4YY-i.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1074 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1075 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/v2.html
- 行号: 3
- 证据: `src="/assets/v2-BHxNkAgE.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1076 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/v2.html
- 行号: 4
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1077 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/v2.html
- 行号: 5
- 证据: `href="/assets/input-LyK4YY-i.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1078 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1079 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/v3.html
- 行号: 2
- 证据: `src="/assets/v3-QEYTMH3h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1080 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/v3.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1081 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/v3.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1082 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/v3.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1083 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/v3.html
- 行号: 6
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1084 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/v4.html
- 行号: 2
- 证据: `src="/assets/v4-Di-jHH2m.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1085 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/v4.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1086 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/v4.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1087 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/v4.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1088 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/v4.html
- 行号: 6
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1089 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/v4.html
- 行号: 7
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1090 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/v6.html
- 行号: 10
- 证据: `src="/assets/v6-CJWD0xK1.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1091 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/v6.html
- 行号: 11
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1092 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/v6.html
- 行号: 12
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1093 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/v6.html
- 行号: 13
- 证据: `href="/assets/v6-BCoGnu87.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1094 固定资源/导航路径
- 文件: tmp/previews/v09-tools-03/v6.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1095 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/classic.html
- 行号: 10
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1096 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/classic.html
- 行号: 11
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1097 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/classic.html
- 行号: 12
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1098 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/classic.html
- 行号: 13
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1099 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/classic.html
- 行号: 14
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1100 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/classic.html
- 行号: 15
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1101 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/classic.html
- 行号: 8
- 证据: `src="/assets/classic-ColVx1QY.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1102 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/classic.html
- 行号: 9
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1103 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/forge.html
- 行号: 10
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1104 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/forge.html
- 行号: 11
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1105 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/forge.html
- 行号: 12
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1106 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/forge.html
- 行号: 13
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1107 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/forge.html
- 行号: 14
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1108 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/forge.html
- 行号: 15
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1109 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/forge.html
- 行号: 16
- 证据: `href="/assets/focus-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1110 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/forge.html
- 行号: 8
- 证据: `src="/assets/forge-DVgB63mP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1111 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/forge.html
- 行号: 9
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1112 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/index.html
- 行号: 10
- 证据: `href="/assets/focus-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1113 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/index.html
- 行号: 2
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1114 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/index.html
- 行号: 2
- 证据: `src="/assets/main-DVgB63mP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1115 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/index.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1116 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/index.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1117 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/index.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1118 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/index.html
- 行号: 6
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1119 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/index.html
- 行号: 7
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1120 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/index.html
- 行号: 8
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1121 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/index.html
- 行号: 9
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1122 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1123 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-D4RccpBr.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1124 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1125 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/legacy.html
- 行号: 4
- 证据: `href="/assets/input-LyK4YY-i.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1126 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1127 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/v2.html
- 行号: 3
- 证据: `src="/assets/v2-BHxNkAgE.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1128 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/v2.html
- 行号: 4
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1129 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/v2.html
- 行号: 5
- 证据: `href="/assets/input-LyK4YY-i.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1130 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1131 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/v3.html
- 行号: 2
- 证据: `src="/assets/v3-QEYTMH3h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1132 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/v3.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1133 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/v3.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1134 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/v3.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1135 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/v3.html
- 行号: 6
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1136 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/v4.html
- 行号: 2
- 证据: `src="/assets/v4-Di-jHH2m.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1137 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/v4.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1138 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/v4.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1139 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/v4.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1140 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/v4.html
- 行号: 6
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1141 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/v4.html
- 行号: 7
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1142 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/v6.html
- 行号: 10
- 证据: `src="/assets/v6-PdJmGe8O.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1143 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/v6.html
- 行号: 11
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1144 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/v6.html
- 行号: 12
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1145 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/v6.html
- 行号: 13
- 证据: `href="/assets/v6-BCoGnu87.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1146 固定资源/导航路径
- 文件: tmp/previews/v09-tools-04/v6.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1147 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/classic.html
- 行号: 10
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1148 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/classic.html
- 行号: 11
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1149 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/classic.html
- 行号: 12
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1150 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/classic.html
- 行号: 13
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1151 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/classic.html
- 行号: 14
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1152 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/classic.html
- 行号: 15
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1153 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/classic.html
- 行号: 8
- 证据: `src="/assets/classic-ColVx1QY.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1154 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/classic.html
- 行号: 9
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1155 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/forge.html
- 行号: 10
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1156 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/forge.html
- 行号: 11
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1157 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/forge.html
- 行号: 12
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1158 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/forge.html
- 行号: 13
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1159 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/forge.html
- 行号: 14
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1160 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/forge.html
- 行号: 15
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1161 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/forge.html
- 行号: 16
- 证据: `href="/assets/focus-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1162 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/forge.html
- 行号: 8
- 证据: `src="/assets/forge-DVgB63mP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1163 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/forge.html
- 行号: 9
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1164 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/index.html
- 行号: 10
- 证据: `href="/assets/focus-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1165 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/index.html
- 行号: 2
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1166 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/index.html
- 行号: 2
- 证据: `src="/assets/main-DVgB63mP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1167 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/index.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1168 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/index.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1169 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/index.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1170 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/index.html
- 行号: 6
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1171 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/index.html
- 行号: 7
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1172 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/index.html
- 行号: 8
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1173 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/index.html
- 行号: 9
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1174 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1175 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-D4RccpBr.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1176 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1177 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/legacy.html
- 行号: 4
- 证据: `href="/assets/input-LyK4YY-i.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1178 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1179 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/v2.html
- 行号: 3
- 证据: `src="/assets/v2-BHxNkAgE.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1180 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/v2.html
- 行号: 4
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1181 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/v2.html
- 行号: 5
- 证据: `href="/assets/input-LyK4YY-i.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1182 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1183 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/v3.html
- 行号: 2
- 证据: `src="/assets/v3-QEYTMH3h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1184 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/v3.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1185 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/v3.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1186 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/v3.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1187 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/v3.html
- 行号: 6
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1188 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/v4.html
- 行号: 2
- 证据: `src="/assets/v4-Di-jHH2m.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1189 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/v4.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1190 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/v4.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1191 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/v4.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1192 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/v4.html
- 行号: 6
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1193 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/v4.html
- 行号: 7
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1194 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/v6.html
- 行号: 10
- 证据: `src="/assets/v6-BwPiWO-D.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1195 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/v6.html
- 行号: 11
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1196 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/v6.html
- 行号: 12
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1197 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/v6.html
- 行号: 13
- 证据: `href="/assets/v6-CEsVhxbU.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1198 固定资源/导航路径
- 文件: tmp/previews/v09-trial-01/v6.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1199 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/classic.html
- 行号: 10
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1200 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/classic.html
- 行号: 11
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1201 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/classic.html
- 行号: 12
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1202 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/classic.html
- 行号: 13
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1203 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/classic.html
- 行号: 14
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1204 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/classic.html
- 行号: 15
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1205 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/classic.html
- 行号: 8
- 证据: `src="/assets/classic-ColVx1QY.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1206 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/classic.html
- 行号: 9
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1207 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/forge.html
- 行号: 10
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1208 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/forge.html
- 行号: 11
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1209 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/forge.html
- 行号: 12
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1210 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/forge.html
- 行号: 13
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1211 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/forge.html
- 行号: 14
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1212 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/forge.html
- 行号: 15
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1213 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/forge.html
- 行号: 16
- 证据: `href="/assets/focus-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1214 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/forge.html
- 行号: 8
- 证据: `src="/assets/forge-DVgB63mP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1215 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/forge.html
- 行号: 9
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1216 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/index.html
- 行号: 10
- 证据: `href="/assets/focus-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1217 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/index.html
- 行号: 2
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1218 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/index.html
- 行号: 2
- 证据: `src="/assets/main-DVgB63mP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1219 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/index.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1220 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/index.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1221 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/index.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1222 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/index.html
- 行号: 6
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1223 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/index.html
- 行号: 7
- 证据: `href="/assets/readability-Cub8NJkP.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1224 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/index.html
- 行号: 8
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1225 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/index.html
- 行号: 9
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1226 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1227 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-D4RccpBr.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1228 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1229 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/legacy.html
- 行号: 4
- 证据: `href="/assets/input-LyK4YY-i.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1230 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1231 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/v2.html
- 行号: 3
- 证据: `src="/assets/v2-BHxNkAgE.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1232 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/v2.html
- 行号: 4
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1233 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/v2.html
- 行号: 5
- 证据: `href="/assets/input-LyK4YY-i.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1234 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1235 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/v3.html
- 行号: 2
- 证据: `src="/assets/v3-QEYTMH3h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1236 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/v3.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1237 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/v3.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1238 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/v3.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1239 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/v3.html
- 行号: 6
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1240 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/v4.html
- 行号: 2
- 证据: `src="/assets/v4-Di-jHH2m.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1241 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/v4.html
- 行号: 3
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1242 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/v4.html
- 行号: 4
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1243 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/v4.html
- 行号: 5
- 证据: `href="/assets/surface-A4ZFOnCc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1244 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/v4.html
- 行号: 6
- 证据: `href="/assets/collection-B7_KQ69_.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1245 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/v4.html
- 行号: 7
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1246 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/v6.html
- 行号: 10
- 证据: `src="/assets/v6-BxIqWAlU.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1247 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/v6.html
- 行号: 11
- 证据: `href="/assets/dom-UdOu9fij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1248 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/v6.html
- 行号: 12
- 证据: `href="/assets/impact-4TS5AN9h.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1249 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/v6.html
- 行号: 13
- 证据: `href="/assets/v6-D7aSbgLi.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1250 固定资源/导航路径
- 文件: tmp/previews/v09-trial-02/v6.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1251 固定CSS资源路径
- 文件: tmp/previews/v1-campaign-storyboard-01/index.html
- 行号: 16
- 证据: `url('/assets/d/customers-atlas-v2.webp')`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为相对URL。

### H-1252 固定资源/导航路径
- 文件: tmp/previews/v1-campaign-storyboard-01/index.html
- 行号: 41
- 证据: `src="/assets/d/reboot/forge-focus-backdrop-v1.webp"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1253 固定资源/导航路径
- 文件: tmp/previews/v1-campaign-storyboard-01/index.html
- 行号: 58
- 证据: `src="/assets/d/v07-chapter3/ending-twelve-lights-v1.webp"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1254 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/campaign.html
- 行号: 10
- 证据: `src="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1255 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/campaign.html
- 行号: 11
- 证据: `src="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1256 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/campaign.html
- 行号: 12
- 证据: `src="/assets/sword-art-ve6p6KDu.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1257 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/campaign.html
- 行号: 13
- 证据: `src="/assets/v7-main-Br4VZxPz.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1258 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/campaign.html
- 行号: 14
- 证据: `href="/assets/v7-main-DK-7eEcS.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1259 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/campaign.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1260 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/classic.html
- 行号: 10
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1261 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/classic.html
- 行号: 11
- 证据: `href="/assets/surface-gaEh7IZv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1262 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/classic.html
- 行号: 12
- 证据: `href="/assets/collection-D358q2Dj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1263 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/classic.html
- 行号: 13
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1264 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/classic.html
- 行号: 14
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1265 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/classic.html
- 行号: 15
- 证据: `href="/assets/readability-B40TUug7.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1266 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/classic.html
- 行号: 16
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1267 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/classic.html
- 行号: 17
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1268 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/classic.html
- 行号: 8
- 证据: `src="/assets/classic-CrMLVByw.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1269 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/classic.html
- 行号: 9
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1270 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/forge.html
- 行号: 10
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1271 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/forge.html
- 行号: 11
- 证据: `href="/assets/surface-gaEh7IZv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1272 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/forge.html
- 行号: 12
- 证据: `href="/assets/collection-D358q2Dj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1273 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/forge.html
- 行号: 13
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1274 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/forge.html
- 行号: 14
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1275 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/forge.html
- 行号: 15
- 证据: `href="/assets/readability-B40TUug7.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1276 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/forge.html
- 行号: 16
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1277 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/forge.html
- 行号: 17
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1278 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/forge.html
- 行号: 18
- 证据: `href="/assets/forge-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1279 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/forge.html
- 行号: 8
- 证据: `src="/assets/forge-CqM7QbBs.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1280 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/forge.html
- 行号: 9
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1281 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/index.html
- 行号: 10
- 证据: `src="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1282 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/index.html
- 行号: 11
- 证据: `src="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1283 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/index.html
- 行号: 12
- 证据: `src="/assets/sword-art-ve6p6KDu.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1284 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/index.html
- 行号: 13
- 证据: `src="/assets/v7-main-Br4VZxPz.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1285 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/index.html
- 行号: 14
- 证据: `href="/assets/v7-main-DK-7eEcS.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1286 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/index.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1287 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1288 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-BA8C34v7.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1289 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1290 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/legacy.html
- 行号: 4
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1291 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/legacy.html
- 行号: 5
- 证据: `href="/assets/input-BKQzqN7g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1292 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/legacy.html
- 行号: 6
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1293 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v2.html
- 行号: 3
- 证据: `src="/assets/v2-DY1pOQ31.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1294 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v2.html
- 行号: 4
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1295 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v2.html
- 行号: 5
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1296 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v2.html
- 行号: 6
- 证据: `href="/assets/input-BKQzqN7g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1297 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v2.html
- 行号: 7
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1298 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v3.html
- 行号: 2
- 证据: `src="/assets/v3-DaoRt3cU.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1299 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v3.html
- 行号: 3
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1300 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v3.html
- 行号: 4
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1301 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v3.html
- 行号: 5
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1302 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v3.html
- 行号: 6
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1303 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v3.html
- 行号: 7
- 证据: `href="/assets/surface-gaEh7IZv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1304 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v3.html
- 行号: 8
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1305 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v4.html
- 行号: 2
- 证据: `src="/assets/v4-Cq3s8Rij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1306 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v4.html
- 行号: 3
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1307 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v4.html
- 行号: 4
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1308 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v4.html
- 行号: 5
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1309 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v4.html
- 行号: 6
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1310 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v4.html
- 行号: 7
- 证据: `href="/assets/surface-gaEh7IZv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1311 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v4.html
- 行号: 8
- 证据: `href="/assets/collection-D358q2Dj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1312 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v4.html
- 行号: 9
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1313 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v6.html
- 行号: 10
- 证据: `src="/assets/v6-DFbii2rT.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1314 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v6.html
- 行号: 11
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1315 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v6.html
- 行号: 12
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1316 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v6.html
- 行号: 13
- 证据: `href="/assets/sword-art-ve6p6KDu.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1317 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v6.html
- 行号: 14
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1318 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v6.html
- 行号: 15
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1319 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v6.html
- 行号: 16
- 证据: `href="/assets/v6-BCoGnu87.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1320 固定资源/导航路径
- 文件: tmp/previews/v1-release-01/v6.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1321 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/campaign.html
- 行号: 10
- 证据: `src="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1322 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/campaign.html
- 行号: 11
- 证据: `src="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1323 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/campaign.html
- 行号: 12
- 证据: `src="/assets/sword-art-ve6p6KDu.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1324 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/campaign.html
- 行号: 13
- 证据: `src="/assets/v7-main-DAtfrHMc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1325 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/campaign.html
- 行号: 14
- 证据: `href="/assets/v7-main-DK-7eEcS.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1326 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/campaign.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1327 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/classic.html
- 行号: 10
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1328 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/classic.html
- 行号: 11
- 证据: `href="/assets/surface-gaEh7IZv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1329 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/classic.html
- 行号: 12
- 证据: `href="/assets/collection-D358q2Dj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1330 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/classic.html
- 行号: 13
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1331 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/classic.html
- 行号: 14
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1332 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/classic.html
- 行号: 15
- 证据: `href="/assets/readability-B40TUug7.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1333 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/classic.html
- 行号: 16
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1334 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/classic.html
- 行号: 17
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1335 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/classic.html
- 行号: 8
- 证据: `src="/assets/classic-CrMLVByw.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1336 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/classic.html
- 行号: 9
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1337 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/forge.html
- 行号: 10
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1338 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/forge.html
- 行号: 11
- 证据: `href="/assets/surface-gaEh7IZv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1339 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/forge.html
- 行号: 12
- 证据: `href="/assets/collection-D358q2Dj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1340 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/forge.html
- 行号: 13
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1341 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/forge.html
- 行号: 14
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1342 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/forge.html
- 行号: 15
- 证据: `href="/assets/readability-B40TUug7.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1343 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/forge.html
- 行号: 16
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1344 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/forge.html
- 行号: 17
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1345 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/forge.html
- 行号: 18
- 证据: `href="/assets/forge-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1346 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/forge.html
- 行号: 8
- 证据: `src="/assets/forge-CqM7QbBs.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1347 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/forge.html
- 行号: 9
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1348 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/index.html
- 行号: 10
- 证据: `src="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1349 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/index.html
- 行号: 11
- 证据: `src="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1350 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/index.html
- 行号: 12
- 证据: `src="/assets/sword-art-ve6p6KDu.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1351 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/index.html
- 行号: 13
- 证据: `src="/assets/v7-main-DAtfrHMc.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1352 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/index.html
- 行号: 14
- 证据: `href="/assets/v7-main-DK-7eEcS.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1353 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/index.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1354 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1355 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-BA8C34v7.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1356 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1357 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/legacy.html
- 行号: 4
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1358 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/legacy.html
- 行号: 5
- 证据: `href="/assets/input-BKQzqN7g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1359 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/legacy.html
- 行号: 6
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1360 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v2.html
- 行号: 3
- 证据: `src="/assets/v2-DY1pOQ31.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1361 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v2.html
- 行号: 4
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1362 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v2.html
- 行号: 5
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1363 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v2.html
- 行号: 6
- 证据: `href="/assets/input-BKQzqN7g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1364 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v2.html
- 行号: 7
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1365 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v3.html
- 行号: 2
- 证据: `src="/assets/v3-DaoRt3cU.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1366 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v3.html
- 行号: 3
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1367 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v3.html
- 行号: 4
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1368 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v3.html
- 行号: 5
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1369 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v3.html
- 行号: 6
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1370 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v3.html
- 行号: 7
- 证据: `href="/assets/surface-gaEh7IZv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1371 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v3.html
- 行号: 8
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1372 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v4.html
- 行号: 2
- 证据: `src="/assets/v4-Cq3s8Rij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1373 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v4.html
- 行号: 3
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1374 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v4.html
- 行号: 4
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1375 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v4.html
- 行号: 5
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1376 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v4.html
- 行号: 6
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1377 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v4.html
- 行号: 7
- 证据: `href="/assets/surface-gaEh7IZv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1378 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v4.html
- 行号: 8
- 证据: `href="/assets/collection-D358q2Dj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1379 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v4.html
- 行号: 9
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1380 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v6.html
- 行号: 10
- 证据: `src="/assets/v6-DFbii2rT.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1381 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v6.html
- 行号: 11
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1382 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v6.html
- 行号: 12
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1383 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v6.html
- 行号: 13
- 证据: `href="/assets/sword-art-ve6p6KDu.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1384 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v6.html
- 行号: 14
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1385 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v6.html
- 行号: 15
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1386 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v6.html
- 行号: 16
- 证据: `href="/assets/v6-BCoGnu87.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1387 固定资源/导航路径
- 文件: tmp/previews/v1-release-02/v6.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1388 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/campaign.html
- 行号: 10
- 证据: `src="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1389 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/campaign.html
- 行号: 11
- 证据: `src="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1390 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/campaign.html
- 行号: 12
- 证据: `src="/assets/sword-art-ve6p6KDu.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1391 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/campaign.html
- 行号: 13
- 证据: `src="/assets/v7-main-DT9FoP3T.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1392 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/campaign.html
- 行号: 14
- 证据: `href="/assets/v7-main-DJv30VVD.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1393 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/campaign.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1394 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/classic.html
- 行号: 10
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1395 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/classic.html
- 行号: 11
- 证据: `href="/assets/surface-gaEh7IZv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1396 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/classic.html
- 行号: 12
- 证据: `href="/assets/collection-D358q2Dj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1397 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/classic.html
- 行号: 13
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1398 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/classic.html
- 行号: 14
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1399 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/classic.html
- 行号: 15
- 证据: `href="/assets/readability-B40TUug7.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1400 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/classic.html
- 行号: 16
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1401 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/classic.html
- 行号: 17
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1402 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/classic.html
- 行号: 8
- 证据: `src="/assets/classic-CrMLVByw.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1403 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/classic.html
- 行号: 9
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1404 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/forge.html
- 行号: 10
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1405 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/forge.html
- 行号: 11
- 证据: `href="/assets/surface-gaEh7IZv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1406 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/forge.html
- 行号: 12
- 证据: `href="/assets/collection-D358q2Dj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1407 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/forge.html
- 行号: 13
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1408 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/forge.html
- 行号: 14
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1409 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/forge.html
- 行号: 15
- 证据: `href="/assets/readability-B40TUug7.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1410 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/forge.html
- 行号: 16
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1411 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/forge.html
- 行号: 17
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1412 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/forge.html
- 行号: 18
- 证据: `href="/assets/forge-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1413 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/forge.html
- 行号: 8
- 证据: `src="/assets/forge-CqM7QbBs.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1414 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/forge.html
- 行号: 9
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1415 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/index.html
- 行号: 10
- 证据: `src="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1416 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/index.html
- 行号: 11
- 证据: `src="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1417 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/index.html
- 行号: 12
- 证据: `src="/assets/sword-art-ve6p6KDu.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1418 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/index.html
- 行号: 13
- 证据: `src="/assets/v7-main-DT9FoP3T.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1419 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/index.html
- 行号: 14
- 证据: `href="/assets/v7-main-DJv30VVD.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1420 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/index.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1421 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1422 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-BA8C34v7.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1423 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1424 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/legacy.html
- 行号: 4
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1425 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/legacy.html
- 行号: 5
- 证据: `href="/assets/input-BKQzqN7g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1426 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/legacy.html
- 行号: 6
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1427 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v2.html
- 行号: 3
- 证据: `src="/assets/v2-DY1pOQ31.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1428 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v2.html
- 行号: 4
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1429 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v2.html
- 行号: 5
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1430 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v2.html
- 行号: 6
- 证据: `href="/assets/input-BKQzqN7g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1431 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v2.html
- 行号: 7
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1432 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v3.html
- 行号: 2
- 证据: `src="/assets/v3-DaoRt3cU.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1433 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v3.html
- 行号: 3
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1434 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v3.html
- 行号: 4
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1435 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v3.html
- 行号: 5
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1436 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v3.html
- 行号: 6
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1437 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v3.html
- 行号: 7
- 证据: `href="/assets/surface-gaEh7IZv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1438 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v3.html
- 行号: 8
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1439 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v4.html
- 行号: 2
- 证据: `src="/assets/v4-Cq3s8Rij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1440 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v4.html
- 行号: 3
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1441 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v4.html
- 行号: 4
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1442 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v4.html
- 行号: 5
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1443 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v4.html
- 行号: 6
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1444 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v4.html
- 行号: 7
- 证据: `href="/assets/surface-gaEh7IZv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1445 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v4.html
- 行号: 8
- 证据: `href="/assets/collection-D358q2Dj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1446 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v4.html
- 行号: 9
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1447 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v6.html
- 行号: 10
- 证据: `src="/assets/v6-DFbii2rT.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1448 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v6.html
- 行号: 11
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1449 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v6.html
- 行号: 12
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1450 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v6.html
- 行号: 13
- 证据: `href="/assets/sword-art-ve6p6KDu.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1451 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v6.html
- 行号: 14
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1452 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v6.html
- 行号: 15
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1453 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v6.html
- 行号: 16
- 证据: `href="/assets/v6-BCoGnu87.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1454 固定资源/导航路径
- 文件: tmp/previews/v1-release-03/v6.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1455 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/campaign.html
- 行号: 10
- 证据: `src="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1456 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/campaign.html
- 行号: 11
- 证据: `src="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1457 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/campaign.html
- 行号: 12
- 证据: `src="/assets/sword-art-ve6p6KDu.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1458 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/campaign.html
- 行号: 13
- 证据: `src="/assets/v7-main-B1FFItfy.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1459 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/campaign.html
- 行号: 14
- 证据: `href="/assets/v7-main-BsBjZ8LS.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1460 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/campaign.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1461 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/classic.html
- 行号: 10
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1462 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/classic.html
- 行号: 11
- 证据: `href="/assets/surface-gaEh7IZv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1463 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/classic.html
- 行号: 12
- 证据: `href="/assets/collection-D358q2Dj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1464 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/classic.html
- 行号: 13
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1465 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/classic.html
- 行号: 14
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1466 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/classic.html
- 行号: 15
- 证据: `href="/assets/readability-B40TUug7.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1467 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/classic.html
- 行号: 16
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1468 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/classic.html
- 行号: 17
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1469 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/classic.html
- 行号: 8
- 证据: `src="/assets/classic-CrMLVByw.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1470 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/classic.html
- 行号: 9
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1471 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/forge.html
- 行号: 10
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1472 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/forge.html
- 行号: 11
- 证据: `href="/assets/surface-gaEh7IZv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1473 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/forge.html
- 行号: 12
- 证据: `href="/assets/collection-D358q2Dj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1474 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/forge.html
- 行号: 13
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1475 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/forge.html
- 行号: 14
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1476 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/forge.html
- 行号: 15
- 证据: `href="/assets/readability-B40TUug7.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1477 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/forge.html
- 行号: 16
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1478 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/forge.html
- 行号: 17
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1479 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/forge.html
- 行号: 18
- 证据: `href="/assets/forge-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1480 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/forge.html
- 行号: 8
- 证据: `src="/assets/forge-CqM7QbBs.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1481 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/forge.html
- 行号: 9
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1482 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/index.html
- 行号: 10
- 证据: `src="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1483 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/index.html
- 行号: 11
- 证据: `src="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1484 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/index.html
- 行号: 12
- 证据: `src="/assets/sword-art-ve6p6KDu.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1485 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/index.html
- 行号: 13
- 证据: `src="/assets/v7-main-B1FFItfy.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1486 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/index.html
- 行号: 14
- 证据: `href="/assets/v7-main-BsBjZ8LS.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1487 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/index.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1488 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1489 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-BA8C34v7.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1490 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1491 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/legacy.html
- 行号: 4
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1492 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/legacy.html
- 行号: 5
- 证据: `href="/assets/input-BKQzqN7g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1493 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/legacy.html
- 行号: 6
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1494 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v2.html
- 行号: 3
- 证据: `src="/assets/v2-DY1pOQ31.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1495 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v2.html
- 行号: 4
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1496 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v2.html
- 行号: 5
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1497 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v2.html
- 行号: 6
- 证据: `href="/assets/input-BKQzqN7g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1498 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v2.html
- 行号: 7
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1499 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v3.html
- 行号: 2
- 证据: `src="/assets/v3-DaoRt3cU.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1500 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v3.html
- 行号: 3
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1501 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v3.html
- 行号: 4
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1502 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v3.html
- 行号: 5
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1503 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v3.html
- 行号: 6
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1504 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v3.html
- 行号: 7
- 证据: `href="/assets/surface-gaEh7IZv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1505 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v3.html
- 行号: 8
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1506 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v4.html
- 行号: 2
- 证据: `src="/assets/v4-Cq3s8Rij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1507 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v4.html
- 行号: 3
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1508 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v4.html
- 行号: 4
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1509 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v4.html
- 行号: 5
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1510 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v4.html
- 行号: 6
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1511 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v4.html
- 行号: 7
- 证据: `href="/assets/surface-gaEh7IZv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1512 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v4.html
- 行号: 8
- 证据: `href="/assets/collection-D358q2Dj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1513 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v4.html
- 行号: 9
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1514 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v6.html
- 行号: 10
- 证据: `src="/assets/v6-DFbii2rT.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1515 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v6.html
- 行号: 11
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1516 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v6.html
- 行号: 12
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1517 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v6.html
- 行号: 13
- 证据: `href="/assets/sword-art-ve6p6KDu.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1518 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v6.html
- 行号: 14
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1519 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v6.html
- 行号: 15
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1520 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v6.html
- 行号: 16
- 证据: `href="/assets/v6-BCoGnu87.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1521 固定资源/导航路径
- 文件: tmp/previews/v1-release-04/v6.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1522 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/campaign.html
- 行号: 10
- 证据: `src="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1523 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/campaign.html
- 行号: 11
- 证据: `src="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1524 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/campaign.html
- 行号: 12
- 证据: `src="/assets/sword-art-ve6p6KDu.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1525 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/campaign.html
- 行号: 13
- 证据: `src="/assets/v7-main-Bi7e4YRl.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1526 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/campaign.html
- 行号: 14
- 证据: `href="/assets/v7-main-BsBjZ8LS.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1527 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/campaign.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1528 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/classic.html
- 行号: 10
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1529 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/classic.html
- 行号: 11
- 证据: `href="/assets/surface-gaEh7IZv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1530 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/classic.html
- 行号: 12
- 证据: `href="/assets/collection-D358q2Dj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1531 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/classic.html
- 行号: 13
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1532 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/classic.html
- 行号: 14
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1533 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/classic.html
- 行号: 15
- 证据: `href="/assets/readability-B40TUug7.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1534 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/classic.html
- 行号: 16
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1535 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/classic.html
- 行号: 17
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1536 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/classic.html
- 行号: 8
- 证据: `src="/assets/classic-CrMLVByw.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1537 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/classic.html
- 行号: 9
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1538 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/forge.html
- 行号: 10
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1539 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/forge.html
- 行号: 11
- 证据: `href="/assets/surface-gaEh7IZv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1540 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/forge.html
- 行号: 12
- 证据: `href="/assets/collection-D358q2Dj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1541 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/forge.html
- 行号: 13
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1542 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/forge.html
- 行号: 14
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1543 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/forge.html
- 行号: 15
- 证据: `href="/assets/readability-B40TUug7.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1544 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/forge.html
- 行号: 16
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1545 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/forge.html
- 行号: 17
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1546 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/forge.html
- 行号: 18
- 证据: `href="/assets/forge-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1547 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/forge.html
- 行号: 8
- 证据: `src="/assets/forge-CqM7QbBs.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1548 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/forge.html
- 行号: 9
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1549 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/index.html
- 行号: 10
- 证据: `src="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1550 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/index.html
- 行号: 11
- 证据: `src="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1551 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/index.html
- 行号: 12
- 证据: `src="/assets/sword-art-ve6p6KDu.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1552 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/index.html
- 行号: 13
- 证据: `src="/assets/v7-main-Bi7e4YRl.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1553 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/index.html
- 行号: 14
- 证据: `href="/assets/v7-main-BsBjZ8LS.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1554 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/index.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1555 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1556 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-BA8C34v7.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1557 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1558 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/legacy.html
- 行号: 4
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1559 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/legacy.html
- 行号: 5
- 证据: `href="/assets/input-BKQzqN7g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1560 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/legacy.html
- 行号: 6
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1561 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v2.html
- 行号: 3
- 证据: `src="/assets/v2-DY1pOQ31.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1562 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v2.html
- 行号: 4
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1563 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v2.html
- 行号: 5
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1564 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v2.html
- 行号: 6
- 证据: `href="/assets/input-BKQzqN7g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1565 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v2.html
- 行号: 7
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1566 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v3.html
- 行号: 2
- 证据: `src="/assets/v3-DaoRt3cU.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1567 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v3.html
- 行号: 3
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1568 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v3.html
- 行号: 4
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1569 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v3.html
- 行号: 5
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1570 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v3.html
- 行号: 6
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1571 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v3.html
- 行号: 7
- 证据: `href="/assets/surface-gaEh7IZv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1572 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v3.html
- 行号: 8
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1573 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v4.html
- 行号: 2
- 证据: `src="/assets/v4-Cq3s8Rij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1574 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v4.html
- 行号: 3
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1575 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v4.html
- 行号: 4
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1576 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v4.html
- 行号: 5
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1577 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v4.html
- 行号: 6
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1578 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v4.html
- 行号: 7
- 证据: `href="/assets/surface-gaEh7IZv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1579 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v4.html
- 行号: 8
- 证据: `href="/assets/collection-D358q2Dj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1580 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v4.html
- 行号: 9
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1581 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v6.html
- 行号: 10
- 证据: `src="/assets/v6-DFbii2rT.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1582 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v6.html
- 行号: 11
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1583 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v6.html
- 行号: 12
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1584 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v6.html
- 行号: 13
- 证据: `href="/assets/sword-art-ve6p6KDu.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1585 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v6.html
- 行号: 14
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1586 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v6.html
- 行号: 15
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1587 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v6.html
- 行号: 16
- 证据: `href="/assets/v6-BCoGnu87.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1588 固定资源/导航路径
- 文件: tmp/previews/v1-release-05/v6.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1589 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/campaign.html
- 行号: 10
- 证据: `src="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1590 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/campaign.html
- 行号: 11
- 证据: `src="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1591 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/campaign.html
- 行号: 12
- 证据: `src="/assets/sword-art-ve6p6KDu.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1592 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/campaign.html
- 行号: 13
- 证据: `src="/assets/v7-main-BnLYJKUJ.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1593 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/campaign.html
- 行号: 14
- 证据: `href="/assets/v7-main-CX8Eti5V.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1594 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/campaign.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1595 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/classic.html
- 行号: 10
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1596 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/classic.html
- 行号: 11
- 证据: `href="/assets/surface-gaEh7IZv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1597 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/classic.html
- 行号: 12
- 证据: `href="/assets/collection-D358q2Dj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1598 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/classic.html
- 行号: 13
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1599 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/classic.html
- 行号: 14
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1600 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/classic.html
- 行号: 15
- 证据: `href="/assets/readability-B40TUug7.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1601 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/classic.html
- 行号: 16
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1602 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/classic.html
- 行号: 17
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1603 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/classic.html
- 行号: 8
- 证据: `src="/assets/classic-CrMLVByw.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1604 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/classic.html
- 行号: 9
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1605 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/forge.html
- 行号: 10
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1606 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/forge.html
- 行号: 11
- 证据: `href="/assets/surface-gaEh7IZv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1607 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/forge.html
- 行号: 12
- 证据: `href="/assets/collection-D358q2Dj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1608 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/forge.html
- 行号: 13
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1609 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/forge.html
- 行号: 14
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1610 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/forge.html
- 行号: 15
- 证据: `href="/assets/readability-B40TUug7.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1611 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/forge.html
- 行号: 16
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1612 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/forge.html
- 行号: 17
- 证据: `href="/assets/readability-CHHEb8y7.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1613 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/forge.html
- 行号: 18
- 证据: `href="/assets/forge-DN0zD0eN.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1614 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/forge.html
- 行号: 8
- 证据: `src="/assets/forge-CqM7QbBs.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1615 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/forge.html
- 行号: 9
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1616 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/index.html
- 行号: 10
- 证据: `src="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1617 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/index.html
- 行号: 11
- 证据: `src="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1618 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/index.html
- 行号: 12
- 证据: `src="/assets/sword-art-ve6p6KDu.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1619 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/index.html
- 行号: 13
- 证据: `src="/assets/v7-main-BnLYJKUJ.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1620 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/index.html
- 行号: 14
- 证据: `href="/assets/v7-main-CX8Eti5V.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1621 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/index.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1622 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1623 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-BA8C34v7.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1624 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1625 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/legacy.html
- 行号: 4
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1626 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/legacy.html
- 行号: 5
- 证据: `href="/assets/input-BKQzqN7g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1627 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/legacy.html
- 行号: 6
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1628 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v2.html
- 行号: 3
- 证据: `src="/assets/v2-DY1pOQ31.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1629 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v2.html
- 行号: 4
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1630 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v2.html
- 行号: 5
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1631 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v2.html
- 行号: 6
- 证据: `href="/assets/input-BKQzqN7g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1632 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v2.html
- 行号: 7
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1633 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v3.html
- 行号: 2
- 证据: `src="/assets/v3-DaoRt3cU.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1634 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v3.html
- 行号: 3
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1635 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v3.html
- 行号: 4
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1636 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v3.html
- 行号: 5
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1637 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v3.html
- 行号: 6
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1638 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v3.html
- 行号: 7
- 证据: `href="/assets/surface-gaEh7IZv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1639 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v3.html
- 行号: 8
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1640 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v4.html
- 行号: 2
- 证据: `src="/assets/v4-Cq3s8Rij.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1641 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v4.html
- 行号: 3
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1642 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v4.html
- 行号: 4
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1643 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v4.html
- 行号: 5
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1644 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v4.html
- 行号: 6
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1645 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v4.html
- 行号: 7
- 证据: `href="/assets/surface-gaEh7IZv.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1646 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v4.html
- 行号: 8
- 证据: `href="/assets/collection-D358q2Dj.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1647 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v4.html
- 行号: 9
- 证据: `href="/assets/collection-CIHM6rhH.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1648 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v6.html
- 行号: 10
- 证据: `src="/assets/v6-DFbii2rT.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1649 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v6.html
- 行号: 11
- 证据: `href="/assets/dom-BSoZuMJB.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1650 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v6.html
- 行号: 12
- 证据: `href="/assets/impact-DF2m9NKI.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1651 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v6.html
- 行号: 13
- 证据: `href="/assets/sword-art-ve6p6KDu.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1652 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v6.html
- 行号: 14
- 证据: `href="/assets/timing-CSM9H-5A.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1653 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v6.html
- 行号: 15
- 证据: `href="/assets/direct-strike-input-B92c14uR.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1654 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v6.html
- 行号: 16
- 证据: `href="/assets/v6-BCoGnu87.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1655 固定资源/导航路径
- 文件: tmp/previews/v1-release-06/v6.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1656 JavaScript协议
- 文件: tmp/research/2026-10-19-forgetax-deep/store-html.html
- 行号: 646
- 证据: `javascript:void(0)`
- 原因: JavaScript协议可以在浏览器上下文执行代码。
- 修复: 移除协议，使用事件监听及安全相对URL。

### H-1657 固定资源/导航路径
- 文件: tmp/research/2026-10-19-forgetax-deep/store-html.html
- 行号: 8
- 证据: `href="/favicon.ico"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1658 JavaScript协议
- 文件: tmp/research/2026-10-19-forgetax-deep/store-html.html
- 行号: 890
- 证据: `javascript:void(0)`
- 原因: JavaScript协议可以在浏览器上下文执行代码。
- 修复: 移除协议，使用事件监听及安全相对URL。

### H-1659 JavaScript协议
- 文件: tmp/research/2026-10-19-forgetax-deep/store-html.html
- 行号: 893
- 证据: `javascript:void(0)`
- 原因: JavaScript协议可以在浏览器上下文执行代码。
- 修复: 移除协议，使用事件监听及安全相对URL。

### H-1660 JavaScript协议
- 文件: tmp/research/2026-10-19-forgetax-deep/store-html.html
- 行号: 941
- 证据: `javascript:addToCart(1814364);`
- 原因: JavaScript协议可以在浏览器上下文执行代码。
- 修复: 移除协议，使用事件监听及安全相对URL。

### H-1661 固定资源/导航路径
- 文件: tmp/T11-4-2-3e/interrupted-worker-artifacts/traces/resources/722b83b5a042c12b8370ae671b8a869dc5ba3d40.html
- 行号: 2
- 证据: `src="/assets/main-CfV13K74.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1662 固定资源/导航路径
- 文件: tmp/T11-4-2-3e/interrupted-worker-artifacts/traces/resources/722b83b5a042c12b8370ae671b8a869dc5ba3d40.html
- 行号: 3
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1663 固定资源/导航路径
- 文件: tmp/T11-4-2-3e/interrupted-worker-artifacts/traces/resources/722b83b5a042c12b8370ae671b8a869dc5ba3d40.html
- 行号: 4
- 证据: `href="/assets/main-BRoht38P.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1664 固定资源/导航路径
- 文件: tmp/T11-4-2-3g/interrupted-full/artifacts/.playwright-artifacts-2/traces/resources/17c31b32bcefeb96295411f4188ed4bae9412f99.html
- 行号: 2
- 证据: `src="/assets/main-BAkmLsCL.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1665 固定资源/导航路径
- 文件: tmp/T11-4-2-3g/interrupted-full/artifacts/.playwright-artifacts-2/traces/resources/17c31b32bcefeb96295411f4188ed4bae9412f99.html
- 行号: 3
- 证据: `href="/assets/dom-BERwQvV5.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1666 固定资源/导航路径
- 文件: tmp/T11-4-2-3g/interrupted-full/artifacts/.playwright-artifacts-2/traces/resources/17c31b32bcefeb96295411f4188ed4bae9412f99.html
- 行号: 4
- 证据: `href="/assets/main-D9ZvR9wR.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1667 固定资源/导航路径
- 文件: tmp/T11-4-2-3i3/forge-initial-all/results/.playwright-artifacts-1/traces/resources/39977622651a63e0c7a7c83665ca4d5840673872.html
- 行号: 3
- 证据: `src="/@vite/client"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1668 固定资源/导航路径
- 文件: tmp/T11-4-2-3i3/forge-initial-all/results/.playwright-artifacts-1/traces/resources/39977622651a63e0c7a7c83665ca4d5840673872.html
- 行号: 4
- 证据: `src="/src/v4-main.ts?t=1792491998078"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1669 固定资源/导航路径
- 文件: tmp/T11-4-2-3i3/forge-initial-all/results/.playwright-artifacts-1/traces/resources/4392da2adeab3d66df7e223a83b2c76091406826.html
- 行号: 3
- 证据: `src="/@vite/client"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1670 固定资源/导航路径
- 文件: tmp/T11-4-2-3i3/forge-initial-all/results/.playwright-artifacts-1/traces/resources/4392da2adeab3d66df7e223a83b2c76091406826.html
- 行号: 4
- 证据: `src="/src/v4-main.ts?t=1792491930145"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1671 固定资源/导航路径
- 文件: tmp/T11-4-2-3i3/pilot/forge-pilot-original/results/.playwright-artifacts-1/traces/resources/39977622651a63e0c7a7c83665ca4d5840673872.html
- 行号: 3
- 证据: `src="/@vite/client"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1672 固定资源/导航路径
- 文件: tmp/T11-4-2-3i3/pilot/forge-pilot-original/results/.playwright-artifacts-1/traces/resources/39977622651a63e0c7a7c83665ca4d5840673872.html
- 行号: 4
- 证据: `src="/src/v4-main.ts?t=1792491998078"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1673 固定资源/导航路径
- 文件: tmp/T11-4-2-3i3/pilot/forge-pilot-original/results/.playwright-artifacts-1/traces/resources/4392da2adeab3d66df7e223a83b2c76091406826.html
- 行号: 3
- 证据: `src="/@vite/client"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1674 固定资源/导航路径
- 文件: tmp/T11-4-2-3i3/pilot/forge-pilot-original/results/.playwright-artifacts-1/traces/resources/4392da2adeab3d66df7e223a83b2c76091406826.html
- 行号: 4
- 证据: `src="/src/v4-main.ts?t=1792491930145"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1675 固定资源/导航路径
- 文件: tmp/T11-4-2-3i3/release-initial/forge-records/results/.playwright-artifacts-1/traces/resources/39977622651a63e0c7a7c83665ca4d5840673872.html
- 行号: 3
- 证据: `src="/@vite/client"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1676 固定资源/导航路径
- 文件: tmp/T11-4-2-3i3/release-initial/forge-records/results/.playwright-artifacts-1/traces/resources/39977622651a63e0c7a7c83665ca4d5840673872.html
- 行号: 4
- 证据: `src="/src/v4-main.ts?t=1792491998078"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1677 固定资源/导航路径
- 文件: tmp/T11-4-2-3i3/release-initial/forge-records/results/.playwright-artifacts-1/traces/resources/4392da2adeab3d66df7e223a83b2c76091406826.html
- 行号: 3
- 证据: `src="/@vite/client"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1678 固定资源/导航路径
- 文件: tmp/T11-4-2-3i3/release-initial/forge-records/results/.playwright-artifacts-1/traces/resources/4392da2adeab3d66df7e223a83b2c76091406826.html
- 行号: 4
- 证据: `src="/src/v4-main.ts?t=1792491930145"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1679 固定资源/导航路径
- 文件: tmp/T11-4-2-3i5/before-listen/dist__index.html
- 行号: 2
- 证据: `src="/assets/main-nr1F7AK6.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1680 固定资源/导航路径
- 文件: tmp/T11-4-2-3i5/before-listen/dist__index.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1681 固定资源/导航路径
- 文件: tmp/T11-4-2-3i5/before-listen/dist__index.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1682 固定资源/导航路径
- 文件: tmp/T11-4-2-3i5/before-listen/dist__index.html
- 行号: 5
- 证据: `href="/assets/main-DUAkKPfG.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1683 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence-fixed/runtime/index.html
- 行号: 2
- 证据: `src="/assets/main-DYDg36dL.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1684 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence-fixed/runtime/index.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1685 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence-fixed/runtime/index.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1686 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence-fixed/runtime/index.html
- 行号: 5
- 证据: `href="/assets/main-Cs7wa2SA.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1687 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence-fixed/runtime/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1688 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence-fixed/runtime/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-BEbDMbhp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1689 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence-fixed/runtime/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1690 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence-fixed/runtime/legacy.html
- 行号: 4
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1691 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence-fixed/runtime/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1692 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence-fixed/runtime/v2.html
- 行号: 3
- 证据: `src="/assets/v2-DiTiUVti.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1693 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence-fixed/runtime/v2.html
- 行号: 4
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1694 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence-fixed/runtime/v2.html
- 行号: 5
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1695 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence-fixed/runtime/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1696 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence-fixed/runtime/v3.html
- 行号: 2
- 证据: `src="/assets/v3-DOzLDQhh.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1697 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence-fixed/runtime/v3.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1698 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence-fixed/runtime/v3.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1699 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence-fixed/runtime/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1700 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence/runtime/index.html
- 行号: 2
- 证据: `src="/assets/main-DYDg36dL.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1701 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence/runtime/index.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1702 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence/runtime/index.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1703 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence/runtime/index.html
- 行号: 5
- 证据: `href="/assets/main-Cs7wa2SA.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1704 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence/runtime/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1705 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence/runtime/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-BEbDMbhp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1706 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence/runtime/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1707 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence/runtime/legacy.html
- 行号: 4
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1708 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence/runtime/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1709 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence/runtime/v2.html
- 行号: 3
- 证据: `src="/assets/v2-DiTiUVti.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1710 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence/runtime/v2.html
- 行号: 4
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1711 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence/runtime/v2.html
- 行号: 5
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1712 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence/runtime/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1713 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence/runtime/v3.html
- 行号: 2
- 证据: `src="/assets/v3-DOzLDQhh.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1714 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence/runtime/v3.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1715 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence/runtime/v3.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1716 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/before-guidance-evidence/runtime/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1717 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final-v2/runtime/index.html
- 行号: 2
- 证据: `src="/assets/main-DhAm8t4z.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1718 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final-v2/runtime/index.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1719 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final-v2/runtime/index.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1720 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final-v2/runtime/index.html
- 行号: 5
- 证据: `href="/assets/main-Cs7wa2SA.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1721 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final-v2/runtime/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1722 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final-v2/runtime/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-BEbDMbhp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1723 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final-v2/runtime/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1724 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final-v2/runtime/legacy.html
- 行号: 4
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1725 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final-v2/runtime/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1726 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final-v2/runtime/v2.html
- 行号: 3
- 证据: `src="/assets/v2-DiTiUVti.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1727 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final-v2/runtime/v2.html
- 行号: 4
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1728 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final-v2/runtime/v2.html
- 行号: 5
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1729 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final-v2/runtime/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1730 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final-v2/runtime/v3.html
- 行号: 2
- 证据: `src="/assets/v3-DOzLDQhh.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1731 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final-v2/runtime/v3.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1732 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final-v2/runtime/v3.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1733 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final-v2/runtime/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1734 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final/runtime/index.html
- 行号: 2
- 证据: `src="/assets/main-DhAm8t4z.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1735 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final/runtime/index.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1736 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final/runtime/index.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1737 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final/runtime/index.html
- 行号: 5
- 证据: `href="/assets/main-Cs7wa2SA.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1738 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final/runtime/legacy.html
- 行号: 2
- 证据: `href="/assets/b/tokens.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1739 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final/runtime/legacy.html
- 行号: 2
- 证据: `src="/assets/legacy-BEbDMbhp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1740 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final/runtime/legacy.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1741 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final/runtime/legacy.html
- 行号: 4
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1742 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final/runtime/legacy.html
- 行号: 5
- 证据: `href="/assets/legacy-CidoUqtJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1743 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final/runtime/v2.html
- 行号: 3
- 证据: `src="/assets/v2-DiTiUVti.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1744 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final/runtime/v2.html
- 行号: 4
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1745 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final/runtime/v2.html
- 行号: 5
- 证据: `href="/assets/input-B0NTSK-g.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1746 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final/runtime/v2.html
- 行号: 6
- 证据: `href="/assets/v2-BgGChR3Q.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1747 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final/runtime/v3.html
- 行号: 2
- 证据: `src="/assets/v3-DOzLDQhh.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1748 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final/runtime/v3.html
- 行号: 3
- 证据: `href="/assets/dom-DOqb_Hkx.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1749 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final/runtime/v3.html
- 行号: 4
- 证据: `href="/assets/surface-C7W-Wbjp.js"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1750 固定资源/导航路径
- 文件: tmp/T11-4-2-3i6/guidance-final/runtime/v3.html
- 行号: 5
- 证据: `href="/assets/v3-D_5nutBJ.css"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1751 固定资源/导航路径
- 文件: tmp/T11-4-2-3l4/initial-source/index.html
- 行号: 2
- 证据: `src="/src/v5-main.ts"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1752 固定资源/导航路径
- 文件: v2.html
- 行号: 4
- 证据: `src="/src/v2-main.ts"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1753 固定资源/导航路径
- 文件: v3.html
- 行号: 2
- 证据: `src="/src/v3-main.ts"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1754 固定资源/导航路径
- 文件: v4.html
- 行号: 2
- 证据: `src="/src/v4-main.ts"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1755 固定资源/导航路径
- 文件: v6.html
- 行号: 11
- 证据: `src="/src/v6-main.ts"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1756 固定资源/导航路径
- 文件: v6.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1757 固定资源/导航路径
- 文件: v8.html
- 行号: 11
- 证据: `src="/src/v8-main.ts"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

### H-1758 固定资源/导航路径
- 文件: v8.html
- 行号: 8
- 证据: `href="/favicon.svg"`
- 原因: 固定根路径或本机路径依赖特定部署位置，子目录静态托管可能失效。
- 修复: 改为包内相对路径并配置base: "./"。

## 中风险

### M-1 中文路径
- 文件: docs/evidence/G4-T03-recovery-progress/originals/tmp/goal4-T03/runs/native-04/native/native-chrome/clean-cache/downloads/clean-restored-current-memory/灯炉行程-v5-journey.json.gz
- 行号: N/A
- 证据: `docs/evidence/G4-T03-recovery-progress/originals/tmp/goal4-T03/runs/native-04/native/native-chrome/clean-cache/downloads/clean-restored-current-memory/灯炉行程-v5-journey.json.gz`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-2 中文路径
- 文件: docs/evidence/G4-T03-recovery-progress/originals/tmp/goal4-T03/runs/native-04/native/native-chrome/clean-cache/downloads/explicitly-reacquired-latest/灯炉行程-v5-journey.json.gz
- 行号: N/A
- 证据: `docs/evidence/G4-T03-recovery-progress/originals/tmp/goal4-T03/runs/native-04/native/native-chrome/clean-cache/downloads/explicitly-reacquired-latest/灯炉行程-v5-journey.json.gz`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-3 中文路径
- 文件: docs/evidence/G4-T03-recovery-progress/originals/tmp/goal4-T03/runs/native-04/native/native-chrome/dirty-cache/downloads/dirty-accepted-before-navigation/灯炉行程-v5-journey.json.gz
- 行号: N/A
- 证据: `docs/evidence/G4-T03-recovery-progress/originals/tmp/goal4-T03/runs/native-04/native/native-chrome/dirty-cache/downloads/dirty-accepted-before-navigation/灯炉行程-v5-journey.json.gz`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-4 中文路径
- 文件: docs/evidence/G4-T03-recovery-progress/originals/tmp/goal4-T03/runs/native-04/native/native-chrome/dirty-cache/downloads/explicitly-reacquired-latest/灯炉行程-v5-journey.json.gz
- 行号: N/A
- 证据: `docs/evidence/G4-T03-recovery-progress/originals/tmp/goal4-T03/runs/native-04/native/native-chrome/dirty-cache/downloads/explicitly-reacquired-latest/灯炉行程-v5-journey.json.gz`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-5 中文路径
- 文件: docs/evidence/G4-T03-recovery-progress/originals/tmp/goal4-T03/runs/native-04/native/native-chrome/dirty-cache/downloads/retained-unsaved-or-memory-after-cache/灯炉行程-v5-journey.json.gz
- 行号: N/A
- 证据: `docs/evidence/G4-T03-recovery-progress/originals/tmp/goal4-T03/runs/native-04/native/native-chrome/dirty-cache/downloads/retained-unsaved-or-memory-after-cache/灯炉行程-v5-journey.json.gz`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-6 中文路径
- 文件: docs/evidence/G4-T03-recovery-progress/originals/tmp/goal4-T03/runs/native-04/native/native-chrome/memory-cache/downloads/memory-before-navigation/灯炉行程-v5-journey.json.gz
- 行号: N/A
- 证据: `docs/evidence/G4-T03-recovery-progress/originals/tmp/goal4-T03/runs/native-04/native/native-chrome/memory-cache/downloads/memory-before-navigation/灯炉行程-v5-journey.json.gz`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-7 中文路径
- 文件: docs/evidence/G4-T03-recovery-progress/originals/tmp/goal4-T03/runs/native-04/native/native-chrome/memory-cache/downloads/new-memory-command-after-cache/灯炉行程-v5-journey.json.gz
- 行号: N/A
- 证据: `docs/evidence/G4-T03-recovery-progress/originals/tmp/goal4-T03/runs/native-04/native/native-chrome/memory-cache/downloads/new-memory-command-after-cache/灯炉行程-v5-journey.json.gz`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-8 中文路径
- 文件: docs/evidence/G4-T03-recovery-progress/originals/tmp/goal4-T03/runs/native-04/native/native-chrome/memory-cache/downloads/retained-unsaved-or-memory-after-cache/灯炉行程-v5-journey.json.gz
- 行号: N/A
- 证据: `docs/evidence/G4-T03-recovery-progress/originals/tmp/goal4-T03/runs/native-04/native/native-chrome/memory-cache/downloads/retained-unsaved-or-memory-after-cache/灯炉行程-v5-journey.json.gz`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-9 中文路径
- 文件: docs/evidence/G4-T03-recovery-progress/originals/tmp/goal4-T03/runs/native-04/native/native-chrome/stale-cache/downloads/clean-restored-current-memory/灯炉行程-v5-journey.json.gz
- 行号: N/A
- 证据: `docs/evidence/G4-T03-recovery-progress/originals/tmp/goal4-T03/runs/native-04/native/native-chrome/stale-cache/downloads/clean-restored-current-memory/灯炉行程-v5-journey.json.gz`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-10 中文路径
- 文件: docs/evidence/G4-T03-recovery-progress/originals/tmp/goal4-T03/runs/native-04/native/native-chrome/stale-cache/downloads/explicitly-reacquired-latest/灯炉行程-v5-journey.json.gz
- 行号: N/A
- 证据: `docs/evidence/G4-T03-recovery-progress/originals/tmp/goal4-T03/runs/native-04/native/native-chrome/stale-cache/downloads/explicitly-reacquired-latest/灯炉行程-v5-journey.json.gz`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-11 中文路径
- 文件: tmp/goal4-T03/runs/native-01/native/native-chrome/clean-cache/downloads/clean-restored-current-memory/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-01/native/native-chrome/clean-cache/downloads/clean-restored-current-memory/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-12 中文路径
- 文件: tmp/goal4-T03/runs/native-01/native/native-chrome/dirty-cache/downloads/dirty-accepted-before-navigation/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-01/native/native-chrome/dirty-cache/downloads/dirty-accepted-before-navigation/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-13 中文路径
- 文件: tmp/goal4-T03/runs/native-01/native/native-chrome/dirty-cache/downloads/retained-unsaved-or-memory-after-cache/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-01/native/native-chrome/dirty-cache/downloads/retained-unsaved-or-memory-after-cache/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-14 中文路径
- 文件: tmp/goal4-T03/runs/native-01/native/native-chrome/memory-cache/downloads/memory-before-navigation/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-01/native/native-chrome/memory-cache/downloads/memory-before-navigation/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-15 中文路径
- 文件: tmp/goal4-T03/runs/native-01/native/native-chrome/memory-cache/downloads/new-memory-command-after-cache/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-01/native/native-chrome/memory-cache/downloads/new-memory-command-after-cache/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-16 中文路径
- 文件: tmp/goal4-T03/runs/native-01/native/native-chrome/memory-cache/downloads/retained-unsaved-or-memory-after-cache/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-01/native/native-chrome/memory-cache/downloads/retained-unsaved-or-memory-after-cache/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-17 中文路径
- 文件: tmp/goal4-T03/runs/native-01/native/native-chrome/stale-cache/downloads/clean-restored-current-memory/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-01/native/native-chrome/stale-cache/downloads/clean-restored-current-memory/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-18 中文路径
- 文件: tmp/goal4-T03/runs/native-02/native/native-chrome/clean-cache/downloads/clean-restored-current-memory/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-02/native/native-chrome/clean-cache/downloads/clean-restored-current-memory/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-19 中文路径
- 文件: tmp/goal4-T03/runs/native-02/native/native-chrome/clean-cache/downloads/explicitly-reacquired-latest/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-02/native/native-chrome/clean-cache/downloads/explicitly-reacquired-latest/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-20 中文路径
- 文件: tmp/goal4-T03/runs/native-02/native/native-chrome/dirty-cache/downloads/dirty-accepted-before-navigation/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-02/native/native-chrome/dirty-cache/downloads/dirty-accepted-before-navigation/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-21 中文路径
- 文件: tmp/goal4-T03/runs/native-02/native/native-chrome/dirty-cache/downloads/explicitly-reacquired-latest/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-02/native/native-chrome/dirty-cache/downloads/explicitly-reacquired-latest/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-22 中文路径
- 文件: tmp/goal4-T03/runs/native-02/native/native-chrome/dirty-cache/downloads/retained-unsaved-or-memory-after-cache/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-02/native/native-chrome/dirty-cache/downloads/retained-unsaved-or-memory-after-cache/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-23 中文路径
- 文件: tmp/goal4-T03/runs/native-02/native/native-chrome/memory-cache/downloads/memory-before-navigation/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-02/native/native-chrome/memory-cache/downloads/memory-before-navigation/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-24 中文路径
- 文件: tmp/goal4-T03/runs/native-02/native/native-chrome/memory-cache/downloads/new-memory-command-after-cache/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-02/native/native-chrome/memory-cache/downloads/new-memory-command-after-cache/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-25 中文路径
- 文件: tmp/goal4-T03/runs/native-02/native/native-chrome/memory-cache/downloads/retained-unsaved-or-memory-after-cache/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-02/native/native-chrome/memory-cache/downloads/retained-unsaved-or-memory-after-cache/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-26 中文路径
- 文件: tmp/goal4-T03/runs/native-02/native/native-chrome/stale-cache/downloads/clean-restored-current-memory/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-02/native/native-chrome/stale-cache/downloads/clean-restored-current-memory/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-27 中文路径
- 文件: tmp/goal4-T03/runs/native-02/native/native-chrome/stale-cache/downloads/explicitly-reacquired-latest/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-02/native/native-chrome/stale-cache/downloads/explicitly-reacquired-latest/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-28 中文路径
- 文件: tmp/goal4-T03/runs/native-04/native/native-chrome/clean-cache/downloads/clean-restored-current-memory/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-04/native/native-chrome/clean-cache/downloads/clean-restored-current-memory/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-29 中文路径
- 文件: tmp/goal4-T03/runs/native-04/native/native-chrome/clean-cache/downloads/explicitly-reacquired-latest/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-04/native/native-chrome/clean-cache/downloads/explicitly-reacquired-latest/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-30 中文路径
- 文件: tmp/goal4-T03/runs/native-04/native/native-chrome/dirty-cache/downloads/dirty-accepted-before-navigation/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-04/native/native-chrome/dirty-cache/downloads/dirty-accepted-before-navigation/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-31 中文路径
- 文件: tmp/goal4-T03/runs/native-04/native/native-chrome/dirty-cache/downloads/explicitly-reacquired-latest/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-04/native/native-chrome/dirty-cache/downloads/explicitly-reacquired-latest/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-32 中文路径
- 文件: tmp/goal4-T03/runs/native-04/native/native-chrome/dirty-cache/downloads/retained-unsaved-or-memory-after-cache/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-04/native/native-chrome/dirty-cache/downloads/retained-unsaved-or-memory-after-cache/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-33 中文路径
- 文件: tmp/goal4-T03/runs/native-04/native/native-chrome/memory-cache/downloads/memory-before-navigation/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-04/native/native-chrome/memory-cache/downloads/memory-before-navigation/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-34 中文路径
- 文件: tmp/goal4-T03/runs/native-04/native/native-chrome/memory-cache/downloads/new-memory-command-after-cache/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-04/native/native-chrome/memory-cache/downloads/new-memory-command-after-cache/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-35 中文路径
- 文件: tmp/goal4-T03/runs/native-04/native/native-chrome/memory-cache/downloads/retained-unsaved-or-memory-after-cache/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-04/native/native-chrome/memory-cache/downloads/retained-unsaved-or-memory-after-cache/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-36 中文路径
- 文件: tmp/goal4-T03/runs/native-04/native/native-chrome/stale-cache/downloads/clean-restored-current-memory/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-04/native/native-chrome/stale-cache/downloads/clean-restored-current-memory/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

### M-37 中文路径
- 文件: tmp/goal4-T03/runs/native-04/native/native-chrome/stale-cache/downloads/explicitly-reacquired-latest/灯炉行程-v5-journey.json
- 行号: N/A
- 证据: `tmp/goal4-T03/runs/native-04/native/native-chrome/stale-cache/downloads/explicitly-reacquired-latest/灯炉行程-v5-journey.json`
- 原因: 路径包含中文，可能影响URL编码或静态托管兼容性。
- 修复: 使用ASCII名称并同步引用；历史证据应保留原始身份。

## 需人工复核

## 建议修复顺序

1. 当前发布高风险命中。
2. 中风险兼容性。
3. 历史内容单列、保持证据身份；不能证明不存在所有漏洞。
