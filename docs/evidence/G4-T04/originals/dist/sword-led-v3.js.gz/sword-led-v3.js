import { d as e, l as t, p as n, r, u as i } from "./core-CvAZnNjA.js";
import { d as a, i as o, s, t as c, u as l } from "./browser-session-BQdQqpuu.js";
import { a as u, c as d, d as f, i as p, l as m, n as h, o as g, r as _, s as v, t as y, u as b } from "./rules-CAo3EZyg.js";
//#region src/core-v3/game.ts
var x = (e) => structuredClone(e), S = (e) => typeof e == "string" && _.some((t) => t === e), C = (e, t) => ({
	ok: !1,
	state: e,
	error: t,
	events: []
});
function w(e, t, n) {
	let r = i(e.rng[t]);
	return e.rng[t] = r.stream, Math.floor(r.value * n);
}
function T(e) {
	let t = Math.min(e.base * 4, e.pendingInheritance);
	e.pendingInheritance = 0;
	for (let n = 1; n <= 3; n++) {
		let r = e.base + (n === 1 ? t : 0);
		e.blades.push({
			id: `r${e.round}-${n}`,
			suppliedRound: e.round,
			status: "active",
			base: r,
			value: r,
			peak: r,
			level: 0,
			cracked: !1,
			hits: 0,
			charge: 0,
			successes: 0,
			finalizedRound: null
		});
	}
	if (e.shop = [], e.sold = [], e.upgraded = !1, e.repaired = !1, [
		3,
		6,
		9
	].includes(e.round)) {
		let t = _.filter((t) => !e.traits.includes(t));
		for (; e.shop.length < 2 && t.length;) {
			let n = t.splice(w(e, "shop", t.length), 1)[0];
			n && e.shop.push(n);
		}
	}
}
function E(r) {
	if (!e(r) || typeof r.runId != "string" || !/^[A-Za-z0-9_-]{1,80}$/.test(r.runId)) return {
		ok: !1,
		error: "invalid_run_id"
	};
	if (typeof r.seed != "string") return {
		ok: !1,
		error: "invalid_seed"
	};
	let i = r.seed.normalize("NFC").trim();
	if (!i || Array.from(i).length > 64) return {
		ok: !1,
		error: "invalid_seed"
	};
	if (r.roundLimit !== void 0 && r.roundLimit !== 3 && r.roundLimit !== 12) return {
		ok: !1,
		error: "invalid_command"
	};
	let a = {
		rulesVersion: "forge-v3",
		runId: r.runId,
		seed: i,
		roundLimit: r.roundLimit ?? 3,
		revision: 0,
		phase: "workshop",
		round: 1,
		coins: 0,
		seals: 3,
		base: 40,
		blades: [],
		reserveId: null,
		delivered: 0,
		traits: [],
		gift: "locked",
		pardonUsed: !1,
		pendingInheritance: 0,
		shop: [],
		sold: [],
		upgraded: !1,
		repaired: !1,
		history: [],
		rng: {
			forge: {
				state: t(`${i}|v3|forge`),
				draws: 0
			},
			shop: {
				state: t(`${i}|v3|shop`),
				draws: 0
			}
		},
		journal: []
	};
	return T(a), n({
		ok: !0,
		state: a
	});
}
function D(t) {
	if (!e(t)) return null;
	let n = Object.keys(t).sort().join(",");
	switch (t.type) {
		case "strike":
		case "deliver":
		case "scrap":
		case "reserve": return n === "pieceId,type" && typeof t.pieceId == "string" ? {
			type: t.type,
			pieceId: t.pieceId
		} : null;
		case "upgrade":
		case "repair":
		case "settle":
		case "advance": return n === "type" ? { type: t.type } : null;
		case "buy":
		case "claimGift": return t.type === "buy" && typeof t.pieceId != "string" || !S(t.traitId) && (t.type !== "claimGift" || t.traitId !== null) || t.replaceId !== void 0 && !S(t.replaceId) || n !== [
			...t.type === "buy" ? ["pieceId"] : [],
			"traitId",
			"type",
			...t.replaceId === void 0 ? [] : ["replaceId"]
		].sort().join(",") ? null : t;
		default: return null;
	}
}
function O(e, t, n) {
	if (e.traits.includes(t)) return "already_owned";
	if (e.traits.length === 3) {
		if (!n || !e.traits.includes(n)) return "invalid_replacement";
		e.traits.splice(e.traits.indexOf(n), 1);
	} else if (n !== void 0) return "invalid_replacement";
	return e.traits.push(t), null;
}
function k(e, t, n) {
	let r = b(e, t), i = w(e, "forge", 1e3), a = t.value, o = [], s = i < (n ? 350 : r.great) ? "great" : !n && i < r.great + r.crack ? "crack" : "success";
	return n || t.hits++, s === "crack" ? t.cracked ? (s = "broken", t.status = "broken", t.finalizedRound = e.round, t.value = 0, e.coins += d(t), e.traits.includes("inherit") && (e.pendingInheritance += Math.floor(t.peak / 5), o.push("inherit"))) : (t.cracked = !0, e.traits.includes("steady") ? o.push("steady") : t.value = Math.floor(t.value * 80 / 100)) : (t.value = Math.min(p, Math.floor(t.value * (s === "great" ? 220 : 145) / 100)), t.level = Math.min(99, t.level + (s === "great" ? 2 : 1)), n || (t.successes++, e.traits.includes("echo") && t.successes % 3 == 0 && (t.value = Math.min(p, Math.floor(t.value * 125 / 100)), o.push("echo"))), !n && t.cracked && e.traits.includes("crackedEdge") && s === "great" && o.push("crackedEdge")), t.peak = Math.max(t.peak, t.value), !n && t.status === "active" && (t.charge = Math.min(6, t.charge + 1)), {
		result: s,
		before: a,
		after: t.value,
		level: t.level,
		triggers: o
	};
}
function A(t, i) {
	let a = r(i);
	if (!a) return C(t, "invalid_command");
	let o = JSON.parse(a);
	if (!e(o)) return C(t, "invalid_command");
	if (o.runId !== t.runId) return C(t, "wrong_run");
	if (o.expectedRevision !== t.revision) return C(t, "stale_revision");
	let s = D(o.action);
	if (!s) return C(t, "invalid_command");
	if (s.type === "advance" ? t.phase !== "summary" : t.phase !== "workshop") return C(t, "wrong_phase");
	if (t.journal.length >= 2048 || t.journal.length >= 1900 && [
		"strike",
		"buy",
		"claimGift",
		"upgrade",
		"repair"
	].includes(s.type) || t.journal.length >= 1900 && s.type === "reserve" && t.reserveId !== s.pieceId) return C(t, "record_limit");
	let c = x(t), l = [], p = "pieceId" in s ? c.blades.find((e) => e.id === s.pieceId) : void 0;
	if ("pieceId" in s && (!p || p.status !== "active")) return C(t, "piece_unavailable");
	if ("pieceId" in s && s.type !== "reserve" && c.reserveId === s.pieceId) return C(t, "reserved_piece");
	switch (s.type) {
		case "strike": {
			if (!p) return C(t, "piece_unavailable");
			if (u(p)) return C(t, "at_cap");
			let e = p.charge === 6, n = [];
			if (e) {
				p.charge = 0;
				let e = c.traits.includes("ember") ? 3 : 2;
				for (let t = 0; t < e && !u(p); t++) {
					let t = k(c, p, !0);
					n.push({
						...t,
						triggers: [...t.triggers, ...e === 3 ? ["ember"] : []]
					});
				}
			} else n.push(k(c, p, !1));
			l.push({
				type: "Strike",
				pieceId: p.id,
				burst: e,
				hits: n
			});
			break;
		}
		case "deliver":
		case "scrap": {
			if (!p) return C(t, "piece_unavailable");
			let e = s.type === "deliver" ? p.value : d(p);
			p.status = s.type === "deliver" ? "delivered" : "recycled", p.finalizedRound = c.round, c.coins += e, s.type === "deliver" && (c.delivered += e, c.gift === "locked" && c.delivered >= v(c.round) && (c.gift = "available")), l.push({
				type: s.type === "deliver" ? "Delivered" : "Recycled",
				pieceId: p.id,
				amount: e
			});
			break;
		}
		case "reserve": {
			if (!p) return C(t, "piece_unavailable");
			let e = c.reserveId;
			c.reserveId = e === p.id ? null : p.id, l.push({
				type: "Reserved",
				pieceId: p.id,
				previousId: e
			});
			break;
		}
		case "claimGift": {
			if (c.gift !== "available") return C(t, "unavailable");
			let e = ["steady", "ember"].filter((e) => !c.traits.includes(e));
			if (e.length === 0) {
				if (s.traitId !== null || s.replaceId !== void 0) return C(t, "unavailable");
				c.coins += 40;
			} else {
				if (s.traitId === null || !e.some((e) => e === s.traitId)) return C(t, "unavailable");
				let n = O(c, s.traitId, s.replaceId);
				if (n) return C(t, n);
			}
			c.gift = "claimed", l.push({
				type: "Trait",
				traitId: s.traitId
			});
			break;
		}
		case "buy": {
			if (!g(c)) return C(t, "no_shop");
			if (!c.shop.includes(s.traitId) || c.sold.includes(s.traitId)) return C(t, "sold_out");
			let e = O(c, s.traitId, s.replaceId);
			if (e) return C(t, e);
			if (!p) return C(t, "piece_unavailable");
			p.status = "traded", p.finalizedRound = c.round, c.sold.push(s.traitId), l.push({
				type: "Traded",
				pieceId: p.id,
				amount: p.value
			}, {
				type: "Trait",
				traitId: s.traitId
			});
			break;
		}
		case "upgrade":
		case "repair": {
			if (!g(c)) return C(t, "no_shop");
			if (s.type === "upgrade" ? c.upgraded : c.repaired || c.seals === 3) return C(t, "unavailable");
			let e = s.type === "upgrade" ? f(c.round) : Math.ceil(v(c.round) / 2);
			if (c.coins < e) return C(t, "insufficient_coins");
			c.coins -= e, s.type === "upgrade" ? (c.base *= 2, c.upgraded = !0, l.push({ type: "Upgraded" })) : (c.seals++, c.repaired = !0, l.push({ type: "Repaired" }));
			break;
		}
		case "settle": {
			let e = m(c), t = {
				round: c.round,
				quota: v(c.round),
				delivered: c.delivered,
				met: e.met,
				recovered: e.recovered,
				recoveredIds: e.remaining.map((e) => e.id),
				reserveId: c.reserveId,
				sealsBefore: c.seals,
				sealsAfter: e.sealsAfter,
				protected: e.protected
			};
			for (let e of c.blades) t.recoveredIds.includes(e.id) && (e.status = "recycled", e.finalizedRound = c.round);
			c.coins += e.recovered, c.seals = e.sealsAfter, e.protected && (c.pardonUsed = !0), c.history.push(t), c.phase = c.seals === 0 ? "defeat" : c.round === c.roundLimit ? c.roundLimit === 3 ? "experienceComplete" : "victory" : "summary", l.push({
				type: "Settled",
				summary: t
			});
			break;
		}
		case "advance": c.round++, c.phase = "workshop", c.delivered = 0, T(c), l.push({ type: "Advanced" });
	}
	return c.revision++, c.journal.push(s), n({
		ok: !0,
		state: c,
		events: l
	});
}
//#endregion
//#region src/core-v3/validate.ts
function j(t) {
	let n = r(t);
	if (!n) return {
		ok: !1,
		error: "invalid_state",
		detail: "Expected bounded plain JSON."
	};
	let i = JSON.parse(n);
	if (!e(i) || i.rulesVersion !== "forge-v3") return {
		ok: !1,
		error: "invalid_rules_version",
		detail: "Expected forge-v3."
	};
	if (typeof i.runId != "string" || typeof i.seed != "string" || i.roundLimit !== 3 && i.roundLimit !== 12 || !Array.isArray(i.journal)) return {
		ok: !1,
		error: "invalid_state",
		detail: "Missing identity or accepted journal."
	};
	let a = E({
		runId: i.runId,
		seed: i.seed,
		roundLimit: i.roundLimit
	});
	if (!a.ok) return {
		ok: !1,
		error: "invalid_state",
		detail: a.error
	};
	let o = a.state;
	for (let e of i.journal) {
		let t = A(o, {
			runId: o.runId,
			expectedRevision: o.revision,
			action: e
		});
		if (!t.ok) return {
			ok: !1,
			error: "invalid_journal",
			detail: t.error
		};
		o = t.state;
	}
	return r(o) === n ? {
		ok: !0,
		state: o
	} : {
		ok: !1,
		error: "invalid_state",
		detail: "Snapshot differs from deterministic replay."
	};
}
//#endregion
//#region src/application/v3-persistence.ts
var M = "sword-led.save.v3", N = "sword-led.save.backup.v3", P = Object.freeze({
	key: M,
	backupKey: N,
	schemaVersion: 3,
	rulesVersion: "forge-v3",
	validate: j
}), F = (e) => l(e, P), I = (e, t) => s(e, P, t);
function L(e = window) {
	return c(e, M, (t) => a(I(() => e.localStorage), o(t), {
		createRun: E,
		applyCommand: A
	}));
}
//#endregion
export { y as QUOTAS, h as TRAITS, _ as TRAIT_IDS, N as V3_BACKUP_KEY, M as V3_SAVE_KEY, p as VALUE_CAP, A as applyCommand, u as atCap, E as createRun, L as createV3BrowserSession, I as createV3SaveRepository, F as decodeV3Save, g as merchantPresent, D as parseAction, v as quotaFor, d as recovery, m as settlementPreview, b as strikeOdds, f as upgradePrice, j as validateRun };
