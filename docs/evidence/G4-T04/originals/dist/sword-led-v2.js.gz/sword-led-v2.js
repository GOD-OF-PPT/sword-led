import { d as e, l as t, p as n, r, u as i } from "./core-CvAZnNjA.js";
import { d as a, i as o, s, t as c, u as l } from "./browser-session-BQdQqpuu.js";
//#region src/core-v2/rules.ts
var u = "forge-v2", d = Object.freeze([
	150,
	180,
	210,
	250,
	290,
	330,
	380,
	430,
	480,
	540,
	600,
	660
]), f = n({
	iron: {
		label: "熟铁",
		value: 18,
		integrity: 4,
		threshold: 40,
		scrap: 3,
		ratings: {
			edge: 0,
			toughness: 2,
			balance: 0
		}
	},
	steel: {
		label: "精钢",
		value: 22,
		integrity: 3,
		threshold: 36,
		scrap: 4,
		ratings: {
			edge: 2,
			toughness: 0,
			balance: 0
		}
	},
	meteorite: {
		label: "陨铁",
		value: 28,
		integrity: 2,
		threshold: 32,
		scrap: 5,
		ratings: {
			edge: 0,
			toughness: 0,
			balance: 2
		}
	}
}), p = n({
	light: {
		label: "轻锤",
		force: 1,
		heat: 8,
		stress: 1,
		periodMs: 1600
	},
	standard: {
		label: "平锤",
		force: 3,
		heat: 16,
		stress: 6,
		periodMs: 1400
	},
	heavy: {
		label: "重锤",
		force: 5,
		heat: 24,
		stress: 12,
		periodMs: 1200
	}
}), m = Object.freeze({
	edge: "锋",
	toughness: "韧",
	balance: "衡"
}), h = Object.freeze({
	edge: "巡锋",
	spine: "守脊",
	bridge: "游衡"
});
Object.freeze([
	"剑尖",
	"前刃",
	"中段",
	"根部",
	"剑茎"
]);
var g = n({
	edgeTooth: {
		label: "巡锋齿",
		effect: "巡锋奖励从 +2锋变为 +4锋",
		coins: 100,
		scrap: 3
	},
	bridgeClip: {
		label: "桥脊扣",
		effect: "形成游衡后，本剑水淬免除 +8应力",
		coins: 100,
		scrap: 3
	},
	reheatSand: {
		label: "回火砂",
		effect: "每件首次回火额外 +2韧",
		coins: 100,
		scrap: 3
	},
	warmTongs: {
		label: "余温钳",
		effect: "每件前两次重锤热耗 −4，应力额外 +2",
		coins: 160,
		scrap: 5
	},
	shardBox: {
		label: "断纹匣",
		effect: "每轮首件破碎额外 +4废料",
		coins: 160,
		scrap: 5
	},
	balanceWeight: {
		label: "匀衡砝",
		effect: "油淬前最高/最低属性差 ≤4，额外 +3衡",
		coins: 160,
		scrap: 5
	}
}), _ = Object.freeze(Object.keys(g)), ee = Object.freeze([
	"edgeTooth",
	"bridgeClip",
	"reheatSand"
]), te = Object.freeze({
	steady: "静炉",
	wetCoal: "湿煤：煤1，回收额外+1废料",
	brightFire: "旺炉：初热120，重锤应力+2",
	brittle: "脆脉：阈值−4，成品价值+20",
	urgent: "急件：委托额外+20，需指定锻纹",
	reclaimed: "旧器回炉：一项初始属性+2，底价−4"
}), v = n({
	guard: {
		label: "巡卫的守夜剑",
		needs: [["edge", 6], ["toughness", 5]],
		pattern: null
	},
	courier: {
		label: "信使的随身剑",
		needs: [["edge", 5], ["balance", 6]],
		pattern: null
	},
	hunter: {
		label: "猎手的开路剑",
		needs: [["edge", 8], ["balance", 3]],
		pattern: null
	},
	protector: {
		label: "护卫的挡击剑",
		needs: [["toughness", 8], ["balance", 3]],
		pattern: null
	},
	ceremony: {
		label: "仪仗的匀衡剑",
		needs: [["toughness", 4], ["balance", 7]],
		pattern: "bridge"
	},
	duelist: {
		label: "剑客的试锋剑",
		needs: [["edge", 7], ["toughness", 4]],
		pattern: "edge"
	}
}), y = Object.freeze(Object.keys(v));
function b(e, t, n) {
	let r = v[e], i = 2 * Math.floor((t - 1) / 3), a = r.pattern ? [r.pattern] : [];
	return n.pattern && !a.includes(n.pattern) && a.push(n.pattern), {
		id: `${t}:${e}`,
		kind: e,
		label: r.label,
		needs: r.needs.map(([e, t]) => ({
			stat: e,
			minimum: t + i
		})),
		patterns: a
	};
}
function x(e) {
	return d[e - 1] ?? 0;
}
function S(e) {
	let t = Math.abs(e - 5e3);
	return t <= 600 ? "precise" : t <= 2e3 ? "ordinary" : "mishit";
}
function C(e) {
	return e % 5 == 2 ? "balance" : e < 5 ? "edge" : "toughness";
}
function w(e, t) {
	return Math.abs(Math.floor(e / 5) - Math.floor(t / 5)) + Math.abs(e % 5 - t % 5) === 1;
}
function T(e) {
	return e.edge + e.toughness + e.balance;
}
function E(e) {
	return e.status === "broken" ? 0 : e.quench === null ? e.baseValue : Math.max(e.baseValue, e.baseValue + 4 * T(e.ratings) + 3 * Math.min(e.ratings.edge, e.ratings.toughness, e.ratings.balance) + 12 * e.patterns.length + (e.patterns.length === 3 ? 12 : 0) - 6 * (e.maxIntegrity - e.integrity) + e.temperedBonus);
}
function D(e, t) {
	return f[e.material].scrap + Math.floor(T(e.ratings) / 12) + +(t.kind === "wetCoal");
}
function O(e, t, n) {
	return e.quench === null || e.status === "broken" || !t.needs.every((t) => e.ratings[t.stat] >= t.minimum) || !t.patterns.every((t) => e.patterns.includes(t)) ? 0 : 40 + (t.needs.every((t) => e.ratings[t.stat] >= t.minimum + 3) ? 20 : 0) + (n.kind === "urgent" ? 20 : 0);
}
function k(e, t, n, r) {
	let i = f[n], a = { ...i.ratings };
	return r.stat && (a[r.stat] += 2), {
		id: `${e}:${t}`,
		material: n,
		baseValue: i.value - (r.kind === "reclaimed" ? 4 : 0),
		temperedBonus: r.kind === "brittle" ? 20 : 0,
		threshold: i.threshold - (r.kind === "brittle" ? 4 : 0),
		maxIntegrity: i.integrity,
		integrity: i.integrity,
		heat: r.kind === "brightFire" ? 120 : 100,
		stress: 0,
		ratings: a,
		nodes: Array(10).fill(0),
		chain: [],
		patterns: [],
		traces: [],
		strikes: 0,
		heavyStrikes: 0,
		reheats: 0,
		bridgeUsed: !1,
		quench: null,
		status: "active",
		paidValue: 0,
		recoveredScrap: 0
	};
}
//#endregion
//#region src/core-v2/game.ts
var A = (e) => structuredClone(e), j = (e) => typeof e == "string" && _.some((t) => t === e), M = (e, t, n) => typeof e == "number" && Number.isInteger(e) && e >= t && e <= n, N = (e, t) => ({
	ok: !1,
	state: e,
	error: t,
	events: []
});
function P(t) {
	if (!e(t)) return {
		ok: !1,
		error: "invalid_command"
	};
	let n = typeof t.pieceId == "string" ? t.pieceId : null;
	switch (t.type) {
		case "chooseTechnique": return j(t.techniqueId) ? {
			ok: !0,
			action: {
				type: t.type,
				techniqueId: t.techniqueId
			}
		} : {
			ok: !1,
			error: "invalid_technique"
		};
		case "chooseRequest": return t.requestId === null || typeof t.requestId == "string" ? {
			ok: !0,
			action: {
				type: t.type,
				requestId: t.requestId
			}
		} : {
			ok: !1,
			error: "invalid_request"
		};
		case "strike": return n ? M(t.node, 0, 9) ? t.mode !== "light" && t.mode !== "standard" && t.mode !== "heavy" ? {
			ok: !1,
			error: "invalid_hammer"
		} : M(t.timingMark, 0, 1e4) ? {
			ok: !0,
			action: {
				type: "strike",
				pieceId: n,
				node: t.node,
				mode: t.mode,
				timingMark: t.timingMark
			}
		} : {
			ok: !1,
			error: "invalid_timing"
		} : {
			ok: !1,
			error: "invalid_node"
		} : {
			ok: !1,
			error: "invalid_command"
		};
		case "reheat":
		case "deliver":
		case "scrap": return n ? {
			ok: !0,
			action: {
				type: t.type,
				pieceId: n
			}
		} : {
			ok: !1,
			error: "invalid_command"
		};
		case "quench": return n && (t.medium === "water" || t.medium === "oil") ? {
			ok: !0,
			action: {
				type: "quench",
				pieceId: n,
				medium: t.medium
			}
		} : {
			ok: !1,
			error: "invalid_command"
		};
		case "settleRound": return typeof t.recycleRemaining == "boolean" ? {
			ok: !0,
			action: {
				type: "settleRound",
				recycleRemaining: t.recycleRemaining
			}
		} : {
			ok: !1,
			error: "invalid_command"
		};
		case "buy": return t.productId !== "repair" && !j(t.productId) ? {
			ok: !1,
			error: "invalid_technique"
		} : t.replaceId !== void 0 && !j(t.replaceId) ? {
			ok: !1,
			error: "invalid_replacement"
		} : {
			ok: !0,
			action: {
				type: "buy",
				productId: t.productId,
				...t.replaceId === void 0 ? {} : { replaceId: t.replaceId }
			}
		};
		case "advanceSummary":
		case "leaveMerchant": return {
			ok: !0,
			action: { type: t.type }
		};
		default: return {
			ok: !1,
			error: "invalid_command"
		};
	}
}
function F(e, t, n) {
	let r = i(e.rng[t]);
	return e.rng[t] = A(r.stream), Math.floor(r.value * n);
}
function I(e, t) {
	let n = e.condition.kind, r = {
		kind: "steady",
		stat: null,
		pattern: null
	};
	if (t >= 4) {
		let t = [
			"steady",
			"wetCoal",
			"brightFire",
			"brittle",
			"urgent",
			"reclaimed"
		].filter((e) => e !== n), i = t[F(e, "conditions", t.length)] ?? "steady";
		r = {
			kind: i,
			stat: i === "reclaimed" ? [
				"edge",
				"toughness",
				"balance"
			][F(e, "conditions", 3)] ?? "edge" : null,
			pattern: i === "urgent" ? [
				"edge",
				"spine",
				"bridge"
			][F(e, "conditions", 3)] ?? "edge" : null
		};
	}
	e.condition = A(r), e.coal = r.kind === "wetCoal" ? 1 : 2;
	let i = t === 1 ? "steel" : [
		"iron",
		"steel",
		"meteorite"
	][(() => {
		let t = F(e, "stock", 100);
		return t < 35 ? 0 : t < 80 ? 1 : 2;
	})()] ?? "iron";
	e.pieces = (t === 1 ? [
		"iron",
		"iron",
		"steel"
	] : [
		"iron",
		"steel",
		i
	]).map((e, n) => A(k(t, n + 1, e, r)));
	let a = t < 4 ? y.slice(0, 4) : [...y];
	e.requests = (t === 1 ? ["guard", "courier"] : Array.from({ length: 2 }, () => a.splice(F(e, "requests", a.length), 1)[0] ?? "guard")).map((e) => A(b(e, t, r))), e.requestDecided = !1, e.acceptedRequestId = null, e.fulfilledRequestId = null, e.roundBreaks = 0, e.merchant = [];
}
function L(r) {
	if (!e(r) || typeof r.runId != "string" || !/^[A-Za-z0-9_-]{1,80}$/.test(r.runId)) return {
		ok: !1,
		error: "invalid_run_id"
	};
	if (typeof r.seed != "string") return {
		ok: !1,
		error: "invalid_seed"
	};
	let i = r.seed.normalize("NFC").trim();
	if (Array.from(i).length < 1 || Array.from(i).length > 64) return {
		ok: !1,
		error: "invalid_seed"
	};
	let a = {
		rulesVersion: u,
		runId: r.runId,
		seed: i,
		revision: 0,
		phase: "workshop",
		round: 1,
		coins: 0,
		scrap: 0,
		coal: 2,
		seals: 3,
		starterChosen: !1,
		techniques: [],
		pieces: [],
		condition: {
			kind: "steady",
			stat: null,
			pattern: null
		},
		credit: 0,
		pendingCredit: 0,
		requests: [],
		requestDecided: !1,
		acceptedRequestId: null,
		fulfilledRequestId: null,
		returns: [],
		roundBreaks: 0,
		merchant: [],
		purchases: [],
		history: [],
		rng: {
			stock: {
				state: t(`${i}|v2|stock`),
				draws: 0
			},
			requests: {
				state: t(`${i}|v2|requests`),
				draws: 0
			},
			conditions: {
				state: t(`${i}|v2|conditions`),
				draws: 0
			},
			merchant: {
				state: t(`${i}|v2|merchant`),
				draws: 0
			}
		},
		journal: []
	};
	return I(a, 1), n({
		ok: !0,
		state: a
	});
}
function R(e, t) {
	return e.phase === "workshop" ? e.starterChosen ? e.requestDecided ? t === void 0 ? "piece_not_found" : t.status === "active" ? null : "piece_finalized" : "choose_request" : "choose_technique" : "wrong_phase";
}
function z(e, t) {
	let n = e.integrity;
	for (e.stress = Math.max(0, e.stress + t); e.stress >= e.threshold && e.integrity > 0;) e.stress -= e.threshold, e.integrity--;
	return e.integrity === 0 && (e.status = "broken"), n - e.integrity;
}
function B(e, t) {
	return {
		allowed: !1,
		reason: t,
		piece: e,
		heatCost: 0,
		stressAdded: 0,
		gained: 0,
		damaged: 0,
		pattern: null
	};
}
function V(e, t, n, r, i) {
	let a = R(e, t);
	if (a) return B(t, a);
	if (t.quench !== null) return B(t, "already_quenched");
	if (!M(n, 0, 9)) return B(t, "invalid_node");
	let o = p[r], s = r === "heavy" && t.heavyStrikes < 2 && e.techniques.includes("warmTongs"), c = o.heat - (s ? 4 : 0);
	if (t.heat < c) return B(t, "no_heat");
	if ((t.nodes[n] ?? 0) + o.force > 6) return B(t, "node_full");
	let l = A(t), u = o.force - +(i === "mishit"), d = Math.max(0, o.stress + (s ? 2 : 0) + (r === "heavy" && e.condition.kind === "brightFire" ? 2 : 0) - (i === "precise" ? 2 : 0)) + (i === "mishit" ? 10 : 0) + (t.heat < 24 ? 8 : 0);
	l.nodes[n] = (l.nodes[n] ?? 0) + o.force, l.heat -= c, l.ratings[C(n)] += u, l.strikes++, r === "heavy" && l.heavyStrikes++;
	let f = null;
	if (i === "mishit") l.chain = [];
	else {
		let t = l.chain.at(-1);
		if (l.chain = t !== void 0 && !l.chain.includes(n) && w(t, n) ? [...l.chain, n] : [n], l.chain.length === 3) {
			let t = l.chain.every((e) => e < 5) ? "edge" : l.chain.every((e) => e >= 5) ? "spine" : "bridge", n = !l.patterns.includes(t);
			if (l.traces.push({
				pattern: t,
				nodes: [...l.chain],
				rewarded: n
			}), l.chain = [], n) {
				l.patterns.push(t), f = t;
				let n = t === "edge" ? "edge" : t === "spine" ? "toughness" : "balance";
				l.ratings[n] += t === "edge" && e.techniques.includes("edgeTooth") ? 4 : 2;
			}
		}
	}
	return {
		allowed: !0,
		reason: null,
		piece: l,
		heatCost: c,
		stressAdded: d,
		gained: u,
		damaged: z(l, d),
		pattern: f
	};
}
function H(e, t, n) {
	let r = R(e, t);
	if (r) return B(t, r);
	if (t.quench !== null) return B(t, "already_quenched");
	if (t.strikes === 0) return B(t, "not_forged");
	let i = A(t), a = n === "water" ? 8 : -8;
	if (n === "water") i.ratings.edge += 2, i.ratings.toughness = Math.max(0, i.ratings.toughness - 1), e.techniques.includes("bridgeClip") && i.patterns.includes("bridge") && !i.bridgeUsed && (a = 0, i.bridgeUsed = !0);
	else {
		let n = t.ratings;
		e.techniques.includes("balanceWeight") && Math.max(n.edge, n.toughness, n.balance) - Math.min(n.edge, n.toughness, n.balance) <= 4 && (i.ratings.balance += 3), i.ratings.toughness += 2, i.ratings.edge = Math.max(0, i.ratings.edge - 1);
	}
	i.quench = n;
	let o = z(i, a);
	return {
		allowed: !0,
		reason: null,
		piece: i,
		heatCost: 0,
		stressAdded: a,
		gained: 0,
		damaged: o,
		pattern: null
	};
}
function ne(e, t, n) {
	if (t.status !== "broken") return;
	let r = 1 + (e.roundBreaks === 0 && e.techniques.includes("shardBox") ? 4 : 0);
	e.roundBreaks++, t.recoveredScrap = r, e.scrap += r, n.push({
		type: "broken",
		pieceId: t.id,
		scrap: r
	});
}
function U(e, t, n) {
	let r = D(t, e.condition);
	t.status = "recycled", t.recoveredScrap = r, e.scrap += r, n.push({
		type: "scrap",
		pieceId: t.id,
		scrap: r
	});
}
function W(e, t, n = !1) {
	for (let r of e.returns) !r.received && (r.dueRound <= e.round || n && e.round === 12) && (r.received = !0, e.scrap++, t.push({
		type: "return",
		pieceId: r.pieceId,
		scrap: 1,
		label: r.label
	}));
}
function G(e, t) {
	e.round++, e.phase = "workshop", e.credit = e.pendingCredit, e.pendingCredit = 0, I(e, e.round), W(e, t), t.push({
		type: "round",
		value: e.round
	});
}
function K(t, r) {
	if (!e(r) || !Number.isInteger(r.expectedRevision) || typeof r.runId != "string") return N(t, "invalid_command");
	if (r.runId !== t.runId) return N(t, "foreign_run");
	if (r.expectedRevision !== t.revision) return N(t, "stale_revision");
	let i = P(r.action);
	if (!i.ok) return N(t, i.error);
	let a = i.action, o = A(t), s = [];
	if ("pieceId" in a) {
		let e = o.pieces.find((e) => e.id === a.pieceId), n = R(t, e);
		if (n) return N(t, n);
		if (!e) return N(t, "piece_not_found");
		switch (a.type) {
			case "strike":
			case "quench": {
				let n = a.type === "strike" ? V(t, e, a.node, a.mode, S(a.timingMark)) : H(t, e, a.medium);
				if (!n.allowed) return N(t, n.reason ?? "invalid_command");
				let r = A(n.piece);
				o.pieces = o.pieces.map((t) => t.id === e.id ? r : t), s.push({
					type: a.type,
					pieceId: e.id,
					...a.type === "strike" ? { grade: S(a.timingMark) } : {}
				}), n.pattern && s.push({
					type: "pattern",
					pieceId: e.id,
					pattern: n.pattern
				}), ne(o, r, s);
				break;
			}
			case "reheat":
				if (e.quench !== null) return N(t, "already_quenched");
				if (o.coal <= 0) return N(t, "no_coal");
				if (e.heat >= 100 && e.stress === 0) return N(t, "already_hot");
				o.coal--, e.heat = 100, e.stress = Math.max(0, e.stress - 18), e.chain = [], e.reheats === 0 && o.techniques.includes("reheatSand") && (e.ratings.toughness += 2), e.reheats++, s.push({
					type: "reheat",
					pieceId: e.id
				});
				break;
			case "deliver": {
				let t = o.requests.find((e) => e.id === o.acceptedRequestId), n = t && o.fulfilledRequestId === null ? O(e, t, o.condition) : 0, r = E(e) + n;
				e.status = "delivered", e.paidValue = r, o.coins += r, n && t && (o.fulfilledRequestId = t.id, o.returns.push({
					requestId: t.id,
					label: t.label,
					pieceId: e.id,
					dueRound: o.round + 2,
					received: !1
				})), s.push({
					type: "delivery",
					pieceId: e.id,
					value: r,
					...n ? { label: t?.label ?? "" } : {}
				});
				break;
			}
			case "scrap": U(o, e, s);
		}
	} else switch (a.type) {
		case "chooseTechnique":
			if (o.phase !== "workshop") return N(t, "wrong_phase");
			if (o.starterChosen) return N(t, "already_chosen");
			if (!ee.includes(a.techniqueId)) return N(t, "invalid_technique");
			o.starterChosen = !0, o.techniques.push(a.techniqueId), s.push({
				type: "starter",
				label: g[a.techniqueId].label
			});
			break;
		case "chooseRequest":
			if (o.phase !== "workshop") return N(t, "wrong_phase");
			if (!o.starterChosen) return N(t, "choose_technique");
			if (o.requestDecided) return N(t, "already_chosen");
			if (a.requestId !== null && !o.requests.some((e) => e.id === a.requestId)) return N(t, "invalid_request");
			o.requestDecided = !0, o.acceptedRequestId = a.requestId, s.push({ type: "request" });
			break;
		case "settleRound": {
			if (o.phase !== "workshop") return N(t, "wrong_phase");
			if (!o.starterChosen) return N(t, "choose_technique");
			if (!o.requestDecided) return N(t, "choose_request");
			if (!a.recycleRemaining && o.pieces.some((e) => e.status === "active")) return N(t, "unprocessed_pieces");
			for (let e of o.pieces) e.status === "active" && U(o, e, s);
			let e = o.pieces.reduce((e, t) => e + t.paidValue, 0), n = x(o.round), r = e + o.credit >= n, i = o.seals;
			o.seals -= +!r, o.pendingCredit = o.round === 12 ? 0 : Math.min(Math.floor(Math.max(0, e - n) / 2), Math.floor(x(o.round + 1) / 4)), o.history.push({
				round: o.round,
				quota: n,
				delivered: e,
				credit: o.credit,
				met: r,
				sealsBefore: i,
				sealsAfter: o.seals,
				nextCredit: o.pendingCredit,
				pieces: A(o.pieces),
				condition: A(o.condition),
				request: A(o.requests.find((e) => e.id === o.acceptedRequestId) ?? null)
			}), o.phase = o.seals === 0 ? "defeat" : o.round === 12 ? "victory" : "roundSummary", (o.phase === "victory" || o.phase === "defeat") && W(o, s, !0), s.push({
				type: "settled",
				value: e
			});
			break;
		}
		case "advanceSummary":
			if (o.phase !== "roundSummary") return N(t, "wrong_phase");
			if ([
				3,
				6,
				9
			].includes(o.round)) {
				let e = _.filter((e) => !o.techniques.includes(e));
				for (o.merchant = []; e.length && o.merchant.length < 3;) o.merchant.push(e.splice(F(o, "merchant", e.length), 1)[0] ?? "edgeTooth");
				o.phase = "merchant", s.push({ type: "merchant" });
			} else G(o, s);
			break;
		case "leaveMerchant":
			if (o.phase !== "merchant") return N(t, "wrong_phase");
			G(o, s);
			break;
		case "buy": {
			if (o.phase !== "merchant") return N(t, "wrong_phase");
			if (o.purchases.some((e) => e.afterRound === o.round && e.productId === a.productId)) return N(t, "already_purchased");
			let e = a.productId, n = e === "repair" ? {
				coins: 240,
				scrap: 6
			} : g[e];
			if (e === "repair") {
				if (a.replaceId !== void 0) return N(t, "invalid_replacement");
				if (o.seals >= 3) return N(t, "repair_not_needed");
			} else {
				if (!o.merchant.includes(e)) return N(t, "not_offered");
				if (o.techniques.includes(e)) return N(t, "already_owned");
				if (a.replaceId !== void 0 && !o.techniques.includes(a.replaceId)) return N(t, "invalid_replacement");
				if (o.techniques.length >= 3 && a.replaceId === void 0) return N(t, "replacement_required");
			}
			if (o.coins < n.coins) return N(t, "insufficient_coins");
			if (o.scrap < n.scrap) return N(t, "insufficient_scrap");
			o.coins -= n.coins, o.scrap -= n.scrap, e === "repair" ? o.seals++ : (a.replaceId !== void 0 && (o.techniques = o.techniques.filter((e) => e !== a.replaceId)), o.techniques.push(e)), o.purchases.push({
				afterRound: o.round,
				productId: e,
				replaced: a.replaceId ?? null,
				coins: n.coins,
				scrap: n.scrap
			}), s.push({
				type: "purchase",
				label: e === "repair" ? "契约修补" : g[e].label
			});
			break;
		}
	}
	return o.revision++, o.journal.push(A(a)), n({
		ok: !0,
		state: o,
		events: s
	});
}
//#endregion
//#region src/core-v2/view.ts
function q(e) {
	return e.quench === null || e.status === "broken" ? null : n({
		cut: Math.min(8, Math.floor(e.ratings.edge / 3)),
		block: Math.min(8, Math.floor(e.ratings.toughness / 3)),
		handling: Math.min(8, Math.floor(e.ratings.balance / 3))
	});
}
function J(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e.history) for (let e of n.pieces) t.set(e.id, e);
	for (let n of e.pieces) t.set(n.id, n);
	return n(structuredClone([...t.values()]));
}
function re(e) {
	let t = new Map(J(e).map((e) => [e.id, e]));
	return n(structuredClone(e.returns.filter((e) => e.received).map((n) => {
		let r = t.get(n.pieceId), i = e.history.find((e) => e.request?.id === n.requestId)?.request ?? e.requests.find((e) => e.id === n.requestId), a = r ? q(r) : null;
		if (!r || !i || !a) throw Error("Missing recorded customer sword");
		return {
			...n,
			kind: i.kind,
			piece: r,
			trial: a,
			receivedRound: Math.min(12, n.dueRound),
			scrap: 1
		};
	})));
}
function ie(e, t, n) {
	if (e.phase === "merchant" && e.purchases.some((t) => t.afterRound === e.round && t.productId === n)) return {
		short: "下轮生效",
		status: "本次新装入，下一轮开始使用。"
	};
	if (!t) return {
		short: "待上砧",
		status: "选择一件来料后查看本剑使用次数。"
	};
	let r = t.quench !== null || t.status !== "active";
	if (n === "edgeTooth") return t.patterns.includes("edge") ? {
		short: "已生效",
		status: "本剑巡锋加成已生效；重复锻纹不再次领奖。"
	} : r ? {
		short: "已封存",
		status: "本剑未形成巡锋加成，已经结束加工，不能再触发。"
	} : {
		short: "待巡锋",
		status: "本剑尚未形成巡锋纹，可获得一次加成。"
	};
	if (n === "bridgeClip") return t.bridgeUsed ? {
		short: "已使用",
		status: "本剑水淬防应力已经使用。"
	} : r ? {
		short: "已封存",
		status: "本剑已经结束加工，水淬防应力未使用。"
	} : t.patterns.includes("bridge") ? {
		short: "保护就绪",
		status: "本剑已成游衡纹，水淬不会增加8应力。"
	} : {
		short: "待游衡",
		status: "本剑还需形成游衡纹才能保护水淬。"
	};
	if (n === "reheatSand") return t.reheats ? {
		short: "已使用",
		status: "本剑首回火加韧已使用；再次回火不重发。"
	} : r ? {
		short: "已封存",
		status: "本剑未使用首回火加韧，已经结束加工。"
	} : {
		short: "余1次",
		status: "本剑首回火加韧还可使用1次。"
	};
	if (n === "warmTongs") {
		let e = Math.max(0, 2 - t.heavyStrikes);
		return {
			short: r ? `未用${e}次` : `余${e}次`,
			status: r ? `本剑已经结束加工，未用的${e}次重锤优惠不结转。` : `本剑前两次重锤优惠还剩${e}次，已经重锤${t.heavyStrikes}次。`
		};
	}
	if (n === "shardBox") return e.roundBreaks ? {
		short: "本轮已用",
		status: "本轮首碎补偿机会已用；下一轮重新计次。"
	} : {
		short: "待首碎",
		status: "本轮首件破碎额外补偿尚未使用。"
	};
	if (t.quench) return {
		short: "已封存",
		status: `本剑已${t.quench === "oil" ? "油" : "水"}淬，当前衡${t.ratings.balance}，不能再淬火。`
	};
	if (t.status !== "active") return {
		short: "已处置",
		status: "这件来料已经处置，不能再加工或淬火。"
	};
	let i = H(e, t, "oil"), a = i.allowed ? i.piece.ratings.balance - t.ratings.balance : 0;
	return a > 0 ? {
		short: `油淬+${a}衡`,
		status: `按当前真实预览，油淬会额外增加${a}衡。`
	} : {
		short: t.strikes ? "待均衡" : "先落锤",
		status: t.strikes ? "当前油淬不会获得额外衡；比较三项性能后再决定。" : "先落锤，再检查油淬的均衡条件。"
	};
}
function ae(e, t = {}) {
	let r = e.pieces.find((e) => e.id === t.pieceId) ?? e.pieces[0] ?? null, i = typeof t.node == "number" && Number.isInteger(t.node) && t.node >= 0 && t.node < 10 ? t.node : 0, a = t.mode === "light" || t.mode === "heavy" ? t.mode : "standard", o = e.requests.find((t) => t.id === e.acceptedRequestId) ?? null, s = e.pieces.reduce((e, t) => e + t.paidValue, 0), c = x(e.round), l = e.pieces.map((t) => ({
		...t,
		materialName: f[t.material].label,
		value: E(t),
		salvage: D(t, e.condition),
		trial: q(t)
	})), u = r ? {
		...r,
		materialName: f[r.material].label,
		value: E(r),
		salvage: D(r, e.condition),
		name: `${f[r.material].label}·${r.patterns.length === 3 ? "三纹名作" : r.patterns.length ? r.patterns.map((e) => h[e]).join("·") : "未定之刃"}`,
		trial: q(r),
		requestBonus: o && e.fulfilledRequestId === null ? O(r, o, e.condition) : 0,
		outcomes: [
			"precise",
			"ordinary",
			"mishit"
		].map((t) => ({
			grade: t,
			...V(e, r, i, a, t)
		})),
		quenches: ["water", "oil"].map((t) => ({
			medium: t,
			...H(e, r, t)
		})),
		productionError: R(e, r),
		nodeViews: r.nodes.map((e, t) => ({
			index: t,
			used: e,
			capacity: 6,
			stat: C(t),
			label: m[C(t)]
		}))
	} : null;
	return n(structuredClone({
		rulesVersion: e.rulesVersion,
		runId: e.runId,
		revision: e.revision,
		phase: e.phase,
		round: e.round,
		totalRounds: 12,
		quota: c,
		delivered: s,
		credit: e.credit,
		remaining: Math.max(0, c - s - e.credit),
		coins: e.coins,
		scrap: e.scrap,
		coal: e.coal,
		seals: e.seals,
		condition: e.condition,
		conditionLabel: e.condition.kind === "reclaimed" && e.condition.stat ? `旧器回炉：${m[e.condition.stat]}初始+2，底价−4` : e.condition.kind === "urgent" && e.condition.pattern ? `急件：委托额外+20，需${h[e.condition.pattern]}纹` : te[e.condition.kind],
		starterChosen: e.starterChosen,
		requestDecided: e.requestDecided,
		requests: e.requests,
		request: o,
		fulfilledRequestId: e.fulfilledRequestId,
		returns: e.returns,
		techniques: e.techniques.map((t) => ({
			id: t,
			...g[t],
			...ie(e, r, t)
		})),
		merchant: e.merchant.map((t) => ({
			id: t,
			...g[t],
			owned: e.techniques.includes(t),
			purchased: e.purchases.some((n) => n.afterRound === e.round && n.productId === t)
		})),
		hammer: p[a],
		mode: a,
		node: i,
		pieces: l,
		selected: u,
		history: e.history,
		purchases: e.purchases
	}));
}
//#endregion
//#region src/core-v2/validate.ts
function Y(t) {
	let n = r(t);
	if (n === null) return {
		ok: !1,
		error: "invalid_state",
		detail: "Expected bounded plain JSON data."
	};
	let i = JSON.parse(n);
	if (!e(i) || typeof i.runId != "string" || typeof i.seed != "string") return {
		ok: !1,
		error: "invalid_state",
		detail: "Run identity and seed are required."
	};
	if (i.rulesVersion !== "forge-v2") return {
		ok: !1,
		error: "invalid_rules_version",
		detail: "Expected forge-v2."
	};
	if (!Array.isArray(i.journal) || i.journal.length > 2048) return {
		ok: !1,
		error: "invalid_journal",
		detail: "Expected a bounded accepted-command journal."
	};
	let a = L({
		runId: i.runId,
		seed: i.seed
	});
	if (!a.ok) return {
		ok: !1,
		error: "invalid_state",
		detail: a.error
	};
	let o = a.state;
	for (let [e, t] of i.journal.entries()) {
		let n = K(o, {
			runId: o.runId,
			expectedRevision: o.revision,
			action: t
		});
		if (!n.ok) return {
			ok: !1,
			error: "invalid_journal",
			detail: `Command ${e}: ${n.error}`
		};
		o = n.state;
	}
	return r(o) === n ? {
		ok: !0,
		state: o
	} : {
		ok: !1,
		error: "invalid_state",
		detail: "Snapshot differs from its deterministic replay."
	};
}
//#endregion
//#region src/application/v2-persistence.ts
var X = "sword-led.save.v2", Z = "sword-led.save.backup.v2", Q = Object.freeze({
	key: X,
	backupKey: Z,
	schemaVersion: 2,
	rulesVersion: "forge-v2",
	validate: Y
}), oe = (e) => l(e, Q), $ = (e, t) => s(e, Q, t);
function se(e = window) {
	return c(e, X, (t) => a($(() => e.localStorage), o(t), {
		createRun: L,
		applyCommand: K
	}));
}
//#endregion
export { Z as V2_BACKUP_KEY, X as V2_SAVE_KEY, K as applyCommand, L as createRun, se as createV2BrowserSession, $ as createV2SaveRepository, oe as decodeV2Save, J as getCollection, re as getCustomerVisits, ae as getRunView, q as getTrial, P as parseAction, H as previewQuench, V as previewStrike, Y as validateRun };
