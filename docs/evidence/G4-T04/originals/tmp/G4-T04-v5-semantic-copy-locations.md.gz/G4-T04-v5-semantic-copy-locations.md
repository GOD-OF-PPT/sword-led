# T04 当前 v5 语义文案直出清单（只读）

2026-10-23；按当前源码读取，root 正在并行修缮，行号可能随 import 小幅后移。以下均为明确 UI 语义字符串边界；不建议扫描 DOM 子树、保存详情/导出 JSON 或回写 core/存档。

## 上游旧词来源

- `core-v5/content.ts:1` 复用 `core-v4/content.ts`；后者 `:3` 又复用 `core-v3/rules.ts` 的 TRAITS。实际旧词：`core-v3/rules.ts:3,5` 的稳手/回响 `text`；`core-v4/content.ts:14,15` 风箱/余温架 `text`；`:30-34` 事件 request/result 的金币/身价；`:46` 第10单 request“更高身价”。
- `core-v5/view.ts:9` 的 `describeRoute()` 直接产出“身价≥”；`core-v5/rules.ts:55` 的 routeAssessment 缺项产出“还差…身价”。应在当前 v5 展示消费处投影，不修改这些 core 输出或保存原文。

## app.ts

按 root 加 `workshopText` 前后当前约行号：

- `renderBelt` 原 `:271` / 当前 `:274`：手艺 modal `element('p',t.text)`，以及同一行 `n.title=t.text`（title 已见 root 接 `workshopText`）。
- `:273` / 当前 `:276`：炉具 modal `openModal(m.name,m.text,...)`。若统一 `openModal` 的 **string body**，该处可由该入口一次覆盖；不要转已构造 HTMLElement 中的 raw 文本。
- `replaceTrait :332-333` / 当前 `:335-336`：新手艺及每个旧手艺卡的 `TRAITS[...].text`。
- `claimGift :340` / 当前 `:343`：首赠手艺卡 `TRAITS[id].text`。
- `commissionDetails :344` / 当前 `:347`：`v.commission.request`（第10单会旧称）。普通 paper 的 condition/requirement 已是估值，不需动规则。
- `journeyPanel :372` / 当前 `:375`：`result.routes[].description`；`:379` / 当前 `:382` 的下一天 `commission.request`；`:380` / 当前 `:383` 的 `MODIFICATIONS[id].text`。CHAPTERS letter 也在该区直接出，但当前三封信文本 **无** 身价/金币，不能宣称已存在旧词。
- `tomorrowPlan :387` / 当前 `:390`：展开纸单 `next.commission.request`、`plan.routes[].description`；`:399-400` / 当前 `:402-403`：`carry.copy`、`carry.missing.join(...)`（后者来自正式 assessment）；不是只替换 `growth-options.ts:72` 的字面“明日身价”就完毕。
- `buyTrait :359` / 当前 `:362` 的 `tradeOption(...).opportunity[]` 会含 carry.copy；`arrangeBlade` 原 `:427` 的 carry.copy 同类。
- `eventModal :440-441` / 当前约 `:443-444`：`newBlankText()` 目前只修“明日第一柄新坯”，未修货币/估值；`sourceEvent.request/result` 直接进段落；确认内原 `:449` 的 `v.result` 也直出。可在明确 request/result 边界归一，保原事件对象/金额/导出。
- `story.ts:43` 的 TRAITS.text 只作为 notice copy 进入 `app.renderNotice` 的 `text('v4-notice-copy',notice.copy)`，已经有纯文字投影，**没有发现这条链仍需另扫 DOM**。

## stages.ts

- 现有 `paragraph(copy)` 原 `:41` 是大多数场景文字的单一入口。将其接纯 helper，可覆盖 `:104-105,109,112,114` 的开场/章开场 request、`describeRoute`/`route.description`，以及回执、下一章开场、历史路线和其它 paragraph。
- **绕过 paragraph 的节点**：`:55-56` `addNext` 的 `next.commission.request` 与 `describeRoute(route)`；`:65` 的 `next.reserve.assessment.routes[].missing`；`:74` 装好炉具的 `m.text`；`:146` 章末三选一的 `modification.text`；`:186` 人物作品详情中 `record.routes[].description`；`:209` 事件卡 `result`（`:207` fallback 使用 `EVENTS[event.id].result`，旧刃回收会“金币”）。
- CHAPTERS 的三段 opening 当前本身无身价/金币；首章实际旧词来自其同屏 `view.commission.routes[].description`，源为 core-v5 describeRoute。不要把无旧词的 opening 原文误报成核心错误。

## collection-ui.ts

- `:37` 炉谱可展开手艺见闻 `TRAITS[id].text`。
- `:43` 尚未留名作品卡 `c.request.replaceAll('昨日','此前')`（第10单旧称）。
- `:55` 作品详情的 `describeRoute(route)`（固定会“身价≥”）；同处 `c.success` 当前无旧词。作品的 sourceLabel、rulesVersion、原始数值/来源不能重标或重写。

## 其它当前 v5 模块

- `market-stall.ts:96` 的 `rule.textContent=trait.text`；`:104` `trade.opportunity`（carry 内的 assessment/describeRoute）；`:113` 备料直写“已有剑的身价”。root 当前已见前者和字面项修为 helper/估值。
- `growth-options.ts:69-76` 的 `missing` / `copy`；`:71` 使用正式 describeRoute 和 assessment.missing。`:72`“明日身价”已见 root 改为估值，但两个上游字符串仍应在合适的视图文案出口转称。
- `decisions.ts:118,128` 的 NextDayDecision description / missing 会进入装箱 modal，不能以主工坊 text() 已转称当整个 modal 已处理。
- `workbench-feedback.ts:74` 收剑 ARIA 原“身价”；root 已见改“估值”。其它 transfer/growth caption 当前无旧词。
- 共享 `presentation-v4/forge.ts` 的 canvas ARIA 默认“身价”与 `presentation-v3/impact.ts:37` 接触 float“身价”：按 root 当前方案仅 v5 可选 label/contactReadout 转称，旧版本默认/原件不动。
- `shell.ts:66` 初始占位“敲出身价…”：root 已见改估值；后续真实主引导使用 app text()。

未执行任何新 UI/SDK/测试；这张清单是源码消费链，不是逐页面实际验收。root/A 的原范围定向体验另承担。
