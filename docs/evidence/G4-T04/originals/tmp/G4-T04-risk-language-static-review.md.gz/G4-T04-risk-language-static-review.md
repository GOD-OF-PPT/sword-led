# T04风险／术语产品差分短审

**静态mustfix＝none。** 只读当前生产git diff、新copy.ts、正式game/rules/view及旧renderer/impact调用链；未运行SDK、consumer、类型检查或构建，未改源／测试／正式doc。root交回的type/build01与保护核为已有执行事实，下面不替未来实际UI结果。

风险提示与正式规则一致：安全连锻先显示“不会裂”；已有裂纹的普通锤显示“再裂会断”；未裂且steady或crackGuard存在才提示“首裂保价，仍留裂纹”，否则首裂掉价。core-v5/game.ts:64–66先处理二裂破碎，首次裂损仍标cracked，只有无两保护才降至80%；credit首次实际裂损消耗，steady本身不消耗。两保护同时有时原核仍消耗credit，当前文案没有承诺它能保留；safe结果不会进入裂损分支，因此不会花credit。没有触碰赔率、抽签、触发、消耗或对象／revision校验。

copy.ts只把v5展示词“身价／金币”替换为“估值／铜钱”；数值字符、报价和正式state不变。element仍委托原DOM helper，保持textContent、className和键盘tabIndex行为；pre/code/textarea/input的字面参数绕过转换，`.value`赋值也未接入它。已检查变更模块的seed使用，仍是原seedDraft／input.value／newInput，没有把seed存值送进翻译。局档／炉谱的正式序列化、Blob下载、磁盘原文读取、JSON／source票据和规则记录路径未改；没有增加全DOM替换、innerHTML或运行时记录重写。

app／stages／collection／market采用的是当前v5显示层。旧来源作品在v5册页显示“估值”不改变其rulesVersion、来源标记、数值或旧解释器；直接进入旧v3/v4页面不导入这个v5 helper。merchant单独textContent赋值的trait说明也明确转换；未借翻译重新计算金额或改物件身份。

浮字由原impact touchdown先生成，随后同一同步调用栈进入forge host.contact→v5 contactReadout，在既有run／revision／generation／epoch／piece守卫通过后转换当前float文本；没有新的observer、timer、rAF或延迟补播。旧v3/v4调用不走该v5接点。共享forge只有可选valueLabel和ARIA文字插值两行变化，默认仍“身价”，v5显式传“估值”；ARIA使用setAttribute，不是HTML。像素绘制、cache key、资源失效、contact时序／几何、音色和默认旧host均未改，不能把这份表示层修补说成旧forge文件原字节完全未动。

未发现把旧存档／JSON／seed／导出原文经翻译的实际路径，也未发现保护条件提前消耗或把二裂误报成保价的新增分支。当前实际UI验证应按root已定合法恢复和真实Accepted小范围消费，不能由此静态审查预填通过；没有新增规则／存档或重复美术批准的必要。
