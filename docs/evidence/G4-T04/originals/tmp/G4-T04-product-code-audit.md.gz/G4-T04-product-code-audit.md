# G4 / T04 当前v5产品、代码与安全只读审计

审计基线：实际 `git rev-parse HEAD` 为 `fbf04ea94ed4ada8d94e45a30cfbb58f6f124544`；读取期间 `git diff --name-only -- src index.html package.json` 为空。root提供的正式试玩身份为build23／G4-T03-forge-menu；本审阅不另做HTTP或浏览器验明。合同采用goal-4原五项、v0.8批准方案及当前十二灯指南。只读当前主线与必要共享实现，未改src/docs/tasks/测试，未启动browser/build/SDK或重新调查T03历史首红。

结论：发现 **1项必须修正的C端风险预告**（M1，root已收到，负责真实复现与修补）；未发现其他已成立的缺功能、占位出口、计价/保存越权或代码执行风险。该结论是所列源码边界的静态审计，不将“未发现”扩写成真人乐趣、所有种子平衡或运行时绝对无缺陷。

## M1 — 有首裂保护时，主风险行仍声称“首裂会掉价”

- 位置：`src/presentation-v5/app.ts:249`，普通锤且未裂的分支固定输出“首裂会掉价”。
- 正式行为：`src/core-v5/game.ts:65` 已裂剑再裂直接断；`:66` 未裂先留下裂纹，当前装备steady或仍有crackGuard时不降估值，二者均无才乘80%。`src/core-v3/rules.ts:3` 的共用稳手说明及批准v0.8合同均保留首次裂损保价。
- 合法触发：首次主单完成后领取稳手，再选一柄无裂余剑；或者接受商人赊护后选无裂剑。主要风险行仍给出掉价预告，可能误导玩家是否继续敲。这是UI预告错误，不是核心保价失效。本审阅未实际点击，真实复现由root处理。
- 最小呈现边界：先判断下一记安全连锻；普通锤时已裂仍明确“再裂会断”；仅未裂且当前steady装备或公开`view.growth.crackGuard`为true才预告首裂保价、仍留裂纹。裂损百分比保持正式odds，不把保价说成防裂或永久防断。
- 已用条件：credit在首裂时即置crackGuard=false，即使同时有steady也消费；不能以eventHistory接受过或上一记lastTriggers反推仍待用。`view.traits[].used`只反映pardonUsed，不是稳手用量。steady没有“本局一次”的额外计数，而是每柄未裂剑的首次裂损；已裂剑即使仍装备稳手也不再保价。公开来源见`src/core-v5/view.ts:42`及`:43`。
- 状态：**开放，交root修复/定向核对**。本文件未用推测修复或未执行验证关闭该项。

## 当前完整能力与出口的源码依据

| 范围 | 当前接线与结论 |
| --- | --- |
| 主线/内容/成长 | `core-v5/content.ts:1`复用完整十二纸单/三章/三商人/六事件；`core-v4/content.ts:36`十二委托仍含双驿两柄、两次连锻、旧/新替代与最终护灯。`core-v5/game.ts:16`按留剑发2或3新坯；`:137`第4/8天两次改造；`:134`保印、10单和4/8/12关键日决定三结局，未发现降低条件、删后段或假终局。 |
| 计价与用户反馈 | `core-v5/rules.ts:18`累计最大路线比例，`:69`给基础增量/品质加赏/普通出售/预算；`game.ts:115`正式收件才入账，页面仅交pieceId。`payment-copy.ts:26`以public quote显示作品估值、整单酬劳/已领、本柄酬劳＋加赏＝实收；`app.ts:495`只读报价说明，无再次发奖。 |
| 可见经营选择 | `app.ts:319`封炉确认列逐柄实际回收、失约/关键日/最终结局后果和下一单；`:383`装箱先预览再确认；`:411`摊内比较不移动炉前选剑；`:422`钱袋空仍有留剑、换艺、明确零价回收和取消出口；`:437`所有炉边事件可暂不决定/拒绝，无剑时有真实返回挂架入口。 |
| 页面流程 | `app.ts:190`固定throughDay12；`stages.ts:111`起程、收据/改造、三结局均给正式命令或回炉边/炉谱/标题/导出出口；`journey.ts:12`以真实phase与history投影。stages中保留4/8天边界和future文案是复用防护分支，当前合法十二天状态不会走这些“后续开放”分支，不能据字符串误判当前缺后两章。 |
| 炉谱与挑战 | `core-v5/view.ts:13`根据真实history/合法交付授成长；`collection-ui.ts:24`按来源显示真实最佳作品、熟练和六手艺见闻；`:51`作品页读收据。`v5-persistence.ts:62`新局资格取已存main炉谱，当前initialEligibility冻结；终局/炉谱/标题都以已保存资格及pending/problem门开启挑战，未发现靠恢复画面重复奖或迁入旧钱包。 |
| 输入与画面 | `app.ts:534`身份含run/revision/generation/epoch，busy/弹窗/readonly均无forge身份；`direct-strike-input.ts:18`只接受正常主指针，Space/Enter与鼠标兼容click去重，取消不补命令。contextmenu仅绑定传入两落锤面且dispose移除；其他控件不拦。`handoff.ts:120`拖剑捕获身份，`app.ts:209`提交前再核真实对象，非合格拖交不暗中出售。Accepted先保存，renderer只投影，不改变RNG/经济。 |
| 声音/动效/画稿异常 | `app.ts:510`每次明确试听先silence使旧试听失效；`audio.ts:58`同owner pending，`:122`待cue绑定当前context/epoch/game，stop清队列，四voice有界；静音/0音量/失焦/后台/模式改变取消旧工作。设置有真实blocked/unavailable重试提示，不阻断锻造。`artwork-recovery.ts:47`重试真实canonical来源并有8秒上限，fallback不充当恢复，disposed/代际检查与WeakMap避免旧modal回调改新图。未把T03软件波形当物理扬声器证据。 |

## 保存、导入、导出与安全边界

- `core-v5/validate.ts:6`完整Accepted journal重放后比较整个快照；`core/validate.ts:10`只接受有界plain JSON、安全整数、无accessor，深度16、节点50000、大小256KiB及journal2048限制。`storage.ts:43`先按版本/封装/时间/大小拒绝，再进入正式校验，不把较新或旧规则静默解释成v5。
- `persistent-session.ts:215`dispatch先核generation/写锁/revision，再同步保存；失败准确保留内存局。`writer-lease.ts:13`使用同源独占ifAvailable锁，`browser-session.ts:22`pagehide释放、persisted恢复重取；v5与旧版的slot/codec分离。`app.ts:85`确认前绑定run/revision/generation；`:515`保存详情提供重试、重新取得保存权、源原文导出、明确不保存，备份确认前复读物理原文，未发现静默删坏档/覆盖未展示备份。
- `v5-persistence.ts:151`只读预览明确主册/备份；`:173`确认只消费私有shown票据、检查来源原字节与当前run/revision/generation，取消/失焦/外部来源变更清票据。只并集章节/配方/见闻/作品；不迁入钱、印、来料升级或局内剑。写盘失败只保留已确认并集供重试，局/炉谱两次写入没有伪称原子。
- `raw-run-export.ts:15`逐槽区分raw/null/拒读；`v5-persistence.ts:199`及下一exportCollection均只读/序列化，UI用本地Blob下载，不调用activate或经济动作。没有通用文件执行/上传入口；本合同“导入”是显式旧册来源，原文导出明确不能直接导入，未以此误列缺功能。
- `app.ts:45`唯一innerHTML为固定shell；动态名称/金额/来源通过`element()`的textContent、DOM属性和Canvas展示。所读当前v5与共享保存/输入路径未见eval/new Function/动态脚本或网络外送；运行依赖为空，dev/preview绑定127.0.0.1。当前receipt校验只是批准的有界来源收据，不冒称拥有每件作品整局journal或服务端防作弊认证。

## 非阻断备注与限界

`docs/v0.8-persistence-contract.md:3`仍称当前仅接第一章，后段扩展措辞也过时；已交B的文档/入口审计负责，未把它当产品缺后两章。六事件沿共用内容仍有“金币”旧词，而v5金额按钮用“铜钱”（`core-v4/content.ts:29`，`app.ts:437`）；金额和币种对象一致，可作为一致性文字修整，不据此重定义经济规则。

本次没有运行时重测、PNG/美术视觉复核、听感、HTTP部署确认或SDK回放。DOM焦点、两尺寸可读性、真人是否理解报价/愿意继续玩及全部种子平衡，需要各自实际证据/真实反馈；旧T03已经归档的结果保其身份，不在此重开调查或改记成当前全量绿。除M1外，静态范围未找到需新增玩法、删功能、改核心/保存或增加验证矩阵才能交付的问题。
