import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import * as sdk from '../../dist/sword-led-v5.js';
const path='tmp/goal4-T04/first-chapter-real-ui-run.json',raw=await readFile(path),sha=buffer=>createHash('sha256').update(buffer).digest('hex'),state=JSON.parse(raw);
const valid=sdk.validateRun(state);assert(valid.ok,valid.detail);assert.deepEqual(valid.state,state);
const created=sdk.createRun({runId:state.runId,seed:state.seed,mode:state.mode,eligibility:state.initialEligibility});assert(created.ok);let replay=created.state,accepted=0;const actions={};
for(const action of state.journal){const result=sdk.applyCommand(replay,{runId:replay.runId,expectedRevision:replay.revision,action});assert(result.ok,JSON.stringify(result));replay=result.state;accepted++;actions[action.type]=(actions[action.type]??0)+1;}
assert.deepEqual(replay,state);assert.equal(state.day,4);assert.equal(state.history.length,4);assert(state.history.every(h=>h.met));assert.equal(state.seals,3);assert.equal(state.coins,379);assert(state.modifications.includes('warmRack'));assert.equal(state.upgradeCount,1);assert.equal(sha(await readFile(path)),sha(raw));
const result={ok:true,at:new Date().toISOString(),scope:'Formal validation and every-command replay of one actually exported CUA/UI first chapter, not a fresh run, full twelve days, model or human evaluation.',input:{path,bytes:raw.length,sha256:sha(raw)},runId:state.runId,seed:state.seed,day:state.day,phase:state.phase,accepted,actions,completed:state.history.filter(h=>h.met).length,seals:state.seals,coins:state.coins,modifications:state.modifications,upgradeCount:state.upgradeCount,state};
await writeFile('tmp/goal4-T04/first-chapter-replay.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({ok:true,accepted,actions,day:state.day,completed:result.completed,seals:state.seals,coins:state.coins,inputSHA256:sha(raw)}));
