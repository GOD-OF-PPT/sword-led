from pathlib import Path
import json,hashlib,gzip,datetime,subprocess
b=Path('tmp/goal4-T04');out=Path('docs/evidence/G4-T04');assert not out.exists()
labels=['build-01','typecheck-02','risk-language-01','typecheck-03','legacy-label-01','first-chapter-replay-01','openspec-strict-01','published-01'];files=set();runs=[]
for label in labels:
 d=b/'runs'/label;r=json.loads((d/'process.json').read_text());assert r['status']=='terminal' and r['actualExitCode']==0;runs.append({'label':label,'process':r});files.update(p for p in d.rglob('*') if p.is_file())
 e=d/'end-fingerprint.json'
 if e.exists():
  v=json.loads(e.read_text());assert v['consumerActualExitCode']==0 and v['fingerprintActualExitCode']==0 and json.loads(v['stdout'])['matches']
files.update(p for p in b.iterdir() if p.is_file())
for name in ['drafts','originals']:files.update(p for p in (b/name).rglob('*') if p.is_file())
files.update(p for p in Path('tmp').glob('G4-T04*.md') if p.is_file())
for name in ['docs/reviews/G4-T04-final-delivery.md','README.md','goal-4/input.md','goal-4/plan.md','goal-4/tasks.md','src/presentation-v4/forge.ts','tests/e2e/v4-forge.spec.ts','tests/release-v5/t04-risk-language.spec.ts','tests/fixtures/v5/t04-credit-prefix.json']:
 files.add(Path(name))
files.update(Path('src/presentation-v5').glob('*.ts'))
files.update(p for p in Path('dist').rglob('*') if p.is_file() and p.suffix in ['.js','.css','.html','.svg'])
sha=lambda raw:hashlib.sha256(raw).hexdigest();before={str(p):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files}
fp=b/'final-fingerprint.json';subprocess.run(['rtk','proxy','node','scripts/release-fingerprint.mjs','verify',str(fp)],check=True)
reviewed=['steady-risk-before.jpg','steady-risk-after.jpg','packing-estimate-after.jpg','chapter-one-growth-choice.jpg','chapter-one-receipt-after.jpg','chapter-one-receipt-pc-1280.jpg'];reviewed=[str(b/p) for p in reviewed]
out.mkdir();rows=[]
for p in sorted(files):
 name=str(p);raw=p.read_bytes();assert sha(raw)==before[name]['sha256'];compressed=p.suffix.lower() not in ['.jpg','.jpeg','.png','.webp'];q=out/'originals'/(name+('.gz' if compressed else ''));q.parent.mkdir(parents=True,exist_ok=True);encoded=gzip.compress(raw,compresslevel=9,mtime=0) if compressed else raw;q.write_bytes(encoded);assert (gzip.decompress(q.read_bytes()) if compressed else q.read_bytes())==raw
 rows.append({'original':name,'archive':str(q),'rawBytes':len(raw),'rawSha256':sha(raw),'archiveBytes':len(encoded),'archiveSha256':sha(encoded),'encoding':'gzip' if compressed else 'identity','rootVisuallyReviewed':name in reviewed})
for name,expected in before.items():assert {'bytes':Path(name).stat().st_size,'sha256':sha(Path(name).read_bytes())}==expected,name
subprocess.run(['rtk','proxy','node','scripts/release-fingerprint.mjs','verify',str(fp)],check=True)
r={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Eight explicit terminal commands, formal fixed prefix sources, actual CUA UI snapshots/export and original screenshots, current code/runtime and bounded audits. Every input retained; pre-publication task/audit snapshots are not completion receipts. Cropped IAB images stay cropped and retain their limits. Not a new twelve-day matrix or human positive endorsement.','runs':runs,'files':rows,'payloads':len(rows),'losslessRoundtrip':True,'allInputBeforeAfterSHA256Match':True,'rootReviewedImages':reviewed,'finalSourceFingerprint':str(fp),'sourcePublicationPending':True,'humanOverallPositiveEndorsement':False};(out/'manifest.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'ok':True,'commands':len(runs),'payloads':len(rows),'archive':str(out)}))
