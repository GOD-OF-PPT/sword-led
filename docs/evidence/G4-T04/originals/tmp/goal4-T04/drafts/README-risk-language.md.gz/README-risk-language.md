# T04 风险预告与估值术语：有界浏览器候选

**UNEXECUTED。只写隔离草稿，未激活/运行/类型检查。** 不在当前tests/glob内；没有更改src/docs/tasks/config/dist或共享helper。root统一审阅、复制、type/build并串行实际消费后，才能产生当前验证结果。

## 激活目标与原件

- `t04-risk-language.UNEXECUTED.spec.ts` → `tests/release-v5/t04-risk-language.spec.ts`。
- `t04-credit-prefix.UNEXECUTED.json` → `tests/fixtures/v5/t04-credit-prefix.json`。
- `t04-risk-language-manifest.json` 绑定全部SHA、激活目标、明确预算及来源；`originals/`保留fbf04ea提交的app/shared-v5 helper/plans原字节，以及实际T02 credit完整原件。已发布胜利记录原件继续引用其现有923713字节文件和SHA，不重复复制或改写。
- 草稿import按激活后目标书写，不能直接从tmp执行。它只复用现有KeyboardV5、正式dist SDK与replayV5；不要求改任何旧helper或配置。

## 固定合法来源，不搜索seed

稳手来源是已发布`v5-economy-0`胜利guide前16条Accepted，下一条公开strike为d3-1首裂；旧audio-identity-crack原件亦记录过该边界。未保护对照仅从这段命令中省略可选claimGift，再由正式createRun/applyCommand完整重放：不是删除trait/改RNG/改估值。两条路线必须各经当前SDK validateRun及正式codec后才能恢复页面，结果不是新整局。

credit来源固定为T02 matrix01 Chromium1的`v5-event-credit-13`原件（manifest有完整路径/SHA）：journal19为charge6且赊护待用，22为真实首次赊护裂损前，23为消费后带裂，25为真实第二裂断。小fixture只提取原input与25条原Accepted命令。候选不会调用旧eventBoundaryV5的64seed选择，也不增加任何种子/模型扫描；若固定来源不再满足断言，应保留失败，不能找另一seed求绿。

## 单case的实际责任

四次独立、明确标注的合法前缀恢复；六次实际UI Accepted落锤，全量状态与冻结正式SDK相等：

1. 未领保护的首裂预告，实际首裂按80%掉估值。
2. 稳手的首裂保价且留纹；实际首裂前后估值相同、trait仍装备，但同一已裂剑预告再裂会断，不能因看见steady就永保价。
3. credit仍待用且charge6时优先显示本记安全连锻；真实连锻无裂/断，不消耗credit。
4. credit普通首裂保价留纹、正式crackGuard变false；选另一未裂新坯时必须不再称首裂保价；回选已裂剑再打一成功及一次真实第二裂，最后断裂且无credit触发。

这同时检查“已消费”的公开字段与真实结果，不从历史接受过credit/旧动画trigger推断仍有保护。主风险行保护文案使用语义regex（首裂/首次裂损保价、仍留裂纹），无要求某个标点或实现函数。无新增音频、性能、兼容矩阵。

稳手边界额外实际打开/关闭手艺说明、明日装箱完整纸单、商人手艺细则，并检查Canvas ARIA；每个窗口前后完整state及四个局/炉谱主备槽原文相同。术语检查只限当前可见说明及ARIA/实时浮字，不重写旧导入原件。float由测试自有MutationObserver记录真实接触时文本，最多16条，无timer/动画/生产hook或领域注入；finally总会解绑，避免Node RPC错过短浮字。

只读窗口的原文全等不等于统计Storage API写调用。六次实际落锤按正常合同写保存，不能报告整case“零写”。另不会把DOM文字检查当画面对比/可读性或物理声音证明。单case使用现有测试预算，不改旧阈值、等待、scope或动作结果。

## 输出与待root处理

运行后`v5-states.json`/`v5-commands.json`保留每次实际保存和Accepted；`t04-risk-language.json`在finally保留phase、各恢复来源、只读窗口原文、真实float及正式事件，失效则保首红。当前没有任何该新case的运行通过结论。

root可先用当前单Chromium DPR1做这一个消费；引擎/DPR范围由实际命令和报告记录，不因已有六项目配置就冒称已运行六项目。现阶段只交候选，不启动root服务、不调用浏览器/SDK/构建或独立nodecheck。
