from pathlib import Path
import hashlib,json,datetime,subprocess
b=Path('tmp/goal4-T04');baseline=json.loads((b/'baseline.json').read_text());sha=lambda data:hashlib.sha256(data).hexdigest()
allowed={'src/presentation-v4/forge.ts','src/presentation-v5/app.ts','src/presentation-v5/collection-ui.ts','src/presentation-v5/growth-options.ts','src/presentation-v5/market-stall.ts','src/presentation-v5/shell.ts','src/presentation-v5/stages.ts','src/presentation-v5/workbench-feedback.ts'}
changed=[]
for name,expected in baseline['source'].items():
 actual=sha(Path(name).read_bytes())
 if actual!=expected:
  assert name in allowed,name;changed.append({'path':name,'beforeSHA256':expected,'afterSHA256':actual})
new={str(p) for p in Path('src').rglob('*') if p.is_file()}-set(baseline['source']);assert new=={'src/presentation-v5/copy.ts'}
for name,expected in baseline['sdk'].items():assert sha(Path(name).read_bytes())==expected,name
before=(b/'originals/src/presentation-v4/forge.ts').read_bytes();assert sha(before)==baseline['sharedForgeBefore']
expected=before.replace(b'reduced():boolean;cue(cue:Cue)',b'reduced():boolean;valueLabel?:string;cue(cue:Cue)',1).replace('，身价${visual.value}，'.encode(),'，${host.valueLabel??\'身价\'}${visual.value}，'.encode(),1)
assert Path('src/presentation-v4/forge.ts').read_bytes()==expected
old=json.loads(Path('tmp/goal4-T03/baseline.json').read_text());protected=old['protected']
for row in protected:assert sha(Path(row['path']).read_bytes())==row['sha256'],row['path']
ref=subprocess.check_output(['rtk','proxy','git','rev-parse','codex/workshop-scene-full-evidence'],text=True).strip();assert ref==old['backupRef']
for p in Path('dist').rglob('*.js'):
 for token in ['t03Runtime','t03Lifecycle','v5ReleaseAudio']:assert token not in p.read_text(),(p,token)
r={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ok':True,'baselineCommit':baseline['baselineCommit'],'sourceFiles':len(baseline['source'])+len(new),'existingSourceUnchanged':len(baseline['source'])-len(changed),'changedPresentationOnly':changed,'newSource':sorted(new),'all9SDKsUnchanged':True,'allCoreAndSaveInterpretersUnchanged':True,'protectedArtUnchanged':len(protected),'backupRef':ref,'sharedForgeExactOptionalLabelDiff':True,'noTestProbeInProduct':True};(b/'preserved.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps(r,ensure_ascii=False))
