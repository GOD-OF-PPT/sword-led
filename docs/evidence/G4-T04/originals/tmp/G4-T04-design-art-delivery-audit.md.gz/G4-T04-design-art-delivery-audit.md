# G4 / T04 设计、美术与交付来源只读审计

审计时间：2026-10-23；只读审计基线 `fbf04ea94ed4ada8d94e45a30cfbb58f6f124544`。读取当前文件、Git 对象/历史、原始批准 JSON、素材 manifest，以及明确标识版本的已归档发布原图。只读阶段工作树仅 `goal-4/plan.md` 为 root 正在更新；随后 root 在同一 T04 明确授权四份当前索引的状态修正，结果单列文末。未修改产品源、任务、资源或 dist，未运行浏览器、构建、SDK、模拟或矩阵。root 的并行产品修缮不由本报告冒称已验证。

## 结论与可修缮项

未找到“选定近景图仍仅停在概念稿、没有开发”的当前对应缺口。近景背景、可操作锤剑、三柄剑架、人物纸单、真实作品及章节用途图均有当前生产接线；它们不是一张概念整图上的点击区域。此结论限于下述具体映射与既有发布截图，不等于任意画面逐像素复刻、当前新一轮浏览器验收或真人认为有趣。

发现以下当前交付一致性问题，可在 T04 内小修，不需要重新选画风、改引擎或改规则：

| 项目 | 精确现状 | 建议与限界 |
| --- | --- | --- |
| 当前保存合同的阶段措辞过时 | `docs/v0.8-persistence-contract.md:3` 仍写“当前默认网页已接 v0.8 第一章”“详见首章指南”；`:27` 写“后续扩展中后段经营”。当前 `README.md:5`、`docs/v0.8-twelve-lights-guide.md:6` 和生产 journey 都已是三章十二天。 | 更新现行顶部/链接与阶段说明，保留历史 3l.2 实施记录；这不是产品缺后八天。 |
| D 素材页仍将旧入口称作当前 | `design/d/README.md:5` 写“当前新版入口为 /v2.html”；该页由当前设计总索引作为正式 D 派生入口引用。 | 增加现行 `/` v0.8 / 旧 `/v2.html` 的明确范围，保留首版资产与五节十点的历史描述。 |
| 当前设计总索引标题落后付款修缮 | `design/README.md:3` 仍称当前为“炉边交易 · 三柄行囊”；`README.md:5`、指南 `:6` 与 v5 标题均为“炉边报价 · 三柄行囊”。 | 对齐当前产品名；“炉边交易”作为过去界面阶段仍可保留。 |
| 当前 v5 仍有旧价格术语直出 | 已发布 1280 图可见 `+105 身价`，对应 `src/presentation-v3/impact.ts:37`；当前 v5 直写字符串还见 `market-stall.ts:113`、`growth-options.ts:72`、`workbench-feedback.ts:74`，共享 forge Canvas ARIA 见 `presentation-v4/forge.ts:141`。这些路径绕开 `presentation-v5/app.ts:48` 已有身价→估值、金币→铜钱的投影。 | 结合已收到的费用关系 H，建议统一当前 v5 语义展示，保留 core、存档原文、旧版本与历史图稿。当前 guide `:3` 已解释旧称同义，因此这本身不证明计价错误。root 已另要求补全精确输出清单。 |

原用户曾指出构图未实装的事实不能被当前修缮追改。`goal-1/feedback-2026-10-19.md` 同时保存后续“界面确实更新了”与玩法复杂的反馈，以及后来“方向和比例已经自然”的锤子单项反馈。以上分别证明不同阶段/具体对象，均不冒称整体趣味获得认可。当前费用反馈及澄清已在 `goal-4/input.md` 原文保留；付款修后的可选再反馈未收到，不能自行编造答复，也不在本子审计另加审批门。

## 原五项的当前证据

| 原要求 | 当前直接证据 | 可证范围 |
| --- | --- | --- |
| 整理游戏思路，创建 GitHub，提交推送 | `docs/game-design.md`、`docs/implementation-plan.md`、原始 `goal-1/input.md` 均在初始提交 `50be0b0521b241c6f431eb50897701cb368fe28b`；当前 origin 与 fresh 远端见下文。 | 文档、仓库、当前提交远端存在；不等于公网游戏托管。 |
| 设计 UI/内核/架构、确认实施、imagegen 三选一后派生 | 当前架构 `docs/architecture.md:3-7` 与历史技术选择 `:25-29`；原答 `docs/decisions/2026-10-17-user-approval.json`；三候选原图/提示词/manifest 与 B→D→近景记录见下文。 | 已形成并批准实施范围，三个独立真实图稿及派生链存在，不是文字替代图。 |
| 复核设计/实施文档、完整流程与可玩性 | 当前 v0.8 提案、公开 API、十二灯 guide 和当前设计/架构顶部分别映射生产 core-v5/session/presentation-v5。原高复杂度操作已由后续获批 v0.4 合同替换；v0.8 继续全十二单、三结局、成长和经营取舍。 | 本项确认设计和实现映射，不用绿测或静态规则声称主观乐趣；root 的 T04 实际体验/最终审计另承担。 |
| 先主逻辑，再按批准风格开发全界面 | Git 历史：设计/架构 `51a022e` → 三图/R1 `582f606` → 核心 `45f7f38` → 存档 `d58ccfd` / 整局核 `a2dd740` → B 派生 `961791d` → 工坊 `c79ea46` / 完整经营界面 `541f2c4`。后续 D 内核 `795b0bc` 早于 D 全界面 `994a925`；指定近景实装为 `f620197`。 | 提交内容与依赖顺序有据；不把 commit subject 单独当实装证明，当前映射另读源码。 |
| PC 网页，不做低版本兼容 | `index.html:2` 真入口为 `/src/v5-main.ts`；`vite.config.ts:7` 保留默认与四个历史 HTML；`src/v5-main.ts:1-14` 装配真实 v5 会话/界面。现行架构为 TypeScript/Vite + DOM/CSS/Canvas 2D。 | 符合已批准的浏览器技术路线；未新增手机、低版本或引擎迁移要求。 |

## 三套 imagegen 候选及批准时间线

`design/concepts/manifest.json` 当前记录 `image_gen.imagegen`、built-in、模型未暴露，A/B/C 各 v1/v2/v3 共九图，每图有完整 prompt 文件、引用父图、工具原保存路径、尺寸、SHA。当前独立重算九图及九 prompt，全部符合 manifest 且已 Git 跟踪；九个 Codex generated_images 源文件仍存在，逐一与项目副本 SHA 相同。实际打开最终三图，A 炉火写实、B 纸木手绘、C 冷灰多边形可辨，均有共同第6/12轮示例状态；三图不是拼成一图代替独立候选。

| 最终候选 | 原件 | 当前 SHA-256 |
| --- | --- | --- |
| A 余烬工坊 v3 | `design/concepts/main-a-v3.png` | `4d8ac390a4e9f9839fed92f3575ae0e9c81d94720f31c03964d3ca3d0f32de69` |
| B 行会手账 v3 | `design/concepts/main-b-v3.png` | `1559ed5b09c82a0a9eff6d3d0e779c16e13ed3c7216aa5925a6d54592aff75bd` |
| C 冷铁控制台 v3 | `design/concepts/main-c-v3.png` | `ff400a9d5f072691677dbd20b6925391b1fa00e15b992fea4f1bf1003e66b283` |

1. 最初实施与 B 选择的两条实际答复在 `docs/decisions/2026-10-17-user-approval.json`，分别为“确认 v0.2，开始玩法内核”“B 行会手账”，不是投递 accepted 推定批准。
2. D 偏好原答在 `docs/decisions/2026-10-18-v03-art-preference.json`；图为 `design/v03/concepts/main-d-v1.png`，SHA `e500a4607f1d3bf8b137038a8ca887d7c6ab28a12e7f76cd38386f55530d8701`。这是美术偏好，规则另有独立批准。
3. 后来用户指明的近景附件保存在 `design/d/reference-main-v2.png`；本次重算确认与早期探索名 `design/v03/concepts/main-b2-v1.png` 同字节，SHA `8851c2d361e032340bcd2f472bab827c83d7122987ee6c200fc387e6141ff949`。旧 B2 当时未选和后来选同一张图并不矛盾，不能以旧文件名否认后来的指定。
4. `docs/decisions/2026-10-19-v04-approval.json` 明确批准移除默认十点选位、时机题、逐锤换锤和独立淬火，保留 D/旧档；故当前没有照搬概念稿的水/油盆、三锤和五节十点，不是悄悄删掉现行合同。
5. v0.7、v0.8 规则批准在相应 `docs/decisions/` JSON；v0.8 答复为“确认 v0.8，开始首章实施”，记录的 approvedScope 是完整提案，包括后十二单/三结局。冻结全文 `docs/evidence/v08-approval/approved-proposal.md` 保留当时未实施措辞，不能为当前状态改写原答/快照。

## 派生资产到当前实际表面的对应

| 资产/设计 | 当前生产接线 | 实装判断 |
| --- | --- | --- |
| 指定近景独立工坊背景 | `design/d/revision-v2-manifest.json` → `public/assets/d/forge-backdrop-v2.webp`；`src/presentation-v4/styles.css:81` 为实际 `.v4-workshop` 背景，`src/v5-main.ts:3` 导入 | 原图背景不是含 HUD 的整张概念稿；目前近景布局仍使用同派生。 |
| 自然锤与完整剑 | `design/d/hammer-forge-v2-manifest.json`；`presentation-v4/forge.ts:133` 注册锤，`:145` 注册武器图集；`forgeAppearance:22-24` 按真实配方/等级取三家族五阶段；`shell.ts:52-61` 是 Canvas+真实按钮+独立 img | 真实 Blade 状态绘制；hit、risk、value 与输入出口为 DOM，不是图片假文字。 |
| 左三柄剑架/配方、中央风险/六格锤势、右订单与报价 | `presentation-v5/shell.ts:35-48,64-108`，`app.ts` 正式 view/Accepted 投影；付款 `payment-copy.ts` 读取正式 quote | 当前三柄供给与估值/实收语义符合 v0.8，概念数字/旧热度不当现行规则。 |
| 人物等待/收剑与手艺实体 | `design/d/v05/runtime-assets.json` / `v3-art-manifest.json`；当前 `styles.css:128,152`、`presentation-v5/market-stall.css:15`，以及 v5 workbench 真实收剑反馈 | 人物和道具为独立图集，不是概念人像烘入纸单。历史 notebook cover/commission guard 等保留，不声称每个历史资产都还在当前界面使用。 |
| 改造/事件 | `design/d/v07/manifest.json`；`presentation-v4/forge.ts:145,200-211` 注册并按真实 id 取图；v5 stages/market 用 prop | 真实成长/事件投影，不注入奖励。 |
| 第1章开场/渡口明暗，第2章冬炉/双驿0、1、2，第3章接力与三结局 | 五张 v07、七张 chapter2、九张 chapter3 manifest；`presentation-v5/journey.ts:32-42,114` 按真实 complete/count/phase 选图，`stages.ts:103` 选章开场 | 21 张图具有状态条件；没有以一张全亮终局代替未完成/部分完成。 |
| 当前交付回执、旅程回望、炉谱真实作品 | `presentation-v5/app.ts:204,365`、`collection-ui.ts:54` 读 outcome/commissionImage 并接辅助画稿恢复 | 不是仅标题/背景有新画稿；三个实际消费入口存在，fallback/重试代码没有替代领域结果。 |

本次 SHA 检查分两组：211 项/158 个唯一项目文件（候选、D 近景/自然锤/兵器、人物与三章来源链）及 73 项/73 文件（历史 B、首版 D、scene UI）；共284项、231个不同项目文件，0缺失/哈希不符/未跟踪。B 包为15原图+9运行图，首版D为10原图+8运行图；新人物、兵器和章节源均另保留。只做字节核对，没有重编码、重画、重新运行 alpha 检验；manifest 的 alpha/转换结论保留其原生产时身份，不写成当前新像素验证。

另实际打开近景参考图和明确已发布的两尺寸原图：

- `docs/evidence/G4-T03-final-technical/originals/tmp/goal4-T03/native-menu-published-workshop-1280.png`，SHA `4951e03db822d4385be2e864ca9c9cae690c925ec8fc73b4489471b127a0f755`。
- 同目录 `native-menu-published-workshop-1920.png`，SHA `e9a8501036095951506b76d4e3ae3550fee3d80b0abf4239c6f083131a5513f2`。

可见近景木铁/青蓝布景、完整大剑、自然锤、左架右纸单、实际估值201/报价120及铜钱等式，与上述代码映射相符。两图的版本来自该 archive manifest/source-publication；它们不冒称本次 T04 新浏览器截图，也不证明所有状态或真人审美接受。

## GitHub、文档与入口一致性

- 当前 origin：`https://github.com/GOD-OF-PPT/sword-led.git`。本次实际 `gh repo view` 返回 `GOD-OF-PPT/sword-led`、`PRIVATE`、默认 `main`、创建 `2026-10-17T08:09:24Z`；没有把“私有 GitHub 仓库”误报成公开部署。
- 本次实际 `git ls-remote origin refs/heads/main` 返回 `fbf04ea94ed4ada8d94e45a30cfbb58f6f124544`，与本地 HEAD 相同。源/图在当前无变更工作树、并由同 HEAD 的 Git 树跟踪。现有最终发布收据 `docs/evidence/G4-T03-final-technical/source-publication.json` 还独立绑定产品提交 `fe14556763b16edfb02ae93b98364f953174bcd5`、证据提交 `b12f6341171d7fd3f0acf5d43a1e4047ed237ee2`、push0、GitHub根tree和七代表blob；本次读到的收据不替换为假新发布事件。
- 默认 `index.html:2` → `src/v5-main.ts` → `mountV5` / `createV5BrowserSession`；`v4.html` / `v3.html` / `v2.html` / `legacy.html` 各装配自己的旧 main。`vite.config.ts:7` 明确五个 HTML 都进入正式构建。
- 当前 README、架构、游戏设计、UI设计、实施方案的顶部均区分现行 v5 与旧 v1–v4；旧表中的热度、五节十点、时机、旧配额不能读成现行未实现需求。README `:144` 的入口表与各 HTML 脚本一致。
- 对 README、当前设计/架构/实施/决策、当前指南/保存合同、设计总索引/D/v03页共11份文档的232条相对 Markdown文件链接做存在性核对，0缺失。只核文件目标存在，不声称逐个锚点/站外URL/游戏运行通过。
- README 明确 4179 是本机预览、未公网部署；原五项没有新增公网托管要求。后续 root 的当前 HTTP/冻结快照检查另承担，不以本次仓库静态核代替。

## 审查限界与责任

本次没有运行游戏、解锁路线、原生声音或性能消费，没有重做任何矩阵，也没有触碰旧档/原图/失败。当前产品功能与安全由同 T04 的独立子审计及 root 最大审查承担；本报告只对设计合同、批准链、资源/代码映射和交付来源作结论。

[杠精审查] 通过只读审计完整性；交付一致性上述文字缺口需由 root 决定并修缮，不因素材数量/提交/历史绿测就宣称整个原目标完成。没有重新加引擎、玩法、低版本、手机范围或重复批准门。

## 同一 T04 的获授权文档修正

root 收到审计后明确授权仅编辑四份现行索引，已经完成：

- `design/d/README.md`：顶部加默认 `/` v0.8、当前指南/技术复核；把 `/v2.html` 与首版素材/报告准确标为 T11.3 历史。
- `docs/v0.8-persistence-contract.md`：改为三章十二天，说明已有首章档可接续后八天，指向当前指南、完整流程和技术复核；原保存/导入合同保持。
- `docs/v0.8-workshop-economy-proposal.md`：修当前实施状态、已采用 v5 身份和当前链接；把来源的 v4 基线、批准前纸面审查与后续已实施事实区分，不改规则/算例。
- `openspec/changes/rebalance-workshop-economy/design.md`：去除中后段待接、实施仍待办等过时现状，保留提案验证安排的历史身份，指向后续分批结果，不改 Decisions。

四文件差异为18行新增/14行删除；scoped `git diff --check` 实际0。对照 HEAD 原文逐字比较，经济提案“为什么继续改玩法”至“来源与审查状态”、OpenSpec 的完整 Decisions、保存合同表格至实施记录前的合同正文均保持原字节；对应SHA分别为 `74984aa06fb0f7d58a273e670d4559593e6821651baef4c8922099095520b3c3`、`a7c8f1560b41187142e262308e1471c1245f8efda128900b74d51ad2148100fd`、`2931e234c1450e13bc0e403d680f12a20725798a2f595cc720b28d8387f858d2`。冻结批准全文仍符合批准JSON的 `c6a605c29e29d83ee9f3bae6700270af96d749f30d29e6de2c17bfb14acd04aa`。新增本地链接0缺失。未提交，交由 root 纳入 T04 整体审查/交付。

语义输出补查另见 `tmp/G4-T04-v5-semantic-copy-locations.md`，是当前源码消费链清单，未执行 UI 消费。当前产品文案和其余文档/任务由 root 独占；本文上方的原发现按审计基线保留，不伪造为修后实测。
