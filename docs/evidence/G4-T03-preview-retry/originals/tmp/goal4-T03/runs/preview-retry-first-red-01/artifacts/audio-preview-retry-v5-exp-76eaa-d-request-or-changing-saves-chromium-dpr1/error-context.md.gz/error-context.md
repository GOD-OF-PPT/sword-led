# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: audio-preview-retry.spec.ts >> v5 explicit preview retry replaces a held preview without replaying the old request or changing saves
- Location: tests/release-v5/audio-preview-retry.spec.ts:5:1

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 1
Received:   1

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - region [ref=e4]:
    - generic [ref=e5]:
      - paragraph [ref=e6]: v0.8 炉边报价 · 三柄行囊
      - heading "锤下求生" [level=1] [ref=e7]
      - paragraph [ref=e8]: 一炉火，一柄剑，一程未熄的灯。
      - button "启程" [ref=e10] [cursor=pointer]
      - generic [ref=e11]:
        - button "翻开炉谱" [ref=e12] [cursor=pointer]
        - button "炉边设置" [ref=e13] [cursor=pointer]
      - link "旧版十二灯行程" [ref=e14] [cursor=pointer]:
        - /url: /v4.html
      - group [ref=e15]:
        - generic "+ 行旅种子与更早旧路" [ref=e16] [cursor=pointer]
    - paragraph [ref=e17]: 左键落锤，拖剑交客。好剑总有它要去的地方。
  - text: › 收讫
  - navigation "行旅工具" [ref=e18]:
    - button "查看保存详情" [ref=e19] [cursor=pointer]: 本机存档
  - status [ref=e20]
  - dialog [ref=e21]:
    - heading "声音与动效" [level=2] [ref=e22]
    - generic [ref=e24]:
      - generic [ref=e25]:
        - generic [ref=e26]: 静音
        - checkbox "静音" [ref=e27]
      - generic [ref=e28]:
        - generic [ref=e29]: 敲击音量
        - slider "敲击音量" [ref=e30]: "55"
      - generic [ref=e31]:
        - generic [ref=e32]: 减弱动效
        - checkbox "减弱动效" [ref=e33]
      - paragraph [ref=e34]: 设置已保留
      - status [ref=e35]: 声音尚未启用，可点“试听敲击声”重试；锻造仍可继续。
      - button "试听敲击声" [active] [ref=e36] [cursor=pointer]
    - generic [ref=e37]:
      - button "保存失败时重试" [ref=e38] [cursor=pointer]
      - button "收好" [ref=e39] [cursor=pointer]
```

# Test source

```ts
  1  | import {test,expect} from '../e2e/fixtures.js';
  2  | import {writeFile} from 'node:fs/promises';
  3  | import {installReleaseAudioProbe,releaseAudioSnapshot,setReleaseAudioFaults,resetReleaseAudioCapture} from './audio-probe.js';
  4  | 
  5  | test('v5 explicit preview retry replaces a held preview without replaying the old request or changing saves',async({page},info)=>{
  6  |  await installReleaseAudioProbe(page);await page.goto('/');await expect(page.locator('#v4-start')).toBeEnabled();
  7  |  const keys=['sword-led.save.v5','sword-led.save.backup.v5','sword-led.collection.v2','sword-led.collection.backup.v2'];
  8  |  const slots=()=>page.evaluate(keys=>Object.fromEntries(keys.map(key=>[key,localStorage.getItem(key)])),keys);
  9  |  const before=await slots(),retry=page.getByRole('button',{name:'试听敲击声',exact:true});
  10 |  let phase='normal-preview';
  11 |  try{
  12 |   await page.locator('#v4-title-settings').click();await retry.click();
  13 |   await expect.poll(async()=>(await releaseAudioSnapshot(page)).capturedPeak).toBeGreaterThan(.001);
  14 |   await expect.poll(async()=>(await releaseAudioSnapshot(page)).starts).toBe(3);
  15 |   await page.getByRole('button',{name:'收好',exact:true}).click();
  16 |   await expect.poll(async()=>(await releaseAudioSnapshot(page)).states).toEqual(['suspended']);
  17 |   await expect.poll(async()=>(await releaseAudioSnapshot(page)).active).toBe(0);
  18 |   await page.locator('#v4-title-settings').click();
  19 |   await setReleaseAudioFaults(page,{defer:true});await resetReleaseAudioCapture(page);
  20 |   phase='held-preview';await retry.click();
  21 |   await expect.poll(async()=>(await releaseAudioSnapshot(page)).deferred).toBe(true);
  22 |   const held=await releaseAudioSnapshot(page);expect(held.hasDeferredResume).toBe(true);expect(held.starts).toBe(3);expect(held.active).toBe(0);
  23 |   phase='explicit-retry';await retry.click();
> 24 |   await expect.poll(async()=>(await releaseAudioSnapshot(page)).resumeCalls).toBeGreaterThan(held.resumeCalls);
     |                                                                              ^ Error: expect(received).toBeGreaterThan(expected)
  25 |   await expect.poll(async()=>(await releaseAudioSnapshot(page)).capturedPeak).toBeGreaterThan(.001);
  26 |   await expect.poll(async()=>(await releaseAudioSnapshot(page)).starts).toBe(6);
  27 |   const current=await releaseAudioSnapshot(page);expect(current.contexts).toBe(1);expect(current.states).toEqual(['running']);
  28 |   phase='release-old';await page.evaluate(()=>{const release=window.v5ReleaseAudio.releaseResume;if(!release)throw Error('Missing held preview request');return release();});
  29 |   await expect.poll(async()=>(await releaseAudioSnapshot(page)).operations.some(row=>row.origin==='held-release'&&row.phase==='settled')).toBe(true);
  30 |   expect((await releaseAudioSnapshot(page)).starts).toBe(6);
  31 |   await page.getByRole('button',{name:'收好',exact:true}).click();
  32 |   await expect.poll(async()=>(await releaseAudioSnapshot(page)).states).toEqual(['suspended']);
  33 |   await expect.poll(async()=>(await releaseAudioSnapshot(page)).active).toBe(0);
  34 |   const final=await releaseAudioSnapshot(page);expect(final.starts).toBe(6);expect(final.sources.every(source=>source.disconnected)).toBe(true);expect(await slots()).toEqual(before);
  35 |   phase='complete';
  36 |  }finally{
  37 |   await writeFile(info.outputPath('explicit-preview-retry.json'),JSON.stringify({phase,before,after:await slots(),audio:await releaseAudioSnapshot(page),scope:'Real normal preview then a declared test fault holding the next native resume invocation after confirmed suspension. A second actual click must issue a fresh native request; stale preview never sounds and all game/collection bytes remain unchanged. Not the original late-title case or proof of physical speakers.'},null,2)+'\n');
  38 |  }
  39 | });
  40 | 
```