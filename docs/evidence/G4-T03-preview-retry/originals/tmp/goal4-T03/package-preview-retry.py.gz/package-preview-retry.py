from pathlib import Path
import json,gzip,hashlib,datetime
base=Path('tmp/goal4-T03');out=Path('docs/evidence/G4-T03-preview-retry');assert not out.exists()
labels=['build-22','preview-retry-first-red-01','preview-retry-repair-01','legacy-clock-cleanup-01','preview-retry-published-01']
files=set();runs=[]
for label in labels:
 folder=base/'runs'/label;p=folder/'process.json';d=json.loads(p.read_text());assert d['status']=='terminal' and isinstance(d['actualExitCode'],int);runs.append(d)
 for p in folder.rglob('*'):
  if p.is_file() and 'attachments' not in p.parts and p.suffix in {'.json','.jsonl','.log','.md','.txt'}:files.add(p)
 for suffix in ['-fingerprint.json']:
  p=base/(label+suffix)
  if p.exists():files.add(p)
for name in ['preview-retry-change.json','preview-retry-runtime-delta.json','preview-retry-snapshot.json','preview-retry-published.json','preview-retry-published-raw-run.json','preview-retry-publish.mjs','package-preview-retry.py','originals/src/presentation-v5/app-preview-retry-before.ts','originals/tests/e2e/v3-impact-clock-cleanup-experiment.ts']:
 p=base/name;assert p.is_file();files.add(p)
for draft in ['v3-clock-cleanup','audio-probe-pure-late-completion']:
 for p in (base/'drafts'/draft).rglob('*'):
  if p.is_file():files.add(p)
for name in ['G4-T03-audio-attribution-review.md','G4-T03-explicit-preview-retry-review.md']:
 p=Path('tmp')/name;assert p.is_file();files.add(p)
visuals=[base/'preview-retry-settings-1280.png',base/'preview-retry-settings-1920.png']
files.update(visuals)
for label in ['preview-retry-first-red-01','legacy-clock-cleanup-01']:
 for p in (base/'runs'/label).rglob('test-failed*.png'):
  if 'attachments' not in p.parts:files.add(p)

rows=[];out.mkdir(parents=True)
for p in sorted(files):
 b=p.read_bytes();compress=p.suffix!='.png';q=out/'originals'/Path(str(p)+('.gz' if compress else ''));q.parent.mkdir(parents=True,exist_ok=True);stored=gzip.compress(b,compresslevel=9,mtime=0) if compress else b;q.write_bytes(stored);assert (gzip.decompress(q.read_bytes()) if compress else q.read_bytes())==b
 rows.append({'source':str(p),'archive':str(q.relative_to(out)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'storedBytes':len(stored),'storedSHA256':hashlib.sha256(stored).hexdigest(),'encoding':'gzip' if compress else 'original'})
for row in rows:assert hashlib.sha256(Path(row['source']).read_bytes()).hexdigest()==row['sha256']
m={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Bounded explicit-preview retry product repair: first red, strict build22, nine three-engine DPR1 passes, immutable publication smoke, and unsuccessful legacy clock cleanup preserved. Pure late-completion probe remains an unexecuted isolated draft. Original audio137/138 and FF2 callback81 remain unchanged facts. Not T03 or goal completion; all originals remain.','taskComplete':False,'goalComplete':False,'runs':runs,'files':rows,'reviewedImages':[{'path':str(p),'reviewer':'root','finding':'Root actually viewed current published settings at1280/720 and1920/1080: retry/status/close visible without clipping. Native wave belongs to separate nine-case batch; screenshot alone is not physical output evidence.'} for p in visuals],'allInputsUnchanged':True,'gzipRoundtripVerified':True};(out/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'ok':True,'runs':len(runs),'files':len(rows),'taskComplete':False}))
