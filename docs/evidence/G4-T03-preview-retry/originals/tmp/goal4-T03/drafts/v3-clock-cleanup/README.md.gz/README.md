# v3 first impact case — paused Clock cleanup candidate (UNEXECUTED)

Only this isolated tmp directory was authored. No shared source/test/config/dist/harness file was changed. No Node/SDK import/replay, compiler, browser, build, test discovery or image decode was run. Python performed text copying/diff, existing JSON parsing and SHA checks only. Root owns actual activation/execution. The original two timeout batches remain untouched.

## Observed failure boundary

| Existing run | Project / environment | Actual first-case result |
| --- | --- | --- |
| legacy-current-02 | v3-chromium / headed | timedOut183980ms; only error `Tearing down "context" exceeded the test timeout of 180000ms.` |
| legacy-target-03 | v3-chromium / headed | timedOut183609ms; same sole context teardown error |
| legacy-current-02 | v3-firefox / headed | passed4602ms |
| legacy-current-02 | v3-webkit / headed | passed2655ms |
| legacy-input-01 | v3-chromium / historical headless | passed2591ms, original identity only |

The two current headed batches ended actual1 with end-fingerprint actual0/matchestrue/changed[]. Their reports do not contain an assertion/dispatch error in this v3 body, but do not contain a body-completion marker either. This supports investigating the fixture close boundary; it is not independent proof of every intermediate assertion or a statement that the product passed. Earlier headless success does not replace the two current headed failures or establish which environmental change matters.

The spec imports `test` directly from `@playwright/test`, so the custom runtimeAudit auto fixture in `tests/e2e/fixtures.ts` is not participating in this case. The legacy config has one worker, retries0, timeout180000, trace/video off. There is no video finalization in this first case and no body `context.close()` or explicit awaited audio disposal. Its later fifth case has an explicit recorded-video context, but that separate case is not this failure.

## Exact test-side clock state

The first case installs the Playwright clock, then near its end calls `pauseAt(Date.now()+1000)`, exercises the real double-click/busy-Space controls, and advances the fake clock with `runFor(350)`. All original state/RNG assertions and the final keyup occur afterward; there is no `clock.resume()` before the test returns. `runFor` advances a bounded interval while the clock remains paused.

Installed Playwright/core version is1.64.1. The installed primary type documentation (`types/types.d.ts:20780–20870`) lists fake Date/Temporal/timers/rAF/idle/performance and defines `resume():Promise<void>` as resuming timer flow. `AudioContext`, its currentTime, native resume/suspend/close and its audio-thread scheduling are not clock-controlled APIs in that contract. Thus fake350ms can finish DOM/rAF animation while native audio has advanced a different real amount. This makes the mixed lifecycle relevant to inspect, but does not prove any native audio Promise is actually pending here or that an ordinary short sound explains180s.

Installed server implementation adds a concrete cleanup boundary: `coreBundle.js:55883` sets the BrowserContextDispatcher `_clockPaused` flag on clockPauseAt; clockRunFor does not clear it; clockResume awaits the context clock's resume and clears it. `_onDispose` checks `context.isClosingOrClosed()` and returns before its later `resumeNoReply` fallback. Therefore a consumer must not assume normal context close first awaits restoration of its paused fake schedule. This is a reason to explicitly release the test's own clock control before fixture teardown, not a confirmed Chromium deadlock diagnosis.

Product entry `src/v3-main.ts` registers app.dispose only for HMR. `mountV3.dispose` would await port/audio disposal if called, and `createForgeAudio.dispose` uses actual native context.close. The current failing body neither exposes nor calls those private functions, and its reports contain no native operation/state timeline. It is not valid to claim that fixture teardown is awaiting a product close Promise, that AudioContext.currentTime was frozen, or that Clock.resume repairs a proven audio bug.

## Minimal proposed consumer cleanup

Only the existing first case changes: install the clock as before, execute its entire original business body inside `try`, then `await page.clock.resume()` in `finally`. The clock release runs after the original final equality assertion on a passing body and also runs if the body fails. All original pause/runFor/double-click/input timing and assertions remain byte-identical as a retained business-body substring. The other four cases are byte-identical, and the spec still contains five cases.

A small existing-test attachment records `bodyCompleted`, the `page.clock.resume` operation's completion and its elapsed Node hrtime. It does not evaluate the page, inspect/close an audio context, trigger a UI action or insert a delay. A cleanup/attachment error after a passed body still fails the case; if the original body already failed, an annotation retains the cleanup error while the original thrown assertion/error propagates unchanged. This avoids replacing an original failure with a secondary cleanup error.

The fixture continues to own and close the context normally. There is no manual page/context close, about:blank navigation, extra pause/mute click, synthetic lifecycle event, native audio wait, sleep, replay, higher timeout or changed expectation. `resume()` restores ordinary flow of the installed fake schedule; it is not an uninstall or a call to native AudioContext.resume.

## Verification root can perform

After other live consumers terminate and the original source SHA still matches `manifest.json`, review and activate this patch alone; use normal strict checking, then run the same already-declared v3-chromium first case in the same headed environment, retries0/180000 unchanged. This is a targeted observation of the existing case, not a new case or matrix. The normal report plus completed `v3-clock-cleanup` attachment must show both body completion and a successful fixture teardown. No fixed added wait is part of the proposal.

If cleanup returns but context still times out, explicit Clock release is insufficient and the preserved attachment distinguishes that boundary. Do not stack mute/navigation/waits to manufacture a green result: next inspect the existing Chromium close/protocol boundary and native audio operations in a separately authorized, bounded diagnostic. If the targeted case passes, it supports this consumer resource cleanup under that identity; it still does not isolate native audio as the causal root or erase the two original red results. FF/WebKit's current passes and all previous evidence keep their own identities.

## Files and activation guard

- `originals/tests/e2e/v3-impact.spec.ts`: complete original8554bytes, SHA256 `673b9e1fa67fb0fb09f17047f5106570ff4887ebbb1b9dec09ec73553511c01c`.
- `candidate/tests/e2e/v3-impact.spec.ts`: complete candidate, hash/bytes in manifest.
- `v3-clock-cleanup.UNEXECUTED.patch`: unified diff; only first case.
- `manifest.json`: original/candidate/patch hashes and static retention checks.
- `read-inputs.json`: SHA/bytes of the exact original reports, configuration, inspected product code and installed clock documentation/implementation. It binds reads, not a new test execution.

After the active batch ends, from repository root:

```sh
rtk proxy git apply --check tmp/goal4-T03/drafts/v3-clock-cleanup/v3-clock-cleanup.UNEXECUTED.patch
rtk proxy git apply tmp/goal4-T03/drafts/v3-clock-cleanup/v3-clock-cleanup.UNEXECUTED.patch
```

Neither command has been run. If the original source differs, stop and rebase the candidate; do not overwrite unknown changes. No current source or old evidence was edited by this work.

[Adversarial review] All original business assertions and controlled busy timing remain intact. The proposal releases only the test-owned fake scheduling control after those assertions, leaves actual context teardown as a required result, records cleanup completion and preserves first failures. Static review only; root must obtain the actual targeted result before calling it fixed.
