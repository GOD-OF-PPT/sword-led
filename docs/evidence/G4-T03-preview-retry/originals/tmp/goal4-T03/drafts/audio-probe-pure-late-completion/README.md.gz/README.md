# 纯 late-completion 探针候选（UNEXECUTED）

仅 isolated tmp 草稿：未激活、未类型检查、未运行浏览器/构建/SDK/测试。`audio-probe.before.ts` 是完整冻结原件；before SHA256 `6a0a867c02ea105bf82d1c1947e11e1437d8deedb2352540e55e4f12c2a2389c`。候选 SHA256 `712d822f846bfa8cf3f91100551f370c8d48394aa871806a8e41d022c0b9d6ef`。准确 diff 与机器清单同目录留存。

原具体前提错误：旧 defer 分支不调用 native resume，直到 release 时才首次调用；它实际是“延迟原生调用”，会把 native 激活移出原真实手势，不能称仅延迟完成。此候选只将 `super.resume()` 同步放回原调用栈，使用原 resume-call id 记录真实 native-start/settled/rejected/threw；返回产品的 held Promise 同时等待原 native 结果及 release 门闩。release 只打开门闩，不发任何 resume/suspend/close，也不伪记 native-start。

静态边界证明：native 先成功则等待门闩；native 先拒绝则立即拥有拒绝处理、等待门闩后原样拒绝（包括 undefined/falsy reason，不新建异常）；release 先来仍等待真正 native 终态，不伪造成功。返回 held 的独立 catch 只拥有内部 rejection，未替换返回值或改变产品可见拒绝。原 observeNative 已处理其原生 Promise 的两个分支；构造器原 void suspend 亦由该观察器拥有，无需扩改。每张票据闭包绑定原 context/probeId/id/held，releaseTicket 只创建一次子 request 与一次终态观察，重复调用返回同一 held，不再次 native 调用/交付。同步 native throw 原样记录并传播，不公布不可完成 release 回调。原全局一次性 deferred 与 releaseResume 函数仍保留；hasDeferredResume 的“函数存在”语义未变。

改动只在一次 defer 的 resume 分支。构造器显式 suspend 注入、持续 rejectResume、constructor deny、原生图与节点、256 FFT/8ms采样、波形门、所有 case/动作/阈值均原字节保留。它是一次命名的“构造器暂停＋产品完成交付门闩”故障，不称无注入的真实用户场景，也不改音色/游戏/保存。初始化器内部自包含，既有 serializable source/export 无外部闭包新增。

消费/证据限制：旧137/138和全部复合注入记录保持原身份，不能用新协议重新解释旧通过/首红。若 root 以后只把此候选用于现有 late-title 的一次有界诊断，须给新 run 独立身份并在 manifest 明确新协议；`audio.spec.ts:142` 现有记录文字“release calls the actual native resume”只适用于旧探针，新诊断中应标为旧文字不再描述本次机制。本草稿不修改该 consumer 的动作/断言/冻结字节，亦不预称原 WebKit 问题已解决。静态独立审阅未发现本候选阻断；无 runtime 通过结论。
