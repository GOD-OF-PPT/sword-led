import {test,expect} from '@playwright/test';
import type {Page} from '@playwright/test';
import {applyCommand,validateRun} from '../../src/core-v3/index.js';
import {installAudioProbe,audioProbe} from './audio-probe';
import {installHammerProbe} from './hammer-probe';
import {mkdir,writeFile} from 'node:fs/promises';
const dir='tmp/v3-impact-states';
declare global{interface Window{v3ImpactObservation:{particles:number;animations:number;outcome:string;observedAt:number}|null}}
async function read(page:Page){const raw=await page.evaluate(()=>localStorage.getItem('sword-led.save.v3'));if(!raw)throw Error('No actual save');const r=validateRun(JSON.parse(raw).state);if(!r.ok)throw Error(r.detail);return r.state;}
async function open(page:Page){await page.goto('/v3.html?mode=3');await expect(page.locator('#v3-hit')).toBeEnabled();}
async function point(page:Page,x=.62,y=.6){const box=await page.locator('#v3-hit').boundingBox();if(!box)throw Error('No hit area');return{x:box.x+box.width*x,y:box.y+box.height*y};}
async function left(page:Page){const before=await read(page),p=await point(page);await page.mouse.move(p.x,p.y);await page.mouse.down();const expected=applyCommand(before,{runId:before.runId,expectedRevision:before.revision,action:{type:'strike',pieceId:'r1-1'}});if(!expected.ok)throw Error(expected.error);expect(await read(page)).toEqual(expected.state);await page.mouse.up();await expect(page.locator('#v3-strike')).toHaveAttribute('aria-busy','false');return expected.state;}
test('left-down on the actual sword commits once, aim is cosmetic, hold/up/double-click/drag do not duplicate',async({page},info)=>{
 await page.clock.install();let bodyCompleted=false;
 try {await open(page);const original=await read(page);let p=await point(page,.35,.55);await page.mouse.move(p.x,p.y);await expect(page.locator('#v3-scene')).toHaveClass(/aiming/);const x1=await page.locator('#v3-scene').evaluate(e=>e.style.getPropertyValue('--aim-x'));p=await point(page,.8,.63);await page.mouse.move(p.x,p.y);expect(await page.locator('#v3-scene').evaluate(e=>e.style.getPropertyValue('--aim-x'))).not.toBe(x1);expect(await read(page)).toEqual(original);
 await page.mouse.down();const hit=await read(page);expect(hit.revision).toBe(original.revision+1);expect(hit.rng.forge.draws).toBe(1);await page.waitForTimeout(320);await page.locator('#v3-strike').focus();await page.keyboard.press('Space');expect(await read(page)).toEqual(hit);await page.mouse.move(5,5);await page.mouse.up();expect(await read(page)).toEqual(hit);
 await page.mouse.down();p=await point(page);await page.mouse.move(p.x,p.y);await page.mouse.up();expect(await read(page)).toEqual(hit);
 await page.mouse.click(p.x,p.y,{button:'right'});expect(await read(page)).toEqual(hit);
 // Freeze only the test clock so protocol/replay latency cannot turn a busy-key test into a fresh legitimate hit.
 await page.clock.pauseAt(new Date(Date.now()+1000));await page.mouse.dblclick(p.x,p.y,{delay:5});const twice=await read(page);expect(twice.revision).toBe(hit.revision+1);await expect(page.locator('#v3-strike')).toHaveAttribute('aria-busy','true');await page.keyboard.down('Space');await page.clock.runFor(350);await expect(page.locator('#v3-strike')).toHaveAttribute('aria-busy','false');await page.keyboard.up('Space');expect(await read(page)).toEqual(twice);
  bodyCompleted=true;
 } finally {
  try {
   const cleanupStarted=process.hrtime.bigint();await page.clock.resume();
   await info.attach('v3-clock-cleanup',{body:Buffer.from(JSON.stringify({bodyCompleted,operation:'page.clock.resume',completed:true,durationMs:Number(process.hrtime.bigint()-cleanupStarted)/1e6,scope:'Consumer cleanup only after original assertions; native AudioContext is neither resumed nor closed by this operation.'},null,2)),contentType:'application/json'});
  } catch(error) {
   if(bodyCompleted)throw error;
   info.annotations.push({type:'clock-cleanup-failure-after-original-body-failure',description:String(error)});
  }
 }
});
test('contact has real particles, ring, blade recoil and distinct native percussive sound; mute and reduced motion still work',async({page},info)=>{
 await installAudioProbe(page);await open(page);await page.locator('#v3-settings summary').click();await expect.poll(async()=>(await audioProbe(page)).states).toContain('running');await page.locator('#v3-settings summary').click();const p=await point(page);await page.mouse.move(p.x,p.y);
 // Observe the real short animation in the page, before protocol round trips can miss it.
 await page.locator('#v3-scene').evaluate(scene=>{window.v3ImpactObservation=null;const observer=new MutationObserver(()=>{const outcome=scene.getAttribute('data-outcome');if(outcome!=='success'&&outcome!=='great')return;window.v3ImpactObservation={particles:scene.querySelectorAll('#v3-sparks i').length,animations:scene.getAnimations({subtree:true}).filter(a=>a.playState==='running').length,outcome,observedAt:performance.now()};observer.disconnect();});observer.observe(scene,{attributes:true,attributeFilter:['data-outcome']});});
 await installHammerProbe(page);await page.mouse.down();await expect.poll(()=>page.evaluate(()=>window.v3ImpactObservation)).not.toBeNull();
 const effects=await page.evaluate(()=>window.v3ImpactObservation);if(!effects)throw Error('No observed impact');expect(effects.particles).toBe(36);expect(effects.animations).toBeGreaterThan(10);await page.mouse.up();const sound=await audioProbe(page);expect(sound.starts).toBe(3);expect(sound.frequencies).toEqual(effects.outcome==='great'?[89,631,1723]:[139,947,2381]);expect(sound.maxActive).toBeLessThanOrEqual(12);
 await expect.poll(()=>page.evaluate(()=>window.v3HammerGeometry.complete)).toBe(true);const geometry=await page.evaluate(()=>window.v3HammerGeometry),best=geometry.frames.reduce((a,b)=>b.gap<a.gap?b:a),contact={...geometry,gap:best.gap,best};await mkdir(dir,{recursive:true});await writeFile(`${dir}/${info.project.name}-contact.json`,JSON.stringify({effects,sound,contact,state:await read(page)},null,2)+'\n');expect(contact.gap).toBeLessThan(6);await page.screenshot({path:`${dir}/${info.project.name}-contact.png`});
 await page.locator('#v3-settings summary').click();await page.locator('#v3-muted').check();await page.locator('#v3-motion').check();await page.locator('#v3-settings summary').click();const starts=(await audioProbe(page)).starts;await expect(page.locator('#v3-hit')).toBeEnabled();await left(page);expect((await audioProbe(page)).starts).toBe(starts);expect((await audioProbe(page)).active).toBe(0);expect(await page.locator('#v3-scene').evaluate(e=>e.getAnimations({subtree:true}).filter(a=>a.playState==='running').length)).toBe(0);
});
test('burst is atomic on left-down and late visual hits cannot survive pause, modal or reload',async({page})=>{
 await open(page);for(let i=0;i<6;i++)await left(page);const before=await read(page),p=await point(page);await page.mouse.move(p.x,p.y);await page.mouse.down();const accepted=await read(page);expect(accepted.rng.forge.draws-before.rng.forge.draws).toBe(2);expect(accepted.journal.length-before.journal.length).toBe(1);await page.mouse.up();await page.keyboard.press('Escape');await page.waitForTimeout(450);expect(await read(page)).toEqual(accepted);expect(await page.locator('#v3-scene').evaluate(e=>e.getAnimations({subtree:true}).length)).toBe(0);await page.getByRole('button',{name:'继续锻造',exact:true}).click();await page.reload();await expect(page.locator('#v3-hit')).toBeEnabled();expect(await read(page)).toEqual(accepted);
 await page.locator('#v3-strike').focus();await page.keyboard.down('Space');await page.locator('#v3-menu').click();await page.keyboard.up('Space');expect(await read(page)).toEqual(accepted);
});
test('large left-click target and keyboard alternatives remain visible at both desktop sizes',async({page})=>{
 await open(page);for(const [width,height]of [[1280,720],[1920,1080]]){await page.setViewportSize({width:width!,height:height!});const box=await page.locator('#v3-hit').boundingBox();expect(box!.width).toBeGreaterThan(400);expect(box!.height).toBeGreaterThanOrEqual(160);expect(box!.y+box!.height).toBeLessThan(height!);await left(page);await expect(page.locator('#v3-hit')).toBeFocused();const before=await read(page);await page.keyboard.press('Space');expect((await read(page)).revision).toBe(before.revision+1);await expect(page.locator('#v3-strike')).toHaveAttribute('aria-busy','false');}
});
test('record actual left-click growth and burst effects without injecting any game result',async({browser},info)=>{
 const context=await browser.newContext({viewport:{width:1280,height:720},recordVideo:{dir:`${dir}/clips`,size:{width:1280,height:720}}}),page=await context.newPage();
 try{await open(page);for(let i=0;i<6;i++){await left(page);await page.waitForTimeout(140);}const before=await read(page),accepted=await left(page);expect(accepted.rng.forge.draws-before.rng.forge.draws).toBe(2);await page.waitForTimeout(500);await writeFile(`${dir}/${info.project.name}-clip-state.json`,JSON.stringify(accepted,null,2)+'\n');}
 finally{const video=page.video();await context.close();if(video){const path=await video.path();await info.attach('actual-left-click-effects',{path,contentType:'video/webm'});}}
});
