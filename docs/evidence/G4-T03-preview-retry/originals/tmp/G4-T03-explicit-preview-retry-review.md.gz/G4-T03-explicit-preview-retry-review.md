# 显式试听重试：限定静态复核

范围：只读当前 `src/presentation-v5/app.ts`、`src/platform/audio.ts` 与新增 `audio-preview-retry.spec.ts`；不运行浏览器、构建或 SDK，不改冻结文件。共享 audio 仍为 `6d86b2b4d4f4c35f32f8128110d66cb6f94587b870e3e27522d61f576119b263`。

结论：未发现本项静态阻断。设置按钮只在原 `setMode('preview'); preview()` 前调用既有 `silence()`。每次明确点击先推进 audio epoch、停止旧试听并清除旧等待 cue；即使仍处于 preview 模式，原 pending 已不属于新 epoch，新点击会实际发起新的 native resume。设置 modal 存在时全局 capture 的 `onGesture` 不会另启游戏 activation，不引入同一次点击的双重请求。

旧异步归属仍完整：旧 preview 捕获的 token 失效，完成后不能播放；旧 activation 的成功分支发现较新有效同 context 授权时不 suspend；旧 `finally` 仅在 `pending===attempt` 时清引用，不能清掉新请求。旧拒绝也不能覆盖新 activation 状态。没有自动重试、timer、旧 cue 补播或更换 context。音色/时长/master gain/音量、四 voice 限制、领域命令与钱包/局/炉谱接口均未修改；重复点击会明确截断前一次试听，符合“替换本次试听”的边界。静音和零音量仍由原 enabled 门拒绝播放。

新消费者先真实正常试听并确认 native suspended/active0，再在既有 context 上启用一次 defer，故本项 held 请求确实归目标 preview，未混入构造器的额外暂停。第二次真实 click 要求 resumeCalls 增加、重置后峰值 >.001、累计由3到6 sources；释放旧请求后仍6，关窗后 suspended/active0/全部断开且四个游戏/炉谱槽原文全等。首红实际停于 explicit-retry、resumeCalls仍1、starts3、suspended、原文相等；418/82结束指纹一致。root 随后报告修复定向9次 C/F/W DPR1全部实际通过且418/82结束一致；本审阅不将其扩成旧23×6或原晚回标题故障的修复。

口径限制：当前 spec 直接断言四槽最终字节相同，未统计 Storage 写 API 调用，因此可写“局/炉谱原文未变”，不能单凭该断言写“实测0次写调用”。处理器静态无保存/经济调用，亦无新游戏动作。故障仍是现有探针“延迟 native 调用”的显式注入；它与已保存的137/138复合晚回标题记录分开，后者不改写、不宣称关闭。native 物理输出与真实听感也不由本项代填。
