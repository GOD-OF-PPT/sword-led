# 音频剩余缺口：只读归因审查（2026-10-23）

范围：选定的 `6d86` pending／当前 cue 实现、原始与 release 探针原文、已保留失败。未修改 src/tests，未运行 SDK、浏览器、构建或声音候选。

**尚未排除的具体消费者前提：defer 不只是“延迟完成”。** 原始 `tests/e2e/audio-probe.ts` 和 `tests/release-v5/audio-probe.ts` 的 defer 分支都先返回测试 Promise，直到 `releaseResume()` 才首次执行 `super.resume()`；原真实手势里并没有调用 native resume。构造器还另发一次真实 `suspend()`，不等待其完成。release 版已修“新 context 重复注入 defer 暂停”，但第一次的这两个额外控制行为仍在。

因此，“真实手势已开始 native resume，仅完成回调晚到”和当前“强制暂停＋延迟 native 调用”不是同一前提。晚标题消费者通过 `page.evaluate` 释放时才发出原生调用，属于明确平台故障注入，不能标作透明观测或真实原生晚完成。`navigator.userActivation.isActive=true` 也不能独自证明该调用仍在原真实输入事件栈中。

原 audio02 WebKit 首红直接体现这个差别：构造后被注入 suspend、首 resume 被 held；native state 先到 interrupted，构造／暂停请求直到释放后才完成。随后新真实 resume 不完成的事实必须保留，但它尚未排除由上述复合探针前提诱发的路径。可确认的是该**注入场景**的恢复缺口，不能直接扩大成未注入玩家的同因故障。旧 cue 零补播、真实 Accepted／存档全等仍是有效的独立观察。此结论也不撤销候选中实际记录到的 running＋clock0、三 source 未结束；那些是另一类原生观测，因果仍未闭环。

**现有玩家出口的具体不足。** `status()` 仅在 resume fulfilled/rejected 后更新失败；若 Promise 一直 pending，页面可一直显示 waiting。设置文字承诺可点“试听敲击声”重试；首次从游戏打开设置会改变 mode/epoch，确能形成一次不同的试听请求，但若这次 preview 自身挂起，再点同按钮时 `setMode('preview')` 不变、`gesture()` 返回同 epoch/context 的旧 pending，不会实际发出新 native 请求。故“可重试”的每次点击并不必然有真实重试行为。对 running＋clock0，现状态又会显示 ready；它只证明原生状态报告，不能证明已产生软件波形，更不能证明扬声器输出。

已存在的可用降级应保留：constructor 不可用与 rejected resume 有明确说明，正常 rejected 后 pending 会清理，试听按钮可再次尝试；静音／零音量明确可继续锻造；音频失败不回滚 Accepted。剩余玩家责任是挂起状态的清楚说明及可核实的重试出口，不应宣称永久 waiting 或同一 pending 复用已经恢复。本轮不实现新的控制策略。

**归档判断：** 有一个明确未排除的消费者故障语义／归因前提，另有一个源码可见的重试 UX 缺口。不能把 native 挂起直接归“环境”，也不能据此认定生产无问题。当前 137/138、所有注入原件与撤回候选各保原身份；不再推荐已失败的退休／resume／suspend 序列、盲测或阈值调整，不要求新增审批或实验。费用关系 UI 交付不由这个归因说明冒领完整音频闭环。
