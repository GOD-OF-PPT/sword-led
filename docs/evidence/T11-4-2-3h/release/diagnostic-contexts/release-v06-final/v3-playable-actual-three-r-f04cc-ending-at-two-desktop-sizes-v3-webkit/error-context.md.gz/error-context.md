# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: v3-playable.spec.ts >> actual three rounds, optional gift, insurance, merchant trade and upgrade; honest ending at two desktop sizes
- Location: tests/e2e/v3-playable.spec.ts:31:1

# Error details

```
Test timeout of 60000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - generic [ref=e5]:
      - text: 锤下求生
      - generic [ref=e6]: v0.6 炉前 · 三轮练手
    - generic [ref=e7]:
      - generic [ref=e8]: 第 3 / 3 轮 · 练手
      - generic [ref=e9]: 交差 585 / 520
      - progressbar "本轮交差进度" [ref=e10]
    - generic [ref=e11]:
      - generic [ref=e12]: 金币 1,102
      - generic "契约印记 3/3" [ref=e13]:
        - generic [aria-hidden] [ref=e14]: 契
        - generic [aria-hidden] [ref=e15]: 契
        - generic [aria-hidden] [ref=e16]: 契
    - button "暂停" [ref=e17] [cursor=pointer]
    - button "契约" [ref=e18] [cursor=pointer]
  - main [ref=e19]:
    - complementary [ref=e20]:
      - heading "今日三柄" [level=2] [ref=e21]
      - button "◆ 镇岳重剑 本轮 · 40" [pressed] [ref=e23] [cursor=pointer]:
        - text: ◆
        - generic [ref=e24]: 镇岳重剑
        - generic [ref=e25]: 本轮 · 40
    - generic [ref=e26]:
      - generic:
        - generic: 镇岳重剑 · 乌铁坯
        - strong: "40"
        - generic: 当前身价 · 收手即可交差
      - generic [ref=e27]:
        - img "镇岳重剑，乌铁坯，等级0，身价40，完好；外形不影响属性" [ref=e28]
        - button "铁砧 · 鼠标左键直接落锤，无需瞄准或卡时机" [ref=e29]
      - status [ref=e30]: 已交差 585 · 目标和金币同时增加。
      - generic [ref=e31]:
        - generic [ref=e32]: 下一锤裂损 0%
        - generic [ref=e33]: 大成 15% · 首次裂损仍能保住剑
      - generic [ref=e34]:
        - generic [ref=e35]: 锤势
        - generic [ref=e43]: 0/6
      - generic:
        - generic: 今日委托已成
        - generic: 剩下的剑可交差、留到明天，或向商人换一门手艺。
      - generic [ref=e44]:
        - button "落锤 左键点剑身 / 空格落锤" [active] [ref=e45] [cursor=pointer]:
          - text: 落锤
          - generic [ref=e46]: 左键点剑身 / 空格落锤
        - button "交差 40" [ref=e47] [cursor=pointer]
        - button "挂剑保留" [ref=e48] [cursor=pointer]
      - generic [ref=e49]:
        - button "回收 · 10金币" [ref=e50] [cursor=pointer]
        - button "收工" [ref=e51] [cursor=pointer]
        - group [ref=e52]:
          - generic "看懂这一锤" [ref=e53] [cursor=pointer]
    - complementary:
      - img "杜伯在炉边等候炉心作品"
      - button "和杜伯聊聊，查看炉心的打造心愿" [ref=e54] [cursor=pointer]:
        - generic [ref=e55]: 杜伯 · 打造心愿
      - paragraph: 想看看这一炉火，能把剑锻成什么模样。
      - generic [ref=e56]:
        - button "行脚商人 · 已到场" [ref=e57] [cursor=pointer]
        - button "本炉手札，已评鉴1/3，只读无额外奖励" [ref=e58] [cursor=pointer]:
          - generic [ref=e59]: 手札
          - generic [ref=e60]: 已评鉴 1/3
    - generic [ref=e62]:
      - button "稳手护符 · 首次裂损可保住身价" [ref=e63] [cursor=pointer]:
        - generic [ref=e65]:
          - text: 稳手护符
          - generic [ref=e66]: 首次裂损可保住身价
      - button "裂锋印 · 完好剑暂不生效" [ref=e67] [cursor=pointer]:
        - generic [ref=e69]:
          - text: 裂锋印
          - generic [ref=e70]: 完好剑暂不生效
  - region "炉边事件" [ref=e71]:
    - status [ref=e72]:
      - generic [ref=e73]: 今日达标 · 印记保住了
      - paragraph [ref=e74]: 交差 585 / 520。余剑可以留一柄；准备好就摇铃收工。
    - generic [ref=e75]:
      - button "查看收工后果" [ref=e76] [cursor=pointer]
      - button "收起今日达标 · 印记保住了提示" [ref=e77] [cursor=pointer]: 收起
  - contentinfo [ref=e78]:
    - button "炉程 · 新" [ref=e79] [cursor=pointer]
    - button "玩法图解" [ref=e80] [cursor=pointer]: "?"
    - group [ref=e81]:
      - generic "声音与动效" [ref=e82] [cursor=pointer]: ⚙
  - generic [aria-hidden]:
    - generic:
      - generic: 委托达成！
      - generic: 印记保住了 · 余剑可以留一手
```