# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: v3-visual.spec.ts >> all six physical handcraft props appear in real merchant offers; equipped echo lights only on its third success
- Location: tests/e2e/v3-visual.spec.ts:24:1

# Error details

```
Error: expect(locator).toHaveClass(expected) failed

Locator: locator('#v3-traits [data-trait="echo"]')
Expected pattern: /trait-triggered/
Received string:  "v3-trait-item"
Timeout: 5000ms

Call log:
  - Expect "toHaveClass" locator('#v3-traits [data-trait="echo"]') with timeout 5000ms
  - waiting for locator('#v3-traits [data-trait="echo"]')
    11 × locator resolved to <button tabindex="0" data-trait="echo" class="v3-trait-item" aria-label="回响锤纹 · 普通成功 0/3 · 第三次额外+25%">…</button>
       - unexpected value "v3-trait-item"

```

```yaml
- button "回响锤纹 · 普通成功 0/3 · 第三次额外+25%": 回响锤纹 普通成功 0/3 · 第三次额外+25%
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | import {createRun,applyCommand,validateRun} from '../../src/core-v3/index.js';
  3  | import type {RunState} from '../../src/core-v3/index.js';
  4  | import {mkdir,writeFile} from 'node:fs/promises';
  5  | const dir='tmp/v3-visual-states';
  6  | async function read(page:import('@playwright/test').Page){const raw=await page.evaluate(()=>localStorage.getItem('sword-led.save.v3'));const run=validateRun(JSON.parse(raw!).state);if(!run.ok)throw Error(run.detail);return run.state;}
  7  | async function hit(page:import('@playwright/test').Page){const before=await read(page),id=(await page.locator('#v3-inventory button[aria-pressed=true]').getAttribute('data-piece'))!;await page.locator('#v3-hit').click({position:{x:400,y:120}});const expected=applyCommand(before,{runId:before.runId,expectedRevision:before.revision,action:{type:'strike',pieceId:id}});if(!expected.ok)throw Error(expected.error);expect(await read(page)).toEqual(expected.state);await expect(page.locator('#v3-strike')).toHaveAttribute('aria-busy','false');return expected.state;}
  8  | function seedFor(family:number){for(let i=0;i<100;i++){const seed=`art-${family}-${i}`,created=createRun({runId:'visual-recipe',seed});if(!created.ok)throw Error('create');let s:RunState=created.state;for(let j=0;j<14;j++){const b=s.blades[family]!;if(b.status==='broken')break;if(b.level>=9)return seed;const result=applyCommand(s,{runId:s.runId,expectedRevision:s.revision,action:{type:'strike',pieceId:b.id}});if(!result.ok)break;s=result.state;}}throw Error('No real recipe');}
  9  | test('three actual supplied weapons grow through five illustrated stages and reload the same appearance',async({page},info)=>{
  10 |  const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()>=400)errors.push(String(r.status())+' '+r.url());});await mkdir(dir,{recursive:true});
  11 |  await page.goto('/?mode=3');await expect(page.locator('#v3-hit')).toBeEnabled();
  12 |  for(let family=0;family<3;family++){
  13 |   await page.locator('#v3-menu').click();await page.locator('#v3-seed').fill(seedFor(family));await page.getByRole('button',{name:'开一炉新契约'}).click();await page.getByRole('button',{name:'确认',exact:true}).click();await page.locator(`[data-piece="r1-${family+1}"]`).click();
  14 |   await expect(page.locator('#v3-blade')).toHaveAttribute('data-illustrated','true');await expect(page.locator('#v3-blade')).toHaveAttribute('data-family',String(family));
  15 |   const seen=new Set<string>(),pixels:unknown[]=[];for(let i=0;i<14;i++){const stage=(await page.locator('#v3-blade').getAttribute('data-stage'))!;if(!seen.has(stage)){seen.add(stage);const sample=await page.locator('#v3-blade').evaluate((c:HTMLCanvasElement)=>{const pixels=c.getContext('2d')!.getImageData(0,0,c.width,c.height).data;let visible=0,hash=2166136261;for(let n=0;n<pixels.length;n++){hash=Math.imul(hash^pixels[n]!,16777619);if(n%4===3&&pixels[n]!>128)visible++;}return{visible,hash:hash>>>0};});expect(sample.visible).toBeGreaterThan(2000);pixels.push({stage,...sample});if(info.project.name==='v3-chromium'||stage==='4')await page.screenshot({path:`${dir}/${info.project.name}-family-${family}-stage-${stage}.png`});}if(stage==='4')break;await hit(page);}await writeFile(`${dir}/${info.project.name}-family-${family}-pixels.json`,JSON.stringify(pixels,null,2)+'\n');
  16 |   expect([...seen]).toEqual(['0','1','2','3','4']);const before=await read(page);await writeFile(`${dir}/${info.project.name}-family-${family}.json`,JSON.stringify(before,null,2)+'\n');await page.reload();await expect(page.locator('#v3-hit')).toBeEnabled();await page.locator(`[data-piece="r1-${family+1}"]`).click();await expect(page.locator('#v3-blade')).toHaveAttribute('data-stage','4');expect(await read(page)).toEqual(before);
  17 |  }
  18 |  for(const [width,height]of [[1280,720],[1920,1080]]){await page.setViewportSize({width:width!,height:height!});for(const sel of ['#v3-hit','#v3-deliver','#v3-settle','#v3-inventory button']){for(const node of await page.locator(sel).all()){const box=await node.boundingBox();expect(box!.y+box!.height).toBeLessThanOrEqual(height!);}}await page.screenshot({path:`${dir}/${info.project.name}-layout-${width}.png`});}
  19 |  expect(errors).toEqual([]);
  20 | });
  21 | test('missing weapon art falls back to a usable native blade and keeps an accepted strike',async({page})=>{
  22 |  await page.route('**/assets/d/blade-*.webp',route=>route.abort());await page.goto('/?mode=3');await expect(page.locator('#v3-hit')).toBeEnabled();await expect(page.locator('#v3-note')).toContainText('画稿未加载');await expect(page.locator('#v3-blade')).toHaveAttribute('data-illustrated','false');await hit(page);await expect(page.locator('#v3-value')).not.toHaveText('40');
  23 | });
  24 | test('all six physical handcraft props appear in real merchant offers; equipped echo lights only on its third success',async({page},info)=>{
  25 |  const missing=new Set(['steady','ember','inherit','echo','crackedEdge','pardon']),recipes:{seed:string;shop:readonly string[]}[]=[];
  26 |  for(let i=0;i<40&&missing.size;i++){const seed=`catalog-${i}`,created=createRun({runId:'catalog',seed});if(!created.ok)throw Error('create');let s=created.state;for(const type of ['settle','advance','settle','advance']as const){const result=applyCommand(s,{runId:s.runId,expectedRevision:s.revision,action:{type}});if(!result.ok)throw Error(result.error);s=result.state;}if(s.shop.some(t=>missing.has(t))){recipes.push({seed,shop:s.shop});s.shop.forEach(t=>missing.delete(t));}}expect(missing.size).toBe(0);
  27 |  await mkdir(dir,{recursive:true});await page.goto('/?mode=3');await expect(page.locator('#v3-hit')).toBeEnabled();let observedEcho=false;
  28 |  for(const recipe of recipes){await page.locator('#v3-menu').click();await page.locator('#v3-seed').fill(recipe.seed);await page.getByRole('button',{name:'开一炉新契约'}).click();await page.getByRole('button',{name:'确认',exact:true}).click();
  29 |   for(let round=1;round<=2;round++){await page.locator('#v3-settle').click();await page.getByRole('button',{name:'确认',exact:true}).click();await page.getByRole('button',{name:'领取下一轮三柄剑'}).click();}expect((await read(page)).shop).toEqual(recipe.shop);
  30 |   await page.locator('#v3-shop').click();for(const id of recipe.shop)await expect(page.locator(`article[data-trait="${id}"] .v3-trait-art`)).toBeVisible();await page.screenshot({path:`${dir}/${info.project.name}-${recipe.seed}-merchant.png`});
  31 |   const id=recipe.shop.includes('echo')?'echo':recipe.shop[0]!;await page.locator(`article[data-trait="${id}"] button`).click();await page.getByRole('button',{name:'确认',exact:true}).click();await expect(page.locator(`#v3-traits [data-trait="${id}"] .v3-trait-art`)).toBeVisible();
> 32 |   if(id==='echo'){for(let n=0;n<2;n++){await hit(page);await expect(page.locator('#v3-traits [data-trait="echo"]')).not.toHaveClass(/trait-triggered/);}await hit(page);await expect(page.locator('#v3-traits [data-trait="echo"]')).toHaveClass(/trait-triggered/);await expect(page.locator('#v3-result')).toContainText('回响锤纹触发');await page.screenshot({path:`${dir}/${info.project.name}-echo-trigger.png`});observedEcho=true;}
     |                                                                                                                                                                                                                                      ^ Error: expect(locator).toHaveClass(expected) failed
  33 |   const state=await read(page);await writeFile(`${dir}/${info.project.name}-${recipe.seed}-equipped.json`,JSON.stringify(state,null,2)+'\n');
  34 |  }
  35 |  expect(observedEcho).toBe(true);
  36 | });
  37 | test('three equipped props keep the full workshop, merchant and settings inside both desktop viewports',async({page},info)=>{
  38 |  await page.goto('/?mode=3');await expect(page.locator('#v3-hit')).toBeEnabled();await page.locator('#v3-menu').click();await page.locator('#v3-seed').fill('three-props-5');await page.getByRole('button',{name:'开一炉新契约'}).click();await page.getByRole('button',{name:'确认',exact:true}).click();
  39 |  while((await read(page)).blades[0]!.value<180)await hit(page);await page.locator('#v3-deliver').click();await page.getByRole('button',{name:'首次达标 · 领一门免费手艺'}).click();await page.getByRole('button',{name:/稳手护符 ·/}).click();
  40 |  for(let n=0;n<2;n++){await page.locator('#v3-settle').click();await page.getByRole('button',{name:'确认',exact:true}).click();await page.getByRole('button',{name:'领取下一轮三柄剑'}).click();}
  41 |  for(const id of ['inherit','pardon']){await page.locator('#v3-shop').click();await page.locator(`article[data-trait="${id}"] button`).click();await page.getByRole('button',{name:'确认',exact:true}).click();}expect((await read(page)).traits).toEqual(['steady','inherit','pardon']);
  42 |  const checks=[];for(const [width,height]of [[1280,720],[1920,1080]]){await page.setViewportSize({width:width!,height:height!});for(const selector of ['#v3-hit','#v3-strike','#v3-deliver','#v3-settle','#v3-shop','#v3-settings summary']){const box=await page.locator(selector).boundingBox();expect(box).not.toBeNull();expect(box!.y+box!.height).toBeLessThanOrEqual(height!);expect(box!.x+box!.width).toBeLessThanOrEqual(width!);checks.push({width,height,selector,box});}await page.screenshot({path:`${dir}/${info.project.name}-three-props-${width}.png`});}await writeFile(`${dir}/${info.project.name}-three-props.json`,JSON.stringify({checks,state:await read(page)},null,2)+'\n');
  43 | });
  44 | 
```