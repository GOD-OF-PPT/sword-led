# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: v3-hammer.spec.ts >> flat face follows actual opaque metal for all three shapes at rough and masterwork stages
- Location: tests/e2e/v3-hammer.spec.ts:10:1

# Error details

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 2
Received:    1
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - generic [ref=e5]:
      - text: 锤下求生
      - generic [ref=e6]: v0.6 炉前 · 三轮练手
    - generic [ref=e7]:
      - generic [ref=e8]: 第 1 / 3 轮 · 练手
      - generic [ref=e9]: 交差 0 / 180
      - progressbar "本轮交差进度" [ref=e10]
    - generic [ref=e11]:
      - generic [ref=e12]: 金币 0
      - generic "契约印记 3/3" [ref=e13]:
        - generic [aria-hidden] [ref=e14]: 契
        - generic [aria-hidden] [ref=e15]: 契
        - generic [aria-hidden] [ref=e16]: 契
    - button "暂停" [ref=e17] [cursor=pointer]
    - button "契约" [ref=e18] [cursor=pointer]
  - main [ref=e19]:
    - complementary [ref=e20]:
      - heading "今日三柄" [level=2] [ref=e21]
      - generic [ref=e22]:
        - button "青云剑" [ref=e23] [cursor=pointer]
        - button "◆ 赤羽刀 本轮 · 58" [pressed] [ref=e25] [cursor=pointer]:
          - text: ◆
          - generic [ref=e26]: 赤羽刀
          - generic [ref=e27]: 本轮 · 58
        - button "镇岳重剑" [ref=e28] [cursor=pointer]
    - generic [ref=e30]:
      - generic:
        - generic: 赤羽刀 · 初开锋
        - strong: "58"
        - generic: 当前身价 · 收手即可交差
      - generic [ref=e31]:
        - img "赤羽刀，初开锋，等级1，身价58，完好；外形不影响属性" [ref=e32]
        - button "铁砧 · 鼠标左键直接落锤，无需瞄准或卡时机" [active] [ref=e33]
      - status [ref=e34]: 锻成 · 身价+18
      - generic [ref=e35]:
        - generic [ref=e36]: 下一锤裂损 0%
        - generic [ref=e37]: 大成 15% · 首次裂损仍能保住剑
      - generic [ref=e38]:
        - generic [ref=e39]: 锤势
        - generic [ref=e47]: 1/6
      - generic [ref=e48]:
        - button "落锤 左键点剑身 / 空格落锤" [ref=e49] [cursor=pointer]:
          - text: 落锤
          - generic [ref=e50]: 左键点剑身 / 空格落锤
        - button "交差 58" [ref=e51] [cursor=pointer]
        - button "留给下一轮" [ref=e52] [cursor=pointer]
      - generic [ref=e53]:
        - button "回收 · 10金币" [ref=e54] [cursor=pointer]
        - button "收工" [ref=e55] [cursor=pointer]
        - group [ref=e56]:
          - generic "看懂这一锤" [ref=e57] [cursor=pointer]
    - complementary:
      - img "阿岚在炉边等候出锋作品"
      - button "和阿岚聊聊，查看出锋的打造心愿" [ref=e58] [cursor=pointer]:
        - generic [ref=e59]: 阿岚 · 打造心愿
      - paragraph: 巡夜的路，想带一柄可靠的新剑。
      - button "本炉手札，已评鉴0/3，只读无额外奖励" [ref=e61] [cursor=pointer]:
        - generic [ref=e62]: 手札
        - generic [ref=e63]: 已评鉴 0/3
  - contentinfo [ref=e64]:
    - button "炉程" [ref=e65] [cursor=pointer]
    - button "玩法图解" [ref=e66] [cursor=pointer]: "?"
    - group [ref=e67]:
      - generic "声音与动效" [ref=e68] [cursor=pointer]: ⚙
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | import {installHammerProbe} from './hammer-probe';
  3  | import {mkdir,writeFile} from 'node:fs/promises';
  4  | import {applyCommand,validateRun} from '../../src/core-v3/index.js';
  5  | test('hammer strikes with a flat metal face and rotates around its grip at both desktop sizes',async({page},info)=>{
  6  |  const dir='tmp/v3-hammer-states';await mkdir(dir,{recursive:true});await page.goto('/?mode=3');await expect(page.locator('#v3-hit')).toBeEnabled();await page.locator('#v3-hammer img').evaluate(async(i:HTMLImageElement)=>{await i.decode();});
  7  |  for(const [width,height]of [[1280,720],[1920,1080]]){await page.setViewportSize({width:width!,height:height!});await page.screenshot({path:`${dir}/${info.project.name}-${width}-idle.png`});await installHammerProbe(page);const box=await page.locator('#v3-hit').boundingBox();if(width===1280)await page.mouse.click(box!.x+box!.width*.58,box!.y+box!.height*.6);else{await page.locator('#v3-hit').focus();await page.keyboard.down('Space');await page.screenshot({path:`${dir}/${info.project.name}-${width}-preparing.png`});await page.keyboard.up('Space');}await expect.poll(()=>page.evaluate(()=>window.v3HammerGeometry.complete)).toBe(true);const probe=await page.evaluate(()=>window.v3HammerGeometry),best=probe.frames.reduce((a,b)=>b.gap<a.gap?b:a);await writeFile(`${dir}/${info.project.name}-${width}-geometry.json`,JSON.stringify({probe,best},null,2)+'\n');await page.screenshot({path:`${dir}/${info.project.name}-${width}-after.png`});expect(Math.abs(best.angle)).toBeLessThan(10);expect(best.pivotGap).toBeLessThan(4);expect(best.gap).toBeLessThan(6);expect(best.metalGap).toBeLessThan(6);expect(Math.min(...probe.sourceAlpha)).toBeGreaterThan(200);expect(best.headHeight).toBeGreaterThan(60);expect(best.headHeight).toBeLessThan(120);}
  8  | });
  9  | 
  10 | test('flat face follows actual opaque metal for all three shapes at rough and masterwork stages',async({page},info)=>{
  11 |  test.setTimeout(180000);const dir='tmp/v3-hammer-states';await mkdir(dir,{recursive:true});await page.goto('/?mode=3');await expect(page.locator('#v3-hit')).toBeEnabled();const samples=[];
  12 |  async function read(){const raw=await page.evaluate(()=>localStorage.getItem('sword-led.save.v3'));if(!raw)throw Error('No save');const r=validateRun(JSON.parse(raw).state);if(!r.ok)throw Error(r.detail);return r.state;}
  13 |  for(let family=0;family<3;family++)for(const [width,height]of [[1280,720],[1920,1080]]){
  14 |   await page.setViewportSize({width:width!,height:height!});await page.locator('#v3-menu').click();await page.locator('#v3-seed').fill(`art-${family}-0`);await page.getByRole('button',{name:'开一炉新契约'}).click();await page.getByRole('button',{name:'确认',exact:true}).click();const id=`r1-${family+1}`;await page.locator(`[data-piece="${id}"]`).click();
  15 |   for(const rank of ['rough','master']){
  16 |    if(rank==='master'){for(let n=0;n<12&&(await page.locator('#v3-blade').getAttribute('data-stage'))!=='4';n++){await expect(page.locator('#v3-strike')).toHaveAttribute('aria-busy','false');await page.locator('#v3-strike').click();await expect(page.locator('#v3-strike')).toHaveAttribute('aria-busy','false');}await expect(page.locator('#v3-blade')).toHaveAttribute('data-stage','4');}
  17 |    await expect(page.locator('#v3-strike')).toHaveAttribute('aria-busy','false');const before=await read(),blade=before.blades.find(b=>b.id===id)!;expect(blade.status).toBe('active');expect(rank==='rough'?blade.level===0:blade.level>=9).toBe(true);
  18 |    await installHammerProbe(page);const box=await page.locator('#v3-hit').boundingBox();await page.mouse.click(box!.x+box!.width*.68,box!.y+box!.height*.6);await expect.poll(()=>page.evaluate(()=>window.v3HammerGeometry.complete)).toBe(true);const after=await read(),expected=applyCommand(before,{runId:before.runId,expectedRevision:before.revision,action:{type:'strike',pieceId:id}});if(!expected.ok)throw Error(expected.error);expect(after).toEqual(expected.state);expect(after.revision).toBe(before.revision+1);
> 19 |    const probe=await page.evaluate(()=>window.v3HammerGeometry),best=probe.frames.reduce((a,b)=>b.gap<a.gap?b:a);samples.push({family,rank,width,before,after,probe,best});expect(probe.frames.filter(f=>f.gap<6&&Math.abs(f.angle)<10).length).toBeGreaterThanOrEqual(2);expect(best.gap).toBeLessThan(6);expect(best.metalGap).toBeLessThan(6);expect(Math.abs(best.angle)).toBeLessThan(10);await expect(page.locator('#v3-strike')).toHaveAttribute('aria-busy','false');
     |                                                                                                                                                                                                                                                 ^ Error: expect(received).toBeGreaterThanOrEqual(expected)
  20 |   }
  21 |  }
  22 |  await writeFile(`${dir}/${info.project.name}-shapes.json`,JSON.stringify(samples,null,2)+'\n');
  23 | });
  24 | 
  25 | test('slow presentation frames still show a flat contact; pause cancels the pending swing without another command',async({page},info)=>{
  26 |  await page.addInitScript(()=>{const raf=window.requestAnimationFrame.bind(window),cancel=window.cancelAnimationFrame.bind(window),pending=new Map<number,number>();let serial=0;window.requestAnimationFrame=callback=>{const id=++serial;let ticks=0;const step=(time:number)=>{if(!pending.has(id))return;if(++ticks===8){pending.delete(id);callback(time);}else pending.set(id,raf(step));};pending.set(id,raf(step));return id;};window.cancelAnimationFrame=id=>{const native=pending.get(id);if(native!==undefined)cancel(native);pending.delete(id);};});
  27 |  await page.goto('/?mode=3');await expect(page.locator('#v3-hit')).toBeEnabled();await installHammerProbe(page);await page.locator('#v3-hit').click();await expect.poll(()=>page.evaluate(()=>window.v3HammerGeometry.complete)).toBe(true);const probe=await page.evaluate(()=>window.v3HammerGeometry),best=probe.frames.reduce((a,b)=>b.gap<a.gap?b:a);expect(best.gap).toBeLessThan(6);expect(Math.abs(best.angle)).toBeLessThan(10);await writeFile(`tmp/v3-hammer-states/${info.project.name}-slow.json`,JSON.stringify({probe,best},null,2)+'\n');
  28 |  await page.locator('#v3-hit').click();const bytes=await page.evaluate(()=>localStorage.getItem('sword-led.save.v3'));await page.keyboard.press('Escape');await page.waitForTimeout(700);expect(await page.evaluate(()=>localStorage.getItem('sword-led.save.v3'))).toBe(bytes);expect(await page.locator('#v3-hammer').getAttribute('data-phase')).toBe('idle');expect(await page.locator('#v3-hammer').evaluate(e=>e.getAnimations().length)).toBe(0);
  29 | });
  30 | 
```