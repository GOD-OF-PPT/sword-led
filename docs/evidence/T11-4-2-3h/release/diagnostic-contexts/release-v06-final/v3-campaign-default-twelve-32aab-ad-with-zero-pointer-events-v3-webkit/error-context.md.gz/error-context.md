# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: v3-campaign.spec.ts >> default twelve-round campaign completes through three merchants, upgrades, replacement and reload with zero pointer events
- Location: tests/e2e/v3-campaign.spec.ts:34:1

# Error details

```
Test timeout of 360000ms exceeded.
```

```
Error: locator.evaluate: Test timeout of 360000ms exceeded.
Call log:
  - waiting for locator('#v3-strike')

```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - banner [ref=f2e4]:
    - generic [ref=f2e5]:
      - text: 锤下求生
      - generic [ref=f2e6]: v0.6 炉前 · 十二轮契约
    - generic [ref=f2e7]:
      - generic [ref=f2e8]: 第 9 / 12 轮
      - generic [ref=f2e9]: 交差 0 / 10,000
      - progressbar "本轮交差进度" [ref=f2e10]
    - generic [ref=f2e11]:
      - generic [ref=f2e12]: 金币 19,748
      - generic "契约印记 3/3" [ref=f2e13]:
        - generic [aria-hidden] [ref=f2e14]: 契
        - generic [aria-hidden] [ref=f2e15]: 契
        - generic [aria-hidden] [ref=f2e16]: 契
    - button "暂停" [ref=f2e17] [cursor=pointer]
    - button "契约" [ref=f2e18] [cursor=pointer]
  - main [ref=f2e19]:
    - complementary [ref=f2e20]:
      - heading "今日三柄" [level=2] [ref=f2e21]
      - generic [ref=f2e22]:
        - button "◆ 青云剑 本轮 · 336" [active] [pressed] [ref=f2e23] [cursor=pointer]:
          - text: ◆
          - generic [ref=f2e24]: 青云剑
          - generic [ref=f2e25]: 本轮 · 336
        - button "赤羽刀" [ref=f2e26] [cursor=pointer]
        - button "镇岳重剑" [ref=f2e28] [cursor=pointer]
    - generic [ref=f2e30]:
      - generic:
        - generic: 青云剑 · 初开锋
        - strong: "336"
        - generic: 当前身价 · 收手即可交差
      - generic [ref=f2e31]:
        - img "青云剑，初开锋，等级2，身价336，完好；外形不影响属性" [ref=f2e32]
        - button "铁砧 · 鼠标左键直接落锤，无需瞄准或卡时机" [ref=f2e33]
      - status [ref=f2e34]: 锻成 · 身价+104
      - generic [ref=f2e35]:
        - generic [ref=f2e36]: 下一锤裂损 0%
        - generic [ref=f2e37]: 大成 15% · 首次裂损仍能保住剑
      - generic [ref=f2e38]:
        - generic [ref=f2e39]: 锤势
        - generic [ref=f2e47]: 2/6
      - generic [ref=f2e48]:
        - button "落锤 左键点剑身 / 空格落锤" [ref=f2e49] [cursor=pointer]:
          - text: 落锤
          - generic [ref=f2e50]: 左键点剑身 / 空格落锤
        - button "交差 336" [ref=f2e51] [cursor=pointer]
        - button "留给下一轮" [ref=f2e52] [cursor=pointer]
      - generic [ref=f2e53]:
        - button "回收 · 40金币" [ref=f2e54] [cursor=pointer]
        - button "收工" [ref=f2e55] [cursor=pointer]
        - group [ref=f2e56]:
          - generic "看懂这一锤" [ref=f2e57] [cursor=pointer]
    - complementary:
      - img "杜伯在炉边等候复炉作品"
      - button "和杜伯聊聊，查看复炉的打造心愿" [ref=f2e58] [cursor=pointer]:
        - generic [ref=f2e59]: 杜伯 · 打造心愿
      - paragraph: 愿再等一炉，看看两次炉火的成品。
      - generic [ref=f2e60]:
        - button "行脚商人 · 已到场" [ref=f2e61] [cursor=pointer]
        - button "本炉手札，已评鉴1/12，只读无额外奖励" [ref=f2e62] [cursor=pointer]:
          - generic [ref=f2e63]: 手札
          - generic [ref=f2e64]: 已评鉴 1/12
    - generic [ref=f2e66]:
      - button "炉心余烬 · 连锻多一记安全锤" [ref=f2e67] [cursor=pointer]:
        - generic [ref=f2e69]:
          - text: 炉心余烬
          - generic [ref=f2e70]: 连锻多一记安全锤
      - button "回响锤纹 · 普通成功 2/3 · 第三次额外+25%" [ref=f2e71] [cursor=pointer]:
        - generic [ref=f2e73]:
          - text: 回响锤纹
          - generic [ref=f2e74]: 普通成功 2/3 · 第三次额外+25%
      - button "护炉契 · 首次失约时保住印记" [ref=f2e75] [cursor=pointer]:
        - generic [ref=f2e77]:
          - text: 护炉契
          - generic [ref=f2e78]: 首次失约时保住印记
  - region "炉边事件" [ref=f2e79]:
    - status [ref=f2e80]:
      - generic [ref=f2e81]: 炉具升级 · 下轮来料更好
      - paragraph [ref=f2e82]: 新配给底价 160 → 320。当前剑不变，投入会在下一轮发配时兑现。
    - generic [ref=f2e83]:
      - button "查看成长" [ref=f2e84] [cursor=pointer]
      - button "收起炉具升级 · 下轮来料更好提示" [ref=f2e85] [cursor=pointer]: 收起
  - contentinfo [ref=f2e86]:
    - button "炉程 · 新" [ref=f2e87] [cursor=pointer]
    - button "玩法图解" [ref=f2e88] [cursor=pointer]: "?"
    - group [ref=f2e89]:
      - generic "声音与动效" [ref=f2e90] [cursor=pointer]: ⚙
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | import type {Page,Locator} from '@playwright/test';
  3  | import {readFileSync} from 'node:fs';
  4  | import {mkdir,writeFile} from 'node:fs/promises';
  5  | import {applyCommand,validateRun,TRAITS} from '../../src/core-v3/index.js';
  6  | import type {Action,RunState} from '../../src/core-v3/index.js';
  7  | import {getNotebook} from '../../src/presentation-v3/notebook.js';
  8  | const dir='tmp/v3-campaign-states';
  9  | type Route={seed:string;actions:Action[];finalState:RunState};
  10 | const route=JSON.parse(readFileSync('docs/evidence/T11-4-2-3d/route.json','utf8')) as Route;
  11 | const repairRoute=JSON.parse(readFileSync('docs/evidence/T11-4-2-3d/repair-route.json','utf8')) as Route;
  12 | async function read(page:Page){const raw=await page.evaluate(()=>localStorage.getItem('sword-led.save.v3'));if(!raw)throw Error('No actual v3 save');const result=validateRun(JSON.parse(raw).state);if(!result.ok)throw Error(result.detail);return result.state;}
> 13 | async function tabTo(page:Page,target:Locator){for(let i=0;i<100;i++){if(await target.evaluate(e=>e===document.activeElement))return;const back=await target.evaluate(e=>Boolean(document.activeElement&&(document.activeElement.compareDocumentPosition(e)&Node.DOCUMENT_POSITION_PRECEDING)));await page.keyboard.press(back?'Shift+Tab':'Tab');}throw Error('Not keyboard reachable');}
     |                                                                                       ^ Error: locator.evaluate: Test timeout of 360000ms exceeded.
  14 | async function activate(page:Page,target:Locator){await tabTo(page,target);await page.keyboard.press('Enter');}
  15 | const confirm=(page:Page)=>activate(page,page.locator('#v3-dialog-actions').getByRole('button',{name:'确认',exact:true}));
  16 | async function start(page:Page,seed:string){await page.goto('/');await expect(page.locator('#v3-workshop')).toBeVisible();await activate(page,page.locator('#v3-menu'));await tabTo(page,page.locator('#v3-seed'));await page.keyboard.press('ControlOrMeta+A');await page.keyboard.type(seed);await expect(page.locator('#v3-mode')).toHaveValue('12');await activate(page,page.getByRole('button',{name:'开一炉新契约'}));await confirm(page);expect((await read(page)).roundLimit).toBe(12);}
  17 | async function snapshot(page:Page,name:string){await mkdir(dir,{recursive:true});await writeFile(`${dir}/${test.info().project.name}-${name}.json`,JSON.stringify(await read(page),null,2)+'\n');}
  18 | async function perform(page:Page,action:Action){
  19 |  const before=await read(page);if('pieceId'in action){if(action.type==='reserve'&&before.reserveId===action.pieceId)await activate(page,page.locator('#v3-reserve-slot button'));else await activate(page,page.locator(`[data-piece="${action.pieceId}"]`));}
  20 |  switch(action.type){
  21 |   case 'strike':await tabTo(page,page.locator('#v3-strike'));await page.keyboard.press('Space');await expect(page.locator('#v3-strike')).toHaveAttribute('aria-busy','false');break;
  22 |   case 'deliver':await activate(page,page.locator('#v3-deliver'));break;
  23 |   case 'reserve':if(before.reserveId!==action.pieceId)await activate(page,page.locator('#v3-store'));break;
  24 |   case 'scrap':await activate(page,page.locator('#v3-scrap'));await confirm(page);break;
  25 |   case 'settle':await activate(page,page.locator('#v3-settle'));await confirm(page);break;
  26 |   case 'advance':await activate(page,page.getByRole('button',{name:'领取下一轮三柄剑'}));break;
  27 |   case 'claimGift':await activate(page,page.getByRole('button',{name:'首次达标 · 领一门免费手艺'}));await activate(page,page.getByRole('button',{name:action.traitId?new RegExp(`^${TRAITS[action.traitId].name} ·`):'领取40金币'}));break;
  28 |   case 'buy':await activate(page,page.locator('#v3-shop'));await activate(page,page.locator(`article[data-trait="${action.traitId}"] button`));if(action.replaceId)await activate(page,page.getByRole('button',{name:new RegExp(`^换下${TRAITS[action.replaceId].name}：`)}));await confirm(page);break;
  29 |   case 'upgrade':await activate(page,page.locator('#v3-shop'));await activate(page,page.getByRole('button',{name:/升级炉具/}));await expect(page.locator('#v3-dialog-body')).toContainText(`${before.base}→${before.base*2}`);await confirm(page);break;
  30 |   case 'repair':await activate(page,page.locator('#v3-shop'));await activate(page,page.getByRole('button',{name:/补一枚印记/}));await confirm(page);break;
  31 |  }
  32 |  const result=applyCommand(before,{runId:before.runId,expectedRevision:before.revision,action});if(!result.ok)throw Error(result.error);expect(await read(page)).toEqual(result.state);return result.state;
  33 | }
  34 | test('default twelve-round campaign completes through three merchants, upgrades, replacement and reload with zero pointer events',async({page},info)=>{
  35 |  test.setTimeout(360000);expect(validateRun(route.finalState).ok).toBe(true);const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()>=400)errors.push(`${r.status()} ${r.url()}`);});await page.addInitScript(()=>window.addEventListener('pointerdown',()=>document.documentElement.dataset.pointers=String(Number(document.documentElement.dataset.pointers??0)+1)));
  36 |  await start(page,route.seed);let checkedCancel=false,checkedDetails=false;const prices:number[]=[],seenFour:number[]=[];
  37 |  for(const action of route.actions){const before=await read(page);
  38 |   if(action.type==='buy'&&action.replaceId&&!checkedCancel){await activate(page,page.locator(`[data-piece="${action.pieceId}"]`));await activate(page,page.locator('#v3-shop'));await activate(page,page.locator(`article[data-trait="${action.traitId}"] button`));await activate(page,page.getByRole('button',{name:'保留原样',exact:true}));expect(await read(page)).toEqual(before);checkedCancel=true;}
  39 |   const s=await perform(page,action);
  40 |   if(action.type==='upgrade'){prices.push(before.coins-s.coins);expect(s.blades.filter(b=>b.status==='active').map(b=>b.base)).toEqual(before.blades.filter(b=>b.status==='active').map(b=>b.base));}
  41 |   if(action.type==='advance'){const fresh=s.blades.filter(b=>b.suppliedRound===s.round);expect(fresh).toHaveLength(3);expect(fresh.slice(1).every(b=>b.base===s.base)).toBe(true);if([4,7,10].includes(s.round)){await snapshot(page,`supply-${s.round}`);const bytes=await page.evaluate(()=>localStorage.getItem('sword-led.save.v3'));await page.reload();await expect(page.locator('#v3-workshop')).toBeVisible();expect(await page.evaluate(()=>localStorage.getItem('sword-led.save.v3'))).toBe(bytes);}}
  42 |   if(action.type==='reserve'&&before.reserveId===action.pieceId&&await page.locator('#v3-inventory button').count()===4){seenFour.push(s.round);for(const [width,height]of [[1280,720],[1920,1080]]){await page.setViewportSize({width:width!,height:height!});const boxes=await page.locator('#v3-inventory button,#v3-strike,#v3-shop,#v3-settings summary').evaluateAll(nodes=>nodes.map(e=>{const r=e.getBoundingClientRect();return{x:r.x,y:r.y,width:r.width,height:r.height};}));expect(boxes).toHaveLength(7);for(const box of boxes){expect(box.width).toBeGreaterThan(0);expect(box.height).toBeGreaterThan(0);expect(box.y).toBeGreaterThanOrEqual(0);expect(box.y+box.height).toBeLessThanOrEqual(height!);}}}
  43 |   if(action.type==='buy'){for(const [width,height]of [[1280,720],[1920,1080]]){await page.setViewportSize({width:width!,height:height!});for(const id of ['v3-value','v3-strike','v3-deliver','v3-shop','v3-settings','v3-notebook','v3-customer-open']){const box=await page.locator('#'+id).boundingBox();expect(box!.y+box!.height).toBeLessThanOrEqual(height!);}await mkdir(dir,{recursive:true});await page.screenshot({path:`${dir}/${info.project.name}-merchant-${s.round}-${width}.png`});}await snapshot(page,`merchant-${s.round}`);}
  44 |   if(!checkedDetails&&s.traits.length){const bytes=await page.evaluate(()=>localStorage.getItem('sword-led.save.v3'));await activate(page,page.locator('#v3-traits .v3-trait-item').first());await expect(page.locator('#v3-dialog')).toBeVisible();await activate(page,page.getByRole('button',{name:'回铁砧',exact:true}));expect(await page.evaluate(()=>localStorage.getItem('sword-led.save.v3'))).toBe(bytes);checkedDetails=true;}
  45 |  }
  46 |  const s=await read(page);expect(s.phase).toBe('victory');expect(s.round).toBe(12);expect(s.history).toHaveLength(12);expect(s.blades).toHaveLength(36);expect(prices).toEqual([180,900,4500]);expect(checkedCancel).toBe(true);expect(seenFour).toEqual([3,6,9]);expect(Number(await page.locator('html').getAttribute('data-pointers'))).toBe(0);
  47 |  await expect(page.locator('#v3-screen-title')).toHaveText('十二轮契约完成');await expect(page.locator('#v3-screen-body')).not.toContainText('三枚印记用尽');await expect(page.getByRole('button',{name:'领取下一轮三柄剑'})).toHaveCount(0);
  48 |  for(const [width,height]of [[1280,720],[1920,1080]]){await page.setViewportSize({width:width!,height:height!});const box=await page.locator('#v3-screen-actions').boundingBox();expect(box!.y+box!.height).toBeLessThanOrEqual(height!);await page.screenshot({path:`${dir}/${info.project.name}-victory-${width}.png`});}
  49 |  await snapshot(page,'victory');const savedBook=await page.evaluate(()=>localStorage.getItem('sword-led.save.v3'));await activate(page,page.getByRole('button',{name:'翻开本炉手札',exact:true}));await expect(page.locator('[data-notebook-round]')).toHaveCount(12);expect(await page.locator('[data-notebook-piece]').evaluateAll(nodes=>nodes.map(n=>(n as HTMLElement).dataset.notebookPiece))).toEqual(getNotebook(s).works.map(w=>w.blade.id));await activate(page,page.getByRole('button',{name:'回铁砧',exact:true}));expect(await page.evaluate(()=>localStorage.getItem('sword-led.save.v3'))).toBe(savedBook);await activate(page,page.locator('#v3-ledger>summary'));await expect(page.locator('#v3-ledger>table>tbody>tr')).toHaveCount(12);await activate(page,page.locator('.v3-piece-ledger>summary'));await expect(page.locator('.v3-piece-ledger li')).toHaveCount(36);await page.keyboard.press('End');await page.reload();expect((await read(page)).phase).toBe('victory');expect(errors).toEqual([]);
  50 | });
  51 | test('twelve-round failure and merchant repair use real seals and coins',async({page})=>{
  52 |  test.setTimeout(90000);await start(page,repairRoute.seed);const stop=repairRoute.actions.findIndex(a=>a.type==='repair');expect(stop).toBeGreaterThan(0);for(const action of repairRoute.actions.slice(0,stop+1))await perform(page,action);const repaired=await read(page);expect(repaired.repaired).toBe(true);expect(repaired.seals).toBe(3);await snapshot(page,'repaired');
  53 |  await activate(page,page.locator('#v3-menu'));await activate(page,page.getByRole('button',{name:'开一炉新契约'}));await confirm(page);for(let n=0;n<3;n++){await perform(page,{type:'settle'});if(n<2)await perform(page,{type:'advance'});}expect((await read(page)).phase).toBe('defeat');expect((await read(page)).roundLimit).toBe(12);await expect(page.locator('#v3-screen-title')).toHaveText('契约终止');await snapshot(page,'defeat');const ended=await page.evaluate(()=>localStorage.getItem('sword-led.save.v3'));await activate(page,page.locator('#v3-events'));await expect(page.locator('.v3-forge-journey')).toContainText('本局契约已结束');await expect(page.locator('.v3-forge-journey')).not.toContainText('下一次商人');await activate(page,page.getByRole('button',{name:'回铁砧',exact:true}));expect(await page.evaluate(()=>localStorage.getItem('sword-led.save.v3'))).toBe(ended);
  54 | });
  55 | test('existing three-round save stays three rounds; explicit fresh campaign supports twelve and cancel preserves the old bytes',async({page})=>{
  56 |  await page.goto('/?mode=3');await expect(page.locator('#v3-hit')).toBeEnabled();expect((await read(page)).roundLimit).toBe(3);await perform(page,{type:'strike',pieceId:'r1-1'});const old=await page.evaluate(()=>localStorage.getItem('sword-led.save.v3'));await page.goto('/');await expect(page.locator('#v3-workshop')).toBeVisible();expect(await page.evaluate(()=>localStorage.getItem('sword-led.save.v3'))).toBe(old);await expect(page.locator('#v3-edition')).toContainText('三轮练手');
  57 |  await activate(page,page.locator('#v3-menu'));await expect(page.locator('#v3-mode')).toHaveValue('12');await activate(page,page.getByRole('button',{name:'开一炉新契约'}));await activate(page,page.locator('#v3-dialog-actions').getByRole('button',{name:'返回',exact:true}));expect(await page.evaluate(()=>localStorage.getItem('sword-led.save.v3'))).toBe(old);await activate(page,page.getByRole('button',{name:'开一炉新契约'}));await confirm(page);expect((await read(page)).roundLimit).toBe(12);const twelve=await page.evaluate(()=>localStorage.getItem('sword-led.save.v3'));await page.goto('/?mode=3');await expect(page.locator('#v3-workshop')).toBeVisible();expect(await page.evaluate(()=>localStorage.getItem('sword-led.save.v3'))).toBe(twelve);await snapshot(page,'mode-continuity');
  58 | });
  59 | 
```