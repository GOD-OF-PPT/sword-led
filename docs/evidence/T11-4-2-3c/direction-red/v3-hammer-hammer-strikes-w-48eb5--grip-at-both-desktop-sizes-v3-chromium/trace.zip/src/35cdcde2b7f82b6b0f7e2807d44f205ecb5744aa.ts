import {test,expect} from '@playwright/test';
import {installHammerProbe} from './hammer-probe';
import {mkdir,writeFile} from 'node:fs/promises';
test('hammer strikes with a flat metal face and rotates around its grip at both desktop sizes',async({page},info)=>{
 const dir='tmp/v3-hammer-states';await mkdir(dir,{recursive:true});await page.goto('/');await expect(page.locator('#v3-hit')).toBeEnabled();await page.locator('#v3-hammer img').evaluate(async(i:HTMLImageElement)=>{await i.decode();});
 for(const [width,height]of [[1280,720],[1920,1080]]){await page.setViewportSize({width:width!,height:height!});await page.screenshot({path:`${dir}/${info.project.name}-${width}-idle.png`});await installHammerProbe(page);const box=await page.locator('#v3-hit').boundingBox();await page.mouse.click(box!.x+box!.width*.58,box!.y+box!.height*.6);await expect.poll(()=>page.evaluate(()=>window.v3HammerGeometry.complete)).toBe(true);const probe=await page.evaluate(()=>window.v3HammerGeometry),best=probe.frames.reduce((a,b)=>b.gap<a.gap?b:a);await writeFile(`${dir}/${info.project.name}-${width}-geometry.json`,JSON.stringify({probe,best},null,2)+'\n');await page.screenshot({path:`${dir}/${info.project.name}-${width}-after.png`});expect(Math.abs(best.angle)).toBeLessThan(10);expect(best.pivotGap).toBeLessThan(4);expect(best.gap).toBeLessThan(6);}
});
