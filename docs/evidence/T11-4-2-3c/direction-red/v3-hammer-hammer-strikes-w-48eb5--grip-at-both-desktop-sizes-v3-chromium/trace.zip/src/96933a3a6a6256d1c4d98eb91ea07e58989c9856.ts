import type {Page} from '@playwright/test';
declare global{interface Window{v3HammerGeometry:{frames:{gap:number;angle:number;pivotGap:number;headHeight:number;time:number}[];complete:boolean;source:string}}}
/** Independently inspected physical face edge and grip landmarks, not the game's FX anchor. */
export async function installHammerProbe(page:Page){await page.locator('#v3-scene').evaluate(scene=>{
 const hammer=scene.querySelector<HTMLElement>('#v3-hammer')!,image=hammer.querySelector('img')!;
 const legacy=image.src.includes('hammer-standard-v1');
 const landmarks=legacy?{a:[110,450],b:[330,595],grip:[1090,1090],head:[400,330]}:{a:[0,0],b:[0,0],grip:[0,0],head:[0,0]};
 const readPoint=(source:number[])=>{const hs=getComputedStyle(hammer),is=getComputedStyle(image),w=image.clientWidth,h=image.clientHeight,fit=Math.min(w/image.naturalWidth,h/image.naturalHeight),fw=image.naturalWidth*fit,fh=image.naturalHeight*fit;
  const io=is.transformOrigin.split(' ').map(parseFloat),ho=hs.transformOrigin.split(' ').map(parseFloat),local=new DOMMatrix(is.transform==='none'?undefined:is.transform).transformPoint({x:(w-fw)/2+source[0]!*fit-io[0]!,y:(h-fh)/2+source[1]!*fit-io[1]!});
  const p=new DOMMatrix(hs.transform==='none'?undefined:hs.transform).transformPoint({x:local.x+io[0]!+image.offsetLeft-ho[0]!,y:local.y+io[1]!+image.offsetTop-ho[1]!});return{x:hammer.offsetLeft+p.x+ho[0]!,y:hammer.offsetTop+p.y+ho[1]!,pivotX:hammer.offsetLeft+ho[0]!,pivotY:hammer.offsetTop+ho[1]!};};
 window.v3HammerGeometry={frames:[],complete:false,source:image.currentSrc||image.src};let started=0;
 function sample(){const probe=window.v3HammerGeometry,a=readPoint(landmarks.a),b=readPoint(landmarks.b),grip=readPoint(landmarks.grip),head=readPoint(landmarks.head),rect=scene.getBoundingClientRect(),hx=parseFloat((scene as HTMLElement).style.getPropertyValue('--hit-x'))/100*rect.width,hy=parseFloat((scene as HTMLElement).style.getPropertyValue('--hit-y'))/100*rect.height;
  const gap=Math.hypot((a.x+b.x)/2-hx,(a.y+b.y)/2-hy),angle=Math.atan2(b.y-a.y,b.x-a.x)*180/Math.PI;
  probe.frames.push({gap,angle,pivotGap:Math.hypot(grip.x-grip.pivotX,grip.y-grip.pivotY),headHeight:Math.hypot(head.x-(a.x+b.x)/2,head.y-(a.y+b.y)/2)*2,time:performance.now()-started});
  if(performance.now()-started>450)probe.complete=true;else requestAnimationFrame(sample);
 }
 scene.addEventListener('pointerdown',()=>{started=performance.now();requestAnimationFrame(sample);},{once:true,capture:true});
});}
