# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: payment-ui.spec.mjs >> actual estimate, commission share and copper received remain clear at both PC sizes
- Location: tmp/goal4-T03/drafts/payment-ui/payment-ui.spec.mjs:11:1

# Error details

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 44
Received:    40
```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - text: +
  - main "行脚灯炉" [ref=f2e4]:
    - generic [aria-hidden]:
      - strong: 锤下求生
      - generic: v0.8 炉边报价 · 三柄行囊
    - generic "契印与行囊" [ref=f2e5]:
      - generic [ref=f2e6]:
        - generic [ref=f2e7]: 契印
        - strong [ref=f2e8]: 3/3
      - generic [ref=f2e9]:
        - generic [ref=f2e10]: 铜钱
        - strong [ref=f2e11]: "120"
    - complementary "炉边剑架" [ref=f2e12]:
      - heading "候火的剑" [level=2] [ref=f2e13]
      - paragraph [ref=f2e14]: 拿起剑，拖给来客
      - generic [ref=f2e15]:
        - button "轻刃 · 40" [pressed] [ref=f2e16] [cursor=pointer]
        - button "轻刃 · 40" [ref=f2e17] [cursor=pointer]
      - region "留给明天的剑" [ref=f2e18]:
        - heading "留一把，待明日" [level=3] [ref=f2e19]
        - generic [ref=f2e20]: 留一柄，给明天
        - paragraph [ref=f2e21]: 明日：新坯3
        - button "明日打算 ›" [ref=f2e22] [cursor=pointer]
      - generic [ref=f2e23]:
        - button "留给明天" [ref=f2e24] [cursor=pointer]
        - generic "配方选择"
    - generic "铁砧与当前兵器" [ref=f2e25]:
      - generic "青云轻刃，乌铁坯，等级0，身价40，完好；仅造型展示"
      - button "在剑身上落锤" [ref=f2e26]
    - region "眼前的打造打算":
      - strong: 今天的约定已经交妥
      - paragraph: 行会可收10铜钱。留到明日会占一位新坯。回收实得10铜钱。
    - region "当前剑的估值与状况":
      - paragraph:
        - generic: 作品估值
        - strong: "40"
        - generic: 轻刃 · 无裂纹
      - paragraph: 估值用来验剑，铜钱按右侧报价入袋。
      - paragraph: 等级 0 · 已完成安全连锻 0次
      - generic:
        - paragraph: 下一锤裂损 0% · 首裂会掉价
        - paragraph: 锤势 0/6
      - button "落锤 左键剑身 / 空格" [ref=f2e27] [cursor=pointer]:
        - text: 落锤
        - generic [ref=f2e28]: 左键剑身 / 空格
    - complementary "等剑的来客与委托" [ref=f2e29]:
      - button "和来客聊聊" [ref=f2e30] [cursor=pointer]:
        - img:
          - img "来客已收1柄：轻刃，身价201"
        - generic [ref=f2e31]:
          - generic [ref=f2e32]: 阿岚
          - generic [ref=f2e33]: 点来客，听听心愿
      - text: ·
      - paragraph [ref=f2e34]: 阿岚点亮第一座灯站，巡夜的人看见了家门。
      - region "来客收剑回执" [ref=f2e35]:
        - text: 收讫
        - img "巡夜第一灯的实际交付" [ref=f2e36]
        - heading "阿岚接过了剑" [level=2] [ref=f2e37]
        - paragraph [ref=f2e38]: 阿岚点亮第一座灯站，巡夜的人看见了家门。
        - paragraph [ref=f2e39]: 实收 120 铜钱 · 酬劳100＋品质加赏20
        - button "收下第一门手艺" [ref=f2e40] [cursor=pointer]
        - button "收好这张回执" [ref=f2e41] [cursor=pointer]: ×
      - button "卖给行会 · 实收10铜钱" [active] [ref=f2e42] [cursor=pointer]
      - button "查看估值与实收说明" [ref=f2e43] [cursor=pointer]:
        - generic [ref=f2e44]: 余剑出售 · 本次实收10铜钱
        - text: 看报价说明 ›
    - generic "已装炉具"
    - region "随身手艺与炉具" [ref=f2e46]:
      - button "首赠 · 选手艺" [ref=f2e48] [cursor=pointer]
    - button "回收这柄剑" [ref=f2e49] [cursor=pointer]
    - button "收炉，准备启程" [ref=f2e50] [cursor=pointer]
  - navigation "行旅工具" [ref=f2e51]:
    - button "暂停与行旅菜单" [ref=f2e52] [cursor=pointer]: 行囊
    - button "打开炉谱" [ref=f2e53] [cursor=pointer]: 炉谱
    - button "打开设置" [ref=f2e54] [cursor=pointer]: 设置
    - button "查看保存详情" [ref=f2e55] [cursor=pointer]: 进度已收好
  - status [ref=f2e56]
```

# Test source

```ts
  1  | // Isolated candidate, not executed while authored and not part of a production/default test glob.
  2  | import {test,expect} from '@playwright/test';
  3  | import {readFile,writeFile,readdir,lstat} from 'node:fs/promises';
  4  | import {createHash} from 'node:crypto';
  5  | import {resolve,join,relative} from 'node:path';
  6  | import {fileURLToPath} from 'node:url';
  7  | const repository=fileURLToPath(new URL('../../../../',import.meta.url)),sizes=[{width:1280,height:720},{width:1920,height:1080}],fmt=value=>value.toLocaleString('zh-CN'),sha=bytes=>createHash('sha256').update(bytes).digest('hex');
  8  | async function manifest(){const root=resolve(repository,'dist'),files=[];async function walk(directory){for(const name of await readdir(directory)){const path=join(directory,name),status=await lstat(path);if(status.isSymbolicLink())throw Error('Unbound runtime symlink');if(status.isDirectory())await walk(path);else if(status.isFile()){const bytes=await readFile(path);files.push({path:relative(root,path),bytes:bytes.length,sha256:sha(bytes)});}}}await walk(root);return files.sort((a,b)=>a.path.localeCompare(b.path));}
  9  | async function allRaw(page){return page.evaluate(()=>Object.fromEntries(Array.from({length:localStorage.length},(_,index)=>localStorage.key(index)).filter(key=>key!==null).sort().map(key=>[key,localStorage.getItem(key)])));}
  10 | 
  11 | test('actual estimate, commission share and copper received remain clear at both PC sizes',async({page},info)=>{
  12 |  const {KeyboardV5,v5Sdk,v5VictoryGuide,V5_GUIDE_PATH}=await import('../../../../tests/e2e/v5-helpers.ts');
  13 |  const h=new KeyboardV5(page,info,'mouse');await h.install();const startManifest=await manifest(),records=[],geometry=[];expect(startManifest).toHaveLength(82);
  14 |  const save=async(name,value)=>writeFile(info.outputPath(name+'.json'),JSON.stringify(value,null,2));
  15 |  // One public pass over the already published legal witness, never a new balance policy or seed search.
  16 |  const witnessBytes=await readFile(resolve(repository,V5_GUIDE_PATH)),source=JSON.parse(witnessBytes.toString()).state,made=v5Sdk.createRun({runId:source.runId,seed:source.seed,mode:source.mode,eligibility:source.initialEligibility});if(!made.ok)throw Error(made.error);
  17 |  let state=made.state,qualified=null,exhausted=null;const twins=[];
  18 |  for(const [index,action]of v5VictoryGuide.entries()){
  19 |   const view=v5Sdk.getRunView(state);if(!exhausted&&state.phase==='workshop'){const spare=view.blades.find(row=>!row.reserved&&row.quote.error==='market_exhausted');if(spare)exhausted={state,pieceId:spare.blade.id,index};}
  20 |   const result=v5Sdk.applyCommand(state,{runId:state.runId,expectedRevision:state.revision,action});if(!result.ok)throw Error('Existing payment witness rejected: '+result.error);
  21 |   if(action.type==='deliver'){const quote=view.blades.find(row=>row.blade.id===action.pieceId)?.quote;if(quote?.allowed&&quote.matched){if(!qualified&&quote.qualityBonus>0)qualified={state,action,index};if(state.day===8)twins.push({state,action,index});}}
  22 |   state=result.state;
  23 |  }
  24 |  expect(state).toEqual(source);if(!qualified||!exhausted||twins.length!==2){const gap={qualified:!!qualified,exhausted:!!exhausted,twinDeliveries:twins.length,source:V5_GUIDE_PATH,scope:'Missing actual guide boundary; do not inject prices, wallet, RNG, level or challenge dates.'};await save('specific-payment-fixture-gap',gap);throw Error(JSON.stringify(gap));}
  25 |  expect(v5Sdk.commissionFor(twins[0].state).id).toBe(8);expect(v5Sdk.commissionFor(twins[0].state).routes.some(route=>route.count===2)).toBe(true);
  26 |  await save('payment-input-identity',{runtime:startManifest,sdkSHA256:sha(await readFile(resolve(repository,'dist/sword-led-v5.js'))),witness:{path:V5_GUIDE_PATH,sha256:sha(witnessBytes)},boundaries:{qualified:{revision:qualified.state.revision,index:qualified.index},exhausted:{revision:exhausted.state.revision,index:exhausted.index},twins:twins.map(item=>({day:item.state.day,revision:item.state.revision,index:item.index}))},scope:'One ChromiumDPR1 logic; every described quote/receipt is checked at1280 and1920. The actual two-sword order is day8, while day6 remains its real single cracked-sword order.'});
  27 |  async function screen(label,selectors){
  28 |   const before=await allRaw(page),rows=[];
> 29 |   for(const size of sizes){await page.setViewportSize(size);await h.assertDpr();for(const selector of selectors){const node=page.locator(selector);await expect(node).toBeVisible();const metric=await node.evaluate(node=>{const box=node.getBoundingClientRect(),top=document.elementFromPoint(box.left+box.width/2,box.top+box.height/2);return{selector:node.id,text:node.textContent,width:box.width,height:box.height,interactive:node instanceof HTMLButtonElement,pointerEvents:getComputedStyle(node).pointerEvents,inside:box.left>=0&&box.top>=0&&box.right<=innerWidth&&box.bottom<=innerHeight,unblocked:top===node||!!top&&node.contains(top),contentFits:node.scrollWidth<=node.clientWidth+1&&node.scrollHeight<=node.clientHeight+1};});expect(metric.inside,selector).toBe(true);expect(metric.contentFits,selector).toBe(true);if(metric.interactive){expect(metric.unblocked,selector).toBe(true);expect(metric.width).toBeGreaterThanOrEqual(44);expect(metric.height).toBeGreaterThanOrEqual(44);}rows.push({size,...metric});}await page.screenshot({path:info.outputPath(label+'-'+size.width+'.png')});}
     |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ^ Error: expect(received).toBeGreaterThanOrEqual(expected)
  30 |   await page.setViewportSize({width:1280,height:720});expect(await allRaw(page)).toEqual(before);geometry.push({label,rows});
  31 |  }
  32 |  async function inspectQuote(label,kind,pieceId){
  33 |   const before=await h.read(),view=v5Sdk.getRunView(before.state),item=view.blades.find(row=>row.blade.id===pieceId);if(!item)throw Error('No real selected quote source');
  34 |   await expect(page.locator('.v4-value-line')).toContainText('作品估值');await expect(page.locator('#v5-value-meaning')).toContainText('估值');await expect(page.locator('#v4-value')).toHaveText(fmt(item.blade.value));const rawBefore=await allRaw(page),q=item.quote;
  35 |   await expect(page.locator('#v5-order-pay')).toHaveText(`整单酬劳 ${fmt(view.market.baseFee)}铜钱 · 已领 ${fmt(view.market.baseFeesPaid)}铜钱`);
  36 |   if(kind==='commission'){expect(q.allowed).toBe(true);expect(q.matched).toBe(true);await expect(page.locator('#v4-deliver')).toHaveText(`交给${view.commission.name} · 实收${fmt(q.amount)}铜钱`);await expect(page.locator('#v5-delivery-quote > span')).toHaveText(`本柄酬劳${fmt(q.baseFeeDelta)}＋品质加赏${fmt(q.qualityBonus)}＝${fmt(q.amount)}铜钱`);}
  37 |   else if(kind==='sale'){expect(q.allowed).toBe(true);expect(q.matched).toBe(false);await expect(page.locator('#v4-deliver')).toHaveText(`卖给行会 · 实收${fmt(q.amount)}铜钱`);await expect(page.locator('#v5-delivery-quote > span')).toHaveText(`余剑出售 · 本次实收${fmt(q.amount)}铜钱`);}
  38 |   else{expect(q.allowed).toBe(false);await expect(page.locator('#v4-deliver')).toBeDisabled();await expect(page.locator('#v4-deliver')).not.toContainText(/实收\s*[\d,]+/);await expect(page.locator('#v5-delivery-quote > span')).not.toContainText(/实收\s*[\d,]+|本柄酬劳\s*[\d,]+/);if(kind==='reserved'){expect(item.reserved).toBe(true);await expect(page.locator('#v4-deliver')).toHaveText('先从剑架取回');}else{expect(q.error).toBe('market_exhausted');expect(view.market.remaining).toBe(0);await expect(page.locator('#v4-deliver')).toHaveText('今日收购余款已用尽');}}
  39 |   await screen(label,['#v4-deliver','#v5-delivery-quote','#v5-order-pay','#v5-value-meaning']);
  40 |   // Both sizes actually open and close the real explanation; every storage slot and decoded layer stays identical.
  41 |   for(const size of sizes){await page.setViewportSize(size);await expect(page.locator('#v5-delivery-quote')).toBeEnabled();await page.locator('#v5-delivery-quote').click();await expect(page.locator('#v4-dialog-title')).toHaveText('估值与这次收款');const body=page.locator('#v4-dialog-body');await expect(body).toContainText(`整单酬劳 ${fmt(view.market.baseFee)}铜钱 · 已领 ${fmt(view.market.baseFeesPaid)}铜钱`);if(kind==='commission'){await expect(body).toContainText(`本柄酬劳${fmt(q.baseFeeDelta)}＋品质加赏${fmt(q.qualityBonus)}＝${fmt(q.amount)}铜钱`);await expect(body).toContainText('1/5');await expect(body).toContainText(`收购余款 ${fmt(view.market.remaining)}铜钱`);}if(kind==='sale'){await expect(body).toContainText('1/4');await expect(body).toContainText(`实收 ${fmt(q.amount)}铜钱`);}if(kind==='reserved'||kind==='exhausted')await expect(body.locator('h3')).not.toContainText(/实收\s*[\d,]+|本柄酬劳\s*[\d,]+/);const close=page.getByRole('button',{name:'明白了，回炉边',exact:true});await expect(close).toBeInViewport({ratio:1});await page.screenshot({path:info.outputPath(label+'-details-'+size.width+'.png')});await close.click();await expect(page.locator('#v4-dialog')).not.toBeVisible();expect(await allRaw(page)).toEqual(rawBefore);const after=await h.read();expect(after.state).toEqual(before.state);expect(after.collection).toEqual(before.collection);}
  42 |   await page.setViewportSize({width:1280,height:720});records.push({label,kind,view:{day:view.day,commissionId:view.commission.id,market:view.market},piece:item.blade,quote:q,state:before.state,raw:rawBefore});return q;
  43 |  }
  44 |  async function paid(action,label){const before=(await h.read()).state,item=v5Sdk.getRunView(before).blades.find(row=>row.blade.id===action.pieceId);if(!item)throw Error('No actual payment sword');const quote=item.quote,expected=v5Sdk.applyCommand(before,{runId:before.runId,expectedRevision:before.revision,action});if(!expected.ok)throw Error(expected.error);const after=await h.command(action);expect(after.coins-before.coins).toBe(quote.amount);expect(after).toEqual(expected.state);const event=expected.events.find(event=>event.type==='Delivered');expect(event?.type).toBe('Delivered');expect(event?.amount).toBe(quote.amount);expect(event?.baseFeeDelta).toBe(quote.baseFeeDelta);expect(event?.qualityBonus).toBe(quote.qualityBonus);await expect(page.locator('#v4-coins')).toHaveText(fmt(after.coins));records.push({label,before,after,quote,events:expected.events,walletDelta:after.coins-before.coins});return{before,after,quote,events:expected.events};}
  45 |  try{
  46 |   await h.start('v5-economy-0');await h.command({type:'continue'});const fresh=(await h.read()).state,first=fresh.blades.find(blade=>blade.status==='active'&&blade.id!==fresh.reserveId);if(!first)throw Error('Real opening has no spare');await h.select(first.id);await inspectQuote('fresh-spare-sale','sale',first.id);const sale=await paid({type:'deliver',pieceId:first.id},'fresh-real-sale');expect(sale.quote.matched).toBe(false);expect(v5Sdk.commissionProgress(sale.after).complete).toBe(false);
  47 |   // Keep the reserved case in this genuinely started run; only legal reserve/recovery actions remove the other spare.
  48 |   const remaining=sale.after.blades.filter(blade=>blade.status==='active'),reserved=remaining[0];if(!reserved||remaining.length!==2)throw Error('Real first sale must leave two current swords');await h.command({type:'reserve',pieceId:reserved.id});for(const blade of remaining.filter(blade=>blade.id!==reserved.id))await h.command({type:'scrap',pieceId:blade.id});await inspectQuote('real-reserved-only-sword','reserved',reserved.id);
  49 |   await h.restoreLegitimate(qualified.state);await h.select(qualified.action.pieceId);const commissionQuote=await inspectQuote('qualified-real-commission','commission',qualified.action.pieceId);expect(commissionQuote.qualityBonus).toBeGreaterThan(0);const main=await paid(qualified.action,'qualified-main-payment');expect(main.events.some(event=>event.type==='MainCompleted')).toBe(true);await expect(page.locator('#v5-inline-payment')).toHaveText(`实收 ${fmt(main.quote.amount)} 铜钱 · 酬劳${fmt(main.quote.baseFeeDelta)}＋品质加赏${fmt(main.quote.qualityBonus)}`);await screen('qualified-actual-receipt',['#v5-inline-payment','#v4-inline-review']);
  50 |   await h.restoreLegitimate(twins[0].state);let twinPayments=0;for(const action of v5VictoryGuide.slice(twins[0].index,twins[1].index+1)){if(action.type==='deliver'){const actual=(await h.read()).state,row=v5Sdk.getRunView(actual).blades.find(row=>row.blade.id===action.pieceId);if(!row?.quote.matched)throw Error('Actual twin action is not a qualified delivery');await h.select(action.pieceId);await inspectQuote('day8-twin-'+(twinPayments+1),'commission',action.pieceId);const beforeView=v5Sdk.getRunView(actual),paidResult=await paid(action,'actual-day8-twin-'+(twinPayments+1));expect(v5Sdk.getRunView(paidResult.after).market.baseFeesPaid-beforeView.market.baseFeesPaid).toBe(paidResult.quote.baseFeeDelta);twinPayments++;if(twinPayments===1){expect(v5Sdk.commissionProgress(paidResult.after).complete).toBe(false);await expect(page.locator('#v4-notice-copy')).toContainText(`实收${fmt(paidResult.quote.amount)}铜钱`);await expect(page.locator('#v4-notice-copy')).toContainText(`酬劳${fmt(paidResult.quote.baseFeeDelta)}＋品质加赏${fmt(paidResult.quote.qualityBonus)}`);await screen('day8-first-actual-receipt',['#v4-notice-copy']);}else{expect(v5Sdk.commissionProgress(paidResult.after).complete).toBe(true);await expect(page.locator('#v5-inline-payment')).toHaveText(`实收 ${fmt(paidResult.quote.amount)} 铜钱 · 酬劳${fmt(paidResult.quote.baseFeeDelta)}＋品质加赏${fmt(paidResult.quote.qualityBonus)}`);await screen('day8-second-actual-receipt',['#v5-inline-payment','#v4-inline-review']);}}else await h.command(action);}expect(twinPayments).toBe(2);
  51 |   await h.restoreLegitimate(exhausted.state);await h.select(exhausted.pieceId);await inspectQuote('real-exhausted-purse','exhausted',exhausted.pieceId);
  52 |   await save('payment-observations',{records,geometry,scope:'Real opening spare sale and reserved-only run; separately labelled formal guide restorations for qualified payment, actual day8 two-sword first/second shares and exhausted purse. Every price comes from public quote; no equal split, fabricated price, wallet, RNG or phase. Each quote explanation is clicked at1280/1920 and all local raw/state/book bytes remain unchanged.'});expect(await manifest()).toEqual(startManifest);await h.finish({scope:'One current payment UI acceptance logic, two real PC sizes; not a fresh full campaign, six-project matrix, economic rebalance or subjective H approval.'});
  53 |  }finally{await save('payment-partial-evidence',{records,geometry});}
  54 | });
  55 | 
```