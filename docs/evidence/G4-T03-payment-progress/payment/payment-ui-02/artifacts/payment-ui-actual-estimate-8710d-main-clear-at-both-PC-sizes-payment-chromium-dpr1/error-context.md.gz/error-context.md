# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: payment-ui.spec.mjs >> actual estimate, commission share and copper received remain clear at both PC sizes
- Location: tmp/goal4-T03/drafts/payment-ui/payment-ui.spec.mjs:11:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('#v4-notice-copy')
Expected substring: "这柄实收158铜钱（酬劳125＋品质33）"
Received string:    "这柄实收158铜钱（酬劳125＋品质加赏33）。已交1/2，再安排余下的合格剑。"
Timeout: 5000ms

Call log:
  - Expect "toContainText" locator('#v4-notice-copy') with timeout 5000ms
  - waiting for locator('#v4-notice-copy')
    14 × locator resolved to <p id="v4-notice-copy">这柄实收158铜钱（酬劳125＋品质加赏33）。已交1/2，再安排余下的合格剑。</p>
       - unexpected value "这柄实收158铜钱（酬劳125＋品质加赏33）。已交1/2，再安排余下的合格剑。"

```

```yaml
- paragraph: 这柄实收158铜钱（酬劳125＋品质加赏33）。已交1/2，再安排余下的合格剑。
```

# Test source

```ts
  31  |   await page.keyboard.press(backwards?'Shift+Tab':'Tab');
  32  |  }
  33  |  throw Error(`Control not reachable by native Tab order: ${target}; visited ${visited.join(' > ')}`);
  34  | }
  35  | export async function keyActivateV5(page:Page,target:Locator){await keyToV5(page,target);await page.keyboard.press('Enter');}
  36  | 
  37  | export class KeyboardV5 {
  38  |  readonly observations:V5Observation[]=[];
  39  |  readonly accepted:{action:Action;runId:string;mode:RunState['mode'];day:number;revision:number;coinsBefore:number;coinsAfter:number;events:unknown}[]=[];
  40  |  readonly pointerEvents:InputObservation[]=[];
  41  |  readonly frames:{label:string;metrics:V5Metrics}[]=[];
  42  |  readonly resources:ResourceObservation[]=[];
  43  |  keyboardClicks=0;
  44  |  readonly pageErrors:string[]=[];
  45  |  readonly expectedDpr:number;
  46  |  readonly expectedOrigin:string;
  47  |  private navigating=false;
  48  |  constructor(readonly page:Page,readonly info:TestInfo,readonly inputMode:'keyboard'|'mouse'='keyboard'){this.expectedDpr=Number(info.project.use.deviceScaleFactor??1);this.expectedOrigin=new URL(String(info.project.use.baseURL??'http://127.0.0.1:4245')).origin;}
  49  |  async install(){
  50  |   await mkdir(this.info.outputPath(),{recursive:true});
  51  |   this.page.on('pageerror',error=>this.pageErrors.push(String(error)));
  52  |   this.page.on('response',response=>{if(new URL(response.url()).origin===this.expectedOrigin&&response.status()>=400)this.resources.push({url:response.url(),resourceType:response.request().resourceType(),status:response.status(),expectedNavigationCancellation:false});});
  53  |   this.page.on('requestfailed',request=>{if(new URL(request.url()).origin!==this.expectedOrigin)return;const error=request.failure()?.errorText??'unknown request failure';this.resources.push({url:request.url(),resourceType:request.resourceType(),error,expectedNavigationCancellation:this.navigating&&/ERR_ABORTED|NS_BINDING_ABORTED|AbortError|cancelled|canceled/i.test(error)});});
  54  |   await this.page.exposeBinding('__v5KeyboardObserve',(_source,event:InputObservation)=>{
  55  |    if(event.type==='click'&&event.detail===0&&event.pointerType==='')this.keyboardClicks++;
  56  |    else this.pointerEvents.push(event);
  57  |   });
  58  |   await this.page.addInitScript(()=>{
  59  |    const observe=(event:Event)=>{
  60  |     const mouse=event instanceof MouseEvent?event:null,pointer=event instanceof PointerEvent?event:null;
  61  |     const report=(window as unknown as {__v5KeyboardObserve:(value:unknown)=>Promise<void>}).__v5KeyboardObserve;
  62  |     void report({type:event.type,detail:mouse?.detail??0,pointerType:pointer?.pointerType??'',trusted:event.isTrusted});
  63  |    };
  64  |    for(const type of ['pointerdown','pointerup','pointermove','mousedown','mouseup','click','dblclick','contextmenu'])window.addEventListener(type,observe,true);
  65  |   });
  66  |  }
  67  |  async assertDpr(){expect(await this.page.evaluate(()=>window.devicePixelRatio)).toBe(this.expectedDpr);}
  68  |  async metrics():Promise<V5Metrics>{return this.page.evaluate(()=>{const node=document.querySelector<HTMLCanvasElement>('#v4-blade'),box=node?.getBoundingClientRect();return{dpr:window.devicePixelRatio,viewport:{width:innerWidth,height:innerHeight},focus:document.activeElement?{id:document.activeElement.id,tag:document.activeElement.tagName}:null,canvas:node&&box?{width:node.width,height:node.height,cssWidth:box.width,cssHeight:box.height,backingRatioX:box.width>0?node.width/box.width:null,backingRatioY:box.height>0?node.height/box.height:null,visible:box.width>0&&box.height>0}:null};});}
  69  |  async reload(){this.navigating=true;try{await this.page.reload();}finally{this.navigating=false;}await this.assertDpr();}
  70  |  async read():Promise<V5Observation>{
  71  |   const raw=await this.page.evaluate(()=>({save:localStorage.getItem('sword-led.save.v5'),collection:localStorage.getItem('sword-led.collection.v2')}));
  72  |   if(!raw.save)throw Error('No actual v5 save');
  73  |   const save=v5Sdk.decodeV5Save(raw.save);if(save.status!=='valid')throw Error('Actual v5 save rejected: '+JSON.stringify(save));
  74  |   const checked=v5Sdk.validateRun(save.state);if(!checked.ok)throw Error(checked.detail);
  75  |   let collection:CollectionState|null=null;
  76  |   if(raw.collection){const decoded=v5Sdk.decodeCollection(raw.collection);if(decoded.status!=='valid')throw Error('Actual collection rejected: '+JSON.stringify(decoded));collection=decoded.state;}
  77  |   return{label:'',state:checked.state,collection,raw:{save:raw.save,collection:raw.collection},metrics:await this.metrics()};
  78  |  }
  79  |  async record(label:string){const observation=await this.read();observation.label=label;this.observations.push(observation);await writeFile(this.info.outputPath('v5-states.json'),JSON.stringify(this.observations,null,2));return observation;}
  80  |  async same(label:string,run:()=>Promise<void>){const before=await this.read();await run();expect((await this.read()).state,label).toEqual(before.state);}
  81  |  async activate(target:Locator){if(this.inputMode==='mouse')await target.click();else await keyActivateV5(this.page,target);}
  82  |  async confirm(){await this.activate(this.page.locator('#v4-dialog-actions').getByRole('button',{name:'确认',exact:true}));}
  83  |  async select(pieceId:string){const button=this.page.locator(`#v4-inventory button[data-piece="${pieceId}"]`);await expect(button).toBeVisible();if(await button.getAttribute('aria-pressed')!=='true')await this.activate(button);}
  84  |  async leaveIntro(){
  85  |   if(await this.page.locator('#v4-stage').isVisible()&&await this.page.locator('#v4-stage').getAttribute('data-scene')==='intro'){
  86  |    const before=(await this.read()).state,back=this.page.locator('#v4-stage-actions').getByRole('button',{name:'回到铁砧',exact:true});
  87  |    if(await back.isVisible())await this.activate(back);expect((await this.read()).state).toEqual(before);
  88  |   }
  89  |  }
  90  |  async start(seed='v5-economy-0'){
  91  |   await this.page.goto('/');await expect(this.page.locator('.v5-app')).toHaveAttribute('data-rules-version','forge-v5');await this.assertDpr();
  92  |   await expect(this.page.locator('#v4-start')).toBeEnabled();if(!await this.page.locator('.v4-journey-options').evaluate(node=>(node as HTMLDetailsElement).open))await this.activate(this.page.locator('.v4-journey-options summary'));
  93  |   if(this.inputMode==='mouse')await this.page.locator('#v4-seed').fill(seed);else{await keyToV5(this.page,this.page.locator('#v4-seed'));await this.page.keyboard.type(seed,{delay:1});}await expect(this.page.locator('#v4-seed')).toHaveValue(seed);
  94  |   await this.activate(this.page.locator('#v4-start'));const first=await this.record('fresh-real-keyboard-title');
  95  |   const expected=v5Sdk.createRun({runId:first.state.runId,seed,mode:'story',eligibility:{recipes:['light'],challenge:false}});if(!expected.ok)throw Error(expected.error);expect(first.state).toEqual(expected.state);return first.state;
  96  |  }
  97  |  async restoreLegitimate(source:RunState,collection?:CollectionState){
  98  |   const fixture=v5Envelopes(source,collection);
  99  |   // Leave the app and its writer lease before replacing an explicitly labelled recovery fixture.
  100 |   this.navigating=true;try{await this.page.goto('/assets/b/manifest.json');}finally{this.navigating=false;}
  101 |   await this.page.evaluate(raw=>{for(const key of ['sword-led.save.v5','sword-led.save.backup.v5','sword-led.collection.v2','sword-led.collection.backup.v2'])localStorage.removeItem(key);localStorage.setItem('sword-led.save.v5',raw.run);localStorage.setItem('sword-led.collection.v2',raw.collection);},fixture);
  102 |   this.navigating=true;try{await this.page.goto('/');}finally{this.navigating=false;}
  103 |   await this.assertDpr();await expect(this.page.locator('#v4-continue')).toBeEnabled();await this.activate(this.page.locator('#v4-continue'));
  104 |   const restored=await this.record('explicit-legitimate-restored-boundary');expect(restored.state).toEqual(source);await this.leaveIntro();return fixture;
  105 |  }
  106 |  async command(action:Action){
  107 |   await this.leaveIntro();const before=(await this.read()).state,result=v5Sdk.applyCommand(before,{runId:before.runId,expectedRevision:before.revision,action});
  108 |   if(!result.ok)throw Error(`Fixed keyboard command rejected: ${JSON.stringify(action)} / ${result.error}`);
  109 |   if('pieceId'in action&&action.type!=='chooseEvent'&&action.type!=='buy'&&action.pieceId!==before.reserveId)await this.select(action.pieceId);
  110 |   switch(action.type){
  111 |    case'continue':await this.activate(this.page.locator('#v4-stage-actions').getByRole('button',{name:'点火开炉',exact:true}));break;
  112 |    case'strike':await expect(this.page.locator('#v4-strike')).toHaveAttribute('aria-busy','false');if(this.inputMode==='mouse')await this.page.locator('#v4-hit').click();else{await keyToV5(this.page,this.page.locator('#v4-strike'));await this.page.keyboard.press('Space');}await expect(this.page.locator('#v4-strike')).toHaveAttribute('aria-busy','false');break;
  113 |    case'deliver':{const item=v5Sdk.getRunView(before).blades.find(item=>item.blade.id===action.pieceId)!;await expect(this.page.locator('#v4-deliver')).toContainText(item.quote.amount.toLocaleString('zh-CN'));await this.activate(this.page.locator('#v4-deliver'));break;}
  114 |    case'reserve':await this.activate(this.page.locator(before.reserveId===action.pieceId?'#v4-reserve-slot button':'#v4-reserve'));if(before.reserveId&&before.reserveId!==action.pieceId||before.day===12&&before.reserveId!==action.pieceId)await this.confirm();break;
  115 |    case'scrap':await this.activate(this.page.locator('#v4-scrap'));await this.confirm();break;
  116 |    case'settle':await this.activate(this.page.locator('#v4-settle'));await this.confirm();break;
  117 |    case'advance':await this.activate(this.page.locator('#v4-stage-actions').getByRole('button',{name:'沿灯路，去下一天',exact:true}));break;
  118 |    case'chooseModification':await this.activate(this.page.locator('#v4-stage-copy').getByRole('button',{name:'装上'+v5Sdk.MODIFICATIONS[action.modification].name,exact:true}));break;
  119 |    case'claimGift':await this.activate(this.page.locator('#v4-gift button'));if(action.traitId){await this.activate(this.page.getByRole('button',{name:'学会'+v5Sdk.TRAITS[action.traitId].name,exact:true}));if(action.replaceId){await this.activate(this.page.getByRole('button',{name:'换下'+v5Sdk.TRAITS[action.replaceId].name,exact:true}));await this.confirm();}}else await this.confirm();break;
  120 |    case'upgrade':case'repair':await this.activate(this.page.locator('#v4-shop'));await this.activate(this.page.locator(`[data-stall-good="${action.type}"]`));await this.activate(this.page.locator('.v5-stall-purchase'));await this.confirm();break;
  121 |    case'buy':await this.activate(this.page.locator('#v4-shop'));await this.activate(this.page.locator(`[data-stall-trait="${action.traitId}"]`));await this.activate(this.page.locator(`[data-stall-piece="${action.pieceId}"]`));await this.activate(this.page.locator('.v5-stall-purchase'));if(action.replaceId)await this.activate(this.page.getByRole('button',{name:'换下'+v5Sdk.TRAITS[action.replaceId].name,exact:true}));await this.confirm();break;
  122 |    case'chooseEvent':await this.activate(this.page.locator('#v4-event-open'));if(action.choice==='decline')await this.activate(this.page.getByRole('button',{name:'拒绝，保留眼前资源',exact:true}));else{await this.activate(action.pieceId?this.page.locator(`[data-event-piece="${action.pieceId}"] button`):this.page.locator('#v4-dialog-body').getByRole('button',{name:/^接受/}));await this.confirm();}break;
  123 |    case'setRecipe':await this.activate(this.page.locator(`#v4-recipes button[data-recipe="${action.recipe}"]`));break;
  124 |   }
  125 |   await expect.poll(async()=>(await this.read()).state.revision).toBe(result.state.revision);
  126 |   const actual=await this.record(`accepted-${this.accepted.length+1}-${action.type}`);expect(actual.state).toEqual(result.state);
  127 |   if(action.type==='deliver'){
  128 |    const quote=v5Sdk.deliveryQuote(before,before.blades.find(blade=>blade.id===action.pieceId)!);
  129 |    if(quote.matched){const amount=quote.amount.toLocaleString('zh-CN'),fee=quote.baseFeeDelta.toLocaleString('zh-CN'),bonus=quote.qualityBonus.toLocaleString('zh-CN');
  130 |     if(result.events.some(event=>event.type==='MainCompleted'))await expect(this.page.locator('#v5-inline-payment')).toHaveText(`实收 ${amount} 铜钱 · 酬劳${fee}＋品质加赏${bonus}`);
> 131 |     else await expect(this.page.locator('#v4-notice-copy')).toContainText(`这柄实收${amount}铜钱（酬劳${fee}＋品质${bonus}）`);
      |                                                             ^ Error: expect(locator).toContainText(expected) failed
  132 |    }
  133 |   }
  134 |   this.accepted.push({action,runId:before.runId,mode:before.mode,day:before.day,revision:actual.state.revision,coinsBefore:before.coins,coinsAfter:actual.state.coins,events:result.events});
  135 |   await writeFile(this.info.outputPath('v5-commands.json'),JSON.stringify(this.accepted,null,2));return actual.state;
  136 |  }
  137 |  async shop(day:number){
  138 |   await this.same(`day${day} keyboard shop preview`,async()=>{
  139 |    await this.activate(this.page.locator('#v4-shop'));await expect(this.page.locator('.v5-market-stall')).toBeVisible();
  140 |    await this.activate(this.page.locator('[data-stall-good="upgrade"]'));await this.capture(`day-${day}-keyboard-merchant`);
  141 |    await this.activate(this.page.locator('#v4-dialog-actions').getByRole('button',{name:'回铁砧',exact:true}));
  142 |   });
  143 |  }
  144 |  async capture(label:string){
  145 |   await mkdir(this.info.outputPath(),{recursive:true});const before=(await this.read()).state;
  146 |   for(const viewport of[{width:1280,height:720},{width:1920,height:1080}]){await this.page.setViewportSize(viewport);await this.assertDpr();await this.page.screenshot({path:this.info.outputPath(`${label}-${viewport.width}.png`)});const metrics=await this.metrics();expect(await this.page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);if(metrics.canvas?.visible){const ratio=Math.min(2,this.expectedDpr);expect(Math.abs((metrics.canvas.backingRatioX??0)-ratio)).toBeLessThan(.03);expect(Math.abs((metrics.canvas.backingRatioY??0)-ratio)).toBeLessThan(.03);}this.frames.push({label,metrics});await writeFile(this.info.outputPath('v5-keyboard-frames.json'),JSON.stringify(this.frames,null,2));}
  147 |   await this.page.setViewportSize(this.info.project.use.viewport??{width:1280,height:720});await this.assertDpr();expect((await this.read()).state).toEqual(before);
  148 |  }
  149 |  async finish(extra:Record<string,unknown>={}){await this.page.waitForLoadState('networkidle');expect(this.pageErrors).toEqual([]);if(this.inputMode==='keyboard'){expect(this.pointerEvents).toEqual([]);expect(this.keyboardClicks).toBeGreaterThan(0);}else expect(this.pointerEvents.length).toBeGreaterThan(0);expect(this.resources.filter(item=>!item.expectedNavigationCancellation)).toEqual([]);await this.assertDpr();const metrics=await this.metrics();await writeFile(this.info.outputPath('v5-keyboard-result.json'),JSON.stringify({ok:true,inputMode:this.inputMode,project:this.info.project.name,actualDpr:metrics.dpr,accepted:this.accepted.length,observations:this.observations.length,pointerEvents:this.pointerEvents,keyboardActivatedClicks:this.keyboardClicks,errors:this.pageErrors,unexpectedResourceErrors:this.resources.filter(item=>!item.expectedNavigationCancellation),navigationCancellations:this.resources.filter(item=>item.expectedNavigationCancellation),scope:'Actual browser UI commands with frozen formal SDK/raw equality. Tests separately label fresh full journeys and legitimate restored boundaries; driver reload/viewport/fixture setup are explicit.',...extra},null,2));}
  150 | }
  151 | 
  152 | /** Replay/codec-validated fixture for declared recovery boundaries, never a claimed fresh UI journey. */
  153 | export function v5Envelopes(source:RunState,collection?:CollectionState){
  154 |  const checked=v5Sdk.validateRun(source);if(!checked.ok)throw Error(checked.detail);
  155 |  const awards=v5Sdk.collectionFromRun(source);if(!awards.ok)throw Error(awards.detail);
  156 |  const book=collection??awards.state,valid=v5Sdk.validateCollection(book);if(!valid.ok)throw Error(valid.detail);
  157 |  const values=new Map<string,string>(),storage={getItem:(key:string)=>values.get(key)??null,setItem:(key:string,value:string)=>{values.set(key,value);},removeItem:(key:string)=>{values.delete(key);}};
  158 |  const now=()=> '2026-10-21T00:00:00.000Z';
  159 |  const run=v5Sdk.createV5SaveRepository(()=>storage,now),profile=v5Sdk.createCollectionRepository(()=>storage,now);run.load();profile.load();
  160 |  if(!run.write(checked.state).ok||!profile.write(book).ok)throw Error('Legitimate fixture codec failed');
  161 |  return{run:values.get('sword-led.save.v5')!,collection:values.get('sword-led.collection.v2')!};
  162 | }
  163 | 
```