# T03 当前性能末项状态：FF DPR2 pressure-long 1920

只读诊断。没有修改产品/测试/config/dist/harness，没有执行 Node、SDK、浏览器、构建或 PNG 解码；只解析既存文本/JSON并计算输入文件 SHA。以下是 `non-audio-current-02` 的实际结果，不把旧预检或后续可能复验混作本批通过。

## 实际终态和唯一红项

`process.json`：headed、`V5_T03_BRING_TO_FRONT=1`、retries0；2026-10-22T18:53:13.757835Z 开始，19:25:27.493639Z 终态 actualExitCode=1。`report.json` 为125通过、1失败、0跳过、0flaky，唯一失败是 `firefox-dpr2 / v5 native callback and trusted handlers pressure-long at1920`；该逻辑实际执行30.201秒，只有 `performance.spec.ts:89` 的 `max≥50ms requires investigation` 断言红：81要求<50。全局report.errors为空，非runner teardown错误。

结束指纹实际0，`matches:true, changed:[]`，consumerActualExitCode=1与process一致。冻结清单实际 417 源/输入、82运行文件；本报告不把125通过重写为126通过，也不据此勾选T03完成。

## 三条路径原门逐项

同一合法恢复边界每路径重新恢复：runId=`g4-t03-legal-boundary`、journal/revision1890、原文72579字节；每路径6次可信真实输入、6条Accepted、6个contact，revision1890→1896。它是三份独立恢复样本，不是18条连续journal或新完整经营局。实读1920×1080、DPR2、Firefox157.0；Node运行环境darwin/x64，页面UA中的Windows字段不作物理平台或GPU证明。

所有值单位ms。callback列为样本数 / p95 / max；direct和root列为p95 / max。

| 路径 | 加载observed upper / 页内MO | callback n/p95/max | direct handler | root capture | input→提交观察 max | 首contact max | 状态 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| pointer | 693 / 611 | 122 / 11 / 81 | 59 / 59 | 1 / 1 | 25 | 121 | 81ms最大回调待调查 |
| space | 668 / 610 | 127 / 8 / 13 | 49 / 49 | 1 / 1 | 8 | 114 | 本路径原门通过 |
| enter | 680 / 617 | 131 / 8 / 15 | 39 / 39 | 1 / 1 | 8 | 173 | 本路径原门通过 |

原门保持：callback n≥60、p95<16.7，max≥50须调查（当前消费者保留该红）；长档direct/root p95<100、max<200；可信input→提交观察≤150、普通首contact≤200；加载upper及页内首次可见可用Continue投影≤3000。三路径全部有足量回调；没有用合并路径稀释81。

完整响应序列：pointer提交观察 `[6,9,7,10,13,25]`、contact `[96,104,110,108,109,121]`；Space提交观察 `[2,5,5,3,8,4]`、contact `[82,102,85,88,114,95]`；Enter提交观察 `[2,4,4,4,5,8]`、contact `[90,109,93,82,173,101]`。这里的Accepted时间来自真实主档setItem成功后探针解析revision的可观察时刻，包含探针开销，不能称内核Accepted精确时间。

真实Continue click capture→bubble冷成本另记pointer135、Space20、Enter19；它们在加载到Continue可用之后，未被并入或抹掉六次direct handler样本。不能把“测量输入handler过门”写成所有JS调用都小于50ms。

每路径idle先800ms再500ms：两次均pending0/runningAnimations0，应用RAF增量0。三个ledger均完成verifiedCount7、每个row.verified=true、failures=[]；这是既有生产者在idle后完成的正式SDK校验记录（共21份capture），本次只读没有重跑SDK，也不代替全体原文独立回放。

## 81ms精确位置和前后台证据

唯一≥50ms行在 **pointer** 路径frame零基索引79（第80个记录）；该路径其余最大值16。原始字段：

```json
{"requestedAt":2966,"stamp":2989.94,"at":2998,"cost":81,
 "requestedVisibility":{"visibilityState":"visible","hidden":false,"hasFocus":true},
 "deliveredVisibility":{"visibilityState":"visible","hidden":false,"hasFocus":true}}
```

这条记录包围实际应用RAF callback的wall time为2998→3079ms。request→callback开始为32ms；81不是两个RAF之间的间隔，也不是request等待81ms。前一行开始2965、cost1；下一行开始3445，属于下一次输入后，不能把这段空闲间隔算成长回调。

它位于第4次pointer输入的尾端：input2699、主档提交观察2709、首contact2807、idle3080。81开始时首contact已经发生191ms，随后callback返回约1ms记录idle。该次input→提交10、首contact108，本锤两个响应门均过；busy381是保留的整段反馈时长，没有为其新造或放宽预算。

pointer `bringToFront` 是测量前一次显式自有页面操作：before963、after969，两次都是visible/hiddenfalse/focustrue，measurement-reset1000。81附近最后一组记录是2705 blur/focus，但记录时document.hasFocus仍true；2998→3079没有新的blur/hidden/visibilitychange记录。窗口捕获的元素焦点转移也可产生blur/focus，不能仅凭事件名当作页面进入后台。

三路径380条RAF的request/delivery快照全部visible、hiddenfalse、hasFocus=true；所有生命周期快照亦同，没有visibilitychange。证据范围内没有页面后台/失焦状态支持“后台节流导致81”的归因。此结论只覆盖页面API与已注册事件，不能据此证明操作系统没有抢占、浏览器没有GC、物理显示器持续前台刷新或GPU没有停顿。

## 能证与不能证

能证：这是当前冻结产品、真实headed Firefox DPR2、合法长档、native RAF中的一次81ms应用callback wall-time异常；触发了执行前保留的调查门。不是n不足、加载超3秒、handler超门、首contact超200、原文oracle混进计时，或已观察到的hidden/hasFocus=false样本。Space/Enter的对应最大回调13/15并不能抵消pointer的81。

不能证：现有frame没有callback名称/调用栈/内部阶段，handler记录没有绝对开始时间，Firefox样本longTasks=null（不可用，非“零长任务”）。因此不能从这份JSON把81分配给Canvas绘制、结束render、GC、系统抢占、声音设备或其他具体子函数，也不能称81为纯CPU自耗或GPU/compositor耗时。

静态代码在 `presentation-v4/forge.ts:165–173` 的watch尾端会render并调用done，而 `presentation-v5/app.ts:117` 的done回调会清busy并render。这与“81紧贴idle”的区段相符，只是优先检查候选路径；原始数据没有回调身份，不能将此候选写成已确认根因或直接改产品。

## 最小下一步

只针对已有 `firefox-dpr2 / pressure-long at1920` 这一逻辑做一次预声明的定向诊断，不重跑全矩阵、不新增seed/领域fixture，不改50/16.7/100/200/150/3000等原门。继续保留三个原输入路径和首次Continue/首次输入；不预热、不mute、不延长动画或加入补偿等待。执行由root另行安排，本报告没有运行它。

若要增加观察，仅在发布测试RAF探针中记录实际callback的名称/身份及返回时刻，并关联其进入/离开时既有hammer phase、aria-busy；不替换callback、不新增RAF、也不对结束render先做缓存/跳过修补。它用于区分watch收尾与其他回调；匿名回调和内部GC/抢占仍须明确unknown，不能靠标签猜原因。实际复验若过门，只能证明该次样本通过；本次81与125/1原始终态必须保留，不能用后来一次绿把未定位根因写成已修复。若再次越门，则按该有据回调路径做更窄的成本定位后再决定产品修复。

当前结论是“长档加载、三路径handler/响应门已有本批依据；pointer单次81ms RAF尾端异常已定位时段，具体原因未定”，不是“性能全绿”或“T03已完成”。其他责任本报告不扩展。

## 只读输入SHA

- `tmp/goal4-T03/runs/non-audio-current-02/process.json` — SHA256 `50dae6a5f8400ee8ac6d0b231a5dab5636f530776b87ab3bd71bb43ca9855952`
- `tmp/goal4-T03/runs/non-audio-current-02/report.json` — SHA256 `02af03424d9e37b5aeaa37b96ef22f131d400e50517fdd118a61168d8c5623ea`
- `tmp/goal4-T03/runs/non-audio-current-02/end-fingerprint.json` — SHA256 `cd2a97ff45ea2bd2a3aad3402f731e7af87491b24392015e9e3e426ef906a239`
- `tmp/goal4-T03/non-audio-current-02-fingerprint.json` — SHA256 `230f82a97ddbbfa9e87387a0e7d616204531593f7bfd9c614e14798f07d7de0e`
- `tmp/goal4-T03/runs/non-audio-current-02/artifacts/performance-v5-native-call-ec96e-ndlers-pressure-long-at1920-firefox-dpr2/native-pressure-long-1920-pointer.json` — SHA256 `2e2f66506dc9bfa675306949040977d75192abf61f597c58c8c934760aa566d2`
- `tmp/goal4-T03/runs/non-audio-current-02/artifacts/performance-v5-native-call-ec96e-ndlers-pressure-long-at1920-firefox-dpr2/native-pressure-long-1920-pointer-foreground.json` — SHA256 `0cea2d6ca42ec762cdc44f204922119e76c98b8bcf11b5fa3471013dd445765d`
- `tmp/goal4-T03/runs/non-audio-current-02/artifacts/performance-v5-native-call-ec96e-ndlers-pressure-long-at1920-firefox-dpr2/native-pressure-long-1920-pointer-load.json` — SHA256 `8993fdad3ce0d97b8e81c41778ededeb93a6a63292ead6b56da9bde51c3591e9`
- `tmp/goal4-T03/runs/non-audio-current-02/artifacts/performance-v5-native-call-ec96e-ndlers-pressure-long-at1920-firefox-dpr2/accepted-observation-native-pressure-long-1920-pointer.json` — SHA256 `d4a54db8b55351ec46e3e66a8812bc465d6e63f638453b3f7a469f018addb2dc`
- `tmp/goal4-T03/runs/non-audio-current-02/artifacts/performance-v5-native-call-ec96e-ndlers-pressure-long-at1920-firefox-dpr2/native-pressure-long-1920-space.json` — SHA256 `56d7c431aaa17ff5728a11165db818ec87da0803e7aede0ebf1146aab24c173e`
- `tmp/goal4-T03/runs/non-audio-current-02/artifacts/performance-v5-native-call-ec96e-ndlers-pressure-long-at1920-firefox-dpr2/native-pressure-long-1920-space-foreground.json` — SHA256 `41c2290ff9ce5fe16887950a13a27ed076aeadf34cbccacbe0a03da712d92681`
- `tmp/goal4-T03/runs/non-audio-current-02/artifacts/performance-v5-native-call-ec96e-ndlers-pressure-long-at1920-firefox-dpr2/native-pressure-long-1920-space-load.json` — SHA256 `f819e317d1fc8608d8fd004ef7285a8b36c00107b6e6463ee92529e6141442eb`
- `tmp/goal4-T03/runs/non-audio-current-02/artifacts/performance-v5-native-call-ec96e-ndlers-pressure-long-at1920-firefox-dpr2/accepted-observation-native-pressure-long-1920-space.json` — SHA256 `ba32653942a2b2263c5928f3f59dbae8aac9ebb2534b80c4b4e4cf43b78c6016`
- `tmp/goal4-T03/runs/non-audio-current-02/artifacts/performance-v5-native-call-ec96e-ndlers-pressure-long-at1920-firefox-dpr2/native-pressure-long-1920-enter.json` — SHA256 `42697f70fe2c83cde9eb2bd1373d900efded5fe4d2c1d70ec280a0c123d85f5b`
- `tmp/goal4-T03/runs/non-audio-current-02/artifacts/performance-v5-native-call-ec96e-ndlers-pressure-long-at1920-firefox-dpr2/native-pressure-long-1920-enter-foreground.json` — SHA256 `113a87afa0bf85468f1f64bb55d4e6e5a47dcef465709ac89c303d3bbb6a1544`
- `tmp/goal4-T03/runs/non-audio-current-02/artifacts/performance-v5-native-call-ec96e-ndlers-pressure-long-at1920-firefox-dpr2/native-pressure-long-1920-enter-load.json` — SHA256 `f466867c621c6de4ab3d2d70252464a0f41c43af372ffc9a93b55ce1adc51891`
- `tmp/goal4-T03/runs/non-audio-current-02/artifacts/performance-v5-native-call-ec96e-ndlers-pressure-long-at1920-firefox-dpr2/accepted-observation-native-pressure-long-1920-enter.json` — SHA256 `2cbb8ca32ce569dabd36b25132c7592ffcab64ad01d8674ff63f7af17bb9f3fd`
- `tests/release-v5/performance.spec.ts` — SHA256 `c789e7e4f7381f54255eaad85a769586c41781314b90624a00ae344b23d04c97`
- `tests/release-v5/resilience-probe.ts` — SHA256 `d38b3428124ab1a10681d9133ec284cd09a8241d100072a2dfa5bdbabf4000b5`
- `src/presentation-v4/forge.ts` — SHA256 `91905bd97d60bf57d5bea137836ba7f4a5855e98aa850916d1b09517e76270a2`
- `src/presentation-v5/app.ts` — SHA256 `58da48d6c84b212043b9a3e2dbb63bfd70aceaacf7bad55d64ef002abaa76289`
