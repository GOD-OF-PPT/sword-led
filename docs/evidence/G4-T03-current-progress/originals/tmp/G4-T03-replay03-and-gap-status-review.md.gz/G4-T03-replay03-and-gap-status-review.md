# T03 replay03与带缺口交付状态简报

只读结论：replay03对已选择T03已知raw结构的核心严格性未发现新的阻断性算法错误；2049 exact-error已修正，未执行SDK／Node／browser／build，也未改共享文件。本页不预填回放通过。

## 回放03

- 显式fingerprint绑定9个SDK/shared JS的bytes/SHA，动态import前核对，结束再次核9文件及每个已读输入，包括脚本／原replay／原process/end／JSON或gzip；fresh输出目录recursive:false、写文件wx，不覆盖原件。
- 原run必须terminal，actualexit与end消费者身份相同，fingerprint实际0且matchestrue/changed[]。允许原失败run作为输入，但结果保留actual nonzero，不转成UI/audio/perf pass。
- actual saved observation及capture primary必须正式decode有效并与完整保留state／expected等值。原verifiedCount/false/missing只作为producer事实留存，不再成为独立核验前置条件；原failures仍在原SHA文件中，回放另记录行数及原flags。未完成producer不等于允许无效raw。
- 只有严格原over-hard-limit-negative.json的scope/exportformat/key/schema/rules/revision2049/journal2049/bytecount/timestamp及精确raw哈希可登记负例，validator与codec全错误对象必须为invalid_state／Expected bounded plain JSON with safe integer fields.。其他badstate/raw一律issue且exit1，无generic状态豁免或假valid。

最小必要文字／范围校正：README标题与两段仍写Replay02，catch标签replay-02、result.version2也沿用。建议标题／消费者标签准确写03；若version2是输出schema版本则明确区分schemaVersion和脚本revision，不让归档混身份。根目录resolve已消除此前尾斜杠containment误差，不声称修了已执行的02产品失败；此版是更强观察覆盖。

一个精确覆盖限制应在执行前写明：当前inspect识别key-bearing exportslot和已知save/backup/collection map，**不识别**正式`sword-led.collection-export.v2`中`stored.main/backup={ok,raw}`无key槽。该结构来自v5-persistence.ts:200及v5-storage-helpers.ts:96；若所选实际corpus含它，必须按format定向检查两个真实slot，或遇到此不支持结构明确失败，不能静默忽略后宣称所有导出storedraw均验。本次静态没有重现某个已选择T03档案的此类失败，不把该覆盖限制写成已修复actual red；root可将当前声明严格限定为实际已识别字段并列出这一边界。没有理由扫描任意字符串或放宽未知负例。

## 本轮唯一非声音性能红

non-audio-current02实际125pass/1fail、417/82结束matches。FF DPR2 pressure-long1920只有pointer的max callback81违反原max<50调查门：n122、p9511过；长directp95/max59、root1、inputmax25、ordinarycontactmax121均过。loadupper693／pageMO611过，Space回调n127/p958/max13、Enter n131/p958/max15，其余门过；三个原ledger各7verified/failures[]。

81ms原行requested2966/stamp2989.94/at2998/cost81，真实callback wall区段2998→3079，紧贴第四次input2699→Accepted2709→contact2807→idle3080的尾段。请求／交付都visible、hiddenfalse、hasFocustrue，此段无blur/hidden事件；LongTasks=null是NA。不能归为采样不足、单纯rAF间隔、load或Nodeoracle，也不能从没有函数profile的wall区段断言paint／GC／OS调度各占多少。必须保留原红和未定因边界，不提高50门或把125pass写126pass。

## delivered_with_gaps能否结束T03

**可如实结束本轮交付／报告为delivered_with_gaps；不可把T03完成复选框或原生goal标complete。** 两种含义必须分开。

依据当前plan：第62行要求全部专项actual终态、独立原文／截图声音观测后联合review并修缮再task[x]；第111行不在最终受影响复验／独立回放／像素审核／发布前标完成；第129行明确“全部责任有据前T03不[x]”；第139行允许按用户测试兼容最低优先级停止不稳定声音候选循环，但同时写“声音仍未关闭，T03/goal不冒记完成”。tasks.md的T03亦保持[ ]。这些规则没有授权用delivered_with_gaps改写完成标准。

因此可以提交当前代码／证据／联合审查和进度回执，注明可玩产品已发布、剩余WebKit声音品质与81ms性能调查等精确缺口，保留各自run与原阈值，T03仍未完成／后续同任务续办，goal保持active；不需要暂停或重复H确认。不应把必需T03责任悄悄移成“仅T04文档尾项”，也不因优先级低就删矩阵／豁免原红。若“结束T03”指真正勾[x]并转任务，当前计划与仍开缺口不支持；仅更换状态词不能成立。
