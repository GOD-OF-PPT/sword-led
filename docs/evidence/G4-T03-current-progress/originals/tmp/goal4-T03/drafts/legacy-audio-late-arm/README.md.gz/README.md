# Existing v2 delayed-resume case: late fault arm — UNEXECUTED

Prepared only under this isolated tmp directory while root's `non-audio-current02` source417/runtime82 consumer batch was frozen. No active source, consumer, configuration, runtime, harness, docs or earlier draft was changed. No Node/SDK import/replay, compiler, discovery, browser, build or image decode was executed. Python was used solely for text copies, a unified diff, hashes and static byte comparisons.

This candidate targets the current published/build16-equivalent audio implementation. It does **not** activate the older `legacy-audio-compat` retirement draft, close an old context, restore a retired product experiment, change the expected zero to three, or reinterpret a previous actual failure as passing. The previous compatibility draft and its known static indexed-access issue remain intact as unexecuted history.

## Why the fault moves

Root's completed `legacy-current02` identified the three v2 delayed failures at the first `starts === 0` assertion, before pause/release. The old page-wide `defer:true` holds the opening resume, while legitimate starter/request/mode/node actions can establish a newer activation. The existing product correctly refuses to let an obsolete pending owner block a new activation. Thus that old injection no longer establishes a held resume belonging to the tested Space-down.

The existing delayed case now uses normal `installAudioProbe/openV2/startV2` and the exact mode/node preparation from `strikeV2`. It observes the one running native context with zero starts/active sources, then calls the new test-only `armDeferResume()` control. This performs a real native suspend on that captured context and awaits its actual Promise. Only after success, same-context identity and exact suspended state does it arm the next resume on that context.

## One-shot transport control

The probe's explicit arm accepts only a previously unused late arm without any existing held/release fault; it refuses combination with `defer` or `rejectResume`. The context array lookup is explicitly checked for undefined and closed state. No counter, source list, waveform, saved run or game result is cleared or replaced.

In `resume()`, the persistent rejection branch remains first and unchanged. The late arm matches only `this === armedContext`, consumes that arm immediately, and creates one held Promise with an identity-bound release ticket. Other contexts are not intercepted. Explicit release verifies that exact ticket/context, clears only its own ticket and exported release reference, then calls the real native resume and forwards its resolution/rejection. A repeat or superseded release fails instead of issuing another native resume.

The original constructor injection, original page-wide first-defer branch and continuous rejection branch are byte-identical to the current source. The two other existing v2 cases are byte-identical. The case count remains three; no case, seed, matrix or product hook is added.

## Existing responsibility preserved

1. Normal UI setup and mode/node preparation finish before the late arm. No further preparation clicks occur after it.
2. Actual Space-down must consume the arm (`held`, release present, native suspended, starts zero). The original standard-quarter-period advance remains 350ms (current 1400ms / 4), then real Space-up creates the actual saved first strike, formally read by the existing helper; starts still must be zero.
3. The real pause click precedes explicit release of the target Promise. The original exact native state `[suspended]` and zero global starts remain; active sources must also be zero. No old cue may be replayed.
4. The existing new-contract UI path and fresh Space-down/up remain. Before fresh keyup the starts must still be zero; afterward a different runId with one genuine strike and exactly three native starts is required. The same single context must now be `[running]`, with the late arm released, not active.

There is no generic allowed-state set, retry click, added arbitrary sleep, waveform relaxation, domain dispatch/economic mutation, threshold change, forged acceptance or retirement logic. Additional probe snapshots are attached to the existing JSON evidence only. These changes locate the existing injected fault at the target gesture; they do not remove the old-cue/fresh-cue responsibility.

## Static TypeScript review and source binding

The candidate uses explicit `Promise<void>` return types for arm/release and the held Promise. The sole array lookup (`contexts[length - 1]`) has an explicit undefined/closed guard, including a post-await context/state check. Optional release is read into a local and checked before invocation. Ticket narrowing uses short-circuit ownership checks; no indexed increment, non-null assertion, cast, `any` or default value masks an unknown context. This is a source-level review, **not** a compiler pass.

`originals/` preserves both complete input files. `candidate/` contains the complete proposed files. `manifest.json` binds their byte counts/SHA256 and the unified patch. The original first-defer block, constructor fault line, other two case sections and active original hashes were statically compared and retained. Root owns final review, activation after the live batch terminates, type checking, fingerprints and actual legacy execution.

From the repository root, after confirming both original hashes still match:

```sh
rtk proxy git apply --check tmp/goal4-T03/drafts/legacy-audio-late-arm/legacy-audio-late-arm.UNEXECUTED.patch
rtk proxy git apply tmp/goal4-T03/drafts/legacy-audio-late-arm/legacy-audio-late-arm.UNEXECUTED.patch
```

Neither command has been executed. If either current input hash changed, stop and rebase the candidate. Earlier actual failures and all original bytes remain preserved. An actual later result will need its own process, artifact and end-fingerprint identity; this draft alone proves no runtime outcome.

[Adversarial review] The expected old start count remains zero both before pause and after release, and the fresh actual strike must still generate exactly three starts. The late fault is one-shot and context-bound, while persistent resume denial is untouched. No responsibility was deleted; runtime/type correctness remains subject to root's separate checks.
