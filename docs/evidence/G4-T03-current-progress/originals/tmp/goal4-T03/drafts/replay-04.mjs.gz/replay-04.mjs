// UNEXECUTED isolated draft04: result schema2 / consumer revision3. Execution performs formal replay.
import {readFile,readdir,mkdir,writeFile,lstat} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve,join,relative,sep,basename} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {gunzipSync} from 'node:zlib';
import assert from 'node:assert/strict';

const repository=resolve(fileURLToPath(new URL('../../../',import.meta.url))),args=process.argv.slice(2),options={},selected=[];
for(let index=0;index<args.length;index++){const token=args[index];if(token.startsWith('--')){assert(['--sdk-root','--sdk-fingerprint','--out'].includes(token),'Unknown option '+token);assert(args[index+1]&&!args[index+1].startsWith('--'),'Missing value for '+token);assert(!options[token],'Duplicate option '+token);options[token]=args[++index];}else{assert(/^[a-z0-9-]+$/.test(token),'Use explicit terminal run labels');assert(!selected.includes(token),'Duplicate run label');selected.push(token);}}
assert(selected.length,'Choose explicit terminal run labels');assert(options['--out']&&options['--sdk-fingerprint'],'Require fresh --out directory and explicit --sdk-fingerprint');
const intendedRuns=['non-audio-current-02','audio-headed-matrix-02','native-04'];assert.deepEqual([...selected].sort(),[...intendedRuns].sort(),'This finite replay is bound to exactly the three declared terminal runs');
const base=resolve(repository,'tmp/goal4-T03'),sdkRoot=resolve(repository,options['--sdk-root']??'dist'),output=resolve(repository,options['--out']);assert(output.startsWith(join(repository,'tmp')+sep),'Output must be isolated beneath tmp');assert.notEqual(output,base);assert(!selected.some(label=>output.startsWith(join(base,'runs',label)+sep)),'Output cannot be inside a selected original run');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex'),name=path=>relative(repository,path).split(sep).join('/');
const stable=value=>Array.isArray(value)?value.map(stable):value&&typeof value==='object'?Object.fromEntries(Object.keys(value).sort().map(key=>[key,stable(value[key])])):value,canonical=value=>JSON.stringify(stable(value));
const inputs=new Map(),files=[],receipts=[],errors=[],negativeDeclarations=new Map(),stateCache=new Map(),collectionCache=new Map(),runRawCache=new Map(),bookRawCache=new Map(),ledgerEvidence=[],collectionExportEvidence=[];
const counts={stateObjects:0,legalStateObjects:0,declaredNegativeStateObjects:0,collectionObjects:0,actualSavedObservations:0,actualSavedRawMatches:0,actualCollectionRawMatches:0,captureLedgers:0,captures:0,producerVerifiedTrue:0,producerVerifiedFalse:0,producerVerifiedMissing:0,independentlyValidatedCaptures:0,captureStateMatches:0,captureExpectedMatches:0,failedLedgerRowsRetained:0,collectionExportObjects:0,collectionExportStoredSlots:0,collectionExportUnreadableSlots:0};
const rawCounts={definition:'Each present known current-v5 run/book raw field occurrence in every selected original JSON, including null and repeated metadata copies. This is not a distinct-state or UI-run count. Codec caches count distinct non-null raw bytes separately.',run:{occurrences:0,empty:0,valid:0,declaredNegative:0,unexpectedInvalid:0},collection:{occurrences:0,empty:0,valid:0,unexpectedInvalid:0}};
let sdk,sdkManifestBefore,startedAt=new Date().toISOString();
function issue(path,message,details){errors.push({path,message,...(details===undefined?{}:{details})});}
function requireEqual(actual,expected,path,message){if(canonical(actual)!==canonical(expected)){issue(path,message,{actual,expected});return false;}return true;}
async function input(path){const absolute=resolve(repository,path);assert(absolute===repository||absolute.startsWith(repository+sep),'Input outside repository');const bytes=await readFile(absolute),entry={path:name(absolute),bytes:bytes.length,sha256:sha(bytes)};if(inputs.has(absolute))assert.deepEqual(entry,inputs.get(absolute),'Input changed during reads: '+entry.path);else inputs.set(absolute,entry);return bytes;}
async function data(path){const bytes=await input(path);return JSON.parse((path.endsWith('.gz')?gunzipSync(bytes):bytes).toString('utf8'));}
async function moduleManifest(){const names=(await readdir(sdkRoot)).filter(file=>file.endsWith('.js')).sort();assert.equal(names.length,9,'Exactly nine frozen root SDK/shared JS modules required');return Promise.all(names.map(async file=>{const bytes=await input(join(sdkRoot,file));return{name:file,path:name(join(sdkRoot,file)),bytes:bytes.length,sha256:sha(bytes)};}));}
async function artifacts(directory){const found=[];for(const entry of await readdir(directory,{withFileTypes:true})){const path=join(directory,entry.name);assert(!entry.isSymbolicLink(),'Original evidence symlink is not accepted');if(entry.isDirectory()&&entry.name!=='attachments')found.push(...await artifacts(path));else if(entry.isFile()&&/\.json(?:\.gz)?$/.test(entry.name)&&!['report.json','process.json','end-fingerprint.json'].includes(entry.name))found.push(path);}return found.sort();}
function decodeRun(raw){if(!runRawCache.has(raw))runRawCache.set(raw,sdk.decodeV5Save(raw));return runRawCache.get(raw);}
function decodeBook(raw){if(!bookRawCache.has(raw))bookRawCache.set(raw,sdk.decodeCollection(raw));return bookRawCache.get(raw);}
const expected2049Validator={ok:false,error:'invalid_state',detail:'Expected bounded plain JSON with safe integer fields.'},expected2049Codec={status:'invalid',error:'invalid_state',detail:'Expected bounded plain JSON with safe integer fields.'};
const negativeScope='Deliberately invalid2049journal negative raw, never called a valid pressure boundary. UI cannot continue/export it as a legal run; raw export and cancelled replacement preserve bytes.';
function isState(value){return value&&typeof value==='object'&&value.rulesVersion==='forge-v5'&&Array.isArray(value.journal);}
function checkState(value,path,{declaredFile=null}={}){
 counts.stateObjects++;const key=canonical(value),declaration=declaredFile&&negativeDeclarations.get(declaredFile);
 if(declaration&&declaration.stateCanonical===key){counts.declaredNegativeStateObjects++;requireEqual(sdk.validateRun(value),expected2049Validator,path,'Explicit2049 validator/error changed');return;}
 if(!stateCache.has(key))stateCache.set(key,sdk.validateRun(value));const checked=stateCache.get(key);if(!checked.ok){issue(path,'Unexpected state failed complete formal replay; no generic negative exemption applies',{actual:checked,stateSHA256:sha(key),journal:value.journal.length,revision:value.revision});return;}counts.legalStateObjects++;requireEqual(checked.state,value,path,'Formal replay differs from retained state');
}
function isBook(value){return value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).sort().join(',')==='challenge,chapters,mastery,traits,works';}
function checkBook(value,path){counts.collectionObjects++;const key=canonical(value);if(!collectionCache.has(key))collectionCache.set(key,sdk.validateCollection(value));const checked=collectionCache.get(key);if(!checked.ok)issue(path,'Retained collection failed full validator',checked);else requireEqual(checked.state,value,path,'Collection validator result differs');}
function checkRawRun(raw,path,{count=true}={}){
 if(count)rawCounts.run.occurrences++;if(raw===null){if(count)rawCounts.run.empty++;return{status:'empty'};}if(typeof raw!=='string'){issue(path,'Known raw run field is neither string nor null');return{status:'invalid-type'};}
 const decoded=decodeRun(raw),declarations=[...negativeDeclarations.values()].filter(item=>item.rawSHA256===sha(raw));
 if(declarations.length){if(count)rawCounts.run.declaredNegative++;requireEqual(decoded,expected2049Codec,path,'Declared2049 raw must retain the exact invalid-state codec error');return decoded;}
 if(decoded.status==='valid'){if(count)rawCounts.run.valid++;return decoded;}if(count)rawCounts.run.unexpectedInvalid++;issue(path,'Unexpected invalid raw run, not an explicitly declared negative',{actual:decoded,rawSHA256:sha(raw),bytes:Buffer.byteLength(raw)});return decoded;
}
function checkRawBook(raw,path,{count=true}={}){if(count)rawCounts.collection.occurrences++;if(raw===null){if(count)rawCounts.collection.empty++;return{status:'empty'};}if(typeof raw!=='string'){issue(path,'Known raw book field is neither string nor null');return{status:'invalid-type'};}const decoded=decodeBook(raw);if(decoded.status==='valid'){if(count)rawCounts.collection.valid++;return decoded;}if(count)rawCounts.collection.unexpectedInvalid++;issue(path,'Unexpected invalid raw collection',{actual:decoded,rawSHA256:sha(raw)});return decoded;}
// A real collection export has a valid in-memory book and independent physical slots.
// An explicit {ok:false} is a retained read failure, not an empty or validated raw slot.
function collectionExport(value,path){
 counts.collectionExportObjects++;
 const record=item=>item!==null&&typeof item==='object'&&!Array.isArray(item);
 assert(record(value),path+' collection export must be an object');
 assert.deepEqual(Object.keys(value).sort(),['collection','format','stored'],path+' collection export fields');
 assert.equal(value.format,'sword-led.collection-export.v2',path+' exact collection export format');
 assert(isBook(value.collection),path+' collection export lacks its complete in-memory collection');
 checkBook(value.collection,path+'.collection');
 assert(record(value.stored),path+' collection export stored slots missing');
 assert.deepEqual(Object.keys(value.stored).sort(),['backup','main'],path+' collection export must retain both physical slots');
 const evidence={path,format:value.format,slots:[]};collectionExportEvidence.push(evidence);
 for(const key of ['main','backup']){
  const slot=value.stored[key],slotPath=path+'.stored.'+key;
  assert(record(slot),slotPath+' must be an explicit slot object');assert.equal(typeof slot.ok,'boolean',slotPath+' missing read outcome');
  counts.collectionExportStoredSlots++;
  if(slot.ok){
   assert.deepEqual(Object.keys(slot).sort(),['ok','raw'],slotPath+' readable slot must contain exact original raw');
   assert(slot.raw===null||typeof slot.raw==='string',slotPath+' raw must be exact string or null');
   const decoded=checkRawBook(slot.raw,slotPath+'.raw');
   evidence.slots.push({slot:key,ok:true,rawSHA256:typeof slot.raw==='string'?sha(slot.raw):null,codecStatus:decoded.status});
  }else{
   assert.deepEqual(Object.keys(slot).sort(),['ok'],slotPath+' unavailable slot must preserve the explicit read-failure shape');
   counts.collectionExportUnreadableSlots++;evidence.slots.push({slot:key,ok:false,codecStatus:'not-read',scope:'Original read failed; no raw bytes are claimed empty, valid or independently decoded.'});
  }
 }
 // Physical main/backup may lag the in-memory book. Do not invent equality between them.
}
const runKeys=new Set(['save','backup','sword-led.save.v5','sword-led.save.backup.v5']),bookKeys=new Set(['collection','collectionBackup','sword-led.collection.v2','sword-led.collection.backup.v2']);
function inspect(value,path,declaredFile){
 if(!value||typeof value!=='object')return;
 const collectionExportShape=!Array.isArray(value)&&((typeof value.format==='string'&&value.format.startsWith('sword-led.collection-export.'))||(Object.hasOwn(value,'stored')&&Object.hasOwn(value,'collection')));
 if(collectionExportShape){collectionExport(value,path);return;}
 if(isState(value)){checkState(value,path,{declaredFile});return;}if(isBook(value)){checkBook(value,path);return;}
 if(!Array.isArray(value)&&value.ok===true&&typeof value.key==='string'&&Object.hasOwn(value,'raw')){if(runKeys.has(value.key))checkRawRun(value.raw,path+'.raw');else if(bookKeys.has(value.key))checkRawBook(value.raw,path+'.raw');}
 const rawMap=Object.hasOwn(value,'save')||Object.hasOwn(value,'backup')||Object.hasOwn(value,'collectionBackup')||Object.keys(value).some(key=>key.startsWith('sword-led.')&&(runKeys.has(key)||bookKeys.has(key)));
 for(const [key,child]of Object.entries(value)){if(rawMap&&(typeof child==='string'||child===null)&&runKeys.has(key))checkRawRun(child,path+'.'+key);else if(rawMap&&(typeof child==='string'||child===null)&&bookKeys.has(key))checkRawBook(child,path+'.'+key);else inspect(child,path+'.'+key,declaredFile);}
}
function savedObservation(row,path){
 counts.actualSavedObservations++;const decoded=checkRawRun(row.raw?.save,path+'.raw.save',{count:false});if(decoded.status!=='valid')issue(path,'A claimed actual saved observation must be valid even if the UI run failed');else if(requireEqual(decoded.state,row.state,path,'Actual saved raw/state mismatch'))counts.actualSavedRawMatches++;
 const actualBook=checkRawBook(row.raw?.collection??null,path+'.raw.collection',{count:false});if(actualBook.status==='valid'){if(requireEqual(actualBook.state,row.collection,path,'Actual collection raw/state mismatch'))counts.actualCollectionRawMatches++;}else requireEqual(row.collection,null,path,'Missing actual book must have null collection observation');
}
function captureLedger(value,path){
 counts.captureLedgers++;if(!Array.isArray(value.captures)){issue(path,'Capture ledger lacks the original capture array');return;}const producerFlags=value.captures.map(row=>Object.hasOwn(row,'verified')?row.verified:null),evidence={path,producerVerifiedCount:value.verifiedCount??null,producerVerifiedFlags:producerFlags,producerFailureRows:Array.isArray(value.failures)?value.failures.length:null,independent:[]};ledgerEvidence.push(evidence);
 if(Array.isArray(value.failures))counts.failedLedgerRowsRetained+=value.failures.length;
 // Original verifiedCount/flags describe that producer's completion; they are retained, never a precondition for independent replay.
 for(const [index,row]of value.captures.entries()){
  const rowPath=path+'.captures['+index+']';counts.captures++;if(row.verified===true)counts.producerVerifiedTrue++;else if(row.verified===false)counts.producerVerifiedFalse++;else counts.producerVerifiedMissing++;
  const decoded=checkRawRun(row.raw?.save,rowPath+'.raw.save',{count:false});let stateMatch=false,expectedMatch=false;
  if(decoded.status!=='valid')issue(rowPath,'Every actual captured primary must independently decode/replay as valid');else{counts.independentlyValidatedCaptures++;stateMatch=requireEqual(decoded.state,row.state,rowPath,'Captured actual plain state differs from raw replay');expectedMatch=requireEqual(decoded.state,row.expected,rowPath,'Captured raw does not equal the retained expected public result');if(stateMatch)counts.captureStateMatches++;if(expectedMatch)counts.captureExpectedMatches++;if(row.identity)requireEqual(row.identity,{runId:decoded.state.runId,revision:decoded.state.revision},rowPath,'Captured identity differs from actual raw');}
  evidence.independent.push({captureIndex:index,label:row.label??null,producerVerified:Object.hasOwn(row,'verified')?row.verified:null,primaryCodecStatus:decoded.status,stateMatch,expectedMatch,rawSHA256:typeof row.raw?.save==='string'?sha(row.raw.save):null});
 }
}
function outcome(receipt){return{label:receipt.label,actualExitCode:receipt.process.actualExitCode,originalUIOutcome:receipt.process.actualExitCode===0?'terminal-zero':'terminal-nonzero',scope:'Independent replay verifies retained legal/negative bytes only; original UI/audio/performance failure and producer verification flags remain unchanged.'};}

await mkdir(output,{recursive:false});
try{
 await input(fileURLToPath(import.meta.url));await input(join(base,'replay.mjs'));
 const frozen=await data(resolve(repository,options['--sdk-fingerprint']));assert(frozen.buildFiles&&typeof frozen.buildFiles==='object','Frozen fingerprint must bind build files');sdkManifestBefore=await moduleManifest();
 for(const module of sdkManifestBefore){const bound=frozen.buildFiles[module.path];assert(bound,'Frozen fingerprint missing module '+module.path);assert.deepEqual({bytes:module.bytes,sha256:module.sha256},{bytes:bound.bytes,sha256:bound.sha256},'SDK differs from explicit frozen fingerprint '+module.path);}
 for(const label of selected){const processPath=join(base,'runs',label,'process.json'),endPath=join(base,'runs',label,'end-fingerprint.json'),process=await data(processPath),end=await data(endPath);assert.equal(process.status,'terminal',label+' is live');assert(Number.isInteger(process.actualExitCode));assert.equal(end.fingerprintActualExitCode,0,label+' end fingerprint exit');const match=JSON.parse(end.stdout);assert.equal(match.matches,true,label+' end fingerprint mismatch');assert.deepEqual(match.changed,[],label+' inputs changed');assert.equal(end.consumerActualExitCode,process.actualExitCode,label+' actual exit identity');receipts.push({label,process,end,files:await artifacts(join(base,'runs',label))});}
 sdk=await import(pathToFileURL(join(sdkRoot,'sword-led-v5.js')).href);assert.equal(sdk.JOURNAL_LIMIT,2048);assert.equal(sdk.JOURNAL_SOFT_LIMIT,1900);
 // First pass registers only the exact original over-hard-limit export artifact. No arbitrary state/filename exemption.
 for(const receipt of receipts)for(const path of receipt.files)if(basename(path)==='over-hard-limit-negative.json'){
  const value=await data(path);assert.equal(value.scope,negativeScope,name(path)+' explicit negative provenance');assert.equal(value.exported?.format,'sword-led.disk-run-export.v1');const main=value.exported.slots?.main;assert.deepEqual({key:main?.key,ok:main?.ok},{key:'sword-led.save.v5',ok:true});assert.equal(typeof main.raw,'string');assert.equal(Buffer.byteLength(main.raw),value.bytes);const envelope=JSON.parse(main.raw);assert.equal(envelope.schemaVersion,5);assert.equal(envelope.rulesVersion,'forge-v5');assert.equal(envelope.state?.rulesVersion,'forge-v5');assert.equal(envelope.state.revision,2049);assert.equal(envelope.state.journal?.length,2049);assert.equal(new Date(envelope.savedAt).toISOString(),envelope.savedAt);assert.deepEqual(sdk.validateRun(envelope.state),expected2049Validator,name(path)+' exact expected validator rejection');assert.deepEqual(decodeRun(main.raw),expected2049Codec,name(path)+' exact expected codec rejection');negativeDeclarations.set(path,{source:name(path),scope:value.scope,rawSHA256:sha(main.raw),stateSHA256:sha(canonical(envelope.state)),stateCanonical:canonical(envelope.state),validatorExpected:expected2049Validator,codecExpected:expected2049Codec});
 }
 for(const receipt of receipts)for(const path of receipt.files){const beforeIssues=errors.length,value=await data(path),fileName=basename(path).replace(/\.gz$/,''),declaredFile=negativeDeclarations.has(path)?path:null;let kind='retained domain/metadata';
  try{
   if(fileName.endsWith('-actual-book.json')){collectionExport(value,name(path));kind='actual collection export with exact physical main/backup read outcomes';}
   else inspect(value,name(path),declaredFile);
   if(fileName==='v5-states.json'){kind='actual saved observations';if(!Array.isArray(value))issue(name(path),'Actual observations file is not an array');else for(const [index,row]of value.entries())savedObservation(row,name(path)+'['+index+']');}
   else if(fileName.startsWith('accepted-observation-')){kind='actual capture ledger independently verified regardless of original completion flags';captureLedger(value,name(path));}
   else if(fileName==='over-hard-limit-negative.json')kind='exact declared2049 negative export with expected validator/codec rejection';
  }catch(error){issue(name(path),'File semantic inspection raised an error',{message:String(error),stack:error.stack});}
  const identity=inputs.get(resolve(path));files.push({...identity,kind,semanticErrors:errors.length-beforeIssues});
 }
}catch(error){issue('replay-04','Consumer/preflight error',{message:String(error),stack:error.stack});}
finally{
 let sdkAfter=null;try{if(sdkManifestBefore){sdkAfter=await moduleManifest();assert.deepEqual(sdkAfter,sdkManifestBefore,'Nine SDK modules changed during independent replay');}}catch(error){issue('SDK integrity',String(error));}
 const changed=[];for(const [path,identity]of inputs){try{const bytes=await readFile(path);if(bytes.length!==identity.bytes||sha(bytes)!==identity.sha256)changed.push(identity.path);}catch{changed.push(identity.path);}}
 if(changed.length)issue('Input integrity','Original read inputs changed',{changed});
 const declarations=[...negativeDeclarations.values()].map(({stateCanonical,...record})=>record),result={version:2,schemaVersion:2,consumerRevision:3,ok:errors.length===0,startedAt,endedAt:new Date().toISOString(),selectedRuns:selected,runReceipts:receipts.map(outcome),sdkRoot:name(sdkRoot),sdkFingerprint:options['--sdk-fingerprint'],sdkManifestBefore,sdkManifestAfter:sdkAfter,inputsUnchanged:changed.length===0,inputChanges:changed,counts,rawCounts,uniqueCounts:{stateCandidates:stateCache.size,validStates:[...stateCache.values()].filter(value=>value.ok).length,collectionCandidates:collectionCache.size,validCollections:[...collectionCache.values()].filter(value=>value.ok).length,distinctRawRunCodecCalls:runRawCache.size,distinctRawBookCodecCalls:bookRawCache.size,declaredNegativeExports:declarations.length},negativeDeclarations:declarations,collectionExportCoverage:{format:'sword-led.collection-export.v2',observedObjects:counts.collectionExportObjects,observedStoredSlots:counts.collectionExportStoredSlots,explicitUnreadableSlots:counts.collectionExportUnreadableSlots,status:counts.collectionExportObjects?'observed-in-selected-inputs':'not-observed-in-selected-inputs',evidence:collectionExportEvidence},captureLedgers:ledgerEvidence,files,inputs:[...inputs.values()],errors,scope:'Independent formal replay/codec comparison of retained actual bytes and expected states. Exact duplicate raw/state bytes are memoized; each occurrence is still counted/compared. Explicit2049 exports verify exact expected invalid-state errors. Original nonzero UI/audio/performance results and every producer verified flag/count remain historical facts and are not promoted to pass. No new cases, commands, seeds or business results are generated.'};
 await writeFile(join(output,'result.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});await writeFile(join(output,'capture-ledgers.json'),JSON.stringify(ledgerEvidence,null,2)+'\n',{flag:'wx'});await writeFile(join(output,'inputs.json'),JSON.stringify([...inputs.values()],null,2)+'\n',{flag:'wx'});process.stdout.write(JSON.stringify({ok:result.ok,schemaVersion:2,consumerRevision:3,selectedRuns:selected,counts,rawCounts,collectionExportCoverage:result.collectionExportCoverage,uniqueCounts:result.uniqueCounts,inputsUnchanged:result.inputsUnchanged,errors:errors.length,output:name(output),uiOutcomesUnchanged:true})+'\n');if(!result.ok)process.exitCode=1;
}
