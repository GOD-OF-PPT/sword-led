# Replay draft04 — schema2 / consumer revision3 — UNEXECUTED

This is a minimal extension of the unchanged `replay-03.mjs`. The result keeps legacy `version:2`, explicitly adds `schemaVersion:2` and `consumerRevision:3`; draft04 is the filename iteration, not a new evidence schema. Consumer error labels identify replay04. The original03 bytes are bound in `replay-04.manifest.json` and were not overwritten.

No Node syntax check, SDK import, replay, browser, build or PNG decoding was executed. Only text drafting/diff/SHA and a read-only marker inventory of the three selected original JSON/gzip corpora were performed. No source/tests/config/dist/harness/official docs were edited. This is stronger observation coverage, not a claim that an earlier executed consumer or product failure has been repaired.

## Exact finite inputs

The draft requires exactly these three terminal run labels, once each, and rejects any different corpus:

- `non-audio-current-02`
- `audio-headed-matrix-02`
- `native-04`

Each original process must be terminal with an actual integer exit code; its end fingerprint must have actual0/matches:true/changed:[] and the same consumer exit. Failed UI/audio/performance outcomes remain failed. The consumer accepts them only as sources of actual bytes to verify independently.

Before dynamic import, all nine root SDK/shared JS modules must match the explicit frozen fingerprint by bytes/SHA. All nine and every read input (including this consumer, original replay, manifest, original process/end and JSON/gzip files) are checked again at the end. Output must be a new isolated directory under repository `tmp/`; mkdir is non-recursive and output files use `wx`. Attachments duplicate original artifacts and remain excluded; no image data is read.

Root may execute once after active work has ended, with a fresh output path and the fingerprint that actually binds current dist:

```sh
rtk proxy node tmp/goal4-T03/drafts/replay-04.mjs --sdk-root dist --sdk-fingerprint tmp/goal4-T03/non-audio-current-02-fingerprint.json --out tmp/goal4-T03/replay-04-data non-audio-current-02 audio-headed-matrix-02 native-04
```

The command has not been run by the author. A different SDK hash must fail; supply the correct frozen identity instead of weakening that guard.

## Collection-export extension

A declared or named actual collection export must be exactly:

```text
{format:'sword-led.collection-export.v2', collection:<full book>, stored:{main:<slot>, backup:<slot>}}
slot = {ok:true,raw:<exact string or null>} or {ok:false}
```

Recognition is restricted to that format family, an explicit `stored`+`collection` export-shaped object, or the existing `*-actual-book.json` artifact name. The exact format, top-level fields, full memory collection, both physical slot names, boolean outcome and exact slot fields are required. Missing `stored`, either slot, an `ok:true` raw field, or a malformed/future format fails immediately for that file; the global consumer keeps the error and continues other files. It never silently marks a malformed export verified.

A non-null readable slot uses the unchanged official collection codec and fails if invalid. A null raw is counted empty. An exact `{ok:false}` is preserved as an explicit original read failure with `codecStatus:'not-read'`; it is neither an empty slot nor independently validated data, and no replacement error text or raw is invented. Its occurrence is counted separately. No generic invalid-collection exemption is introduced.

The memory collection is formally validated. Physical main/backup can legitimately lag the memory collection; they are decoded independently and are not forced equal to it unless an existing actual observation already claims that equality. This preserves the existing storage/export contract rather than inventing saved progress.

`collectionExportCoverage` records exact detected export/slot occurrences, unreadable slots and paths/statuses. If the export format is absent, it reports `not-observed-in-selected-inputs`; zero detections do not mean this new branch was exercised or proved at runtime.

## Actual static inventory, without replay

A read-only streaming search for the producer's ASCII `sword-led.collection-export.` marker covered only the selected original JSON/gzip files, excluding attachments and report/process/end metadata:

| Run | Files | Original bytes read | Format-marker files |
| --- | ---: | ---: | ---: |
| non-audio-current-02 |1219|541092509|0|
| audio-headed-matrix-02 |522|19837142|0|
| native-04 |17|2315338|0|

No `*-actual-book.json` was present. Thus the known current corpus has no observed collection-export envelope; no sample was fabricated to claim branch coverage. This marker inventory is not semantic replay or a file-hash acceptance result; the actual consumer will enumerate, hash and validate its own inputs during execution. Exact inventory metadata is retained in the draft manifest.

## Unchanged strict semantics

All existing actual primary saves/captures must decode as valid and equal their complete retained state and expected public result; complete identity matches remain. Every recognized backup/book raw field is still checked. Producer verifiedCount/true/false/missing flags and failure row counts are recorded separately; unfinished producer ledgers do not block independent checking, but invalid/mismatched raw still causes exit1 and original flags are never promoted.

Only the specifically declared original2049 export can be negative, after exact scope/export/key/schema/rules/revision/journal/byte/timestamp checks and full equality with validator and codec errors `invalid_state / Expected bounded plain JSON with safe integer fields.`. Exact raw hashes scope that declaration. No arbitrary state, unknown raw, generic filename or negative-codec count is exempted.

An exit0 would mean only this finite corpus passed the stated independent formal checks under the bound SDK. It would not turn the original audio/performance failures into passes, prove the unobserved collection-export branch, satisfy page timing budgets, close T03, or complete the overall goal.
