from pathlib import Path
import json,gzip,hashlib,datetime
base=Path('tmp/goal4-T03');out=Path('docs/evidence/G4-T03-current-progress');assert not out.exists()
labels=['non-audio-current-02','legacy-current-02','legacy-target-03','typecheck-20','replay-current-01']
files=set();runs=[]
for label in labels:
 folder=base/'runs'/label;p=folder/'process.json';d=json.loads(p.read_text());assert d['status']=='terminal' and isinstance(d['actualExitCode'],int);runs.append(d)
 for p in folder.rglob('*'):
  if p.is_file() and 'attachments' not in p.parts and p.suffix in {'.json','.jsonl','.log','.md','.txt'}:files.add(p)
 for suffix in ['-fingerprint.json']:
  p=base/(label+suffix)
  if p.exists():files.add(p)
for name in ['current-preview-82.json','checkpoint.json','drafts/replay-04.mjs','drafts/replay-04.README.md','package-current-progress.py']:
 p=base/name;assert p.is_file();files.add(p)
for p in (base/'replay-current-01-data').rglob('*'):
 if p.is_file() and p.suffix in {'.json','.md'}:files.add(p)
for p in (base/'drafts/legacy-audio-late-arm').rglob('*'):
 if p.is_file():files.add(p)
for name in ['G4-T03-final-impact-map.md','G4-T03-final-code-security.md','G4-T03-objective-coverage.md','G4-T03-audio-final-status.md','G4-T03-performance-final-status.md','G4-T03-replay03-and-gap-status-review.md']:
 p=Path('tmp')/name;assert p.is_file();files.add(p)
visuals=[Path('tmp/goal4-T03/runs/non-audio-current-02/artifacts/accessibility-v5-actual-wo-24b4e-settings-readability-at1280-chromium-dpr2/workshop-1280.png'),Path('tmp/goal4-T03/runs/non-audio-current-02/artifacts/performance-v5-native-call-ec96e-ndlers-pressure-long-at1920-firefox-dpr2/test-failed-1.png')]
files.update(visuals)
for label in ['legacy-current-02','legacy-target-03']:
 for p in (base/'runs'/label).rglob('test-failed*.png'):
  if 'attachments' not in p.parts:files.add(p)

rows=[];out.mkdir(parents=True)
for p in sorted(files):
 b=p.read_bytes();compress=p.suffix!='.png';q=out/'originals'/Path(str(p)+('.gz' if compress else ''));q.parent.mkdir(parents=True,exist_ok=True);stored=gzip.compress(b,compresslevel=9,mtime=0) if compress else b;q.write_bytes(stored);assert (gzip.decompress(q.read_bytes()) if compress else q.read_bytes())==b
 rows.append({'source':str(p),'archive':str(q.relative_to(out)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'storedBytes':len(stored),'storedSHA256':hashlib.sha256(stored).hexdigest(),'encoding':'gzip' if compress else 'original'})
for row in rows:assert hashlib.sha256(Path(row['source']).read_bytes()).hexdigest()==row['sha256']
m={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Current progress evidence only: exact 125/126 native non-audio outcome, targeted legacy correction, independent raw verification and joint review. Original nonzero outcomes remain; no product/runtime delta or all-gates signoff. WebKit output, FF2 81ms callback and legacy v3 context teardown remain unclosed. Earlier recovery/payment archives retain their original identities. All local originals and nonselected success images remain untouched.','taskComplete':False,'goalComplete':False,'runs':runs,'files':rows,'reviewedImages':[{'path':str(p),'reviewer':'root','finding':'Actually viewed original after operation: current forge/quote/risk/focus or pressure sword visible, no art replacement or viewport clipping observed. Actual process/runtime scope remains in run receipts.'} for p in visuals],'allInputsUnchanged':True,'gzipRoundtripVerified':True};(out/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'ok':True,'runs':len(runs),'files':len(rows),'taskComplete':False}))
