# G4-T03 音频归档状态（2026-10-23）

本轮停止声音生产修补。主控已恢复已发布的精确实现 `6d86b2b4d4f4c35f32f8128110d66cb6f94587b870e3e27522d61f576119b263`；按主控恢复回执，82 个运行文件与已发布版相同，本轮音频产品码相对发布版无差异。当前 UI／资源／性能批次仍属独立执行，不由此说明提前结项。

**已交付的修复：** pending 按 context、epoch 和执行身份归属；旧 Promise 不再清除或撤销较新有效授权。实际 Accepted 接触若早于本次 resume 完成，最多 4 个当前 cue 只等待其所属激活；暂停、弹窗、静音、身份变化和 dispose 沿原 stop 路径清空，旧 cue 不补播。未改领域规则、存档、音色、音量或声音阈值。

**完整实际记录：** `audio-headed-matrix-02`／74637，23 逻辑 × 六个现代引擎/DPR 项目，共 138 次；实际 137 通过、1 失败，零跳过／flaky，consumer exit 1；结束指纹 417 源文件／82 产物 matches。唯一红为 WebKit DPR1 的 late-title 新声音。这是该批原身份，不能写成当前所有产品均通过，也不能用局部重复通过抹去首红。

**保留的两类原生缺口，来自不同运行：**

- resume 已实际调用但长时间不完成，context 保持 suspended/interrupted；真实接触发生，队列仍等该 Promise，零 source。WebKit 权限记录显示页面有焦点、可见且 native userActivation 为 true；失焦或没有真实手势不足以解释。
- resume 成功、context 报 running，但 currentTime／输出时间戳不推进；三条正确 source 已创建却不 ended、波形为零。退休候选中旧 close 已先完成，仍出现此类失败，不能归为漏采或用 close 屏障已解决。

| 已撤回候选 | 实际证据及限界 |
| --- | --- |
| 等旧 native suspend Promise 再 resume | `native-suspend-order-01`：3 过／6 红；旧 Promise 可不完成，新增阻塞。 |
| 取消后退休旧 context，下一真实手势新建并 resume | 固定 9 次曾全过；`audio-headed-matrix-03` 后仍有真实 WebKit 时钟红（133 过／5 红中另 4 项为单 context 消费者假设）。未稳定。 |
| 仅真实 capture 重申 running context 的 resume | `running-native-refresh-title-01`：8 过／2 红，consumer exit 1。未稳定。 |

三种候选均已退出生产；源码原件、运行身份、指纹和所有失败保留。WebKit 官方源码／263627、276687 的相关报告仅作线索，涉及移动环境的事实不能证明本 PC 同因；事件栈授权、宿主输出或引擎机制仍是推测，不作为已确认根因。

**后置责任：** 音频保留“现代 PC 原生异常后真实新手势恢复声音”的未闭环责任，不能宣布 T03／整体目标完成。恢复闭环须以选定产品字节、原严格波形／零旧 cue／资源清理／真实进度门和实际终态为据；历史通过继续保留原身份。物理扬声器、听感与真人 H 分开。此归档不要求新增采样、实验或审批；本轮优先用户费用关系 UI 交付。
