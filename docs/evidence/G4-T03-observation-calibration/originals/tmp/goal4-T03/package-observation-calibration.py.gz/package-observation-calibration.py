from pathlib import Path
import json,gzip,hashlib,datetime
base=Path('tmp/goal4-T03');out=Path('docs/evidence/G4-T03-observation-calibration');assert not out.exists()
labels=['typecheck-21','pure-completion-title-01','pure-completion-fault-axis-01','legacy-close-protocol-01','typecheck-22','ff2-pressure-profiler-01','ff2-pressure-profiler-02','close-minimal-01','typecheck-23','ff2-calibrated-observation-01','ff2-calibrated-burst-01']
files=set();runs=[]
for label in labels:
 folder=base/'runs'/label;p=folder/'process.json';d=json.loads(p.read_text());assert d['status']=='terminal' and isinstance(d['actualExitCode'],int);runs.append(d)
 for p in folder.rglob('*'):
  if p.is_file() and 'attachments' not in p.parts and p.suffix in {'.json','.jsonl','.log','.md','.txt'}:files.add(p)
 for suffix in ['-fingerprint.json']:
  p=base/(label+suffix)
  if p.exists():files.add(p)
for name in ['pure-completion-activation.json','pure-completion-title-protocol.json','pure-completion-axis-protocol.json','legacy-close-protocol-01-summary.json','ff2-profiler-selector-correction.json','run-close-minimal-frozen.py','checkpoint.json','package-observation-calibration.py','originals/tests/release-v5/audio-spec-before-pure-completion.ts']:
 p=base/name;assert p.is_file();files.add(p)
for directory in [base/'profiles/ff2-pressure-profiler-02',base/'close-minimal-01-data']:
 for p in directory.rglob('*'):
  if p.is_file():files.add(p)
for draft in ['audio-probe-pure-late-completion','slow-callback-observation','v3-close-boundary','v3-close-minimal']:
 for p in (base/'drafts'/draft).rglob('*'):
  if p.is_file():files.add(p)
for name in ['G4-T03-pure-completion-closeout-review.md','G4-T03-slow-callback-metadata-plan.md','G4-T03-firefox-profiler-plan.md','G4-T03-ff2-profiler02-analysis.md']:
 p=Path('tmp')/name;assert p.is_file();files.add(p)
visuals=[base/'runs/ff2-calibrated-observation-01/artifacts/performance-v5-native-call-ec96e-ndlers-pressure-long-at1920-firefox-dpr2/native-pressure-long-1920-post-measurement.png']
files.update(visuals)
for label in ['legacy-close-protocol-01','ff2-pressure-profiler-02']:
 for p in (base/'runs'/label).rglob('test-failed*.png'):
  if 'attachments' not in p.parts:files.add(p)

rows=[];out.mkdir(parents=True)
for p in sorted(files):
 b=p.read_bytes();compress=p.suffix!='.png';q=out/'originals'/Path(str(p)+('.gz' if compress else ''));q.parent.mkdir(parents=True,exist_ok=True);stored=gzip.compress(b,compresslevel=9,mtime=0) if compress else b;q.write_bytes(stored);assert (gzip.decompress(q.read_bytes()) if compress else q.read_bytes())==b
 rows.append({'source':str(p),'archive':str(q.relative_to(out)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'storedBytes':len(stored),'storedSHA256':hashlib.sha256(stored).hexdigest(),'encoding':'gzip' if compress else 'original'})
for row in rows:assert hashlib.sha256(Path(row['source']).read_bytes()).hexdigest()==row['sha256']
m={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Observation calibration progress only: correct late-completion3+54 actualpasses, protocol-close originalred, bounded4staticconditions, real Firefox nativeprofile with2originalbudgetreds, corrected-wait normal andburst actualpasses. Eleven exact terminal commands; selectors/failed/corrected protocols keep separate identities. Sixretry artifact literal invocation is obsolete for this54 batch; actualoperation confirms completion gate; originals unchanged. Product/runtime82unchanged. Not T03/fullgoal signoff; all local originals remain.','taskComplete':False,'goalComplete':False,'runs':runs,'files':rows,'reviewedImages':[{'path':str(p),'reviewer':'root','finding':'Root actually viewed current calibrated FF DPR2/1920 pressure forge after the three measured paths; source sword, risk, order, quote and controls visible without clipping. Image does not prove framecost or physical output.'} for p in visuals],'allInputsUnchanged':True,'gzipRoundtripVerified':True};(out/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'ok':True,'runs':len(runs),'files':len(rows),'taskComplete':False}))
