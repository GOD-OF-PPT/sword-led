# V3 context.close 分界诊断（未执行草稿）

本轮仅写隔离tmp说明和日志分析器；没有改共享源/tests/config/dist/harness，没有运行浏览器、SDK、Node、构建、编译或图像解码。分析器本身也未执行。Clock恢复候选已撤回，当前原spec SHA256为 `673b9e1fa67fb0fb09f17047f5106570ff4887ebbb1b9dec09ec73553511c01c`；不再次叠加Clock恢复、延时、手工关闭或静音方案。

## 新的实际边界

`legacy-clock-cleanup-01` actual1，单case耗时183123ms；唯一错误仍为 `Tearing down "context" exceeded the test timeout of 180000ms.`。原report内JSON attachment可直接解出 `bodyCompleted:true`、`page.clock.resume` completed true、durationMs4.851013。结束指纹实际0/matchestrue/changed[]。因此原业务body确已完成且显式Clock恢复已返回；Clock恢复不足以解决该次关闭超时，不能再写成“Clock待恢复导致卡住”。原两次teardown红和该次候选红均保留。

但报告没有CDP发送/回复日志或close分阶段记录。“context fixture超时”并不等于已经进入Chromium的context销毁命令，也不等于正在等待原生音频设备。本轮可定位到fixture关闭链，尚不能定位链内哪一个await。

## 安装版1.64.1的真实关闭链

以下行号来自已读取并绑定SHA的安装文件，不是网络版本的推断。

1. 客户端 `playwright-core/lib/coreBundle.js:64139`：BrowserContext.close先标closing，依次await `request.dispose`、`instrumentation.runBeforeCloseBrowserContext`、HAR导出、channel.close，然后await客户端closed事件Promise。
2. `playwright/lib/index.js:156,657`：测试runner的beforeClose会await artifactsRecorder：停止trace、captureTemporary截图、必要时页快照。`index.js:597` 明确 **only-on-failure也在关闭前尝试临时截图**；截图本身设5000ms，snapshot在记录错误后最多5000ms。这说明“body无业务错”不能用于排除关闭前的产物路径；也不能仅凭截图路径存在认定它是180秒根因。
3. 服务端 `coreBundle.js:53327`：BrowserContext.close发BeforeClose/置closing，await两类trace flush、每页screencast收尾，再进入doClose；doClose返回后删除downloads/tempDirs、调用_didCloseInternal，最后await_closePromise。trace/video配置off减少相关工作，但不能凭配置跳过这段真实控制流。
4. Chromium `coreBundle.js:40165`：doClose先await关闭**已经存在的**beforeunload对话框，再取消download；对普通非默认测试context，await browser根CDP session `Target.disposeBrowserContext({browserContextId})`。返回后移除context映射/相关service-worker对象。默认context才返回close-browser；本用例是test fixture新context。
5. `coreBundle.js:53112`：_didCloseInternal置closed、完成服务端closePromise并发Close；客户端_onClose在64125附近接收事件并完成其关闭状态。协议回复与最终fixture完成是两个不同边界。

因此先分清 **未发送销毁命令 / 已发送但未回复 / 已回复但fixture未结束**，比先改产品退出逻辑更有依据。

## V3退出、声音和资源的实际关系

- `src/v3-main.ts:8`仅HMR注册app.dispose；正常context销毁不会通过这个入口显式await mountV3.dispose。
- `platform/browser-session.ts:22` 的pagehide handler为 `void session.suspend()`。`application/persistent-session.ts:243` 同步invalidate/改active、lease.release、publish，再返回release Promise。`writer-lease.ts:19` release同步释放hold引用并返回原navigator.locks requestDone；事件handler未await它。
- `presentation-v3/app.ts:234–239` hidden/blur同步取消输入/表现、递增epoch、render；render中的syncAudio把隐藏页面设silent。`platform/audio.ts` 的silent→suspend调用真实AudioContext.suspend并以catch/finally跟踪，但调用方不await这个Promise阻塞页面事件。
- `mountV3.dispose` 若实际调用，会移除监听、取消动画/计时器/资源、断ResizeObserver，最终await port.dispose和audio.dispose；`audio.dispose`会停源、断master、await真实context.close。当前正常退出没有显式调用这条app.dispose链的证据，失败原case也没有安装audio-probe或记录native操作。
- 全src搜索未发现beforeunload/onbeforeunload/unload handler。Chromium doClose的`closeBeforeUnloadDialogs()`仅处理已有原生beforeunload dialog；这不是主动调用`page.close({runBeforeUnload:true})`。页面的HTML `<dialog>`也不等于原生JavaScript beforeunload dialog。

源码没有把V3的audio/lease Promise显式接入Playwright context.close的await链。浏览器内部销毁资源仍可能涉及它们，但现有证据不足以判断哪一个，更不能推定系统音频设备/驱动异常。Clock的fake350ms与原生AudioContext.currentTime不是同一个时钟；新附件仅证明Clock API已返回，不证明原生声音已ended或context已closed。

## 最小下一步：先只加协议日志，不改消费者

对已还原的现有首case，沿用原headed环境、180000ms/retries0、相同构建/配置，仅在root统一冻结和执行包装中加 `DEBUG=pw:api,pw:protocol,pw:browser`，保存完整stdout/stderr。安装版 `coreBundle.js:22203–22208` 的protocol logger确会输出SEND/RECV消息及request id/sessionId；该选择不添加页面监听、CDP session、浏览器操作或清理动作。它只是一次原有case的定向诊断，不扩矩阵。

供root纳入原执行/指纹包装的命令形状（本轮未运行）：

```sh
rtk proxy env DEBUG=pw:api,pw:protocol,pw:browser V5_LEGACY_REPORT=tmp/goal4-T03/runs/legacy-close-boundary-01/report.json npx playwright test --config playwright.v5-t03-legacy.config.ts --project=v3-chromium --grep 'left-down on the actual sword commits once' --headed --output tmp/goal4-T03/runs/legacy-close-boundary-01/artifacts
```

不关截图以跳过未知阶段，不改trace/video配置，不加about:blank、native audio.close、额外暂停/静音、sleep或更大timeout。原case的state/RNG/输入断言完全保持；DEBUG日志的开销属于这次非性能诊断，不拿它更新真实性能预算。

| 实际日志边界 | 可以收窄到 | 仍不能推断 |
| --- | --- | --- |
| 没有观察到Target.disposeBrowserContext发送 | 核DEBUG是否完整，再看request.dispose、beforeClose产物/截图、服务端flush/screencast、已有dialog/download的上游阶段 | 不能直接归原生音频或证明“命令从未发送” |
| 观察到SEND id/session，终态前没有同id回复 | Chromium销毁请求已发，尚未观察到响应；记录detach/crash/browser stderr及错误回复 | 不能把浏览器内部待销毁资源直接归某音频设备/JS Promise |
| 收到对应成功回复，但context.close/fixture仍没完成 | doClose后下载/临时文件清理、Close事件/客户端仪器或fixture收尾 | 不等于浏览器context仍活跃或native audio未释放 |
| Page.javascriptDialogOpening type=beforeunload，且handleJavaScriptDialog请求未回复 | 已有原生对话框处理边界有实证 | 不能从HTML弹窗、按钮disabled或“没有pagehide日志”替代该证据 |
| Page.captureScreenshot/其回复最后可见且无dispose发送 | 有据优先核产物关闭前阶段 | 没有更细记录时不能断言截图就是卡住的await |

`pw:browser`原样保存自有Chrome进程stderr，只有实际出现并能对齐该窗口的native/renderer错误才能作为进一步线索；没有此类日志时应保留unknown，不能补环境故事。

## 日志分析器草稿

`summarize-close-protocol.py`只读一个已终态运行的原始日志和process回执，按id+sessionId配对指定关闭/对话框/截图命令与回复；保留API边界和target/dialog/WebAudio事件。它不复制截图base64、不启动浏览器、不加载SDK，不修改原件；输出必须为原run目录之外的新文件。缺日志、截断行与未配对请求均明确保留，原consumer exitcode照录，不转绿。

后续实际运行终态后，root可执行（分析器本身尚未执行/编译）：

```sh
rtk proxy python3 tmp/goal4-T03/drafts/v3-close-boundary/summarize-close-protocol.py --log tmp/goal4-T03/runs/legacy-close-boundary-01/stdout.log --process tmp/goal4-T03/runs/legacy-close-boundary-01/process.json --out tmp/goal4-T03/legacy-close-boundary-01-summary.json
```

若debug实际写在独立stderr文件，使用那个完整文件；不可把仅stdout无protocol记录解释为无命令。分析器对输入逐项SHA前后验证，拒绝读取未终态回执或覆盖原run/旧summary。

## 只有协议仍不足时才加的观察

若已定位到Chromium销毁请求内部，现有日志仍缺页面pagehide执行和原生context状态时，才在单个诊断候选里考虑只读pagehide/visibility console记录，以及公开CDP `WebAudio.enable`后的contextCreated/contextChanged/contextWillBeDestroyed（安装protocol.d.ts:19494–19625确有）。不添加beforeunload监听（会改变原页面退出条件），不替换AudioContext方法、不调用resume/suspend/close。新增CDP observer自身会增加会话，需单独绑定其诊断身份，不能与无observer原case混称同一次关闭。

这些WebAudio事件只能证明浏览器报告的图生命周期；不证明物理设备输出。若要定位具体native控制Promise，还需另有原始调用/settle记录，当前数据没有。初步DEBUG-only诊断前不先铺这个第二层observer，避免同时改变两个条件。

结论：Clock释放不足已被实际反证；当前不能把180秒定位为产品audio、pagehide、beforeunload或设备故障。已有安装源码给出了最小协议分界，下一份真实SEND/RECV/API日志才能继续收窄。没有源码变更或根因修复可在此阶段宣称。

`inputs.json`绑定本次读取的安装实现、产品退出链、原spec和clockcleanup01回执/report/endfp；原文保持。旧Clock草稿/候选失败记录不覆盖。[杠精审查]未复用无效Clock方案、未删业务断言、未靠延时/静音/关截图掩盖未知关闭阶段，也未把协议/设备猜测当根因；缺失观测逐项说明。
