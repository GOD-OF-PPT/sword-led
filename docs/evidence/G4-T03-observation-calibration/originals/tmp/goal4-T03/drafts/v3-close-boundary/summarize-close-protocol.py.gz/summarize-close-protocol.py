#!/usr/bin/env python3
"""UNEXECUTED log-only diagnostic; never launches a browser or imports a game SDK."""
from __future__ import annotations
import argparse
from collections import defaultdict, deque
import hashlib
import json
from pathlib import Path
import re


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--log', required=True, type=Path)
parser.add_argument('--process', required=True, type=Path)
parser.add_argument('--out', required=True, type=Path)
args = parser.parse_args()
log = args.log.resolve()
process = args.process.resolve()
out = args.out.resolve()
if out.exists() or out in (log, process) or process.parent in out.parents:
    parser.error('Use a fresh summary path outside the original run directory.')
process_hash = sha(process)
receipt = json.loads(process.read_text())
if receipt.get('status') != 'terminal' or type(receipt.get('actualExitCode')) is not int:
    parser.error('Only summarize a terminal process receipt; active logs cannot establish missing replies.')
log_hash = sha(log)
ansi = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
wire = re.compile(r'pw:protocol\s+(SEND\s*►|◀\s*RECV)\s*')
commands = {
    'Target.disposeBrowserContext', 'Target.closeTarget', 'Browser.close',
    'Browser.cancelDownload', 'Page.captureScreenshot', 'Page.stopScreencast',
    'Page.handleJavaScriptDialog', 'Page.close', 'WebAudio.enable',
    'WebAudio.getRealtimeData',
}
event_names = {
    'Target.detachedFromTarget', 'Target.targetDestroyed', 'Target.targetCrashed',
    'Inspector.detached', 'Inspector.targetCrashed', 'Page.javascriptDialogOpening',
    'Page.javascriptDialogClosed', 'WebAudio.contextCreated',
    'WebAudio.contextChanged', 'WebAudio.contextWillBeDestroyed',
}
requests: list[dict] = []
pending: dict[tuple[str, int], deque[dict]] = defaultdict(deque)
events: list[dict] = []
api: list[dict] = []
malformed: list[dict] = []
parsed_rows = 0
protocol_lines = 0
for line_number, line in enumerate(log.open(errors='replace'), 1):
    line = ansi.sub('', line).rstrip('\n')
    if 'pw:api' in line and any(word in line for word in ('browserContext.close', 'apiRequestContext.dispose', 'page.screenshot', 'browser.close', 'clock.resume')):
        api.append({'line': line_number, 'text': line})
    match = wire.search(line)
    if not match:
        continue
    protocol_lines += 1
    try:
        message, _ = json.JSONDecoder().raw_decode(line[match.end():])
        if not isinstance(message, dict):
            raise ValueError('Protocol row is not an object')
    except (ValueError, json.JSONDecodeError) as error:
        malformed.append({'line': line_number, 'error': str(error), 'logTruncated': 'LOG TRUNCATED' in line})
        continue
    parsed_rows += 1
    sent = match.group(1).startswith('SEND')
    session = message.get('sessionId', '')
    identity = message.get('id')
    if sent and type(identity) is int:
        method = message.get('method', '')
        if method not in commands:
            continue
        record = {'method': method, 'id': identity, 'sessionId': session, 'sentLine': line_number,
                  'sentPrefix': line[:match.start()], 'params': message.get('params', {}), 'reply': None}
        requests.append(record)
        pending[(session, identity)].append(record)
    elif not sent and type(identity) is int:
        queue = pending.get((session, identity))
        if queue:
            record = queue.popleft()
            record['reply'] = {'line': line_number, 'prefix': line[:match.start()],
                               'error': message.get('error'), 'resultKeys': list(message['result']) if isinstance(message.get('result'), dict) else []}
    elif not sent and message.get('method') in event_names:
        params = message.get('params', {})
        if message['method'] == 'Page.javascriptDialogOpening':
            params = {key: params[key] for key in ('type', 'hasBrowserHandler', 'frameId') if key in params}
        events.append({'line': line_number, 'prefix': line[:match.start()], 'method': message['method'],
                       'sessionId': session, 'params': params})
if sha(log) != log_hash or sha(process) != process_hash:
    raise SystemExit('Inputs changed during summary; original log/process must remain immutable.')
result = {
    'scope': 'Existing terminal run log correlation only; no browser/SDK execution or pass conversion.',
    'originalConsumer': {key: receipt.get(key) for key in ('label', 'status', 'actualExitCode', 'startedAt', 'completedAt')},
    'inputs': [{'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest} for path, digest in ((log, log_hash), (process, process_hash))],
    'protocolLines': protocol_lines, 'parsedProtocolRows': parsed_rows,
    'coverage': 'no-protocol-evidence' if parsed_rows == 0 else 'partial-truncated-or-malformed' if malformed else 'parsed-native-protocol-rows',
    'malformedProtocolRows': malformed, 'requests': requests, 'events': events, 'apiLines': api,
    'disposeRequests': [record for record in requests if record['method'] == 'Target.disposeBrowserContext'],
    'limits': [
        'Missing rows are not proof a command was never sent; verify DEBUG coverage and malformed/truncated rows.',
        'Matched reply means that specific protocol response, not total fixture completion or native device causality.',
        'No WebAudio events are expected unless a separately reviewed observer enabled that protocol domain.',
        'Original nonzero results remain nonzero; this report neither reruns a test nor declares a fix.',
    ],
}
out.parent.mkdir(parents=True, exist_ok=True)
with out.open('x') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps({'summary': str(out), 'protocolLines': protocol_lines,
                  'disposeRequests': len(result['disposeRequests']), 'malformedProtocolRows': len(malformed)}, ensure_ascii=False))
