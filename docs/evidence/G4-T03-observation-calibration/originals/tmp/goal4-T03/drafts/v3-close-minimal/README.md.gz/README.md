# 四个固定条件：Chromium context.close 最小诊断（未执行）

`run-close-minimal.mjs`是独立Node/Playwright脚本；本轮只写草稿、静态检查，没有启动或执行它，没有改任何共享文件。root负责外部执行回执、协议日志和指纹，不另造测试框架或证据包。

新依据：`legacy-close-protocol-01-summary.json`共458条native protocol记录、无解析缺行。截图147成功；root Target.disposeBrowserContext149发送后约3分钟没有回复；runner browser.close开始后才出现target detach和149成功回复，随后context.close/browser.close均完成。没有beforeunload事件。它将原缺口收窄到Chromium处理销毁请求期间，尚不确定哪个资源造成阻塞。OS sample guard发现终态而未执行，不存在采样回执。

固定顺序只有四叶：none、PlaywrightClock、nativeAudio、Clock+Audio。每叶串行新建一个自有headed browser和context；同一自有loopback静态页面/按钮，每叶都实际点击一次。无游戏、存档、领域SDK、WebLocks、资源图或其他case。

浏览器绑定原protocol01安装路径：`chromium-1248/chrome-mac-x64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing`，版本156.0.8078.4；与实际chromium.executablePath/browser.version不符即停止准备，不暗换系统Chrome。DEBUG保留实际launch参数/PID，脚本用仅本叶chromium.launch返回的对象正常清理，绝不连接/关闭用户浏览器。

时序保持：Clock两叶先install自动运行，再goto静态页、真实按钮准备；Audio两叶在该trusted活跃手势中实际new AudioContext/resume，并原生调度三条220ms短source。直接把原生resume准备Promise交给Node观察，无RAF轮询/页面计时器等待。准备成功后Clock两叶才调用原形状pauseAt(Node Date.now()+1000)，再runFor350，保持paused至context.close，不调用Clock.resume。每个Clock调用、fake前后时钟与native currentTime均留记录。

三source以719/1193/1777Hz真实Oscillator/Gain连接destination；start成功与native ended事件分别记录。自然ended后断开source/envelope，但context/master和引用保持存活直到浏览器销毁；脚本不替换任何AudioContext方法，也不主动suspend/close它。不把source已排程或state=running当物理听感证明。

context.close只调用一次，立刻附双分支settlement记录并保留原Promise。Node原生计时器从该调用开始锚定5000ms观察；超时只记pending，不reject/取消原关闭Promise。若pending，调用且只调用该叶自有browser.close正常清理；无pending时同样正常关browser以回收自有进程。记录context何时resolve/reject、page/context close和browser disconnected，以及它是否只在browser.close开始后才首次settle。这是时间先后证据，单次四叶不证明一般因果或原游戏已修。

browser.close若5000ms仍pending，写marker并保留唯一正常关闭等待，不启动下一叶、不kill/二次close。若browser.close拒绝，先保存当前叶和partial结果并停止，不进入下一browser。此时root可从外部执行句柄确认真实进程状态；脚本不会伪造实际terminal回执。准备Promise/Clock调用也用Node有界观察；准备未完成或拒绝明确setup-incomplete，不能视为该条件的有效close结果。

执行前root可进行常规语法审核，再在无其他browser/性能活动时统一冻结并运行。此处命令未执行，输出目录必须全新；外部包装另记actual exit/日志：

```sh
rtk proxy env DEBUG=pw:api,pw:protocol,pw:browser node tmp/goal4-T03/drafts/v3-close-minimal/run-close-minimal.mjs --out tmp/goal4-T03/close-minimal-01-data
```

仅输出诊断events.jsonl、逐叶JSON、partial-results.json及result.json；API/协议launch日志由root包装保存。内部requestedExitCode：0表示四叶有效准备且context均在5000ms观察内settle；1表示至少一叶在观察点仍pending；2表示准备、清理或runner错误。实际进程exit由外部回执确认，这些代码从不覆盖原game失败。

5000ms是最小诊断的pending观察窗口，不是原v3 180000ms或任何性能门的新阈值。Node事件循环可能稍晚交付timer，实际elapsedMs原样记录。不追加任意sleep以等音源结束，原生音源在关闭前的state/currentTime/ended均保留。

若四叶均未复现，只能说明当前极小静态程序未复现；原游戏关闭仍未修复。WebLocks未加入：只有原数据进一步指向它时才先说明需要，不自行扩大八叶矩阵。没有别的新条件、seed、全局回归或音频产品改动。

[静态审阅] C指出的“browser.close拒绝后仍可进下一叶”已修为持久记录后stop；原close Promise不丢失，准备等待不依赖paused RAF。未执行脚本、语法编译或浏览器，不预设任何叶结果。
