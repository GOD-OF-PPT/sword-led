// UNEXECUTED isolated four-condition Chrome context.close diagnostic. No game or domain SDK.
import assert from 'node:assert/strict';
import {appendFileSync,existsSync,mkdirSync,writeFileSync} from 'node:fs';
import {createServer} from 'node:http';
import {dirname,resolve,relative} from 'node:path';
import {fileURLToPath} from 'node:url';
import {parseArgs} from 'node:util';
import {chromium,devices} from '@playwright/test';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'../../../..');
const {values}=parseArgs({options:{out:{type:'string'},'expected-executable':{type:'string'},'expected-version':{type:'string',default:'156.0.8078.4'}},strict:true});
assert(values.out,'Required --out fresh directory beneath repository tmp');
const out=resolve(root,values.out),withinTmp=relative(resolve(root,'tmp'),out);
assert(withinTmp&&!withinTmp.startsWith('..')&&!withinTmp.startsWith('/'),'Output must remain beneath repository tmp');
assert(!existsSync(out),'Refusing to overwrite an existing output directory');
const expectedExecutable=values['expected-executable']??'/Users/gordon/Library/Caches/ms-playwright/chromium-1248/chrome-mac-x64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing';
const executable=chromium.executablePath();assert.equal(executable,expectedExecutable,'Use the exact Chromium executable from protocol01');
assert((process.env.DEBUG??'').includes('pw:browser')&&(process.env.DEBUG??'').includes('pw:protocol'),'Set DEBUG=pw:api,pw:protocol,pw:browser to preserve actual launch/close evidence');
const conditions=[{name:'none',clock:false,audio:false},{name:'PlaywrightClock',clock:true,audio:false},{name:'nativeAudio',clock:false,audio:true},{name:'Clock+Audio',clock:true,audio:true}];
const observationMs=5000,start=process.hrtime.bigint(),events=[],results=[];
mkdirSync(out,{recursive:true});
const now=()=>Number(process.hrtime.bigint()-start)/1e6;
const errorText=error=>({name:error?.name??typeof error,message:error?.message??String(error),stack:error?.stack??null});
function record(condition,type,data={}){const row={sequence:events.length,wallAt:new Date().toISOString(),nodeMs:now(),condition,type,...data};events.push(row);appendFileSync(resolve(out,'events.jsonl'),JSON.stringify(row)+'\n');process.stdout.write('CLOSE_MIN '+JSON.stringify(row)+'\n');return row;}
function save(name,value){writeFileSync(resolve(out,name),JSON.stringify(value,null,2)+'\n');}
function track(condition,name,invoke){
 const state={name,status:'pending',startedAt:now(),settledAt:null,error:null};record(condition,name+'.start');
 let original;try{original=invoke();}catch(error){original=Promise.reject(error);}
 const settled=Promise.resolve(original).then(value=>{state.status='resolved';state.settledAt=now();record(condition,name+'.resolved',{startedAt:state.startedAt,settledAt:state.settledAt});return{state,value};},error=>{state.status='rejected';state.settledAt=now();state.error=errorText(error);record(condition,name+'.rejected',{startedAt:state.startedAt,settledAt:state.settledAt,error:state.error});return{state,value:null};});
 return{original,settled,state};
}
async function observe(condition,operation,label){
 let timer;const remainingMs=Math.max(0,observationMs-(now()-operation.state.startedAt)),timed=new Promise(resolveTimer=>{timer=setTimeout(()=>resolveTimer({settled:false,at:now()}),remainingMs);});
 const result=await Promise.race([operation.settled.then(()=>({settled:true,at:now()})),timed]);clearTimeout(timer);
 const observation={targetObservationMs:observationMs,observedAt:result.at,elapsedMs:result.at-operation.state.startedAt,settled:result.settled,status:operation.state.status};record(condition,label,observation);return observation;
}
async function requireSetup(condition,operation){const observed=await observe(condition,operation,operation.state.name+'.setup-observation');assert(observed.settled&&operation.state.status==='resolved',operation.state.name+' did not settle successfully: setup-incomplete');return operation.settled;}
const html=String.raw`<!doctype html><meta charset="utf-8"><title>Owned close diagnostic</title><style>body{font:16px sans-serif;margin:32px}button{min-width:240px;min-height:48px}</style><button id="start">Start fixed condition</button><p id="status">Waiting for one trusted click</p><script>
(()=>{
 const audioEnabled=new URL(location.href).searchParams.get('audio')==='1';
 const probe={audioEnabled,input:null,ready:null,context:null,master:null,sources:[],events:[],createdAt:null};
 const emit=(type,data={})=>{const row={type,pageNow:performance.now(),pageDate:Date.now(),...data};probe.events.push(row);console.debug('CLOSE_MIN_PAGE '+JSON.stringify(row));};
 const visibility=()=>({visibilityState:document.visibilityState,hidden:document.hidden,hasFocus:document.hasFocus()});
 probe.snapshot=()=>({audioEnabled,input:probe.input,visibility:visibility(),pageNow:performance.now(),pageDate:Date.now(),context:probe.context?{state:probe.context.state,currentTime:probe.context.currentTime,baseLatency:probe.context.baseLatency,sampleRate:probe.context.sampleRate}:null,sources:probe.sources.map(source=>({...source})),events:probe.events.map(event=>({...event}))});
 window.closeMinProbe=probe;
 document.querySelector('#start').addEventListener('click',event=>{
  probe.input={trusted:event.isTrusted,activation:{isActive:navigator.userActivation.isActive,hasBeenActive:navigator.userActivation.hasBeenActive},...visibility()};emit('trusted-click',probe.input);
  probe.ready=(async()=>{
   if(!event.isTrusted||!navigator.userActivation.isActive)throw new Error('Expected one real active trusted button gesture');
   if(!audioEnabled){document.querySelector('#status').textContent='No audio condition prepared';return{prepared:true,sourceStarts:0};}
   const context=new AudioContext({latencyHint:'interactive'});probe.context=context;probe.createdAt=performance.now();emit('context-created',{state:context.state,currentTime:context.currentTime});
   context.addEventListener('statechange',()=>emit('context-statechange',{state:context.state,currentTime:context.currentTime}));
   const master=context.createGain();master.gain.value=.2;master.connect(context.destination);probe.master=master;
   emit('native-resume-call',{state:context.state,currentTime:context.currentTime});await context.resume();emit('native-resume-settled',{state:context.state,currentTime:context.currentTime});
   if(context.state!=='running')throw new Error('Native resume did not leave a running context');
   const when=context.currentTime,duration=.22;
   for(const frequency of [719,1193,1777]){
    const source=context.createOscillator(),gain=context.createGain(),entry={frequency,started:false,ended:false,startAt:when,scheduledStopAt:when+duration+.01};probe.sources.push(entry);
    source.type='sine';source.frequency.setValueAtTime(frequency,when);gain.gain.setValueAtTime(0,when);gain.gain.linearRampToValueAtTime(.06,when+.003);gain.gain.exponentialRampToValueAtTime(.0001,when+duration);source.connect(gain);gain.connect(master);
    source.addEventListener('ended',()=>{entry.ended=true;source.disconnect();gain.disconnect();emit('source-ended',{frequency,currentTime:context.currentTime});},{once:true});
    source.start(when);entry.started=true;source.stop(entry.scheduledStopAt);emit('source-started',{frequency,currentTime:context.currentTime,scheduledStopAt:entry.scheduledStopAt});
   }
   document.querySelector('#status').textContent='Native three-source audio scheduled; context stays alive';return{prepared:true,sourceStarts:probe.sources.filter(source=>source.started).length};
  })();
 },{once:true});
})();
</script>`;
record(null,'run.start',{pid:process.pid,command:process.argv,debug:process.env.DEBUG,conditions,observationMs,executable,expectedVersion:values['expected-version'],headless:false});
const server=createServer((request,response)=>{if(request.url==='/favicon.ico'){response.writeHead(204);response.end();return;}response.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});response.end(html);});
await new Promise((resolveListen,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolveListen);});
const address=server.address();assert(address&&typeof address==='object');const baseURL='http://127.0.0.1:'+address.port;
let exitCode=0;
try{
 for(const condition of conditions){
  const name=condition.name;let browser=null,context=null,page=null,close=null,ready=null,setupError=null,preClose=null,closeObservation=null,browserClose=null;
  record(name,'condition.start',{clock:condition.clock,audio:condition.audio,baseURL,headless:false,executable});
  try{
   browser=await chromium.launch({headless:false});const browserVersion=browser.version();record(name,'browser.launched',{browserVersion,executable,ownership:'New chromium.launch result for this condition only; no connect/reuse or foreign process.'});assert.equal(browserVersion,values['expected-version']);
   browser.on('disconnected',()=>record(name,'browser.disconnected'));
   context=await browser.newContext({...devices['Desktop Chrome'],viewport:{width:1280,height:720},deviceScaleFactor:1});context.on('close',()=>record(name,'context.close-event'));
   page=await context.newPage();page.on('close',()=>record(name,'page.close-event'));page.on('crash',()=>record(name,'page.crash'));
   page.on('pageerror',error=>record(name,'page.error',{error:errorText(error)}));page.on('console',message=>{const text=message.text();if(text.startsWith('CLOSE_MIN_PAGE '))record(name,'page.observation',{value:JSON.parse(text.slice('CLOSE_MIN_PAGE '.length))});});
   if(condition.clock){const install=track(name,'clock.install',()=>page.clock.install());await requireSetup(name,install);}
   await page.goto(baseURL+'/?audio='+(condition.audio?'1':'0'));await page.bringToFront();
   record(name,'before-click',{snapshot:await page.evaluate(()=>window.closeMinProbe.snapshot())});await page.locator('#start').click();
   ready=track(name,'button.ready',()=>page.evaluate(()=>{const ready=window.closeMinProbe.ready;if(!ready)throw new Error('Trusted click did not assign preparation Promise');return ready;}));
   const readyObservation=await observe(name,ready,'button.ready-observation');assert(readyObservation.settled&&ready.state.status==='resolved','Preparation did not settle: setup-incomplete, never a valid context-close result');assert.equal(readyObservation.status,'resolved');assert.equal((await ready.settled).value.sourceStarts,condition.audio?3:0);
   if(condition.clock){
    const before=await page.evaluate(()=>window.closeMinProbe.snapshot());const target=new Date(Date.now()+1000);const pause=track(name,'clock.pauseAt',()=>page.clock.pauseAt(target));await requireSetup(name,pause);record(name,'clock.pauseAt-values',{target:target.toISOString(),before,after:await page.evaluate(()=>window.closeMinProbe.snapshot())});
    const run=track(name,'clock.runFor350',()=>page.clock.runFor(350));await requireSetup(name,run);record(name,'clock.runFor350-values',{after:await page.evaluate(()=>window.closeMinProbe.snapshot()),remainsPaused:true,clockResumeCalled:false});
   }
   preClose=await page.evaluate(()=>({snapshot:window.closeMinProbe.snapshot(),ua:navigator.userAgent,dpr:devicePixelRatio,width:innerWidth,height:innerHeight}));assert.equal(preClose.snapshot.input.trusted,true);assert.equal(preClose.snapshot.context===null,!condition.audio);if(condition.audio){assert.equal(preClose.snapshot.context.state,'running');assert.equal(preClose.snapshot.sources.filter(source=>source.started).length,3);}
   record(name,'pre-context-close',{preClose});
  }catch(error){setupError=errorText(error);exitCode=2;record(name,'setup-incomplete',{error:setupError});}
  finally{
   if(context){close=track(name,'context.close',()=>context.close());closeObservation=await observe(name,close,'context.close-observation');if(!closeObservation.settled&&exitCode===0)exitCode=1;if(close.state.status==='rejected')exitCode=2;}
   if(browser){
    const contextPending=close?.state.status==='pending';record(name,'before-owned-browser-close',{contextPending,contextStatus:close?.state.status??'not-created'});
    browserClose=track(name,'browser.close',()=>browser.close());
    const marker=setTimeout(()=>record(name,'browser.close-still-pending-at5000',{status:browserClose.state.status,note:'Only normal owned browser.close is retained; no kill, second close or next condition while cleanup remains pending.'}),observationMs);
    try{await browserClose.settled;}finally{clearTimeout(marker);}
    if(browserClose.state.status!=='resolved'){
     exitCode=2;const failedCleanup={condition,setupComplete:setupError===null,setupError,preClose,contextClose:close?.state??null,contextCloseObservation:closeObservation,browserClose:browserClose.state,ready:ready?.state??null,cleanupComplete:false};results.push(failedCleanup);save(name.replace('+','-')+'.json',failedCleanup);save('partial-results.json',{scope:'Stopped after owned browser cleanup rejected; never launch the next condition with an unconfirmed process.',conditionsRecorded:results.length,results});throw new Error('Owned browser.close rejected; stop before another browser condition');
    }
    const afterBrowser=close?await observe(name,close,'context.close-after-browser-cleanup-observation'):null;
    const temporal={pendingWhenBrowserCloseBegan:contextPending,contextSettledAt:close?.state.settledAt??null,browserCloseBeganAt:browserClose.state.startedAt,contextFirstObservedSettledAfterBrowserCloseBegan:!!(contextPending&&close?.state.settledAt!==null&&close?.state.settledAt>=browserClose.state.startedAt),afterBrowser,note:'Observed temporal order only; a single four-condition diagnostic does not prove device or general causal root.'};record(name,'cleanup-order',temporal);
    if(close?.state.status==='pending')throw new Error('Owned browser closed but retained context.close is still pending; stop before another browser condition');
   }
  }
  const result={condition,setupComplete:setupError===null,setupError,preClose,contextClose:close?.state??null,contextCloseObservation:closeObservation,browserClose:browserClose?.state??null,ready:ready?.state??null};results.push(result);save(name.replace('+','-')+'.json',result);save('partial-results.json',{scope:'Independent static-page diagnostic; original game outcomes unchanged',completedConditions:results.length,results});record(name,'condition.complete',{setupComplete:result.setupComplete});
 }
}catch(error){exitCode=2;record(null,'runner-error',{error:errorText(error)});}
finally{
 await new Promise((resolveClose,reject)=>server.close(error=>error?reject(error):resolveClose()));
 const summary={scope:'Exactly four fixed independent static-page conditions; no game/save/WebLocks/domain SDK or original-game fix claim',conditionsRequested:conditions,conditionsRecorded:results.length,conditionsCompleted:results.filter(row=>row.cleanupComplete!==false&&row.browserClose?.status==='resolved').length,conditionsWithValidSetup:results.filter(row=>row.setupComplete).length,results,contextObservationMs:observationMs,contextDeadlineScope:'Node pending observation only, not original game/performance budget',events:events.length,requestedExitCode:exitCode};save('result.json',summary);record(null,'run.body-complete',{requestedExitCode:exitCode,note:'Root execution wrapper owns actual process terminal/exit and source fingerprints.'});process.exitCode=exitCode;
}
