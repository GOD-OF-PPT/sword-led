# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: performance.spec.ts >> v5 native callback and trusted handlers pressure-long at1920
- Location: tests/release-v5/performance.spec.ts:74:97

# Error details

```
Error: native RAF JS p95

expect(received).toBeLessThan(expected)

Expected: < 16.7
Received:   17
```

```
Error: normal first contact

expect(received).toBeLessThanOrEqual(expected)

Expected: <= 200
Received:    228
```

# Page snapshot

```yaml
- generic [ref=f5e3]:
  - text: +
  - main "行脚灯炉" [ref=f5e4]:
    - generic [aria-hidden]:
      - strong: 锤下求生
      - generic: v0.8 炉边报价 · 三柄行囊
    - generic "契印与行囊" [ref=f5e5]:
      - generic [ref=f5e6]:
        - generic [ref=f5e7]: 契印
        - strong [ref=f5e8]: 3/3
      - generic [ref=f5e9]:
        - generic [ref=f5e10]: 铜钱
        - strong [ref=f5e11]: "243"
    - complementary "炉边剑架" [ref=f5e12]:
      - heading "候火的剑" [level=2] [ref=f5e13]
      - paragraph [ref=f5e14]: 拿起剑，拖给来客
      - generic [ref=f5e15]:
        - button "护刃 · 163" [ref=f5e16] [cursor=pointer]
        - button "护刃 · 228" [pressed] [ref=f5e17] [cursor=pointer]
        - button "护刃 · 60" [ref=f5e18] [cursor=pointer]
      - region "留给明天的剑" [ref=f5e19]:
        - heading "留一把，待明日" [level=3] [ref=f5e20]
        - generic [ref=f5e21]: 留一柄，给明天
        - paragraph [ref=f5e22]: 明日：新坯3
        - button "明日打算 ›" [ref=f5e23] [cursor=pointer]
      - generic [ref=f5e24]:
        - button "留给明天" [ref=f5e25] [cursor=pointer]
        - generic "配方选择"
    - generic "铁砧与当前兵器" [ref=f5e26]:
      - generic "巡灯护刃，叠纹，等级4，身价228，完好；仅造型展示"
      - button "在剑身上落锤" [ref=f5e27]
    - region "眼前的打造打算":
      - strong: 还差132估值
      - paragraph: 再攒3记普通锤，剑撑住后才有安全连锻。下一记普通锤裂损率3%；继续敲要承担这份风险。
    - region "当前剑的估值与状况":
      - paragraph:
        - generic: 作品估值
        - strong: "228"
        - generic: 护刃 · 无裂纹
      - paragraph: 估值用来验剑，铜钱按右侧报价入袋。
      - paragraph: 等级 4 · 已完成安全连锻 0次
      - generic:
        - paragraph: 下一锤裂损 3% · 首裂会掉价
        - paragraph: 锤势 3/6
      - button "落锤 左键剑身 / 空格" [ref=f5e28] [cursor=pointer]:
        - text: 落锤
        - generic [ref=f5e29]: 左键剑身 / 空格
    - complementary "等剑的来客与委托" [ref=f5e30]:
      - button "和来客聊聊" [ref=f5e31] [cursor=pointer]:
        - generic [ref=f5e32]:
          - generic [ref=f5e33]: 阿岚
          - generic [ref=f5e34]: 点来客，听听心愿
      - generic [ref=f5e35]:
        - paragraph [ref=f5e36]: 第4天 · 灯从炉起 · 关键约定
        - heading "守住渡口" [level=1] [ref=f5e37]
        - paragraph [ref=f5e38]: 好剑有它要去的地方
        - generic [ref=f5e41]:
          - generic [ref=f5e42]:
            - paragraph [ref=f5e43]:
              - strong [ref=f5e44]: 交付一柄
              - text: · 护刃 · 无裂纹 · 估值≥360
            - paragraph [ref=f5e45]: 还差132估值
          - img "第1柄尚未交付" [ref=f5e47]:
            - generic [ref=f5e48]: 待交
        - paragraph [ref=f5e49]: 合格后递给来客，才算交妥
        - paragraph [ref=f5e50]: 整单酬劳 100铜钱 · 已领 0铜钱
      - paragraph [ref=f5e51]: 渡口需要一柄无裂护刃，守住来往的人。
      - text: 收讫
      - button "卖给行会 · 实收57铜钱" [ref=f5e52] [cursor=pointer]
      - button "查看估值与实收说明" [ref=f5e53] [cursor=pointer]:
        - generic [ref=f5e54]: 余剑出售 · 本次实收57铜钱
        - text: 看报价说明 ›
    - generic "已装炉具":
      - button "备料1次" [ref=f5e56] [cursor=pointer]
    - region "随身手艺与炉具" [ref=f5e58]:
      - button "稳手护符" [ref=f5e60] [cursor=pointer]
    - button "回收这柄剑" [ref=f5e62] [cursor=pointer]
    - button "收工，封炉" [ref=f5e63] [cursor=pointer]
  - navigation "行旅工具" [ref=f5e64]:
    - button "暂停与行旅菜单" [ref=f5e65] [cursor=pointer]: 行囊
    - button "打开炉谱" [ref=f5e66] [cursor=pointer]: 炉谱
    - button "打开设置" [ref=f5e67] [cursor=pointer]: 设置
    - button "查看保存详情" [active] [ref=f5e68] [cursor=pointer]: 进度已收好
  - status [ref=f5e69]: 落锤 · 锻成 · 这一记后估值 228
```

# Test source

```ts
  1   | import {test,expect} from '../e2e/fixtures.js';
  2   | import type {RunState} from '../../src/core-v5/index.js';
  3   | import {KeyboardV5,v5Envelopes,v5Sdk} from '../e2e/v5-helpers.js';
  4   | import {maximumBurstFixture} from './audio-probe.js';
  5   | import {createAcceptedObserver,installAcceptedDiagnostics,readAcceptedRaw} from './accepted-observation.js';
  6   | import {installT03Runtime,t03Driver,t03Export,t03Idle,t03Pressure,t03Record,t03Stats,t03Step,t03StrikeFixture,t03Workshop,T03_BUDGETS,T03_KEYS,T03_SIZES} from './resilience-probe.js';
  7   | import type {T03RuntimeSample} from './resilience-probe.js';
  8   | 
  9   | // No screenshots, codec replays, video, Clock or trace overlap the measured animation interval.
  10  | test.use({trace:'off',video:'off'});
  11  | const paths=['pointer','space','enter'] as const;
  12  | type Path=typeof paths[number];
  13  | async function nativeInput(h:KeyboardV5,path:Path){
  14  |  if(path==='pointer')await h.page.locator('#v4-hit').click();else{await h.page.locator('#v4-strike').focus();await h.page.keyboard.press(path==='space'?'Space':'Enter');}
  15  | }
  16  | async function recordPageForeground(h:KeyboardV5,label:string){
  17  |  const read=()=>h.page.evaluate(()=>({at:performance.now(),visibilityState:document.visibilityState,hidden:document.hidden,hasFocus:document.hasFocus()}));
  18  |  const before=await read(),requested=process.env.V5_T03_BRING_TO_FRONT==='1';
  19  |  // Optional owned-tab activation is explicitly recorded before measurement reset/first input.
  20  |  // It does not preview audio, accept a game action, wait for focus, or retry a failed sample.
  21  |  if(requested)await h.page.bringToFront();
  22  |  const after=await read();await t03Record(h.info,label+'-foreground',{requested,operation:requested?'Playwright page.bringToFront once':'passive observation only',before,after,method:'Actual visibilityState/hidden/hasFocus on the page clock. Focus/blur/visibility events and per-RAF request/delivery state remain in runtime sample. No synthetic lifecycle event, window manipulation or causal host/GPU claim.'});
  23  | }
  24  | async function restoreTimed(h:KeyboardV5,source:RunState,label:string){
  25  |  const envelope=v5Envelopes(source);await h.page.waitForLoadState('networkidle');await h.page.goto('/assets/b/manifest.json');
  26  |  await h.page.evaluate(({envelope,keys})=>{for(const key of keys.filter(key=>key!=='sword-led.settings.v1'))localStorage.removeItem(key);localStorage.setItem('sword-led.save.v5',envelope.run);localStorage.setItem('sword-led.collection.v2',envelope.collection);},{envelope,keys:T03_KEYS});
  27  |  let navigationToReadyMs:number|null=null;
  28  |  try{
  29  |   await h.page.goto('/');await expect(h.page.locator('#v4-continue')).toBeEnabled();navigationToReadyMs=await h.page.evaluate(()=>performance.now());await h.assertDpr();
  30  |   const projection=await h.page.evaluate(()=>{
  31  |    const ready=window.v5AcceptedDiagnostics.continueReady;
  32  |    const entry=performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming|undefined;
  33  |    return{ready,navigation:entry?{responseEnd:entry.responseEnd,domInteractive:entry.domInteractive,domContentLoadedEventEnd:entry.domContentLoadedEventEnd,loadEventEnd:entry.loadEventEnd,duration:entry.duration}:null};
  34  |   });
  35  |   const pageProjectionReadyMs=projection.ready?.at??null;
  36  |   await t03Record(h.info,label+'-load',{phase:'title-ready-before-actual-continue',navigationToReadyMs,observedUpperMs:navigationToReadyMs,pageProjectionReadyMs,projection,observedAfterProjectionMs:pageProjectionReadyMs===null?null:navigationToReadyMs-pageProjectionReadyMs,bytes:Buffer.byteLength(envelope.run),journal:source.journal.length,sourceIdentity:{runId:source.runId,revision:source.revision}});
  37  |   expect(pageProjectionReadyMs,'one real page-side Continue readiness observation').not.toBeNull();
  38  |   await h.page.locator('#v4-continue').click();await expect(h.page.locator('#v4-workshop')).toBeVisible();
  39  |   const continueEvents=await h.page.evaluate(()=>window.v5AcceptedDiagnostics.continueEvents);expect(continueEvents).toHaveLength(1);expect(continueEvents[0]).toMatchObject({trusted:true,workshopVisible:true});expect(continueEvents[0]!.cost).not.toBeNull();
  40  |   const load={navigationToReadyMs,observedUpperMs:navigationToReadyMs,pageProjectionReadyMs,projection,observedAfterProjectionMs:pageProjectionReadyMs===null?null:navigationToReadyMs-pageProjectionReadyMs,bytes:Buffer.byteLength(envelope.run),journal:source.journal.length,continueEvents,continueMethod:'Page clock capture→bubble interval of the real Continue click. Product may initialize audio here; consumer does not preview, mute or warm it. Original post-Playwright observed upper bound remains alongside the first page-side visible/enabled projection.'};await t03Record(h.info,label+'-load',load);await recordPageForeground(h,label);return load;
  41  |  }catch(error){await t03Record(h.info,label+'-load-failure',{error:String(error),navigationToReadyMs,raw:await readAcceptedRaw(h.page),runtime:await h.page.evaluate(()=>({sample:window.t03Runtime.sample(),continueReady:window.v5AcceptedDiagnostics.continueReady}))});throw error;}
  42  | }
  43  | function actualHandlers(sample:T03RuntimeSample,path:Path){return sample.handlers.filter(row=>row.trusted&&(path==='pointer'?row.type==='pointerdown'&&row.target==='button#v4-hit':path==='space'?row.type==='keyup'&&row.target==='window'&&row.key==='Space':row.type==='keydown'&&row.target==='button#v4-strike'&&row.key==='Enter'));}
  44  | function rootHandlers(sample:T03RuntimeSample,path:Path){
  45  |  // Reuse the existing observer. Nearest preceding same-type root row is capture onGesture.
  46  |  // Space starts root work on down, while its direct commit listener runs on up.
  47  |  const type=path==='pointer'?'pointerdown':'keydown',key=path==='pointer'?'':path==='space'?'Space':'Enter',paired=[];
  48  |  for(let index=0;index<sample.handlers.length;index++){
  49  |   const direct=sample.handlers[index]!;
  50  |   if(!direct.trusted||direct.type!==type||direct.key!==key||direct.target!==(path==='pointer'?'button#v4-hit':'button#v4-strike'))continue;
  51  |   const capture=sample.handlers.slice(0,index).reverse().find(row=>row.trusted&&row.type===type&&row.key===key&&row.target==='div#app');if(!capture)throw Error('No root capture record preceding the actual forge listener');paired.push(capture);
  52  |  }
  53  |  return{paired,allRoot:sample.handlers.filter(row=>row.trusted&&row.target==='div#app'&&row.type===type&&row.key===key),method:'Nearest preceding root row paired by native dispatch order; all root rows retained. No second listener wrapper, percentile summation or total browser propagation claim. Space root cost belongs to keydown, direct commit to keyup.'};
  54  | }
  55  | 
  56  | for(const hz of [60,120,144])test(`v5 controlled${hz}Hz ordinary, safe burst and cancellation preserve exact command counts`,async({page},info)=>{
  57  |  test.setTimeout(600000);await installT03Runtime(page);await installAcceptedDiagnostics(page);const h=await t03Driver(page,info),results=[];
  58  |  for(const kind of ['ordinary','burst'] as const){
  59  |   const fixture=kind==='burst'?maximumBurstFixture(v5Sdk):t03StrikeFixture('ordinary');await h.restoreLegitimate(fixture.before);const observed=createAcceptedObserver(h,fixture.before,{name:`controlled-${hz}-${kind}`});await observed.capture('controlled-restored-boundary');await page.evaluate(hz=>{window.t03Runtime.cadence(hz);window.t03Runtime.reset();},hz);
  60  |   try{
  61  |    await observed.accept(fixture.action,()=>page.locator('#v4-hit').click());await expect(page.locator('#v4-strike')).toHaveAttribute('aria-busy','false');const idle=await t03Idle(page),sample=idle.before;await observed.persist('captured-after-controlled-idle');
  62  |    const measured={kind,hz,fixture,sample,idle,intervalMs:t03Stats(sample.frames.slice(1).map((frame,index)=>frame.at-sample.frames[index]!.at))};await t03Record(info,`controlled-${hz}-${kind}-raw`,{...measured,captures:observed.captures});
  63  |    const oracle=await observed.verifyAll();expect(observed.state).toEqual(fixture.after);expect(sample.inputs.filter(row=>row.acceptedAt!==null)).toHaveLength(1);expect(sample.contacts).toHaveLength(fixture.strike.hits.length);expect(sample.frames.length).toBeGreaterThan(0);results.push({...measured,oracle});
  64  |   }catch(error){await observed.persist('controlled-failed');await t03Record(info,`controlled-${hz}-${kind}-failure`,{error:String(error),actual:await observed.actualSnapshot('controlled-failed')});throw error;}
  65  |  }
  66  |  const fixture=maximumBurstFixture(v5Sdk);await h.restoreLegitimate(fixture.before);const observed=createAcceptedObserver(h,fixture.before,{name:`controlled-${hz}-cancel`});await observed.capture('cancellation-restored-boundary');await page.evaluate(hz=>{window.t03Runtime.cadence(hz);window.t03Runtime.reset();window.t03Runtime.hold(true);},hz);
  67  |  try{
  68  |   await observed.accept(fixture.action,()=>page.locator('#v4-hit').click());await expect(page.locator('#v4-strike')).toHaveAttribute('aria-busy','true');const beforeCancel=await page.evaluate(()=>window.t03Runtime.sample());expect(beforeCancel.pending).toBeGreaterThan(0);await page.keyboard.press('Escape');await expect(page.locator('#v4-dialog')).toBeVisible();const cancelled=await page.evaluate(()=>window.t03Runtime.sample());expect(cancelled.pending).toBe(0);expect(cancelled.cancelled).toBeGreaterThan(0);await page.evaluate(()=>window.t03Runtime.hold(false));await page.getByRole('button',{name:'继续锻造',exact:true}).click();const idle=await t03Idle(page);await observed.capture('cancelled-atomic-result-preserved');await observed.persist('controlled-cancel-idle');
  69  |   await t03Record(info,`controlled-${hz}-cancel-raw`,{beforeCancel,cancelled,idle,captures:observed.captures});const oracle=await observed.verifyAll();expect(observed.state).toEqual(fixture.after);
  70  |   await t03Record(info,`controlled-${hz}`,{scope:'Test-only timer RAF cadence; real native animations and legal atomic commands. Counts and full domain/RNG equality are observed; not physicalHz, real paint or GPU evidence.',hz,results,cancellation:{beforeCancel,cancelled,idle,expected:fixture.after,oracle}});await h.finish();
  71  |  }catch(error){await observed.persist('controlled-cancel-failed');await t03Record(info,`controlled-${hz}-cancel-failure`,{error:String(error),actual:await observed.actualSnapshot('controlled-cancel-failed')});throw error;}
  72  | });
  73  | 
  74  | for(const size of T03_SIZES)for(const kind of ['short','natural-long','pressure-long'] as const)test(`v5 native callback and trusted handlers ${kind} at${size.width}`,async({page},info)=>{
  75  |  test.setTimeout(600000);await page.setViewportSize(size);await installT03Runtime(page);await installAcceptedDiagnostics(page);const h=await t03Driver(page,info);
  76  |  let source=kind==='short'?t03Workshop():kind==='natural-long'?t03Workshop(12):t03Pressure(1890);if(source.reserveId)source=t03Step(source,{type:'reserve',pieceId:source.reserveId}).state;
  77  |  const perPath=[];let final=source;
  78  |  for(const path of paths){
  79  |   const label=`native-${kind}-${size.width}-${path}`,load=await restoreTimed(h,source,label),observed=createAcceptedObserver(h,source,{name:label});await observed.capture('explicit-timed-restored-boundary');await page.waitForLoadState('networkidle');await page.evaluate(()=>window.t03Runtime.reset());
  80  |   try{
  81  |    const blades=source.blades.filter(blade=>blade.status==='active'&&blade.id!==source.reserveId&&blade.suppliedDay===source.day&&blade.hits===0).slice(0,2);expect(blades).toHaveLength(2);
  82  |    for(const blade of blades)for(let hit=0;hit<3;hit++){await expect(page.locator('#v4-strike')).toHaveAttribute('aria-busy','false');await h.select(blade.id);await observed.accept({type:'strike',pieceId:blade.id},()=>nativeInput(h,path));await expect(page.locator('#v4-strike')).toHaveAttribute('aria-busy','false');}
  83  |    const idle=await t03Idle(page),sample=idle.before,handlers=actualHandlers(sample,path),root=rootHandlers(sample,path),inputs=sample.inputs.filter(row=>row.acceptedAt!==null),callback=t03Stats(sample.frames.map(frame=>frame.cost)),handler=t03Stats(handlers.map(row=>row.cost)),rootHandler=t03Stats(root.paired.map(row=>row.cost));
  84  |    const response=inputs.map(row=>({kind:row.kind,inputToAcceptedMs:row.acceptedAt!-row.at,firstContactMs:row.contactAt===null?null:row.contactAt-row.at,busyMs:row.idleAt===null?null:row.idleAt-row.at})),measured={path,load,callback,handler,rootHandler,root,response,sample,idle,callbackInvestigationRequired:(callback.max??0)>=T03_BUDGETS.callbackInvestigateMaxMs};await observed.persist('native-page-measurement-complete');
  85  |    await t03Record(info,label,{scope:'Native RAF and trusted listener wall time. Direct and root capture work are retained; Continue cold cost is a separate actual product click. Primary raw snapshots are formally decoded once after idle. Not GPU/compositor/full propagation/physical display certification.',budgets:T03_BUDGETS,source,measured,captures:observed.captures,environment:{browser:page.context().browser()?.version(),node:process.version,platform:process.platform,arch:process.arch}});
  86  |    const oracle=await observed.verifyAll();final=observed.state;perPath.push({...measured,oracle});expect(handlers).toHaveLength(6);expect(root.paired).toHaveLength(6);expect(inputs).toHaveLength(6);expect(sample.frames.length).toBeGreaterThanOrEqual(60);expect(inputs.every(row=>row.trusted)).toBe(true);
  87  |    expect.soft(load.navigationToReadyMs,'restore→visible enabled Continue (original observed upper bound)').toBeLessThanOrEqual(T03_BUDGETS.loadMs);
  88  |    expect.soft(load.pageProjectionReadyMs,'page-side first visible/enabled Continue projection').not.toBeNull();if(load.pageProjectionReadyMs!==null)expect.soft(load.pageProjectionReadyMs,'page-side first visible/enabled Continue projection').toBeLessThanOrEqual(T03_BUDGETS.loadMs);
  89  |    expect.soft(callback.p95,'native RAF JS p95').toBeLessThan(T03_BUDGETS.callbackP95Ms);expect.soft(callback.max,'max≥50ms requires investigation').toBeLessThan(T03_BUDGETS.callbackInvestigateMaxMs);
  90  |    const p95=kind==='short'?T03_BUDGETS.shortHandlerP95Ms:T03_BUDGETS.longHandlerP95Ms,max=kind==='short'?T03_BUDGETS.shortHandlerMaxMs:T03_BUDGETS.longHandlerMaxMs;
  91  |    expect.soft(handler.p95,'actual direct handler p95').toBeLessThan(p95);expect.soft(handler.max,'actual direct handler max').toBeLessThan(max);expect.soft(rootHandler.p95,'actual root capture handler p95').toBeLessThan(p95);expect.soft(rootHandler.max,'actual root capture handler max').toBeLessThan(max);
> 92  |    for(const row of response){expect.soft(row.inputToAcceptedMs,'trusted input→Accepted').toBeLessThanOrEqual(T03_BUDGETS.inputToAcceptedMs);expect.soft(row.firstContactMs,'ordinary contact observed').not.toBeNull();if(row.firstContactMs!==null)expect.soft(row.firstContactMs,'normal first contact').toBeLessThanOrEqual(T03_BUDGETS.firstContactMs);}
      |                                                                                                                                                                                                                                                                                                             ^ Error: normal first contact
  93  |   }catch(error){await observed.persist('native-path-failed');await t03Record(info,label+'-failure',{error:String(error),actual:await observed.actualSnapshot('native-path-failed')});throw error;}
  94  |  }
  95  |  expect(await t03Export(page)).toEqual(final);await page.screenshot({path:info.outputPath(`native-${kind}-${size.width}-post-measurement.png`)});await t03Record(info,`native-${kind}-${size.width}-summary`,{source,perPath,final,measurementNotes:'Each actual path keeps its first input and six Accepted commands. All animation/idle and raw capture finish before formal codec replays, exports, screenshots or attachments. Oracle timing never replaces page budgets. Screenshot uses this independently declared target size.'});await h.finish();
  96  | });
  97  | 
  98  | for(const size of T03_SIZES)test(`v5 native four-hit maximum safe burst callback budget at${size.width}`,async({page},info)=>{
  99  |  test.setTimeout(600000);await page.setViewportSize(size);await installT03Runtime(page);await installAcceptedDiagnostics(page);const h=await t03Driver(page,info),fixture=maximumBurstFixture(v5Sdk);expect(fixture.strike.hits).toHaveLength(4);
  100 |  const label=`native-four-hit-${size.width}`,samples=[];
  101 |  // Exactly three independent legal recoveries are decided before observing their costs.
  102 |  // A single four-hit animation may naturally contain fewer than60 application callbacks.
  103 |  for(const sampleIndex of [1,2,3]){
  104 |   const sampleLabel=`${label}-sample-${sampleIndex}`,load=await restoreTimed(h,fixture.before,sampleLabel),observed=createAcceptedObserver(h,fixture.before,{name:sampleLabel});await observed.capture('four-hit-restored-boundary');await page.waitForLoadState('networkidle');await h.select(fixture.action.pieceId);await page.evaluate(()=>window.t03Runtime.reset());
  105 |   try{
  106 |    await observed.accept(fixture.action,()=>page.locator('#v4-hit').click());await expect(page.locator('#v4-strike')).toHaveAttribute('aria-busy','false');const idle=await t03Idle(page),sample=idle.before,callback=t03Stats(sample.frames.map(frame=>frame.cost)),root=rootHandlers(sample,'pointer'),rootHandler=t03Stats(root.paired.map(row=>row.cost)),direct=actualHandlers(sample,'pointer'),directHandler=t03Stats(direct.map(row=>row.cost));
  107 |    const inputs=sample.inputs.filter(row=>row.acceptedAt!==null),response=inputs.map(row=>({kind:row.kind,inputToAcceptedMs:row.acceptedAt!-row.at,firstContactMs:row.contactAt===null?null:row.contactAt-row.at,busyMs:row.idleAt===null?null:row.idleAt-row.at}));await observed.persist('four-hit-page-idle');
  108 |    await t03Record(info,sampleLabel,{scope:'One independent legal restored maximum-burst boundary and one actual four-hit Accepted. Fixed sample1/2/3, including the first cold continuation/input. Real application RAF only; no no-op RAF, timer cadence, trace, geometry sampler or animation extension. Ordinary first-contact200ms is not silently applied as a new burst gate; actual burst response is fully retained.',sampleIndex,fixture,load,callback,root,rootHandler,directHandler,response,sample,idle,captures:observed.captures,budgets:T03_BUDGETS});
  109 |    const oracle=await observed.verifyAll();expect(observed.state).toEqual(fixture.after);expect(sample.contacts).toHaveLength(4);expect(inputs).toHaveLength(1);expect(inputs[0]!.trusted).toBe(true);expect(root.paired).toHaveLength(1);expect(direct).toHaveLength(1);
  110 |    samples.push({sampleIndex,load,callback,rootHandler,directHandler,response,sample,idle,oracle,actualState:observed.state});await t03Record(info,label+'-partial',{scope:'Fixed three-sample group in progress; prior original one-burst45/35 insufficient-sample reds remain separate and unchanged.',fixture,completedIndependentSamples:samples.length,samples});
  111 |    // Costs remain bounded for EACH sample; aggregation never conceals a slow member.
  112 |    expect.soft(callback.p95,'each actual four-hit callback JS p95').toBeLessThan(T03_BUDGETS.callbackP95Ms);expect.soft(callback.max,'each four-hit max≥50ms requires investigation').toBeLessThan(T03_BUDGETS.callbackInvestigateMaxMs);expect.soft(rootHandler.p95,'each burst root capture p95').toBeLessThan(T03_BUDGETS.longHandlerP95Ms);expect.soft(rootHandler.max,'each burst root capture max').toBeLessThan(T03_BUDGETS.longHandlerMaxMs);expect.soft(directHandler.p95,'each burst direct handler p95').toBeLessThan(T03_BUDGETS.longHandlerP95Ms);expect.soft(directHandler.max,'each burst direct handler max').toBeLessThan(T03_BUDGETS.longHandlerMaxMs);
  113 |   }catch(error){await observed.persist('four-hit-failed');await t03Record(info,sampleLabel+'-failure',{sampleIndex,error:String(error),actual:await observed.actualSnapshot('four-hit-failed'),completedIndependentSamples:samples.length});throw error;}
  114 |  }
  115 |  const actualFrames=samples.flatMap(row=>row.sample.frames),callback=t03Stats(actualFrames.map(frame=>frame.cost));await t03Record(info,label,{scope:'Exactly three independent legal restore→one four-hit Accepted→idle→formal-codec samples. The group contains three accepted commands and twelve contacts, not one animation or three complete campaigns. Aggregate samples are exclusively the real application callbacks already preserved per member; no physicalHz/GPU claim. Original45/35-case failures remain archived.',fixture,independentSamples:samples.length,acceptedCommands:samples.length,contacts:samples.reduce((sum,row)=>sum+row.sample.contacts.length,0),callback,samples,budgets:T03_BUDGETS,burstResponseScope:'Actual per-sample input/contact timings remain recorded, including any205ms observation. The existing ordinary200ms response gate is unchanged in the ordinary cases, not retroactively imposed or removed here.'});
  116 |  expect(samples).toHaveLength(3);expect(samples.reduce((sum,row)=>sum+row.sample.contacts.length,0)).toBe(12);expect(actualFrames.length).toBeGreaterThanOrEqual(60);expect(callback.p95).toBeLessThan(T03_BUDGETS.callbackP95Ms);expect(callback.max).toBeLessThan(T03_BUDGETS.callbackInvestigateMaxMs);await h.finish({independentMaximumBurstSamples:3,scope:'Fixed three legal recovered maximum-burst measurements, each1Accepted/4contacts with per-raw shipping codec verification after idle; not fresh complete games or one composite atomic command.'});
  117 | });
  118 | 
```