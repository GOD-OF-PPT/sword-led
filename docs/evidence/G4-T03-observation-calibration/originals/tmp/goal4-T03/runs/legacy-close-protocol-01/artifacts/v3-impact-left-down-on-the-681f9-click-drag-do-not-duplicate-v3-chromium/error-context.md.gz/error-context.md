# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: v3-impact.spec.ts >> left-down on the actual sword commits once, aim is cosmetic, hold/up/double-click/drag do not duplicate
- Location: tests/e2e/v3-impact.spec.ts:13:1

# Error details

```
Tearing down "context" exceeded the test timeout of 180000ms.
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - generic [ref=e5]:
      - text: 锤下求生
      - generic [ref=e6]: v0.6 炉前 · 三轮练手
    - generic [ref=e7]:
      - generic [ref=e8]: 第 1 / 3 轮 · 练手
      - generic [ref=e9]: 交差 0 / 180
      - progressbar "本轮交差进度" [ref=e10]
    - generic [ref=e11]:
      - generic [ref=e12]: 金币 0
      - generic "契约印记 3/3" [ref=e13]:
        - generic [aria-hidden] [ref=e14]: 契
        - generic [aria-hidden] [ref=e15]: 契
        - generic [aria-hidden] [ref=e16]: 契
    - button "暂停" [ref=e17] [cursor=pointer]
    - button "契约" [ref=e18] [cursor=pointer]
  - main [ref=e19]:
    - complementary [ref=e20]:
      - heading "今日三柄" [level=2] [ref=e21]
      - generic [ref=e22]:
        - button "◆ 青云剑 本轮 · 127" [disabled] [pressed] [ref=e23]:
          - text: ◆
          - generic [ref=e24]: 青云剑
          - generic [ref=e25]: 本轮 · 127
        - button "赤羽刀" [disabled] [ref=e26]
        - button "镇岳重剑" [disabled] [ref=e28]
    - generic [ref=e30]:
      - generic:
        - generic: 青云剑 · 叠纹
        - strong: "127"
        - generic: 当前身价 · 收手即可交差
      - generic [ref=e31]:
        - img "青云剑，叠纹，等级3，身价127，完好；外形不影响属性" [ref=e32]
        - button "铁砧 · 鼠标左键直接落锤，无需瞄准或卡时机" [disabled] [ref=e33]
      - status [ref=e34]: 大成 · 身价+69
      - generic [ref=e35]:
        - generic [ref=e36]: 下一锤裂损 0%
        - generic [ref=e37]: 大成 15% · 首次裂损仍能保住剑
      - generic [ref=e38]:
        - generic [ref=e39]: 锤势
        - generic [ref=e47]: 2/6
      - generic [ref=e48]:
        - button "落锤 左键点剑身 / 空格落锤" [disabled] [ref=e49]:
          - text: 落锤
          - generic [ref=e50]: 左键点剑身 / 空格落锤
        - button "交差 127" [disabled] [ref=e51]
        - button "留给下一轮" [disabled] [ref=e52]
      - generic [ref=e53]:
        - button "回收 · 10金币" [disabled] [ref=e54]
        - button "收工" [disabled] [ref=e55]
        - group [ref=e56]:
          - generic "看懂这一锤" [ref=e57] [cursor=pointer]
    - complementary:
      - img "阿岚在炉边等候出锋作品"
      - button "和阿岚聊聊，查看出锋的打造心愿" [ref=e58] [cursor=pointer]:
        - generic [ref=e59]: 阿岚 · 打造心愿
      - paragraph: 巡夜的路，想带一柄可靠的新剑。
      - button "本炉手札，已评鉴0/3，只读无额外奖励" [ref=e61] [cursor=pointer]:
        - generic [ref=e62]: 手札
        - generic [ref=e63]: 已评鉴 0/3
  - contentinfo [ref=e64]:
    - button "炉程" [ref=e65] [cursor=pointer]
    - button "玩法图解" [ref=e66] [cursor=pointer]: "?"
    - group [ref=e67]:
      - generic "声音与动效" [ref=e68] [cursor=pointer]: ⚙
```