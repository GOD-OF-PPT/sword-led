# FF DPR2 pressure1920 callback81：最小观测方案（未执行）

实际旧红只证明原pointer回调wall cost81ms，不证明GC／OS／paint根因。原行requested2966／stamp2989.94／begin2998／cost81，位于第四次contact2807后、idle3080前；请求与交付都visible/focustrue，p9511与其他原门通过，LongTasks在Firefox为null／NA。不能用再跑一次未复现便消除该红。

隔离候选在 `tmp/goal4-T03/drafts/slow-callback-observation/`：完整 `resilience-probe.UNEXECUTED.ts`、`slow-callback.UNEXECUTED.patch`及manifest。正式helper原SHA `d38b3428124ab1a10681d9133ec284cd09a8241d100072a2dfa5bdbabf4000b5`；候选SHA `0a9bcdbc29edf455971185757a965bd0b756aa68db5420bf6d985df0efed53da`。仅改T03Frame的诊断类型和原deliver的finally观测，不改产品／渲染、预算、callback选择、Clock、调度、样本或命令。

顺序严格为：原callback实际调用→finally第一项 `endedAt=performance.now()` 和 `cost=endedAt-begin`→其后才读callback.name；原cost>=50时才读原生Function.prototype.toString文本，保存前4096字符、原长度与截断标志。所有metadata误差／异常只在本行diagnostic.error显式记录，不覆盖callback原异常。metadataCostMs和记录时点单列；frames条数／request/delivery/visibility与所有原统计继续保留，不添加noopRAF或timer，也不把81改小或排除。

可定位的东西是“哪一个原回调函数对象／冻结bundle代码形状执行了这段wall区间”。root可在同一次有界原case结束后，将保留函数文本与当时dist主bundle逐字对应并绑定SHA；即使minifier把watch改名，source片段仍可与冻结产物核对。若只是匿名wrapper并隐藏真正闭包fn，则只能报告wrapper身份，不能杜撰内部callee。callback返回后创建Error.stack只会看到deliver／probe调用链，不是执行时真实callback栈，因此候选刻意不输出假栈或伪CPU占比。

**观测影响限界：** 先取cost只保证元数据不算进同一callback cost；读取source／追加诊断仍发生在同一个浏览器任务中，可能影响后续paint／callback排程。新run必须标为有此observer增量的诊断，不能把较低p95或未再现81称纯性能优化，也不能将metadataCostMs从原响应／预算手动扣掉。metadataCostMs只是已直接量到的本段观察耗时，不证明没有其他扰动。

最小激活／消费责任由root持有：当前冻结批次终态后核原SHA，review/激活此单helper候选，完成必要strict后，仅同一个既有 `native callback and trusted handlers pressure-long at1920`、FirefoxDPR2（原环境）单case；保每路径6输入、真实冷Continue／首锤、原3000/150/200与16.7/50等全部门、正式raw与测后oracle。不得同时跑browser／SDK重任务干扰。若有slow行读取函数身份后再决定下一步；若无slow行，本次只证明该次未再现，不回填原红。这里没有提出新case、seed扫、外部profiler部署或修改玩法。

本代理仅静态读源码并在隔离tmp写候选；未运行Node/SDK/browser/build/compiler，不产生新的性能数字或通过结果。正式helper字节未改。当前callbacks只在这一deliver创建T03Frame；新必需metadata字段由同一构造路径填写，静态未见类型／取消语义阻断，但尚不声称严格编译通过。
