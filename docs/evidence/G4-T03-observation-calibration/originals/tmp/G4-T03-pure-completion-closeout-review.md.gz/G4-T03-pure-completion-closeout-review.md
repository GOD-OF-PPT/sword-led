# 正确 late-completion 责任独立复核

结论：更正协议下，旧声取消、较新授权归属与明确试听重试的有界责任可以闭环；有一项机制文案需随归档勘误。不是把旧137/138改成138/138，也不是全音频、物理扬声器或整体T03完成。本审阅只读源码、两份proof、report/process/end-fingerprint及57份关联原件，未运行浏览器/构建/SDK/新测试，未改共享文件。

当前 probe SHA `712d822f846bfa8cf3f91100551f370c8d48394aa871806a8e41d022c0b9d6ef` 与独立审阅候选相同；shared audio 仍为 `6d86b2b4d4f4c35f32f8128110d66cb6f94587b870e3e27522d61f576119b263`。native resume 与原调用同栈，held只门控其结果交付；release不发native API。票据绑定context/id、重复释放幂等，原拒绝值和内部拒绝处理保留；产品epoch/旧finally/较新授权逻辑未改。构造器显式suspend仍是声明的注入，本次不是无故障普通玩家场景。

| 实际运行 | 结果 |
| --- | --- |
| pure-completion-title-01 / PID6812 | 原WK DPR1标题固定3次，actual0、3/3；旧声0、新声3，峰值.02679–.02960。 |
| pure-completion-fault-axis-01 / PID7253 | 原8项defer＋明确重试，9×三引擎两DPR＝54/54，actual0。 |

两批均0跳过/flaky/重试，结束fingerprint matches true；本批418源/82运行文件保持。独立核对57个链接SHA及原始ops：每个held id恰有一次原resume-call/native-start，早于release 54–1394ms；原native终态与同票据的一次交付终态对应，release无native-start。全部final active0、sources断开。原动作与>.001波形/旧cue/保存门未变：暂停/标题/新局旧声0后新声3，关设置取消0后新试听3，静音/零音量/系统动效取消0，跨设置新试听3，明确重试总6且旧释放不加声。正式case保留原文等值；六份明确重试before/after亦直接全等，不能因此称实测0次Storage写API。实际held均native成功；原生拒绝门闩仅静态证明，不冒称新增拒绝实验。

文案余项：`audio.spec.ts:142` 已正确描述新协议，但 `audio-preview-retry.spec.ts` 的 finally.scope 及本批六份原件仍写“holding the next native resume invocation”。应保原件，在本批proof/归档manifest标明旧措辞已过时、实际操作为仅延迟completion；未来消费者文字同步更正，不改动作/阈值，也不为文字重跑54次。这不推翻原始操作或行为结果。

旧137过/1红及其probe/source/runtime、native挂起/clock0和撤回候选全部按旧身份保留。旧defer实际延迟native调用到release，混入原手势之外激活和构造器暂停；旧记录“仅完成晚到”的描述不成立，不能继续作为正确late-completion未闭的依据，也不能直接推出未注入产品同因。新57份成功与旧真实失败并列：不抹失败、不称旧复合故障消失、不归咎环境。其他未重跑声音、真实听感及非声音/T04责任保持各自身份；不再建议声音产品候选或盲测。

依据：`tmp/goal4-T03/pure-completion-title-protocol.json`、`pure-completion-axis-protocol.json`及其链接原件、两运行目录的正式回执。复核未发现行为阻断；上述文案勘误随归档处理。
