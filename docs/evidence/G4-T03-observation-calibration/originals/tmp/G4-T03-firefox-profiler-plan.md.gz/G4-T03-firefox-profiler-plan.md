# FF DPR2 pressure1920：本地真实采样可行性与限界

状态：仅只读调查／未执行命令草稿。没有启动Firefox、安装工具、运行Node/SDK/browser/build/profile或上传文件，也没有修改当前54冻结输入。本机当前PATH的 `shutil.which('profiler-cli')` 与 `shutil.which('samply')` 均为None；所查本项目node_modules、常见npm全局／Homebrew receipt路径和用户cargo bin也没有对应包／可执行文件。这不是全盘软件清单，准确结论是本次可见位置没有可直接调用的这两项工具。

## 官方能力与选择

无需这两个CLI也能先用Firefox内置profiler。Mozilla文档明确给出启动采样及退出写本地JSON的环境变量，macOS也适用；本次只取STARTUP／FILTERS／SHUTDOWN，不开启HTTP日志、远程symbolication或上传。[Mozilla：启动采样并退出保存](https://firefox-source-docs.mozilla.org/networking/http/logging.html#capturing-a-profile-with-logs-at-startup)

内置profiler支持统计栈采样、JS/native/label帧及markers，并能记录线程实际CPU时间和采样开销。因此真实profile有机会区分执行工作与等待，但功能／平台数据必须看本次文件，不能仅由环境变量推定齐全。[Mozilla：Gecko Profiler](https://firefox-source-docs.mozilla.org/tools/profiler/)、[Mozilla：采样、CPU与开销](https://firefox-source-docs.mozilla.org/tools/profiler/code-overview.html#periodic-sampling)

这是调查方案，不是“81ms已经归因”。当前81ms只有同一个callback执行区间的wall时长；原request/delivery可见且有焦点，也不能证明CPU用了81ms。

## 一次既有case的命令草稿（未执行）

root须先结束当前冻结批次，review/激活已准备的after-cost函数身份observer并完成必要严格检查，再绑定新的source/consumer/runtime指纹。下列仅一个既有FF DPR2原pressure1920case，保留原headed、显式bringToFront、三路径六输入、冷Continue／首锤和所有预算；不加noopRAF／timer／重试。输出目录必须全新，shutdown路径为绝对路径。

```sh
rtk proxy mkdir /Users/gordon/githome/sword-led/tmp/goal4-T03/runs/ff2-pressure-profiler-01
rtk proxy env \
  MOZ_PROFILER_STARTUP=1 \
  MOZ_PROFILER_STARTUP_FILTERS=GeckoMain \
  MOZ_PROFILER_SHUTDOWN=/Users/gordon/githome/sword-led/tmp/goal4-T03/runs/ff2-pressure-profiler-01/firefox-profile.json \
  V5_T03_BRING_TO_FRONT=1 \
  V5_RELEASE_REPORT=tmp/goal4-T03/runs/ff2-pressure-profiler-01/report.json \
  npx playwright test tests/release-v5/performance.spec.ts \
  --config playwright.v5-release.config.ts --project firefox-dpr2 \
  --grep '^v5 native callback and trusted handlers pressure-long at1920$' \
  --headed --workers 1 --retries 0 \
  --output tmp/goal4-T03/runs/ff2-pressure-profiler-01/artifacts
```

进程必须正常退出才有shutdown产物的预期；不存在、空、截断或仅父进程数据均不能称采样成功。现有runner应保存actualexit／begin-end fingerprint与环境，另核本地profile字节/SHA；不重新跑同一目录覆盖。如果Playwright的Firefox构建未支持／未保留这组profiler能力，应如实停在“采样不可用”，不安装别的浏览器或用非原运行器结果代填。

## 与after-cost函数身份补丁的必要关联

候选在 `tmp/goal4-T03/drafts/slow-callback-observation/`，原helperSHA d38b3428...、candidate0a9bcdbc...。先取原cost终点，再读name；达到原50ms调查线才保存函数文本，能把慢callback对应到当时冻结bundle，不能给出执行时栈。采样负责真正的执行栈／CPU数据，两者职责不同。

应在同一诊断的每次页面导航后、测量reset之前只读留存 `performance.timeOrigin`，或将其放到after-cost诊断字段。原case三路径会导航，裸 `performance.now()` 数值不能跨页面直接对齐。用该文档的timeOrigin＋callback begin/end建立页面时间窗口，再根据实际profile的进程／页面／时间基准核对内容GeckoMain及目标区间；不可把旧JSON的2998ms硬套到新profile。时间基准用途见[Mozilla MDN：performance.timeOrigin](https://developer.mozilla.org/en-US/docs/Web/API/Performance/timeOrigin)。这项读数不放到原callback cost区段，不生成新的测试帧或业务命令。

## 什么证据才足以缩小原因

本段是本地诊断判断标准，不是声称已取得的结果：

- profile须实际包含目标内容进程GeckoMain、页面URL／导航关联、目标时间范围、足够栈样本和可用CPU running-time数据；还要核buffer没有淘汰早期pointer慢段。只见父进程、native地址无法映射、CPU字段缺失或样本空洞，均属于证据不足。
- 若重现慢回调，且该区段线程CPU增量高、连续样本落在同一应用JS调用链，可支持“此函数链在该区段执行了显著CPU工作”。采样是统计近似，不保证逐函数精确加和等于81ms，也不能因名称含paint就认定整段绘制。
- 只有GC／layout等真实marker或符号化调用链与同一窗口重叠，才能据该数据说它们参与；仍应区分inclusive/self及重叠。没有marker、符号或CPU数据不能猜GC。
- 若该wall窗口线程CPU增量很低且实际栈／marker显示等待，可支持“主要非CPU执行”。仅GeckoMain仍不能区分GPU、I/O、锁还是主机调度；**没有样本不等于OS暂停**，采样器也可能延迟。现方案不凭这次有限采样扩成OS/GPU认证。
- 若单次未重现50ms以上回调，只能记录这次未再现和常规函数分布，原81红仍保留；不得选最小值求绿。profile与函数source记录都有观察开销，必须报告实际采样开销／meta配置，不能将profile run当原无profile预算基准或扣掉开销改原门。

“足够”的准确答复：**函数身份＋实际有效采样是一次有界原case定位的合理最小组合，但不保证一次就能分清所有CPU与wall原因。** 必须以上述真实数据完整性和慢段重现为前提；profile尚未产生时，归因依旧未完成。所有输出留本地，先离线检查JSON实际meta／线程／样本结构；本方案不调用profiler网站上传或发送profile，也不为可视化安装新依赖。
