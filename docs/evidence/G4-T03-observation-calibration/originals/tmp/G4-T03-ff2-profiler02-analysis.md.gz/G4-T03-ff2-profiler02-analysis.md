# FF DPR2 pressure1920：实际 profiler02 有界分析

**结论：有有效内容主线程 CPU／JS 栈，本次 30／31ms 可对齐到锤击结束后的重投影；原 81ms 未重现、未定位、未关闭。** 本次 profile 下 pointer p95=17ms（原门 <16.7）及首 contact=228ms（原门 ≤200）仍红；space／Enter 原门通过。这是诊断运行，不能替换无 profiler 基线或宣称优化。

身份：`runs/ff2-pressure-profiler-02/process.json` 实际 terminal／exit1，结束指纹 consumer1／fingerprint0、418源／82产物无变化。`01/stdout.log` 的 `No tests found` 原红仍在，02 才是首个实际采样。只解析既有本地 JSON，未启动浏览器／SDK／构建、未安装或上传。

原生 profile：53,181,242B，raw schema36；Firefox157／macOS26.6.2；1ms，features=`js,mainthreadio,fileio,fileioall,screenshots,stackwalk,ipcmessages,processcpu`。命令请求2M entries，**实际 meta capacity=16,777,216**，以原生记录为准。Web Content `GeckoMain` pid9392／tid9701753 有40,757 samples、40,756个 `threadCPUDelta`（µs），范围62.953–41,252.484ms，shutdown41,256.850ms，无 pausedRanges。Parent／WebExtensions／Utility 另有主线程；未采集其他线程完整栈。三次 `/` 页面 innerWindowID 12884901890／892／894、相关 input／rAF／Styles markers 和本文区段均在保留窗口内。

用 `path.environment.timeOrigin + page.now − content.meta.startTime(1792702250899.177)` 初对齐，再用相应页面的 rAF start/end marker 复核；三个偏移为5569.823／18772.823／28654.823ms。页内整数时钟与采样端点约有1ms量化差，不能把邻接 marker 自动算进回调。

| 本次路径最大值 | 同页原生 rAF marker，content ms | 采样／CPU delta近似合计 | 实际栈与 marker |
| --- | --- | --- | --- |
| pointer30ms | 11608.580–11637.786（29.206ms） | 28／18.886ms | 28含 `collection:R`，24含 `main:X`；Styles9个 inclusive samples，样式区间合计7.492ms，两个 sync reflow 合计3.171ms；未采到 drawImage |
| Space31ms | 20241.054–20271.636（30.582ms） | 28／26.696ms | 28含R、26含X；Styles4、baseline compilation5、drawImage1个 samples。此前 CCSlice 20227.798–20240.207 **已在 rAF 前结束** |
| Enter17ms | 32224.896–32242.403（17.507ms） | 18／13.745ms | 18含R、15含X；视图推导／DOM样式布局／Canvas路径有样本 |

冻结 bundle 的 R 对应 [forge.ts:165](../src/presentation-v4/forge.ts#L165) `watch`，在结束处 `render(); own.done()`；done 对应 [app.ts:117](../src/presentation-v5/app.ts#L117)，X 对应 [app.ts:299](../src/presentation-v5/app.ts#L299) 整体 `render()`。因此本次有“结束重投影”实际采样支持，尚不能称单一 Canvas 瓶颈。R 下另能见 `debugger eval` query／serialize 栈；这些是实际测试环境的一部分，不能把整段 CPU 都记作纯产品函数成本。inclusive sample 数可重叠，不是逐函数毫秒；CPU delta按终点落窗求和，边界区间／采样与 profiler 开销均保留，wall−CPU 不能直接命名为 OS／GC 停顿。

读写定位：pointer／Space／Enter最大回调分别有12／6／6个 **inclusive** samples 含 `get Element.clientWidth → PresShell::DoFlushPendingNotifications Layout → Styles/Reflow`；实际链为 `watch → renderer.render → paintBladeProjection → paintWhenChanged`，或 `watch → done → app.render → draw → renderer.render → …`，读端对应 [forge.ts:61](../src/presentation-v4/forge.ts#L61)，发生在像素cache命中判断前。renderer本身在读前写scene dataset／canvas aria（139–143），app在draw前还执行 [charge七节点replaceChildren:250](../src/presentation-v5/app.ts#L250) 与 [paper三dataset写:127](../src/presentation-v5/commission-paper.ts#L127)（130行key相同返回之前）。**读端触发同步flush有栈；是哪一次写入使其失效则未定位。** 三段最大回调未采到 `replaceChildren`／`DOMStringMap` 栈，不能给charge或paper分配self耗时；首contact228窗虽有4个replaceChildren样本，其调用方也不唯一。impact的geometry投影读仅有源码路径；最大回调未采到getBoundingClientRect，不能替它预填热点。当前证据适合指导后续读写边界定位，不足以据猜测新增产品cache。

首 contact228：page input3062／Accepted3081／contact3290；首个直接 handler63ms（不是6次最大74ms）。早期 rAF3169→下次3271有102ms交付间隔，contact callback3271–3290为19ms。对应原生102.255ms间隔有102 samples，其中68含 `TaskController::GetRunnableForMTTask::Wait`、29含 JSActor，能见 Juggler `_ariaSnapshotForExpect`／aria树；该窗 CPU delta约31.362ms。contact rAF18.859ms有19 samples／约13.640ms CPU，含 impact/cue/readout。**228ms不是228ms产品同步执行**；含真实动画进程、调度间隔与测试协议工作，不能据此确认其唯一原因，更不能解释另一运行的81ms。

可复核摘录／全SHA：[independent-profile-extract.json](goal4-T03/profiles/ff2-pressure-profiler-02/independent-profile-extract.json)，含三份输入、各 timeOrigin、marker／栈／CPU原字段、冻结418／82身份及8个所引用源／bundle当前SHA逐项全等。原 profile SHA256=`bffcbccb32bcd9aa283ad74d4743db6c5c46cad4887c066eda6be05e8ab5760d`；摘录SHA=`1c7112c44d6a9c98dd1012c93b3b6771d651bf0ae468ff898517f888688ca67a`。profile与三路径原JSON读前后SHA均未变。未新增产品必修结论；原81ms调查门、T03余项继续开放。
