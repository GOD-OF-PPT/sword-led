# G4-T03 final impact map

Current source baseline: `15bad19430b6cffcf7eaccc9690841a3472ce341` (parent identified15bad19; worktree read clean). This read-only map inspects existing fingerprints/report JSON and source dependency boundaries. It does not run SDK/replay/browser/build or edit source/tests/config/official docs. Current dist82 files match the complete payment-ui04 runtime fingerprint by direct bytes/SHA read. Shipment/HTTP4179 facts come from the parent receipt and tasks record, not a new browser session here.

**Decision:** preserve every old result with its original build, engine, DPR and environment. Use exact unchanged mechanism dependencies plus explicit differential bridges to avoid rerunning unrelated384 T01/T02 checks. Changed output, native audio timing, memory retention and actual pixel/readability/performance observations still require affected current-build consumption. No old green is renamed a current-bundle run. Original53 logical×6=318, system-native6 and targeted legacy18 remain the accounting scope.

## Evidence identities and bridges

| Existing evidence | Actual scope | Current use |
| --- | --- | --- |
| build11 non-audio-matrix01 |30 logical×6=180;153pass/27fail,0skip/retry | Historical input/resource/lifecycle/load/geometry/timing facts only; individual affected groups below |
| audio-headed-matrix01 |23×6=138;126pass/12fail | Earlier pre-queue output/cancellation evidence; preserve all original reds |
| build12 audio-cue-preflight02 |Firefox DPR1 headed23/23 actual0 | Current audio.ts/forge/probe/spec bytes match this run; core allocation and payment surface changed later, bridged separately, so it is still a build12 run |
| build12 forge-perf-preflight02 |FF DPR2 headed1280 four cases,2pass/2fail | Records post-cache CPU costs/fixed3 pass and contact323/page-ready3029/3234 failures; no claim latest allocation meets3000 yet |
| canvas-equivalence01 |Chromium DPR2,7 legal boundary selections,3family+5stage union and growth/crack/broken/resize/hidden/retry | Exact before/after bitmap/alpha/metadata bridge for unchanged current cached forge; not15family×stage exhaustive nor cross-engine performance |
| golden-core-allocation02 |Actual0;4908 edges/25 paths/32 checkpoints/174ownership rows; all inputs unchanged | Oldbuild11 vs current v5 SDK full-result/domain/state/RNG/event/view/codec/collection/qualification and mutable/frozen/mixed ownership bridge; does not prove page timing/native output/leaks |
| payment-ui04 + publication smoke02 |Current82; two PC sizes, actual sale10/commission120/day8 158+127, explanations raw0write; parent actual publication receipts | Current payment projection/ordinary HTML wiring and bounded release smoke only; not whole53 matrix |
| native02 + pointer03 |Old80:5pass+1initial consumer failure, then pointer-only1pass | Trusted heap/BFCache/real minimized-window historical mechanism proof; current6 still distinct |
| legacy-input01 |Actual9pass: v3 one×3 and v4 two×3; no v2-audio cases ran then | Shared direct-input regression at old source; cannot report current configured18 as already done |

Current original protection exceptions remain110old source+3shared(input/audio/forge),6core+game.ts,8SDK+v5SDK; other protected originals/ref unchanged responsibility. No new rule/schema/RNG/wallet/eligibility exception is introduced by this map.

## Exact dependency checks

Compared with non-audio01, direct-strike-input.ts, browser-session.ts, writer-lease.ts, persistent-session.ts, storage.ts, settings.ts, artwork-recovery.ts and input/resilience/accessibility/readability helper source bytes remain identical. core-v5/game.ts, audio.ts, forge.ts, app.ts and the current payment/text/CSS surfaces changed. accepted-observation.ts/performance.spec.ts and audio probe/spec also changed for the recorded readiness/fixed3/single-active-sample fixes. Both lifecycle harness JS and CSS bytes changed, so the old same-realm harness run cannot certify the new harness.

Compared with audio-cue-preflight02, current audio.ts SHA6d86b2b4d4f4c35f32f8128110d66cb6f94587b870e3e27522d61f576119b263 and forge.ts SHA91905bd97d60bf57d5bea137836ba7f4a5855e98aa850916d1b09517e76270a2 match; audio probe/spec and all release observers match too. The later delta is core allocation and payment app/template/text/CSS plus lifecycle harness. Core old/new same-value and payment current UI evidence are explicit semantic bridges, never a fabricated new full audio run.

## Group-by-group retention and current delta

| Logical group / original projects | What can remain under its old identity | What actually needs a current/delta run |
| --- | --- | --- |
| Input4×6=24 | All24 passed. Dedicated spec, direct-input implementation, browser/session/storage/lock code and hammer timing remain identical; later app changes concern payment text/read-only modal, while coregolden preserves results. Keep exact input/routing/zero-command/native250gate old observations; no evidence requires mechanically repeating these24. | Existing current performance/native consumption provides changed render/timing and native lifecycle edges; re-run an input leaf only if its relevant source/selector/context semantics change or a fresh failure appears. Do not call old24 “current bundle24”. |
| Controlled60/120/144Hz3×6=18 | All18 passed. Controlled cadence observer, domain counts, hammer timing/two-real-frame contract remain; allocationgolden and pixelpair bridge core/render output. Retain logical count/atomicity/cancel evidence under old build. | The later per-native-callback costs/contact scheduling are covered by native performance groups, not by another syntheticHz sweep. Do not turn controlled timers into physical display/GPU evidence. |
| Resource recovery5×6=30 | All30 passed. Source identity/retry transport/count/source decode, actual zero-write/raw observations and unchanged artwork-recovery lifecycle remain valid historical proof. | Cache/app/template now differ. Reuse the same five bounded existing cases over six projects for current render/fallback/retry/three auxiliary entry wiring, especially seven main/thumb/prop assets. No new resource cases or seeded outcomes. Pixelpair alone is oneengine bridge, not six-engine current retry. |
| Saved/system motion1×6=6; twenty production cycles1×6=6; same-realm dispose1×6=6 | All18 passed historically, retaining actual old listener/rAF/WAAPI/audio cleanup baselines. | Current audio waiting set and renderer cache add owned state, app adds a new modal/button and lifecycle harness outputs changed. Reuse these three cases×six with current actual harness/module fingerprints. Payment raw0write is not leak evidence. Detached nodes strongly retained by probe stay report-only. |
| Qualified1898→1900 exits1×6=6 and2049 raw preservation1×6=6 | All12 passed; storage/writer/raw-export source remains; golden02 exactly replays actual1898/1900 main/sale/recovery/exit and preserves2049 validator/codec errors. Retain original browser fault/raw/export semantics as old proof. | Current core load<=3000 and latest app export/button integration are still real browser responsibilities. Reuse current long-load/combined-fault/actual native consume plus a bounded existing near-limit exit as needed; do not regenerate a fresh longfixture per irrelevant path or repeat old fulljourneys. If exact latest six-engine UI certification is asserted for these cases, run their existing case bodies; otherwise label the layered old+golden bridge explicitly. |
| Readability5×6=30 | Original27pass/3fail retained. Helper methods/required four fields/actual scrolled scene/card/traits sampling remain source-identical. | All five current case bodies touch new quote text/button, paper/rack CSS or combined risk/export layout. Reuse them×six; preserve12px/4.5/44 and two sizes, also include current quote control in stated current coverage. Old3reds are not resolved by color source edits or paymentC1 screenshots alone. |
| Native performance6ordinary+2four-hit=8×6=48 | Original24pass/24fail and old raw costs remain, plus later FF2 four-case partial proof. | Coreallocation affects restore CPU, cache affects paint/direct handlers, environment scheduling caused late contacts. Run these same8 logical×six at original two sizes and all original budgets after root resolves true long-load priority. Retain both oldobservedUpper and pageProjectionReady, Continue cold cost, firstcoldinput, >=60realcallbacks and fixed3bursts. No synthetic cadence or timinggate relaxation. |
| Audio gameplay15logical×6 | Firstgameplay1, five strike outcomes, earned4hit1, persistedmute/zero2, failureblocked/unavailable2, latepause/title/newrun3, atomicburstpause1. Current audio/renderer/probe/spec bytes match build12 FF1all23, and golden bridges domain events; retain FF1build12 identity as specific same-mechanism proof. | Queue changed game-cue timing after old138, so remaining five projects need current original15 gameplay cases (75executions) to resolve oldF2 reds and establish queue/output native behavior. A current FF1 wiring witness can be folded into root current audio/native/perf work; no need to pretend build12 is new or repeat23FF1 solely for text. If root wants a whole current audio batch, run23×6 and label it so; dependency map itself does not invent that run. |
| Audio preview8logical×6 | Coldtitle/preview, pendingpreviewclose, previewmute/zero/systemmotion3, repeatedpreviewcap, twentycycles, explicitnewpreviewownership. Preview path itself is not queued, and gesture/pending/preview implementation matches post-queue FF1run. Earlier successful preview leaves retain their nativegraph/stop/cancel observations, with scope unchanged. | Corrected consumers still need actual oldunresolved leaves: pendingpreviewzero W1/W2 (native slider mouse correction) and twentycycles C1/F2 (single successful active-snapshot consumer); FF1twenty already passed correctedbuild12. Preserve original consumer failures. Current lifecycle cases also exercise normal sound cleanup; do not claim isolated oldpreviewgreen is a new whole audio batch. |

The audio15+8 partition covers all23 exactly; it does not remove six-project responsibility. The historical report still has138rows and the matrix ledger below retains every row. Delta scheduling can be split by relevant source identity, but the final report must show each original project outcome and its current bridge/new result rather than summing mixed versions into “latest318pass”. An unresolved old red requires a real resolving observation in its engine/DPR; a static proof is not a pass substitution.

## System native6 and targeted legacy18

| Responsibility | Required actual current evidence |
| --- | --- |
| native space-minimize / pointer-minimize | Current self-created systemChrome/headful/profile cleanup; trusted realblur/visibility, actual minimized bounds, oldrelease raw unchanged before any observer UI, freshAccepted formal equal. Pointer explicitly uses owned focus handoff while sounding before actual minimization, not a false claim that OSmin alone stopped190ms sound. Audioqueue/cache/app/core changed since old80, so current both must run. |
| native clean-cache / dirty-cache / memory-cache / stale-cache | Current trusted persistedpageshow+sameheap, writerB actual run/book update, readonlyday projection, oldSpace/oldconfirm no overwrite, correct dirty/memory authority/export and explicit continuation/newinput. Current4 must run; oldproof remains historical, not new current native green. |
| legacy v2 native waveform/mute/pause/menu/reload; delayedresume; denial =3×3=9 | These are already existing v2-audio specs now in the configured scope. Current sharedaudio changed; v2-specificcore/SDK unchanged. Execute existing9 acrossC/F/W with honest output environment and original gates. They were absent from old9case run and cannot be backfilled. |
| legacy v3 sword left-down/aim/hold/up/dblclick/drag =1×3=3 | Shared direct-input byte unchanged since old9pass, but sharedaudio changed; retain oldinput evidence and execute existing3 as the cheap current integration witness. No fulllegacygame/model. |
| legacy v4 face/steel twoPCsizes +250ms/two-contact/busySpace/cancel =2×3=6 | Sharedforge now caches while currentaudio changes, so original6green is historical. Execute same6 current and keep realcontact/opaqueface/twoframes/raw outcome gates. No seed/model sweep or original47fullmatrix expansion. |

Total current native6 and legacy18 are small existing targeted responsibilities; they are not replaced by Playwright WebKit=Safari naming or DOM-synthesized lifecycle events.

## Original53 logical ledger (historical outcomes, not current claims)

Project codes: C1/C2=ChromiumDPR1/2, F1/F2=FirefoxDPR1/2, W1/W2=WebKitDPR1/2. Audio rows belong to headed audio-headed-matrix01; other rows to headless non-audio-matrix01. A red code is the original report outcome, regardless of a later partial correction.

| File | Exact logical title | Old pass/6 | Original red projects |
| --- | --- | ---: | --- |
| accessibility.spec.ts | v5 actual workshop, earned collection, work details and settings readability at1280 | 4 | C2,W2 |
| accessibility.spec.ts | v5 actual workshop, earned collection, work details and settings readability at1920 | 6 | — |
| accessibility.spec.ts | v5 legal maximum three-sword rack and real settings refusal stay readable at1280 | 5 | W1 |
| accessibility.spec.ts | v5 legal maximum three-sword rack and real settings refusal stay readable at1920 | 6 | — |
| accessibility.spec.ts | v5 actual cracked1898 pressure state survives run and settings refusal with usable risk/export/retry | 6 | — |
| input.spec.ts | v5 input tail: native aim and Control Alt Meta clicks never change a legal forge state | 6 | — |
| input.spec.ts | v5 input tail: native callbacks gated at250ms keep doubleclick and busy Space from queuing a later strike | 6 | — |
| input.spec.ts | v5 input tail: pointer cancellation cannot swallow the next detail-zero accessibility activation | 6 | — |
| input.spec.ts | v5 input tail: a background source change cancels held Space while the active page keeps focus | 6 | — |
| performance.spec.ts | v5 controlled60Hz ordinary, safe burst and cancellation preserve exact command counts | 6 | — |
| performance.spec.ts | v5 controlled120Hz ordinary, safe burst and cancellation preserve exact command counts | 6 | — |
| performance.spec.ts | v5 controlled144Hz ordinary, safe burst and cancellation preserve exact command counts | 6 | — |
| performance.spec.ts | v5 native callback and trusted handlers short at1280 | 4 | F2,W2 |
| performance.spec.ts | v5 native callback and trusted handlers natural-long at1280 | 4 | F2,W2 |
| performance.spec.ts | v5 native callback and trusted handlers pressure-long at1280 | 2 | F1,F2,W1,W2 |
| performance.spec.ts | v5 native callback and trusted handlers short at1920 | 3 | F2,W1,W2 |
| performance.spec.ts | v5 native callback and trusted handlers natural-long at1920 | 3 | F2,W1,W2 |
| performance.spec.ts | v5 native callback and trusted handlers pressure-long at1920 | 2 | F1,F2,W1,W2 |
| performance.spec.ts | v5 native four-hit maximum safe burst callback budget at1280 | 4 | F1,F2 |
| performance.spec.ts | v5 native four-hit maximum safe burst callback budget at1920 | 2 | F1,F2,W1,W2 |
| resilience.spec.ts | v5 seven actual forge asset failures retry once without a game command or reload | 6 | — |
| resilience.spec.ts | v5 failed opening scene recovers its canonical art while keeping zero Accepted commands | 6 | — |
| resilience.spec.ts | v5 actual delivery image failure is reported and retried from settings | 6 | — |
| resilience.spec.ts | v5 real journey review art failure is reported and retried without changing progress | 6 | — |
| resilience.spec.ts | v5 earned collection work image failure is reported and retried without changing receipts | 6 | — |
| resilience.spec.ts | v5 saved settings and system reduced motion cancel presentation without altering Accepted state | 6 | — |
| resilience.spec.ts | v5 twenty real title, settings and pause round trips have stable listeners and no orphan callbacks | 6 | — |
| resilience.spec.ts | v5 twenty actual same-realm mounts dispose their listeners and pending presentation | 6 | — |
| resilience.spec.ts | v5 legitimate 1898 journal reaches soft1900 and keeps export, delivery and settlement exits | 6 | — |
| resilience.spec.ts | v5 over-hard-limit2049 negative bytes stay preserved and explicitly exportable | 6 | — |
| audio.spec.ts | v5 release cold title/settings are silent until explicit preview creates a real output graph and waveform | 6 | — |
| audio.spec.ts | v5 release first actual gameplay gesture makes one accepted impact audible with trusted contact identity | 6 | — |
| audio.spec.ts | v5 release success tones belong to the actual legal accepted strike | 5 | F1 |
| audio.spec.ts | v5 release great tones belong to the actual legal accepted strike | 6 | — |
| audio.spec.ts | v5 release crack tones belong to the actual legal accepted strike | 6 | — |
| audio.spec.ts | v5 release broken tones belong to the actual legal accepted strike | 6 | — |
| audio.spec.ts | v5 release safeBurst tones belong to the actual legal accepted strike | 6 | — |
| audio.spec.ts | v5 release earned Ember and Wide Mouth produce exactly four safe-hit cues from one accepted command | 6 | — |
| audio.spec.ts | v5 release persisted mute silences accepted work across reload and resumes only on fresh input | 5 | F1 |
| audio.spec.ts | v5 release persisted zero silences accepted work across reload and resumes only on fresh input | 4 | F1,F2 |
| audio.spec.ts | v5 release blocked native audio remains readable, does not revoke accepted progress and retries through UI | 6 | — |
| audio.spec.ts | v5 release unavailable native audio remains readable, does not revoke accepted progress and retries through UI | 6 | — |
| audio.spec.ts | v5 release late native resume cannot replay an old accepted impact after pause | 4 | F1,F2 |
| audio.spec.ts | v5 release late native resume cannot replay an old accepted impact after title | 6 | — |
| audio.spec.ts | v5 release late native resume cannot replay an old accepted impact after new-run | 5 | F1 |
| audio.spec.ts | v5 release closing a pending preview cancels it without creating game progress or delayed sound | 6 | — |
| audio.spec.ts | v5 release mute invalidates pending preview without changing accepted progress | 6 | — |
| audio.spec.ts | v5 release zero invalidates pending preview without changing accepted progress | 4 | W1,W2 |
| audio.spec.ts | v5 release system-motion invalidates pending preview without changing accepted progress | 6 | — |
| audio.spec.ts | v5 release repeated native previews cap concurrent sources and stop on settings close without economic writes | 6 | — |
| audio.spec.ts | v5 release twenty real sounding settings-close-pause-resume cycles stop every voice and stay silent through two idle windows | 3 | C1,F1,F2 |
| audio.spec.ts | v5 release a fresh explicit preview owns native resume when an older game resume crosses settings | 6 | — |
| audio.spec.ts | v5 release safeBurst commits atomically and pause cancels unplayed contacts and native sources through reload | 6 | — |

## Closure and publication boundary

Quote clarity is already published and4179 is the82-file current immutable snapshot; do not continue saying it is only T02 or that H has not answered. H specifically explained price-display confusion; latest bounded payment04 and manual screenshots address that feedback, not final human fun/acceptance. The progress source wasca4d852... and parent current receipt baseline is15bad19; T03 remains unchecked.

After affected actual outcomes, retain source/runtime/consumer/environment fingerprints, all original reds and diagnostic experiments, independently replay the archived actualraw/commands (this author’s observer/golden implementation is not a second independent execution), measure current cold first-screen requests against original150KiBJS/3MiBimages, then write the final T01–T03 joint review and current delivery receipt. The new user-facing shipment does not erase still-open long-load/contact/native/currentmatrix responsibility. No unrelated384rerun, newgameengine, mobilescope, extra seed policy or dropped six-project promise is proposed.

Source hash differences from each inspected run (exact, current read):

- `non-audio-matrix-01`: `src/core-v5/game.ts`; `src/platform/audio.ts`; `src/presentation-v4/forge.ts`; `src/presentation-v5/app.ts`; `src/presentation-v5/collection-ui.ts`; `src/presentation-v5/commission-paper.ts`; `src/presentation-v5/decisions.ts`; `src/presentation-v5/economy.css`; `src/presentation-v5/readability.css`; `src/presentation-v5/shell.ts`; `src/presentation-v5/stages.ts`; `src/presentation-v5/story.ts`; `tests/e2e/v5-helpers.ts`; `tests/release-v5/accepted-observation.ts`; `tests/release-v5/audio-probe.ts`; `tests/release-v5/audio.spec.ts`; `tests/release-v5/performance.spec.ts`; `tmp/goal4-T03/harness/lifecycle.js`; `tmp/goal4-T03/harness/style.css`

- `audio-cue-preflight-02`: `src/core-v5/game.ts`; `src/presentation-v5/app.ts`; `src/presentation-v5/collection-ui.ts`; `src/presentation-v5/commission-paper.ts`; `src/presentation-v5/decisions.ts`; `src/presentation-v5/economy.css`; `src/presentation-v5/shell.ts`; `src/presentation-v5/stages.ts`; `src/presentation-v5/story.ts`; `tests/e2e/v5-helpers.ts`; `tmp/goal4-T03/harness/lifecycle.js`; `tmp/goal4-T03/harness/style.css`

- `legacy-input-01`: `src/core-v5/game.ts`; `src/platform/audio.ts`; `src/presentation-v4/forge.ts`; `src/presentation-v5/app.ts`; `src/presentation-v5/collection-ui.ts`; `src/presentation-v5/commission-paper.ts`; `src/presentation-v5/decisions.ts`; `src/presentation-v5/economy.css`; `src/presentation-v5/shell.ts`; `src/presentation-v5/stages.ts`; `src/presentation-v5/story.ts`; `src/v5-main.ts`; `tests/e2e/v5-helpers.ts`; `tests/fixtures/v5/t03-lifecycle-entry.ts`; `tests/release-v5/accessibility.spec.ts`; `tests/release-v5/audio-probe.ts`; `tests/release-v5/audio.spec.ts`; `tests/release-v5/native-v5.mjs`; `tests/release-v5/performance.spec.ts`; `tests/release-v5/resilience-probe.ts`; `tests/release-v5/resilience.spec.ts`; `index.html`; `playwright.v5-release.config.ts`; `playwright.v5-t03-legacy.config.ts`; `tmp/goal4-T03/harness/lifecycle.js`; `tmp/goal4-T03/harness/style.css`

- `native-02`: `src/core-v5/game.ts`; `src/platform/audio.ts`; `src/presentation-v4/forge.ts`; `src/presentation-v5/app.ts`; `src/presentation-v5/collection-ui.ts`; `src/presentation-v5/commission-paper.ts`; `src/presentation-v5/decisions.ts`; `src/presentation-v5/economy.css`; `src/presentation-v5/shell.ts`; `src/presentation-v5/stages.ts`; `src/presentation-v5/story.ts`; `src/v5-main.ts`; `tests/e2e/v5-helpers.ts`; `tests/fixtures/v5/t03-lifecycle-entry.ts`; `tests/release-v5/accessibility.spec.ts`; `tests/release-v5/audio-probe.ts`; `tests/release-v5/audio.spec.ts`; `tests/release-v5/native-v5.mjs`; `tests/release-v5/performance.spec.ts`; `tests/release-v5/resilience-probe.ts`; `tests/release-v5/resilience.spec.ts`; `index.html`; `playwright.v5-t03-legacy.config.ts`; `tmp/goal4-T03/harness/lifecycle.js`; `tmp/goal4-T03/harness/style.css`

- `native-pointer-03`: `src/core-v5/game.ts`; `src/platform/audio.ts`; `src/presentation-v4/forge.ts`; `src/presentation-v5/app.ts`; `src/presentation-v5/collection-ui.ts`; `src/presentation-v5/commission-paper.ts`; `src/presentation-v5/decisions.ts`; `src/presentation-v5/economy.css`; `src/presentation-v5/shell.ts`; `src/presentation-v5/stages.ts`; `src/presentation-v5/story.ts`; `src/v5-main.ts`; `tests/e2e/v5-helpers.ts`; `tests/fixtures/v5/t03-lifecycle-entry.ts`; `tests/release-v5/accessibility.spec.ts`; `tests/release-v5/audio-probe.ts`; `tests/release-v5/audio.spec.ts`; `tests/release-v5/performance.spec.ts`; `tests/release-v5/resilience-probe.ts`; `tests/release-v5/resilience.spec.ts`; `index.html`; `playwright.v5-t03-legacy.config.ts`; `tmp/goal4-T03/harness/lifecycle.js`; `tmp/goal4-T03/harness/style.css`

- `payment-ui-04`: none
