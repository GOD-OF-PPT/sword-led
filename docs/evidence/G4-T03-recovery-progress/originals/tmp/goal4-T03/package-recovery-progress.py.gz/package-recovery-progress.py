from pathlib import Path
import json,gzip,hashlib,datetime
base=Path('tmp/goal4-T03');out=Path('docs/evidence/G4-T03-recovery-progress');assert not out.exists()
labels=['cold-budget-01','core-load-preflight-03','native-04','audio-headed-matrix-02','webkit-title-authority-01','native-suspend-order-01','canceled-native-context-01','audio-headed-matrix-03','running-native-refresh-title-01','build-17','build-18','build-19','build-20','build-21','typecheck-19','harness-build-13']
files=set();runs=[]
for label in labels:
 folder=base/'runs'/label;p=folder/'process.json';d=json.loads(p.read_text());assert d['status']=='terminal' and isinstance(d['actualExitCode'],int);runs.append(d)
 for p in folder.rglob('*'):
  if p.is_file() and 'attachments' not in p.parts and p.suffix in {'.json','.jsonl','.log','.md','.txt'}:files.add(p)
 for suffix in ['-fingerprint.json']:
  p=base/(label+suffix)
  if p.exists():files.add(p)
for name in ['cold-budget.json','cold-budget.mjs','restored-build21-identity.json','audio-preservation-exception.json','preserved.json','package-recovery-progress.py']:
 p=base/name;assert p.is_file();files.add(p)
for p in (base/'originals').rglob('*'):
 if p.is_file() and ('audio' in p.name or 'v2-audio' in p.name):files.add(p)
for name in ['G4-T03-final-impact-map.md','G4-T03-final-code-security.md','G4-T03-canceled-native-context-review.md','G4-T03-native-clock-reference.md']:
 p=Path('tmp')/name;assert p.is_file();files.add(p)
visuals=[Path('tmp/goal4-T03/runs/native-04/native/native-chrome/space-minimize/restored-forge.png'),Path('tmp/goal4-T03/runs/core-load-preflight-03/artifacts/performance-v5-native-call-80a7f-ndlers-pressure-long-at1280-firefox-dpr2/native-pressure-long-1280-post-measurement.png')]
files.update(visuals)
rows=[];out.mkdir(parents=True)
for p in sorted(files):
 b=p.read_bytes();compress=p.suffix!='.png';q=out/'originals'/Path(str(p)+('.gz' if compress else ''));q.parent.mkdir(parents=True,exist_ok=True);stored=gzip.compress(b,compresslevel=9,mtime=0) if compress else b;q.write_bytes(stored);assert (gzip.decompress(q.read_bytes()) if compress else q.read_bytes())==b
 rows.append({'source':str(p),'archive':str(q.relative_to(out)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'storedBytes':len(stored),'storedSHA256':hashlib.sha256(stored).hexdigest(),'encoding':'gzip' if compress else 'original'})
for row in rows:assert hashlib.sha256(Path(row['source']).read_bytes()).hexdigest()==row['sha256']
m={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Progress evidence only. Published product retained; unsuccessful native-audio experiments not shipped. Not complete T03 archive or all-gates signoff. All local originals, including every failed screenshot, remain untouched.','taskComplete':False,'goalComplete':False,'runs':runs,'files':rows,'reviewedImages':[{'path':str(p),'reviewer':'root','finding':'Actually viewed original after operation: current forge/quote/risk/focus or pressure sword visible, no art replacement or viewport clipping observed. Actual process/runtime scope remains in run receipts.'} for p in visuals],'allInputsUnchanged':True,'gzipRoundtripVerified':True};(out/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'ok':True,'runs':len(runs),'files':len(rows),'taskComplete':False}))
