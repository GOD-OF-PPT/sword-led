# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: audio.spec.ts >> v5 release twenty real sounding settings-close-pause-resume cycles stop every voice and stay silent through two idle windows
- Location: tests/release-v5/audio.spec.ts:146:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 1
Received: 2
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - text: −
  - main "行脚灯炉" [ref=e4]:
    - generic [aria-hidden]:
      - strong: 锤下求生
      - generic: v0.8 炉边报价 · 三柄行囊
    - generic "契印与行囊" [ref=e5]:
      - generic [ref=e6]:
        - generic [ref=e7]: 契印
        - strong [ref=e8]: 3/3
      - generic [ref=e9]:
        - generic [ref=e10]: 铜钱
        - strong [ref=e11]: "0"
    - complementary "炉边剑架" [ref=e12]:
      - heading "候火的剑" [level=2] [ref=e13]
      - paragraph [ref=e14]: 拿起剑，拖给来客
      - generic [ref=e15]:
        - button "轻刃 · 40" [pressed] [ref=e16] [cursor=pointer]
        - button "轻刃 · 40" [ref=e17] [cursor=pointer]
        - button "轻刃 · 40" [ref=e18] [cursor=pointer]
      - region "留给明天的剑" [ref=e19]:
        - heading "留一把，待明日" [level=3] [ref=e20]
        - generic [ref=e21]: 留一柄，给明天
        - paragraph [ref=e22]: 明日：新坯3
        - button "明日打算 ›" [ref=e23] [cursor=pointer]
      - generic [ref=e24]:
        - button "留给明天" [ref=e25] [cursor=pointer]
        - generic "配方选择"
    - generic "铁砧与当前兵器" [ref=e26]:
      - generic "青云轻刃，乌铁坯，等级0，身价40，完好；仅造型展示"
      - button "在剑身上落锤" [ref=e27]
    - region "当前剑的估值与状况":
      - paragraph:
        - generic: 作品估值
        - strong: "40"
        - generic: 轻刃 · 无裂纹
      - paragraph: 估值用来验剑，铜钱按右侧报价入袋。
      - paragraph: 等级 0 · 已完成安全连锻 0次
      - generic:
        - paragraph: 下一锤裂损 0% · 首裂会掉价
        - paragraph: 锤势 0/6
      - button "落锤 左键剑身 / 空格" [ref=e28] [cursor=pointer]:
        - text: 落锤
        - generic [ref=e29]: 左键剑身 / 空格
    - complementary "等剑的来客与委托" [ref=e30]:
      - button "和来客聊聊" [ref=e31] [cursor=pointer]:
        - generic [ref=e32]:
          - generic [ref=e33]: 阿岚
          - generic [ref=e34]: 点来客，听听心愿
      - generic [ref=e35]:
        - paragraph [ref=e36]: 第1天 · 灯从炉起
        - heading "巡夜第一灯" [level=1] [ref=e37]
        - paragraph [ref=e38]: 好剑有它要去的地方
        - generic [ref=e41]:
          - generic [ref=e42]:
            - paragraph [ref=e43]:
              - strong [ref=e44]: 交付一柄
              - text: · 无裂纹 · 估值≥100
            - paragraph [ref=e45]: 还差60估值
          - img "第1柄尚未交付" [ref=e47]:
            - generic [ref=e48]: 待交
        - paragraph [ref=e49]: 合格后递给来客，才算交妥
        - paragraph [ref=e50]: 整单酬劳 100铜钱 · 已领 0铜钱
      - paragraph [ref=e51]: 巡夜的人要一柄无裂新剑，先点亮归家的第一站。
      - text: 收讫
      - button "卖给行会 · 实收10铜钱" [ref=e52] [cursor=pointer]
      - button "查看估值与实收说明" [ref=e53] [cursor=pointer]:
        - generic [ref=e54]: 余剑出售 · 本次实收10铜钱
        - text: 看报价说明 ›
    - generic "已装炉具"
    - region "随身手艺与炉具"
    - button "回收这柄剑" [ref=e56] [cursor=pointer]
    - button "收工，封炉" [ref=e57] [cursor=pointer]
  - navigation "行旅工具" [ref=e58]:
    - button "暂停与行旅菜单" [ref=e59] [cursor=pointer]: 行囊
    - button "打开炉谱" [ref=e60] [cursor=pointer]: 炉谱
    - button "打开设置" [ref=e61] [cursor=pointer]: 设置
    - button "查看保存详情" [ref=e62] [cursor=pointer]: 进度已收好
  - region [ref=e63]:
    - generic [ref=e65]:
      - heading "炉火点着了" [level=2] [ref=e66]
      - paragraph [ref=e67]: 左键点剑身落锤。纸单下会写出实际收款，合格后再交给来客。
    - button "收起这条炉边消息" [ref=e68] [cursor=pointer]: ×
  - status [ref=e69]
  - dialog [ref=e70]:
    - heading "声音与动效" [level=2] [ref=e71]
    - generic [ref=e73]:
      - generic [ref=e74]:
        - generic [ref=e75]: 静音
        - checkbox "静音" [ref=e76]
      - generic [ref=e77]:
        - generic [ref=e78]: 敲击音量
        - slider "敲击音量" [ref=e79]: "55"
      - generic [ref=e80]:
        - generic [ref=e81]: 减弱动效
        - checkbox "减弱动效" [ref=e82]
      - paragraph [ref=e83]: 设置已保留
      - status [ref=e84]: 声音已就绪。
      - button "试听敲击声" [active] [ref=e85] [cursor=pointer]
    - generic [ref=e86]:
      - button "保存失败时重试" [ref=e87] [cursor=pointer]
      - button "收好" [ref=e88] [cursor=pointer]
```

# Test source

```ts
  1   | import {test,expect} from '../e2e/fixtures.js';
  2   | import type {Page,TestInfo} from '@playwright/test';
  3   | import {writeFile} from 'node:fs/promises';
  4   | import type {Action,DomainEvent,RunState} from '../../src/core-v5/index.js';
  5   | import {KeyboardV5,keyToV5,v5Sdk,v5VictoryGuide} from '../e2e/v5-helpers.js';
  6   | import {acceptedByV5,lastStrikeV5} from '../e2e/v5-interaction-helpers.js';
  7   | import {installReleaseAudioProbe,releaseAudioSnapshot,resetReleaseAudioCapture,releaseDeferredAudio,setReleaseAudioFaults,maximumBurstFixture} from './audio-probe.js';
  8   | import type {AudioFaults,ReleaseAudioSnapshot} from './audio-probe.js';
  9   | 
  10  | type Strike=Extract<DomainEvent,{type:'Strike'}>;
  11  | type StrikeKind='success'|'great'|'crack'|'broken'|'safeBurst';
  12  | interface StrikeFixture {before:RunState;action:Extract<Action,{type:'strike'|'deliver'|'scrap'|'reserve'}>;after:RunState;strike:Strike;witnessPrefix:number}
  13  | const gameKeys=['sword-led.save.v5','sword-led.save.backup.v5','sword-led.collection.v2','sword-led.collection.backup.v2'] as const;
  14  | const impactTones=(strike:Strike)=>strike.hits.flatMap(hit=>hit.result==='great'?[89,631,1723]:hit.result==='crack'?[197,1499,3167]:hit.result==='broken'?[173,467,2279]:[139,947,2381]);
  15  | 
  16  | /** Search only the already published finite witness. No random state/resources/phase are assigned. */
  17  | function strikeFixture(kind:StrikeKind):StrikeFixture{
  18  |  const made=v5Sdk.createRun({runId:'v5-release-audio-boundary',seed:'v5-economy-0'});if(!made.ok)throw Error(made.error);let before=made.state;
  19  |  for(const [index,action] of v5VictoryGuide.entries()){
  20  |   const result=v5Sdk.applyCommand(before,{runId:before.runId,expectedRevision:before.revision,action});if(!result.ok)throw Error('Published audio witness rejected: '+result.error);
  21  |   const strike=result.events.find(event=>event.type==='Strike');
  22  |   if(action.type==='strike'&&strike?.type==='Strike'&&(kind==='safeBurst'?strike.burst&&strike.hits.length>=2:!strike.burst&&strike.hits[0]?.result===kind)){
  23  |    const checked=v5Sdk.validateRun(before);if(!checked.ok)throw Error(checked.detail);return{before:checked.state,action,after:result.state,strike,witnessPrefix:index};
  24  |   }
  25  |   before=result.state;
  26  |  }
  27  |  throw Error(`Published guide has no ${kind} boundary; do not inject an outcome to make this pass.`);
  28  | }
  29  | async function slots(page:Page){return page.evaluate(keys=>Object.fromEntries(keys.map(key=>[key,localStorage.getItem(key)])),gameKeys);}
  30  | async function quiet(page:Page){await expect.poll(async()=>(await releaseAudioSnapshot(page)).active).toBe(0);}
  31  | async function suspended(page:Page){await expect.poll(async()=>(await releaseAudioSnapshot(page)).states.some(state=>state==='running')).toBe(false);}
  32  | async function audioState(page:Page,state:string){await expect(page.locator('#v4-audio-status')).toHaveAttribute('data-state',state);}
  33  | async function settings(h:KeyboardV5){await h.activate(h.page.locator(await h.page.locator('#v4-title').isVisible()?'#v4-title-settings':'#v4-settings'));await expect(h.page.locator('#v4-dialog-title')).toHaveText('声音与动效');}
  34  | async function closeSettings(h:KeyboardV5){await h.activate(h.page.getByRole('button',{name:'收好',exact:true}));await expect(h.page.locator('#v4-dialog')).not.toBeVisible();}
  35  | async function preview(h:KeyboardV5){await settings(h);await h.activate(h.page.getByRole('button',{name:'试听敲击声',exact:true}));await audioState(h.page,'ready');}
  36  | async function prepared(page:Page,info:TestInfo,faults:AudioFaults={},fixture?:StrikeFixture){
  37  |  await installReleaseAudioProbe(page,faults);const h=new KeyboardV5(page,info,'mouse');await h.install();
  38  |  if(fixture)await h.restoreLegitimate(fixture.before);else{await h.start();await h.command({type:'continue'});}
  39  |  return h;
  40  | }
  41  | function outputGraph(snapshot:ReleaseAudioSnapshot){
> 42  |  expect(snapshot.contexts).toBe(1);const master=snapshot.nodes.find(node=>node.kind==='master'),destination=snapshot.nodes.find(node=>node.kind==='destination'),analyser=snapshot.nodes.find(node=>node.kind==='post-master-analyser');
      |                            ^ Error: expect(received).toBe(expected) // Object.is equality
  43  |  if(!master||!destination||!analyser)throw Error('Native master/destination/analyser missing');
  44  |  expect(snapshot.edges.some(edge=>edge.from===master.id&&edge.to===destination.id)).toBe(true);
  45  |  expect(snapshot.edges.some(edge=>edge.from===master.id&&edge.to===analyser.id)).toBe(true);
  46  |  for(const source of snapshot.sources){const envelope=snapshot.edges.find(edge=>edge.from===source.id);expect(envelope).toBeDefined();expect(snapshot.nodes.find(node=>node.id===envelope!.to)?.kind).toBe('envelope');expect(snapshot.edges.some(edge=>edge.from===envelope!.to&&edge.to===master.id)).toBe(true);}
  47  |  expect(snapshot.maxActive).toBeLessThanOrEqual(12);
  48  | }
  49  | async function record(info:TestInfo,label:string,details:Record<string,unknown>){await writeFile(info.outputPath(`audio-${label}.json`),JSON.stringify({label,project:info.project.name,scope:'Native AudioContext graph, post-master waveform and trusted UI inputs. Named platform faults are test-only. No physical speaker/listening/OS-volume approval.',...details},null,2));}
  50  | async function diagnostic(page:Page){
  51  |  const [audio,raw,view]=await Promise.all([
  52  |   releaseAudioSnapshot(page).catch(error=>({error:String(error)})),
  53  |   slots(page).catch(error=>({error:String(error)})),
  54  |   page.evaluate(()=>{
  55  |    const attributes=(selector:string)=>{const node=document.querySelector(selector);return node?Object.fromEntries([...node.attributes].map(attribute=>[attribute.name,attribute.value])):null;};
  56  |    return{url:location.href,hidden:document.hidden,visibilityState:document.visibilityState,dialog:{attributes:attributes('#v4-dialog'),title:document.querySelector('#v4-dialog-title')?.textContent??null},audioStatus:{attributes:attributes('#v4-audio-status'),text:document.querySelector('#v4-audio-status')?.textContent??null},scene:attributes('#v4-scene'),hammer:attributes('#v4-hammer'),stage:attributes('#v4-stage'),title:attributes('#v4-title'),focus:document.activeElement?{id:document.activeElement.id,tag:document.activeElement.tagName}:null};
  57  |   }).catch(error=>({error:String(error)})),
  58  |  ]);
  59  |  return{audio,raw,view};
  60  | }
  61  | test.afterEach(async({page},info)=>{if(info.status!==info.expectedStatus)await record(info,'failed-final-observation',{status:info.status,expectedStatus:info.expectedStatus,observation:await diagnostic(page)});});
  62  | async function readyWithoutPreview(h:KeyboardV5){
  63  |  // A real UI gesture resumes game audio, but this non-economic control never fabricates an impact.
  64  |  await h.activate(h.page.locator('#v4-inventory button').first());
  65  |  await expect.poll(async()=>(await releaseAudioSnapshot(h.page)).states).toEqual(['running']);
  66  | }
  67  | async function strikeNow(h:KeyboardV5,action:Action={type:'strike',pieceId:'d1-1'}){await h.command(action);return lastStrikeV5(h);}
  68  | 
  69  | test('v5 release cold title/settings are silent until explicit preview creates a real output graph and waveform',async({page},info)=>{
  70  |  await installReleaseAudioProbe(page);const h=new KeyboardV5(page,info,'mouse');await h.install();await page.goto('/');await expect(page.locator('#v4-start')).toBeEnabled();await h.assertDpr();const before=await slots(page);
  71  |  expect((await releaseAudioSnapshot(page)).constructors).toBe(0);await settings(h);await audioState(page,'waiting');expect((await releaseAudioSnapshot(page)).constructors).toBe(0);
  72  |  await h.activate(page.getByRole('button',{name:'试听敲击声',exact:true}));await audioState(page,'ready');await expect.poll(async()=>(await releaseAudioSnapshot(page)).capturedPeak).toBeGreaterThan(.001);
  73  |  const sounding=await releaseAudioSnapshot(page);expect(sounding.starts).toBe(3);expect(sounding.frequencies).toEqual([139,947,2381]);outputGraph(sounding);await closeSettings(h);await quiet(page);await suspended(page);expect(await slots(page)).toEqual(before);
  74  |  await record(info,'cold-preview',{before,sounding,after:await releaseAudioSnapshot(page)});await page.screenshot({path:info.outputPath('audio-title-after-preview.png')});await h.finish({gameplayCommands:0});
  75  | });
  76  | 
  77  | test('v5 release first actual gameplay gesture makes one accepted impact audible with trusted contact identity',async({page},info)=>{
  78  |  const h=await prepared(page,info);expect((await releaseAudioSnapshot(page)).starts).toBe(0);await resetReleaseAudioCapture(page);const before=await releaseAudioSnapshot(page);const strike=await strikeNow(h);
  79  |  await expect.poll(async()=>(await releaseAudioSnapshot(page)).capturedPeak).toBeGreaterThan(.001);const after=await releaseAudioSnapshot(page);expect(after.starts-before.starts).toBe(3);expect(after.frequencies.slice(before.frequencies.length)).toEqual(impactTones(strike));expect(after.inputs.some(input=>input.trusted&&input.type==='pointerdown')).toBe(true);expect(after.contacts.map(contact=>contact.outcome)).toEqual(strike.hits.map(hit=>hit.result));outputGraph(after);
  80  |  const first=after.sources[before.starts]!,input=after.inputs.find(input=>input.type==='pointerdown')!;expect(first.at).toBeGreaterThanOrEqual(input.at);expect(Math.abs(first.at-after.contacts[0]!.at)).toBeLessThan(100);
  81  |  await quiet(page);expect((await releaseAudioSnapshot(page)).sources.every(source=>source.disconnected)).toBe(true);await record(info,'first-game-impact',{strike,before,after});await h.finish();
  82  | });
  83  | 
  84  | for(const kind of ['success','great','crack','broken','safeBurst'] as const)test(`v5 release ${kind} tones belong to the actual legal accepted strike`,async({page},info)=>{
  85  |  const fixture=strikeFixture(kind),h=await prepared(page,info,{},fixture);await readyWithoutPreview(h);await quiet(page);await resetReleaseAudioCapture(page);const before=await releaseAudioSnapshot(page),strike=await strikeNow(h,fixture.action);expect(strike).toEqual(fixture.strike);expect((await h.read()).state).toEqual(fixture.after);
  86  |  const tones=impactTones(strike);await expect.poll(async()=>(await releaseAudioSnapshot(page)).starts).toBe(before.starts+tones.length);await expect.poll(async()=>(await releaseAudioSnapshot(page)).capturedPeak).toBeGreaterThan(.001);const after=await releaseAudioSnapshot(page);expect(after.frequencies.slice(before.frequencies.length)).toEqual(tones);expect(after.contacts.map(contact=>contact.outcome)).toEqual(strike.hits.map(hit=>hit.result));outputGraph(after);
  87  |  if(kind==='safeBurst'){expect(strike.burst).toBe(true);expect(strike.hits.every(hit=>hit.result==='success'||hit.result==='great')).toBe(true);expect(fixture.after.revision).toBe(fixture.before.revision+1);}
  88  |  await quiet(page);await record(info,'identity-'+kind,{fixture,before,after,scope:'Explicit formal-witness recovery boundary and one real UI strike; not a new complete campaign.'});await h.finish();
  89  | });
  90  | 
  91  | test('v5 release earned Ember and Wide Mouth produce exactly four safe-hit cues from one accepted command',async({page},info)=>{
  92  |  const fixture=maximumBurstFixture(v5Sdk),h=await prepared(page,info,{},fixture);await readyWithoutPreview(h);await h.select(fixture.action.pieceId);await resetReleaseAudioCapture(page);const before=await releaseAudioSnapshot(page),strike=await strikeNow(h,fixture.action);expect(strike).toEqual(fixture.strike);expect(strike.hits).toHaveLength(4);expect(strike.hits.every(hit=>hit.triggers.includes('ember')&&hit.triggers.includes('wideMouth'))).toBe(true);expect((await h.read()).state).toEqual(fixture.after);
  93  |  await expect.poll(async()=>(await releaseAudioSnapshot(page)).starts).toBe(before.starts+12);const after=await releaseAudioSnapshot(page);expect(after.frequencies.slice(before.frequencies.length)).toEqual(impactTones(strike));expect(after.contacts.map(contact=>contact.outcome)).toEqual(strike.hits.map(hit=>hit.result));expect(after.capturedPeak).toBeGreaterThan(.001);outputGraph(after);await quiet(page);await record(info,'earned-max-four',{fixture,before,after,scope:'One fixed-seed finite public-command recovery witness, earning Ember and Wide Mouth through legal actions; one actual UI four-hit Accepted. Not a full UI campaign or seed simulation.'});await h.finish();
  94  | });
  95  | 
  96  | for(const kind of ['mute','zero'] as const)test(`v5 release persisted ${kind} silences accepted work across reload and resumes only on fresh input`,async({page},info)=>{
  97  |  const h=await prepared(page,info);await preview(h);await closeSettings(h);await quiet(page);const before=await slots(page);await settings(h);
  98  |  if(kind==='mute')await page.getByLabel('静音',{exact:true}).check();else{await keyToV5(page,page.getByLabel('敲击音量',{exact:true}));await page.keyboard.press('Home');}
  99  |  await audioState(page,'muted');await quiet(page);await suspended(page);expect(await slots(page)).toEqual(before);const settingsRaw=await page.evaluate(()=>localStorage.getItem('sword-led.settings.v1'));expect(settingsRaw).not.toBeNull();await closeSettings(h);await h.reload();expect((await releaseAudioSnapshot(page)).constructors).toBe(0);await h.activate(page.locator('#v4-continue'));
  100 |  const mutedBefore=await releaseAudioSnapshot(page);const first=await strikeNow(h);expect((await releaseAudioSnapshot(page)).starts).toBe(mutedBefore.starts);await quiet(page);await settings(h);await audioState(page,'muted');
  101 |  if(kind==='mute'){await expect(page.getByLabel('静音',{exact:true})).toBeChecked();await page.getByLabel('静音',{exact:true}).uncheck();}else{await expect(page.getByLabel('敲击音量',{exact:true})).toHaveValue('0');await keyToV5(page,page.getByLabel('敲击音量',{exact:true}));await page.keyboard.press('End');}
  102 |  await closeSettings(h);const silent=await releaseAudioSnapshot(page);expect(silent.starts).toBe(0);await resetReleaseAudioCapture(page);const second=await strikeNow(h);await expect.poll(async()=>(await releaseAudioSnapshot(page)).capturedPeak).toBeGreaterThan(.001);expect((await releaseAudioSnapshot(page)).starts).toBe(impactTones(second).length);
  103 |  await record(info,'persisted-'+kind,{settingsRaw,first,second,probe:await releaseAudioSnapshot(page)});await h.finish();
  104 | });
  105 | 
  106 | for(const failure of ['blocked','unavailable'] as const)test(`v5 release ${failure} native audio remains readable, does not revoke accepted progress and retries through UI`,async({page},info)=>{
  107 |  const h=await prepared(page,info,failure==='blocked'?{rejectResume:true}:{deny:true});const strike=await strikeNow(h),accepted=(await h.read()).state;await settings(h);await audioState(page,failure);await expect(page.locator('#v4-audio-status')).toContainText('锻造仍可继续');const retry=page.getByRole('button',{name:'试听敲击声',exact:true});await expect(retry).toBeEnabled();await h.activate(retry);await audioState(page,failure);const denied=await releaseAudioSnapshot(page);expect(denied.starts).toBe(0);expect(denied.active).toBe(0);expect(denied.contexts).toBe(failure==='blocked'?1:0);expect((await h.read()).state).toEqual(accepted);
  108 |  await setReleaseAudioFaults(page,{deny:false,rejectResume:false});await h.activate(retry);await audioState(page,'ready');await expect.poll(async()=>(await releaseAudioSnapshot(page)).capturedPeak).toBeGreaterThan(.001);const retried=await releaseAudioSnapshot(page);expect(retried.starts).toBe(3);outputGraph(retried);expect((await h.read()).state).toEqual(accepted);await closeSettings(h);await quiet(page);await h.command({type:'deliver',pieceId:'d1-1'});expect((await h.read()).state.coins).toBeGreaterThan(accepted.coins);
  109 |  await record(info,'fault-'+failure,{fault:failure==='blocked'?'Native context suspended at creation; resume promise rejected until explicit test fault release':'Native AudioContext constructor rejected until explicit test fault release',strike,denied,retried});await h.finish();
  110 | });
  111 | 
  112 | for(const destination of ['pause','title','new-run'] as const)test(`v5 release late native resume cannot replay an old accepted impact after ${destination}`,async({page},info)=>{
  113 |  const fixture=strikeFixture('success'),h=await prepared(page,info,{defer:true},fixture),titleStages:Record<string,unknown>[]=[];let titlePhase='before-old-strike';
  114 |  const titleCheckpoint=(phase:string)=>{if(destination==='title'){titlePhase=phase;titleStages.push({phase});}};
  115 |  try{
  116 |   await strikeNow(h,fixture.action);await expect.poll(async()=>(await releaseAudioSnapshot(page)).deferred).toBe(true);const accepted=await h.read(),originalActivation=await releaseAudioSnapshot(page);expect(originalActivation.starts).toBe(0);await h.activate(page.locator('#v4-menu'));
  117 |   if(destination!=='pause'){await h.activate(page.getByRole('button',{name:'回标题',exact:true}));if(destination==='new-run'){await h.activate(page.locator('#v4-start'));await h.confirm();}}
  118 |   const current=await h.record('before-release-after-'+destination);if(destination==='new-run'){expect(current.state.runId).not.toBe(accepted.state.runId);expect(current.state).toMatchObject({phase:'opening',revision:0,coins:0,journal:[]});}else expect(current.state).toEqual(accepted.state);
  119 |   let newerActivation:ReleaseAudioSnapshot|null=null;
  120 |   if(destination==='new-run'){await expect.poll(async()=>(await releaseAudioSnapshot(page)).states).toEqual(['running']);newerActivation=await releaseAudioSnapshot(page);expect(newerActivation.resumeCalls).toBeGreaterThan(originalActivation.resumeCalls);expect(newerActivation.starts).toBe(0);expect(newerActivation.active).toBe(0);}
  121 |   await releaseDeferredAudio(page);if(destination==='new-run')await expect.poll(async()=>(await releaseAudioSnapshot(page)).states).toEqual(['running']);else await suspended(page);await quiet(page);const stale=await releaseAudioSnapshot(page);expect(stale.starts).toBe(0);expect((await h.read()).raw).toEqual(current.raw);
  122 |   if(destination==='title')titleCheckpoint('precontinue');
  123 |   if(destination==='pause')await h.activate(page.getByRole('button',{name:'继续锻造',exact:true}));else if(destination==='title')await h.activate(page.locator('#v4-continue'));else await h.command({type:'continue'});
  124 |   if(destination==='title')titleCheckpoint('postcontinue');
  125 |   const pieceId=destination==='new-run'?'d1-1':fixture.action.pieceId;await resetReleaseAudioCapture(page);if(destination==='title')titleCheckpoint('prefresh');const fresh=await strikeNow(h,{type:'strike',pieceId});if(destination==='title')titleCheckpoint('postfresh');await expect.poll(async()=>(await releaseAudioSnapshot(page)).capturedPeak).toBeGreaterThan(.001);expect((await releaseAudioSnapshot(page)).starts).toBe(impactTones(fresh).length);await record(info,'late-'+destination,{fault:'Only first native resume completion was held; release calls the actual native resume',fixture,accepted,current,originalActivation,newerActivation,stale,fresh,after:await releaseAudioSnapshot(page),authority:destination==='new-run'?'Actual confirmed new-run gesture acquired a newer native activation before older resume release; old cue stays absent and its completion cannot revoke the newer activation':'No newer continue/start gesture before older resume release; native context must remain suspended'});await h.finish();
  126 |  }finally{
  127 |   if(destination==='title')await record(info,'late-title-stages',{phase:titlePhase,stages:titleStages,final:await diagnostic(page),scope:'Phase labels have no browser calls between real Continue and fresh strike; only final/failed observation reads native diagnostics. Actual native button/lifecycle traces and strict waveform assertions remain.'});
  128 |  }
  129 | });
  130 | 
  131 | test('v5 release closing a pending preview cancels it without creating game progress or delayed sound',async({page},info)=>{
  132 |  await installReleaseAudioProbe(page,{defer:true});const h=new KeyboardV5(page,info,'mouse');await h.install();await page.goto('/');await expect(page.locator('#v4-start')).toBeEnabled();const before=await slots(page);await settings(h);await h.activate(page.getByRole('button',{name:'试听敲击声',exact:true}));await expect.poll(async()=>(await releaseAudioSnapshot(page)).deferred).toBe(true);await closeSettings(h);await releaseDeferredAudio(page);await suspended(page);await quiet(page);const cancelled=await releaseAudioSnapshot(page);expect(cancelled.starts).toBe(0);expect(await slots(page)).toEqual(before);
  133 |  await preview(h);await expect.poll(async()=>(await releaseAudioSnapshot(page)).capturedPeak).toBeGreaterThan(.001);expect((await releaseAudioSnapshot(page)).starts).toBe(3);await closeSettings(h);await quiet(page);expect(await slots(page)).toEqual(before);await record(info,'cancel-preview-close',{before,cancelled,after:await releaseAudioSnapshot(page)});await h.finish({gameplayCommands:0});
  134 | });
  135 | 
  136 | for(const cancellation of ['mute','zero','system-motion'] as const)test(`v5 release ${cancellation} invalidates pending preview without changing accepted progress`,async({page},info)=>{
  137 |  const fixture=strikeFixture('success'),h=await prepared(page,info,{},fixture),before=await slots(page);await settings(h);await suspended(page);await setReleaseAudioFaults(page,{defer:true});await h.activate(page.getByRole('button',{name:'试听敲击声',exact:true}));await expect.poll(async()=>(await releaseAudioSnapshot(page)).deferred).toBe(true);
  138 |  if(cancellation==='mute')await page.getByLabel('静音',{exact:true}).check();else if(cancellation==='zero'){await page.getByLabel('敲击音量',{exact:true}).click();await page.keyboard.press('Home');}else{await page.emulateMedia({reducedMotion:'reduce'});await expect(page.locator('#v4-scene')).toHaveAttribute('data-reduced','true');await expect(page.locator('#v4-preference-status')).toContainText('系统减弱动效已启用');}
  139 |  await releaseDeferredAudio(page);await suspended(page);await quiet(page);expect((await releaseAudioSnapshot(page)).starts).toBe(0);expect(await slots(page)).toEqual(before);await record(info,'cancel-preview-'+cancellation,{before,after:await releaseAudioSnapshot(page),faultOwner:'Fault-free restore and settings entry; defer enabled only after native suspension, so the held resume belongs to this one explicit preview',scope:cancellation==='system-motion'?'Browser-emulated prefers-reduced-motion media change; physical OS preference not changed':'Actual persisted settings UI; only native resume completion is held'});await closeSettings(h);await h.finish();
  140 | });
  141 | 
  142 | test('v5 release repeated native previews cap concurrent sources and stop on settings close without economic writes',async({page},info)=>{
```