# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: audio.spec.ts >> v5 release late native resume cannot replay an old accepted impact after new-run
- Location: tests/release-v5/audio.spec.ts:112:63

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 0.001
Received:   0

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - text: +
  - main "行脚灯炉" [ref=f1e4]:
    - generic [aria-hidden]:
      - strong: 锤下求生
      - generic: v0.8 炉边报价 · 三柄行囊
    - generic "契印与行囊" [ref=f1e5]:
      - generic [ref=f1e6]:
        - generic [ref=f1e7]: 契印
        - strong [ref=f1e8]: 3/3
      - generic [ref=f1e9]:
        - generic [ref=f1e10]: 铜钱
        - strong [ref=f1e11]: "0"
    - complementary "炉边剑架" [ref=f1e12]:
      - heading "候火的剑" [level=2] [ref=f1e13]
      - paragraph [ref=f1e14]: 拿起剑，拖给来客
      - generic [ref=f1e15]:
        - button "轻刃 · 84" [pressed] [ref=f1e16] [cursor=pointer]
        - button "轻刃 · 40" [ref=f1e17] [cursor=pointer]
        - button "轻刃 · 40" [ref=f1e18] [cursor=pointer]
      - region "留给明天的剑" [ref=f1e19]:
        - heading "留一把，待明日" [level=3] [ref=f1e20]
        - generic [ref=f1e21]: 留一柄，给明天
        - paragraph [ref=f1e22]: 明日：新坯3
        - button "明日打算 ›" [ref=f1e23] [cursor=pointer]
      - generic [ref=f1e24]:
        - button "留给明天" [ref=f1e25] [cursor=pointer]
        - generic "配方选择"
    - generic "铁砧与当前兵器" [ref=f1e26]:
      - generic "青云轻刃，初开锋，等级2，身价84，完好；仅造型展示"
      - button "在剑身上落锤" [active] [ref=f1e27]
    - region "眼前的打造打算":
      - strong: 还差16估值
      - paragraph: 再攒5记普通锤，剑撑住后才有安全连锻。下一记普通锤不会裂，不代表之后也一直安全。
    - region "当前剑的估值与状况":
      - paragraph:
        - generic: 作品估值
        - strong: "84"
        - generic: 轻刃 · 无裂纹
      - paragraph: 估值用来验剑，铜钱按右侧报价入袋。
      - paragraph: 等级 2 · 已完成安全连锻 0次
      - generic:
        - paragraph: 下一锤裂损 0% · 首裂会掉价
        - paragraph: 锤势 1/6
      - button "落锤 左键剑身 / 空格" [ref=f1e28] [cursor=pointer]:
        - text: 落锤
        - generic [ref=f1e29]: 左键剑身 / 空格
    - complementary "等剑的来客与委托" [ref=f1e30]:
      - button "和来客聊聊" [ref=f1e31] [cursor=pointer]:
        - generic [ref=f1e32]:
          - generic [ref=f1e33]: 阿岚
          - generic [ref=f1e34]: 点来客，听听心愿
      - generic [ref=f1e35]:
        - paragraph [ref=f1e36]: 第1天 · 灯从炉起
        - heading "巡夜第一灯" [level=1] [ref=f1e37]
        - paragraph [ref=f1e38]: 好剑有它要去的地方
        - generic [ref=f1e41]:
          - generic [ref=f1e42]:
            - paragraph [ref=f1e43]:
              - strong [ref=f1e44]: 交付一柄
              - text: · 无裂纹 · 估值≥100
            - paragraph [ref=f1e45]: 还差16估值
          - img "第1柄尚未交付" [ref=f1e47]:
            - generic [ref=f1e48]: 待交
        - paragraph [ref=f1e49]: 合格后递给来客，才算交妥
        - paragraph [ref=f1e50]: 整单酬劳 100铜钱 · 已领 0铜钱
      - paragraph [ref=f1e51]: 巡夜的人要一柄无裂新剑，先点亮归家的第一站。
      - text: 收讫
      - button "卖给行会 · 实收21铜钱" [ref=f1e52] [cursor=pointer]
      - button "查看估值与实收说明" [ref=f1e53] [cursor=pointer]:
        - generic [ref=f1e54]: 余剑出售 · 本次实收21铜钱
        - text: 看报价说明 ›
    - generic "已装炉具"
    - region "随身手艺与炉具"
    - button "回收这柄剑" [ref=f1e56] [cursor=pointer]
    - button "收工，封炉" [ref=f1e57] [cursor=pointer]
  - navigation "行旅工具" [ref=f1e58]:
    - button "暂停与行旅菜单" [ref=f1e59] [cursor=pointer]: 行囊
    - button "打开炉谱" [ref=f1e60] [cursor=pointer]: 炉谱
    - button "打开设置" [ref=f1e61] [cursor=pointer]: 设置
    - button "查看保存详情" [ref=f1e62] [cursor=pointer]: 进度已收好
  - status [ref=f1e63]: 落锤 · 大成 · 这一记后估值 84
```

# Test source

```ts
  25  |   before=result.state;
  26  |  }
  27  |  throw Error(`Published guide has no ${kind} boundary; do not inject an outcome to make this pass.`);
  28  | }
  29  | async function slots(page:Page){return page.evaluate(keys=>Object.fromEntries(keys.map(key=>[key,localStorage.getItem(key)])),gameKeys);}
  30  | async function quiet(page:Page){await expect.poll(async()=>(await releaseAudioSnapshot(page)).active).toBe(0);}
  31  | async function suspended(page:Page){await expect.poll(async()=>(await releaseAudioSnapshot(page)).states.some(state=>state==='running')).toBe(false);}
  32  | async function audioState(page:Page,state:string){await expect(page.locator('#v4-audio-status')).toHaveAttribute('data-state',state);}
  33  | async function settings(h:KeyboardV5){await h.activate(h.page.locator(await h.page.locator('#v4-title').isVisible()?'#v4-title-settings':'#v4-settings'));await expect(h.page.locator('#v4-dialog-title')).toHaveText('声音与动效');}
  34  | async function closeSettings(h:KeyboardV5){await h.activate(h.page.getByRole('button',{name:'收好',exact:true}));await expect(h.page.locator('#v4-dialog')).not.toBeVisible();}
  35  | async function preview(h:KeyboardV5){await settings(h);await h.activate(h.page.getByRole('button',{name:'试听敲击声',exact:true}));await audioState(h.page,'ready');}
  36  | async function prepared(page:Page,info:TestInfo,faults:AudioFaults={},fixture?:StrikeFixture){
  37  |  await installReleaseAudioProbe(page,faults);const h=new KeyboardV5(page,info,'mouse');await h.install();
  38  |  if(fixture)await h.restoreLegitimate(fixture.before);else{await h.start();await h.command({type:'continue'});}
  39  |  return h;
  40  | }
  41  | function outputGraph(snapshot:ReleaseAudioSnapshot){
  42  |  expect(snapshot.contexts).toBe(1);const master=snapshot.nodes.find(node=>node.kind==='master'),destination=snapshot.nodes.find(node=>node.kind==='destination'),analyser=snapshot.nodes.find(node=>node.kind==='post-master-analyser');
  43  |  if(!master||!destination||!analyser)throw Error('Native master/destination/analyser missing');
  44  |  expect(snapshot.edges.some(edge=>edge.from===master.id&&edge.to===destination.id)).toBe(true);
  45  |  expect(snapshot.edges.some(edge=>edge.from===master.id&&edge.to===analyser.id)).toBe(true);
  46  |  for(const source of snapshot.sources){const envelope=snapshot.edges.find(edge=>edge.from===source.id);expect(envelope).toBeDefined();expect(snapshot.nodes.find(node=>node.id===envelope!.to)?.kind).toBe('envelope');expect(snapshot.edges.some(edge=>edge.from===envelope!.to&&edge.to===master.id)).toBe(true);}
  47  |  expect(snapshot.maxActive).toBeLessThanOrEqual(12);
  48  | }
  49  | async function record(info:TestInfo,label:string,details:Record<string,unknown>){await writeFile(info.outputPath(`audio-${label}.json`),JSON.stringify({label,project:info.project.name,scope:'Native AudioContext graph, post-master waveform and trusted UI inputs. Named platform faults are test-only. No physical speaker/listening/OS-volume approval.',...details},null,2));}
  50  | async function diagnostic(page:Page){
  51  |  const [audio,raw,view]=await Promise.all([
  52  |   releaseAudioSnapshot(page).catch(error=>({error:String(error)})),
  53  |   slots(page).catch(error=>({error:String(error)})),
  54  |   page.evaluate(()=>{
  55  |    const attributes=(selector:string)=>{const node=document.querySelector(selector);return node?Object.fromEntries([...node.attributes].map(attribute=>[attribute.name,attribute.value])):null;};
  56  |    return{url:location.href,hidden:document.hidden,visibilityState:document.visibilityState,dialog:{attributes:attributes('#v4-dialog'),title:document.querySelector('#v4-dialog-title')?.textContent??null},audioStatus:{attributes:attributes('#v4-audio-status'),text:document.querySelector('#v4-audio-status')?.textContent??null},scene:attributes('#v4-scene'),hammer:attributes('#v4-hammer'),stage:attributes('#v4-stage'),title:attributes('#v4-title'),focus:document.activeElement?{id:document.activeElement.id,tag:document.activeElement.tagName}:null};
  57  |   }).catch(error=>({error:String(error)})),
  58  |  ]);
  59  |  return{audio,raw,view};
  60  | }
  61  | test.afterEach(async({page},info)=>{if(info.status!==info.expectedStatus)await record(info,'failed-final-observation',{status:info.status,expectedStatus:info.expectedStatus,observation:await diagnostic(page)});});
  62  | async function readyWithoutPreview(h:KeyboardV5){
  63  |  // A real UI gesture resumes game audio, but this non-economic control never fabricates an impact.
  64  |  await h.activate(h.page.locator('#v4-inventory button').first());
  65  |  await expect.poll(async()=>(await releaseAudioSnapshot(h.page)).states).toEqual(['running']);
  66  | }
  67  | async function strikeNow(h:KeyboardV5,action:Action={type:'strike',pieceId:'d1-1'}){await h.command(action);return lastStrikeV5(h);}
  68  | 
  69  | test('v5 release cold title/settings are silent until explicit preview creates a real output graph and waveform',async({page},info)=>{
  70  |  await installReleaseAudioProbe(page);const h=new KeyboardV5(page,info,'mouse');await h.install();await page.goto('/');await expect(page.locator('#v4-start')).toBeEnabled();await h.assertDpr();const before=await slots(page);
  71  |  expect((await releaseAudioSnapshot(page)).constructors).toBe(0);await settings(h);await audioState(page,'waiting');expect((await releaseAudioSnapshot(page)).constructors).toBe(0);
  72  |  await h.activate(page.getByRole('button',{name:'试听敲击声',exact:true}));await audioState(page,'ready');await expect.poll(async()=>(await releaseAudioSnapshot(page)).capturedPeak).toBeGreaterThan(.001);
  73  |  const sounding=await releaseAudioSnapshot(page);expect(sounding.starts).toBe(3);expect(sounding.frequencies).toEqual([139,947,2381]);outputGraph(sounding);await closeSettings(h);await quiet(page);await suspended(page);expect(await slots(page)).toEqual(before);
  74  |  await record(info,'cold-preview',{before,sounding,after:await releaseAudioSnapshot(page)});await page.screenshot({path:info.outputPath('audio-title-after-preview.png')});await h.finish({gameplayCommands:0});
  75  | });
  76  | 
  77  | test('v5 release first actual gameplay gesture makes one accepted impact audible with trusted contact identity',async({page},info)=>{
  78  |  const h=await prepared(page,info);expect((await releaseAudioSnapshot(page)).starts).toBe(0);await resetReleaseAudioCapture(page);const before=await releaseAudioSnapshot(page);const strike=await strikeNow(h);
  79  |  await expect.poll(async()=>(await releaseAudioSnapshot(page)).capturedPeak).toBeGreaterThan(.001);const after=await releaseAudioSnapshot(page);expect(after.starts-before.starts).toBe(3);expect(after.frequencies.slice(before.frequencies.length)).toEqual(impactTones(strike));expect(after.inputs.some(input=>input.trusted&&input.type==='pointerdown')).toBe(true);expect(after.contacts.map(contact=>contact.outcome)).toEqual(strike.hits.map(hit=>hit.result));outputGraph(after);
  80  |  const first=after.sources[before.starts]!,input=after.inputs.find(input=>input.type==='pointerdown')!;expect(first.at).toBeGreaterThanOrEqual(input.at);expect(Math.abs(first.at-after.contacts[0]!.at)).toBeLessThan(100);
  81  |  await quiet(page);expect((await releaseAudioSnapshot(page)).sources.every(source=>source.disconnected)).toBe(true);await record(info,'first-game-impact',{strike,before,after});await h.finish();
  82  | });
  83  | 
  84  | for(const kind of ['success','great','crack','broken','safeBurst'] as const)test(`v5 release ${kind} tones belong to the actual legal accepted strike`,async({page},info)=>{
  85  |  const fixture=strikeFixture(kind),h=await prepared(page,info,{},fixture);await readyWithoutPreview(h);await quiet(page);await resetReleaseAudioCapture(page);const before=await releaseAudioSnapshot(page),strike=await strikeNow(h,fixture.action);expect(strike).toEqual(fixture.strike);expect((await h.read()).state).toEqual(fixture.after);
  86  |  const tones=impactTones(strike);await expect.poll(async()=>(await releaseAudioSnapshot(page)).starts).toBe(before.starts+tones.length);await expect.poll(async()=>(await releaseAudioSnapshot(page)).capturedPeak).toBeGreaterThan(.001);const after=await releaseAudioSnapshot(page);expect(after.frequencies.slice(before.frequencies.length)).toEqual(tones);expect(after.contacts.map(contact=>contact.outcome)).toEqual(strike.hits.map(hit=>hit.result));outputGraph(after);
  87  |  if(kind==='safeBurst'){expect(strike.burst).toBe(true);expect(strike.hits.every(hit=>hit.result==='success'||hit.result==='great')).toBe(true);expect(fixture.after.revision).toBe(fixture.before.revision+1);}
  88  |  await quiet(page);await record(info,'identity-'+kind,{fixture,before,after,scope:'Explicit formal-witness recovery boundary and one real UI strike; not a new complete campaign.'});await h.finish();
  89  | });
  90  | 
  91  | test('v5 release earned Ember and Wide Mouth produce exactly four safe-hit cues from one accepted command',async({page},info)=>{
  92  |  const fixture=maximumBurstFixture(v5Sdk),h=await prepared(page,info,{},fixture);await readyWithoutPreview(h);await h.select(fixture.action.pieceId);await resetReleaseAudioCapture(page);const before=await releaseAudioSnapshot(page),strike=await strikeNow(h,fixture.action);expect(strike).toEqual(fixture.strike);expect(strike.hits).toHaveLength(4);expect(strike.hits.every(hit=>hit.triggers.includes('ember')&&hit.triggers.includes('wideMouth'))).toBe(true);expect((await h.read()).state).toEqual(fixture.after);
  93  |  await expect.poll(async()=>(await releaseAudioSnapshot(page)).starts).toBe(before.starts+12);const after=await releaseAudioSnapshot(page);expect(after.frequencies.slice(before.frequencies.length)).toEqual(impactTones(strike));expect(after.contacts.map(contact=>contact.outcome)).toEqual(strike.hits.map(hit=>hit.result));expect(after.capturedPeak).toBeGreaterThan(.001);outputGraph(after);await quiet(page);await record(info,'earned-max-four',{fixture,before,after,scope:'One fixed-seed finite public-command recovery witness, earning Ember and Wide Mouth through legal actions; one actual UI four-hit Accepted. Not a full UI campaign or seed simulation.'});await h.finish();
  94  | });
  95  | 
  96  | for(const kind of ['mute','zero'] as const)test(`v5 release persisted ${kind} silences accepted work across reload and resumes only on fresh input`,async({page},info)=>{
  97  |  const h=await prepared(page,info);await preview(h);await closeSettings(h);await quiet(page);const before=await slots(page);await settings(h);
  98  |  if(kind==='mute')await page.getByLabel('静音',{exact:true}).check();else{await keyToV5(page,page.getByLabel('敲击音量',{exact:true}));await page.keyboard.press('Home');}
  99  |  await audioState(page,'muted');await quiet(page);await suspended(page);expect(await slots(page)).toEqual(before);const settingsRaw=await page.evaluate(()=>localStorage.getItem('sword-led.settings.v1'));expect(settingsRaw).not.toBeNull();await closeSettings(h);await h.reload();expect((await releaseAudioSnapshot(page)).constructors).toBe(0);await h.activate(page.locator('#v4-continue'));
  100 |  const mutedBefore=await releaseAudioSnapshot(page);const first=await strikeNow(h);expect((await releaseAudioSnapshot(page)).starts).toBe(mutedBefore.starts);await quiet(page);await settings(h);await audioState(page,'muted');
  101 |  if(kind==='mute'){await expect(page.getByLabel('静音',{exact:true})).toBeChecked();await page.getByLabel('静音',{exact:true}).uncheck();}else{await expect(page.getByLabel('敲击音量',{exact:true})).toHaveValue('0');await keyToV5(page,page.getByLabel('敲击音量',{exact:true}));await page.keyboard.press('End');}
  102 |  await closeSettings(h);const silent=await releaseAudioSnapshot(page);expect(silent.starts).toBe(0);await resetReleaseAudioCapture(page);const second=await strikeNow(h);await expect.poll(async()=>(await releaseAudioSnapshot(page)).capturedPeak).toBeGreaterThan(.001);expect((await releaseAudioSnapshot(page)).starts).toBe(impactTones(second).length);
  103 |  await record(info,'persisted-'+kind,{settingsRaw,first,second,probe:await releaseAudioSnapshot(page)});await h.finish();
  104 | });
  105 | 
  106 | for(const failure of ['blocked','unavailable'] as const)test(`v5 release ${failure} native audio remains readable, does not revoke accepted progress and retries through UI`,async({page},info)=>{
  107 |  const h=await prepared(page,info,failure==='blocked'?{rejectResume:true}:{deny:true});const strike=await strikeNow(h),accepted=(await h.read()).state;await settings(h);await audioState(page,failure);await expect(page.locator('#v4-audio-status')).toContainText('锻造仍可继续');const retry=page.getByRole('button',{name:'试听敲击声',exact:true});await expect(retry).toBeEnabled();await h.activate(retry);await audioState(page,failure);const denied=await releaseAudioSnapshot(page);expect(denied.starts).toBe(0);expect(denied.active).toBe(0);expect(denied.contexts).toBe(failure==='blocked'?1:0);expect((await h.read()).state).toEqual(accepted);
  108 |  await setReleaseAudioFaults(page,{deny:false,rejectResume:false});await h.activate(retry);await audioState(page,'ready');await expect.poll(async()=>(await releaseAudioSnapshot(page)).capturedPeak).toBeGreaterThan(.001);const retried=await releaseAudioSnapshot(page);expect(retried.starts).toBe(3);outputGraph(retried);expect((await h.read()).state).toEqual(accepted);await closeSettings(h);await quiet(page);await h.command({type:'deliver',pieceId:'d1-1'});expect((await h.read()).state.coins).toBeGreaterThan(accepted.coins);
  109 |  await record(info,'fault-'+failure,{fault:failure==='blocked'?'Native context suspended at creation; resume promise rejected until explicit test fault release':'Native AudioContext constructor rejected until explicit test fault release',strike,denied,retried});await h.finish();
  110 | });
  111 | 
  112 | for(const destination of ['pause','title','new-run'] as const)test(`v5 release late native resume cannot replay an old accepted impact after ${destination}`,async({page},info)=>{
  113 |  const fixture=strikeFixture('success'),h=await prepared(page,info,{defer:true},fixture),titleStages:Record<string,unknown>[]=[];let titlePhase='before-old-strike';
  114 |  const titleCheckpoint=(phase:string)=>{if(destination==='title'){titlePhase=phase;titleStages.push({phase});}};
  115 |  try{
  116 |   await strikeNow(h,fixture.action);await expect.poll(async()=>(await releaseAudioSnapshot(page)).deferred).toBe(true);const accepted=await h.read(),originalActivation=await releaseAudioSnapshot(page);expect(originalActivation.starts).toBe(0);await h.activate(page.locator('#v4-menu'));
  117 |   if(destination!=='pause'){await h.activate(page.getByRole('button',{name:'回标题',exact:true}));if(destination==='new-run'){await h.activate(page.locator('#v4-start'));await h.confirm();}}
  118 |   const current=await h.record('before-release-after-'+destination);if(destination==='new-run'){expect(current.state.runId).not.toBe(accepted.state.runId);expect(current.state).toMatchObject({phase:'opening',revision:0,coins:0,journal:[]});}else expect(current.state).toEqual(accepted.state);
  119 |   let newerActivation:ReleaseAudioSnapshot|null=null;
  120 |   if(destination==='new-run'){await expect.poll(async()=>(await releaseAudioSnapshot(page)).states).toEqual(['running']);newerActivation=await releaseAudioSnapshot(page);expect(newerActivation.resumeCalls).toBeGreaterThan(originalActivation.resumeCalls);expect(newerActivation.starts).toBe(0);expect(newerActivation.active).toBe(0);}
  121 |   await releaseDeferredAudio(page);if(destination==='new-run')await expect.poll(async()=>(await releaseAudioSnapshot(page)).states).toEqual(['running']);else await suspended(page);await quiet(page);const stale=await releaseAudioSnapshot(page);expect(stale.starts).toBe(0);expect((await h.read()).raw).toEqual(current.raw);
  122 |   if(destination==='title')titleCheckpoint('precontinue');
  123 |   if(destination==='pause')await h.activate(page.getByRole('button',{name:'继续锻造',exact:true}));else if(destination==='title')await h.activate(page.locator('#v4-continue'));else await h.command({type:'continue'});
  124 |   if(destination==='title')titleCheckpoint('postcontinue');
> 125 |   const pieceId=destination==='new-run'?'d1-1':fixture.action.pieceId;await resetReleaseAudioCapture(page);if(destination==='title')titleCheckpoint('prefresh');const fresh=await strikeNow(h,{type:'strike',pieceId});if(destination==='title')titleCheckpoint('postfresh');await expect.poll(async()=>(await releaseAudioSnapshot(page)).capturedPeak).toBeGreaterThan(.001);expect((await releaseAudioSnapshot(page)).starts).toBe(impactTones(fresh).length);await record(info,'late-'+destination,{fault:'Only first native resume completion was held; release calls the actual native resume',fixture,accepted,current,originalActivation,newerActivation,stale,fresh,after:await releaseAudioSnapshot(page),authority:destination==='new-run'?'Actual confirmed new-run gesture acquired a newer native activation before older resume release; old cue stays absent and its completion cannot revoke the newer activation':'No newer continue/start gesture before older resume release; native context must remain suspended'});await h.finish();
      |                                                                                                                                                                                                                                                                                                                                                          ^ Error: expect(received).toBeGreaterThan(expected)
  126 |  }finally{
  127 |   if(destination==='title')await record(info,'late-title-stages',{phase:titlePhase,stages:titleStages,final:await diagnostic(page),scope:'Phase labels have no browser calls between real Continue and fresh strike; only final/failed observation reads native diagnostics. Actual native button/lifecycle traces and strict waveform assertions remain.'});
  128 |  }
  129 | });
  130 | 
  131 | test('v5 release closing a pending preview cancels it without creating game progress or delayed sound',async({page},info)=>{
  132 |  await installReleaseAudioProbe(page,{defer:true});const h=new KeyboardV5(page,info,'mouse');await h.install();await page.goto('/');await expect(page.locator('#v4-start')).toBeEnabled();const before=await slots(page);await settings(h);await h.activate(page.getByRole('button',{name:'试听敲击声',exact:true}));await expect.poll(async()=>(await releaseAudioSnapshot(page)).deferred).toBe(true);await closeSettings(h);await releaseDeferredAudio(page);await suspended(page);await quiet(page);const cancelled=await releaseAudioSnapshot(page);expect(cancelled.starts).toBe(0);expect(await slots(page)).toEqual(before);
  133 |  await preview(h);await expect.poll(async()=>(await releaseAudioSnapshot(page)).capturedPeak).toBeGreaterThan(.001);expect((await releaseAudioSnapshot(page)).starts).toBe(3);await closeSettings(h);await quiet(page);expect(await slots(page)).toEqual(before);await record(info,'cancel-preview-close',{before,cancelled,after:await releaseAudioSnapshot(page)});await h.finish({gameplayCommands:0});
  134 | });
  135 | 
  136 | for(const cancellation of ['mute','zero','system-motion'] as const)test(`v5 release ${cancellation} invalidates pending preview without changing accepted progress`,async({page},info)=>{
  137 |  const fixture=strikeFixture('success'),h=await prepared(page,info,{},fixture),before=await slots(page);await settings(h);await suspended(page);await setReleaseAudioFaults(page,{defer:true});await h.activate(page.getByRole('button',{name:'试听敲击声',exact:true}));await expect.poll(async()=>(await releaseAudioSnapshot(page)).deferred).toBe(true);
  138 |  if(cancellation==='mute')await page.getByLabel('静音',{exact:true}).check();else if(cancellation==='zero'){await page.getByLabel('敲击音量',{exact:true}).click();await page.keyboard.press('Home');}else{await page.emulateMedia({reducedMotion:'reduce'});await expect(page.locator('#v4-scene')).toHaveAttribute('data-reduced','true');await expect(page.locator('#v4-preference-status')).toContainText('系统减弱动效已启用');}
  139 |  await releaseDeferredAudio(page);await suspended(page);await quiet(page);expect((await releaseAudioSnapshot(page)).starts).toBe(0);expect(await slots(page)).toEqual(before);await record(info,'cancel-preview-'+cancellation,{before,after:await releaseAudioSnapshot(page),faultOwner:'Fault-free restore and settings entry; defer enabled only after native suspension, so the held resume belongs to this one explicit preview',scope:cancellation==='system-motion'?'Browser-emulated prefers-reduced-motion media change; physical OS preference not changed':'Actual persisted settings UI; only native resume completion is held'});await closeSettings(h);await h.finish();
  140 | });
  141 | 
  142 | test('v5 release repeated native previews cap concurrent sources and stop on settings close without economic writes',async({page},info)=>{
  143 |  const h=await prepared(page,info),before=await slots(page);await preview(h);for(let i=0;i<12;i++)await h.activate(page.getByRole('button',{name:'试听敲击声',exact:true}));const loaded=await releaseAudioSnapshot(page);expect(loaded.starts).toBe(39);outputGraph(loaded);await closeSettings(h);await quiet(page);expect((await releaseAudioSnapshot(page)).sources.every(source=>source.disconnected)).toBe(true);expect(await slots(page)).toEqual(before);await record(info,'preview-cap',{before,loaded,after:await releaseAudioSnapshot(page)});await h.finish();
  144 | });
  145 | 
  146 | test('v5 release twenty real sounding settings-close-pause-resume cycles stop every voice and stay silent through two idle windows',async({page},info)=>{
  147 |  const h=await prepared(page,info),before=await slots(page),initial=await releaseAudioSnapshot(page),cycles:Record<string,unknown>[]=[];
  148 |  let cycleAtFailure=0,phase='before-loop',explicitStopSources=0,naturalEndSources=0,explicitStopCycles=0,naturalEndCycles=0;
  149 |  try{
  150 |   expect(initial.starts).toBe(0);
  151 |   for(let cycle=1;cycle<=20;cycle++){
  152 |    cycleAtFailure=cycle;phase='before-preview';
  153 |    const previous=await releaseAudioSnapshot(page);await preview(h);phase='after-preview-ready';
  154 |    const observed:{sounding?:ReleaseAudioSnapshot}={};
  155 |    await expect.poll(async()=>{const sample=await releaseAudioSnapshot(page);if(sample.active>0)observed.sounding=sample;return sample.active;}).toBeGreaterThan(0);
  156 |    const sounding=observed.sounding;if(!sounding)throw Error('Missing the successful actual active-source observation');expect(sounding.starts).toBe(previous.starts+3);expect(sounding.active).toBeGreaterThan(0);outputGraph(sounding);
  157 |    phase='closing-settings';await closeSettings(h);await quiet(page);const closed=await releaseAudioSnapshot(page),sources=closed.sources.slice(previous.sources.length);
  158 |    const previewClickSequence=sounding.buttonClicks.at(-1)?.sequence??0,closeClicks=closed.buttonClicks.filter(click=>click.sequence>previewClickSequence&&click.label==='收好');expect(closeClicks).toHaveLength(1);const closeClick=closeClicks[0]!;
  159 |    expect(closeClick.trusted).toBe(true);expect(closeClick.starts).toBe(sounding.starts);expect(sources).toHaveLength(3);expect(closeClick.activeSourceIds.every(id=>sources.some(source=>source.id===id))).toBe(true);
  160 |    const explicitlyStopped=sources.filter(source=>closeClick.activeSourceIds.includes(source.id)),naturallyEnded=sources.filter(source=>!closeClick.activeSourceIds.includes(source.id));
  161 |    expect(explicitlyStopped.every(source=>source.disconnected&&source.stopAt===0)).toBe(true);expect(naturallyEnded.every(source=>source.ended&&source.disconnected&&source.stopAt!==null&&source.stopAt>0)).toBe(true);
  162 |    explicitStopSources+=explicitlyStopped.length;naturalEndSources+=naturallyEnded.length;if(explicitlyStopped.length)explicitStopCycles++;if(naturallyEnded.length)naturalEndCycles++;
  163 |    expect(closed.starts).toBe(sounding.starts);expect(await slots(page)).toEqual(before);
  164 |    phase='pausing';await h.activate(page.locator('#v4-menu'));await expect(page.locator('#v4-dialog-title')).toHaveText('炉火为你留着');await quiet(page);await suspended(page);
  165 |    const paused=await releaseAudioSnapshot(page);expect(paused.starts).toBe(closed.starts);expect(paused.active).toBe(0);
  166 |    phase='resuming';await h.activate(page.getByRole('button',{name:'继续锻造',exact:true}));await expect(page.locator('#v4-dialog')).not.toBeVisible();await quiet(page);
  167 |    const resumed=await releaseAudioSnapshot(page);expect(resumed.starts).toBe(closed.starts);expect(resumed.sources.every(source=>source.disconnected)).toBe(true);expect(await slots(page)).toEqual(before);
  168 |    cycles.push({cycle,sounding:{starts:sounding.starts,active:sounding.active,maxActive:sounding.maxActive,capturedPeak:sounding.capturedPeak},closed:{starts:closed.starts,active:closed.active,actualTrustedClose:closeClick,explicitStopSources:explicitlyStopped.length,naturalEndSources:naturallyEnded.length,sources},paused:{starts:paused.starts,active:paused.active,states:paused.states},resumed:{starts:resumed.starts,active:resumed.active,states:resumed.states}});
  169 |   }
  170 |   phase='idle-windows';const completed=await releaseAudioSnapshot(page);expect(completed.starts).toBe(60);expect(completed.capturedPeak).toBeGreaterThan(.001);outputGraph(completed);
  171 |   const idle:Record<string,unknown>[]=[];
  172 |   for(const durationMs of [800,500]){await page.waitForTimeout(durationMs);const observed=await releaseAudioSnapshot(page);expect(observed.starts).toBe(completed.starts);expect(observed.active).toBe(0);expect(observed.sources.every(source=>source.disconnected)).toBe(true);expect(await slots(page)).toEqual(before);idle.push({durationMs,starts:observed.starts,active:observed.active,states:observed.states});}
  173 |   expect(explicitStopSources+naturalEndSources).toBe(60);phase='complete';await record(info,'twenty-real-audio-cycles',{before,cycles,idle,explicitStopSources,naturalEndSources,explicitStopCycles,naturalEndCycles,final:await releaseAudioSnapshot(page),scope:'Twenty actual UI previews each observed sounding. Native sources still active at the trusted close click must be explicitly stopped/disconnected; sources already naturally ended must be ended/disconnected. Actual explicit-stop and natural-end counts are reported separately, with no claim that all twenty closes preceded natural ending. Every close/pause/resume retains identical raw economic slots, and both later real idle windows stay silent.'});await h.finish({audioSettingsPauseCycles:20,previewSources:60,explicitStopSources,naturalEndSources,explicitStopCycles,naturalEndCycles,idleWindowsMs:[800,500],gameplayCommands:1});
  174 |  }finally{
  175 |   await record(info,'twenty-cycle-final-observation',{cycle:cycleAtFailure,phase,completedCycles:cycles,initial,explicitStopSources,naturalEndSources,explicitStopCycles,naturalEndCycles,audio:await releaseAudioSnapshot(page).catch(error=>({error:String(error)})),visibleStatus:await page.locator('#v4-audio-status').getAttribute('data-state').catch(()=>null),visibleDialog:await page.locator('#v4-dialog-title').textContent().catch(()=>null),actualGameSlots:await slots(page).catch(error=>({error:String(error)}))});
  176 |  }
  177 | });
  178 | 
  179 | test('v5 release a fresh explicit preview owns native resume when an older game resume crosses settings',async({page},info)=>{
  180 |  const h=await prepared(page,info),before=await slots(page),observations:Record<string,unknown>[]=[];let phase='before-pause';
  181 |  try{
  182 |   await h.activate(page.locator('#v4-menu'));await expect(page.locator('#v4-dialog-title')).toHaveText('炉火为你留着');await suspended(page);
  183 |   await h.activate(page.getByRole('button',{name:'继续锻造',exact:true}));await expect(page.locator('#v4-dialog')).not.toBeVisible();await suspended(page);
  184 |   await setReleaseAudioFaults(page,{defer:true});phase='opening-settings-with-held-game-resume';await settings(h);
  185 |   await expect.poll(async()=>(await releaseAudioSnapshot(page)).deferred).toBe(true);const held=await releaseAudioSnapshot(page);expect(held.hasDeferredResume).toBe(true);expect(held.starts).toBe(0);observations.push({phase,audio:held});
  186 |   phase='fresh-explicit-preview';await h.activate(page.getByRole('button',{name:'试听敲击声',exact:true}));observations.push({phase,audio:await releaseAudioSnapshot(page)});
  187 |   phase='release-older-native-resume';await releaseDeferredAudio(page);await audioState(page,'ready');await expect.poll(async()=>(await releaseAudioSnapshot(page)).starts).toBe(3);await expect.poll(async()=>(await releaseAudioSnapshot(page)).capturedPeak).toBeGreaterThan(.001);
  188 |   const fresh=await releaseAudioSnapshot(page);expect(fresh.resumeCalls).toBeGreaterThan(held.resumeCalls);expect(fresh.states).toEqual(['running']);outputGraph(fresh);expect(await slots(page)).toEqual(before);observations.push({phase,audio:fresh});
  189 |   phase='close-and-pause';await closeSettings(h);await quiet(page);expect((await releaseAudioSnapshot(page)).sources.every(source=>source.disconnected)).toBe(true);await h.activate(page.locator('#v4-menu'));await suspended(page);expect(await slots(page)).toEqual(before);await h.activate(page.getByRole('button',{name:'继续锻造',exact:true}));await quiet(page);expect((await releaseAudioSnapshot(page)).starts).toBe(3);expect(await slots(page)).toEqual(before);
  190 |   phase='complete';await h.finish({scope:'Deterministic named platform fault: settings pointerdown starts a held game resume; one fresh explicit preview must obtain its own native activation and survive completion of the older request. Not a claim about the exact scheduling of preflight-normal-01.'});
  191 |  }finally{
  192 |   await record(info,'fresh-preview-crossed-resume',{phase,before,observations,audio:await releaseAudioSnapshot(page).catch(error=>({error:String(error)})),visibleStatus:await page.locator('#v4-audio-status').getAttribute('data-state').catch(()=>null),actualGameSlots:await slots(page).catch(error=>({error:String(error)})),fault:'Only the first native resume requested after actual pause/resume is held, using the existing AudioContext probe. No game state or UI activation is synthesized.'});
  193 |  }
  194 | });
  195 | 
  196 | test('v5 release safeBurst commits atomically and pause cancels unplayed contacts and native sources through reload',async({page},info)=>{
  197 |  const fixture=strikeFixture('safeBurst'),h=await prepared(page,info,{},fixture);await readyWithoutPreview(h);await h.select(fixture.action.pieceId);await resetReleaseAudioCapture(page);const before=await releaseAudioSnapshot(page);
  198 |  await acceptedByV5(h,fixture.action,async()=>{await page.locator('#v4-hit').click();await page.keyboard.press('Escape');});await expect(page.locator('#v4-dialog-title')).toHaveText('炉火为你留着');expect((await h.read()).state).toEqual(fixture.after);await quiet(page);await suspended(page);const cancelled=await releaseAudioSnapshot(page);expect(cancelled.starts-before.starts).toBeLessThan(impactTones(fixture.strike).length);
  199 |  await page.waitForTimeout(900);expect((await releaseAudioSnapshot(page)).starts).toBe(cancelled.starts);expect((await h.read()).state).toEqual(fixture.after);await expect(page.locator('#v4-hammer')).toHaveAttribute('data-phase','idle');expect(await page.locator('#v4-scene').evaluate(node=>node.getAnimations({subtree:true}).filter(animation=>animation.playState==='running').length)).toBe(0);
  200 |  await h.reload();expect((await releaseAudioSnapshot(page)).constructors).toBe(0);await h.activate(page.locator('#v4-continue'));expect((await h.read()).state).toEqual(fixture.after);expect((await releaseAudioSnapshot(page)).starts).toBe(0);await record(info,'safeBurst-pause-reload',{fixture,before,cancelled,afterReload:await releaseAudioSnapshot(page)});await h.finish();
  201 | });
  202 | 
```