# 原生声音时钟的参考与边界

本地audio03实际WebKit1新context running而currentTime保持0；三sources路径/时序正确、旧close已完成。只有这些是本项目已证事实。

WebKit公开问题 [263627](https://bugs.webkit.org/show_bug.cgi?id=263627) 和 [276687](https://bugs.webkit.org/show_bug.cgi?id=276687) 记录过类似状态与声音不一致的报告，主要涉及iOS/后台切换，不能据此认定当前PC测试为同一缺陷，也不替代本地复现。当前 [AudioContext源码](https://github.com/WebKit/WebKit/blob/main/Source/WebCore/Modules/webaudio/AudioContext.cpp) 只作原生API行为参考，不证明测试内具体构建的实现。没有采用帖子里的定时重试或添加手机范围。

给后来真实输入保留native resume机会是受控候选；它不检测物理扬声器，也不保证修复所有引擎时钟问题。验证仍使用原wave0.001门/原动作，不放宽为state=running即通过。
