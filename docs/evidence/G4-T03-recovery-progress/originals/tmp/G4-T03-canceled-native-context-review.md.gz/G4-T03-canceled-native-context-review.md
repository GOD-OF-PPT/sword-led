# Cancelled native output ownership — final static review

Current shared audio SHA-256: `cda6ae053d186fe1a5aea09e0639977f6275871cdc487139297d2ae14e2e08d7`.

Compared byte-for-byte with the preserved bounded-cue source `audio-before-native-suspend-order.ts` (SHA-256 `6d86b2b4d4f4c35f32f8128110d66cb6f94587b870e3e27522d61f576119b263`), the final change adds only idempotent context retirement, uses it for a stale completed activation with no newer valid same-context owner, and makes a newly created graph perform actual native resume even if its initial state reports running. The unsuccessful suspend-Promise wait is absent. Domain, Accepted queue bounds, palette, gain, voice count and save behavior are unchanged.

Static ownership review found no new must-fix blocker:

- A newer same-context activation in the current epoch remains protected. An old completion returns false and cannot stop that newer preview/new-run owner.
- Retirement only stops/disconnects the global voices/master and clears current context/master/suspending when the retired object is still the current context. A completion for a different old context cannot clear a newly created graph or its cue queue.
- The WeakSet makes native close idempotent. The old state listener is removed. The existing exact-attempt `finally` cannot clear a newer pending operation. Any remaining old activation reference is rejected by context/epoch identity and overwritten by the next actual gesture.
- Waiting cues are cleared by the existing stop path when the current graph retires. There is no replay from the old context, no timer, no global autoplay, no consumer delay and no new input protocol.
- Ordinary pause of completed/ready audio still suspends; only a stale completed activation with no newer authorized owner retires its output. Dispose cannot authorize or create a graph and does not publish after disposal.

Actual bounded evidence read: `runs/canceled-native-context-01/report.json` is terminal 0, nine passed / zero failed / zero skipped / zero flaky. The three unchanged WebKit DPR1 responsibilities—late title, late new run and fresh preview crossing older resume—each ran exactly three fixed times. `end-fingerprint.json` records consumer 0, fingerprint 0 and `matches:true`. This proves that explicit sample, including strict waveform/zero-old-cue/state assertions. It does not convert the previous matrix's 137 passed / 1 failed into a current all-green matrix.

The directly affected closure is the current audio consumer set, since pending ownership can reach every native cue and settings/lifecycle boundary. Root plans one final current 23 × six-project audio run; preserve its identity and terminal. Shared older audio consumers and actual system-Chrome audio cancellation should retain their scoped dependent verification. No unrelated full non-audio or full-campaign rerun is implied merely by a changed bundle hash: preserve prior receipts with their actual source/runtime identities, and rerun only behavior affected by the shared audio seam. Human speaker/listening quality and earlier headless native-output limitations remain separate claims.

This reviewer only read small source/diff/receipt files and wrote this tmp note. No source, active consumer, configuration, distribution or harness edit, browser/build/SDK/test execution occurred.
