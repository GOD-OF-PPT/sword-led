# G4-T03 three-task review: code, safety and dependencies

结论：**本次定向静态审查 mustfix＝none**，未发现新增的代码、安全或依赖问题阻止已发布产品进度及既有范围的继续收尾。此结论不等于T03验收全绿：root的core-load-preflight03仍在冻结build16的417/82输入上执行；真实性能、当前原生／受影响矩阵、独立归档回放及T04用户体验闭环尚未结。本代理未运行SDK、browser、build、测试或大扫描，未改src/tests/config/dist/正式docs，仅写此tmp记录。

## Scope与来源

原五项仍是游戏设计与GitHub交付、批准美术/UI及架构、完整流程与可玩性复核、主逻辑及全UI实施、现代PC网页。当前没有新引擎、移动／低版兼容、经济再平衡或存档迁移。H已经答复“身价、酬劳和实收关系困惑”，付款UI以作品估值／整单酬劳已领／本柄酬劳＋品质加赏＝实收回应，并已按实际付款04及发布回执交付；不把此反馈当整体乐趣或听感已获接受。

保护口径保持精确：110旧源＋direct-input/audio/forge三项有据共享表示层例外，6core＋game.ts分配例外，8SDK＋v5SDK例外；85原画、历史输入和保留ref责任不减。T01/T02交付与原384消费保留其原构建身份，不由本审查改写。新代码涉及以下边界：

| 边界 | 定向检查与结论 |
| --- | --- |
| 付款投影 | payment-copy.ts:25-68只读getRunView/quote，不推新价格；day8各柄酬劳用baseFeeDelta。app.ts:254-258的交付仍受canAct/busy/quote.allowed；495-499说明只生成文字并开关现有modal，没有send/port mutation/prefs/storage写。报价模态的read-only性质与旧行程来源不变 |
| 核心journal分配 | game.ts:94-142保command canonicalJSON/身份／revision／phase/1900与2048门，deep clone非journal事务body、新journal数组、仅push本次已解析Action，原freezeDeep与失败原state引用保持。当前合法Action全是平坦primitive字段；既有freezeDeep隔离mutable条目、可共享frozen条目，不对任意非法嵌套输入假称深不可变。完整validateRun:6-12仍逐条回放并canonical全state等值；回放仍O(n²)，未跳验证或改规则 |
| 输入、原生与保存权 | direct-input例外仅让独立detail0不被鼠标兼容click消费；上下文票据与canAct仍独立。app.ts:76/85的经济动作和confirm检查run/revision/generation。BFCache暂停提示由当前render投影，过期对象只在缺失或此前已终结时换剑。browser-session.ts配对安装/移除pagehide/pageshow/storage并委托suspend/activate/dispose；静态代码不证明实际trusted persisted/heap或OS最小化，当前native6仍需实际 |
| 音频所有权 | audio.ts:58-86 pending按context/epoch/serial，旧finally仅清本ticket，旧完成不撤较新有效授权。114-124只对本次真实pendingpromise排当前gamecue，live waiting集合≤4；play还受enabled/mode/native running。stop/silence/identify/mute0/mode/dispose清等待和voice，preview另await token不重复队列；旧排空请求完成后不能补播。dispose先置disposed/epoch、移listener与master、关闭context。没有领域命令／RNG／保存写入路径；浏览器native输出、挂起Promise及真实资源释放仍由实际probe/生命周期证据承担 |
| 唯一renderer缓存 | forge.ts:51-76以canvas弱键、完整painted输入、CSS/backing/DPR和asset attempt/status/src/currentSrc/complete/natural尺寸判定；zeroCSS不存成功，paint后backing不符不存。cachehit不跳aria/scene/prop metadata或impact.refresh；miss保原完整绘画。dispose:212取消rAF/WAAPI、断resize/visibility、拆asset监听／在途src并丢Map/WeakMap。不能由此静态声称帧预算已改善 |
| 资源故障与重试 | artwork-recovery.ts保canonical source身份，WeakMap绑定临时节点，attempt/source/expected/complete/natural尺寸＋disposed防晚到；fallback不当canonical成功。retry probe有8秒终态、clear timer/listener/src，成功只重绑当前root后代；dispose清probe/source及bindings。forge和stage另有代际/attempt守卫，图源来自正式常量，未从seed或存档raw生成URL。关闭的modal节点不被强registry为重试永久保留 |
| app销毁 | app.ts:570先disposed并cancel表现，再退订run/book/prefs/audio，清辅助图与stage回调，disposeinput/handoff/feedback/paper/renderer，移motion/document/window/root监听，等待port/audio清理；只在仍拥有原root时清DOM。动态modal按钮随旧DOM释放，slot读者／probe强持有的detached nodes不能凭数量当产品泄漏 |

## 用户输入、解析与下载

`root.innerHTML=V5_TEMPLATE`（app.ts:45）使用固定生产模板；本次没有把用户seed、档案原文、回执或错误字符串拼入HTML。可变显示经textContent或element()的文本参数，modal用replaceChildren实际节点；没有新增eval/new Function、脚本URL或对任意输入的innerHTML。新seed继续由核心NFC/长度/安全runId约束，未作为资源URL或可执行内容。

`canonicalJson`（core/validate.ts:10-68）拒绝非plain原型、accessor/symbol、稀疏／超长数组及unsafe整数，并限制节点50,000、深度16、UTF8 256KiB；descriptor读取不会调用getter。storage.ts:43-57先限定原文256KiB，再JSON.parse、严格envelope/schema/rules/timestamp与正式validate。解析没有eval，接收存档仍按全journal重建比较，不因性能优化信任外部快照。collection继承有来源规则和正式validator，不接受钱包/RNG迁入。

T02备份修复仍检查展示的具体原文：app.ts:518-529分别读run/book来源，在确认动作前复读相同raw；变化或拒读回明确重看。旧炉谱import（v5-persistence.ts:151-198）保previewId/generation/run/revision及展示raw票据、确认与writer/dirty门，复读只合并已展示collection。没有“重试时导入未展示新成果”路径。

下载（app.ts:87-94）为本地application/json Blob/objectURL，真实按钮下载，1秒后revoke；下载名的runId经核心约束。exportRun／collection仅序列化当前state／书册及允许读取的原文，不向远程端点发送。raw-run-export.ts:15-32独立读取主／备份并标记各自拒读，不把raw包装导出称可续玩合法档，也不因一处拒读丢另一份原文。此1秒释放计时只回收objectURL，不捕获game/DOM经济状态或延迟命令。

## 机密、依赖与生产隔离

相对28fabc1只读diff：package.json、package-lock及相关yarn/pnpm锁文件、vite主／SDK配置未变，无新依赖、安装钩子、外部API或凭据需求。此轮只对18个本次变更生产文本文件（index、game/input/audio/forge、v5app与表示模块/CSS、v5-main、本地SVG）检查private-key、常见GitHub/OpenAI/Slack token形态，**0命中**；输出没有打印潜在secret值。所查文件的t03Runtime/t03Lifecycle/v5ReleaseAudio/v5AcceptedDiagnostics/accepted-observation探针名亦0命中。独立测试harness不由生产v5-main导入。SVG无script/foreignObject/href/src/on*或DOCTYPE/ENTITY；原ICO封装静态检查保留此前身份，此轮未解码PNG。

这只是明确范围的秘密形态与导入检查，不声称全Git历史审计、漏洞库扫描或生产安全认证。源图/本地下载/JSON并未因包含外来文字成为主动内容；没有无依据新增权限或审批门。

## 既有结果与未结责任

已读取的golden02实际0记录为4908边／25路径／32检查点／174所有权行，原8SDK字节一致、输入前后不变；它支持上述分配语义，但该脚本和部分observer由本代理编写，root实际执行，本次回读不是第二份独立回放。build12 FF1headed23、pixelpair和当前付款04各有自己的源／运行身份；不拿旧结果填最新原生或六项目整批。

代码的当前审查字节：game.ts `0d5306cd2dd750c8a90296dcd7fad6862d3ffd6b1bf0c5602059bd6700cdaa59`；audio.ts `6d86b2b4d4f4c35f32f8128110d66cb6f94587b870e3e27522d61f576119b263`；forge.ts `91905bd97d60bf57d5bea137836ba7f4a5855e98aa850916d1b09517e76270a2`；artwork-recovery.ts `4294cc463904dee09fa2a0801011362a5cdda79e065ebe8d6c316e85ce62890c`；payment-copy.ts `d06bda691e0e7ddd9859f80f976db89312ee84f37ca4e551bf149e5edcc892eb`。

root当前真实长档加载和既有contact调度红仍待原阈值消费，原生6／受影响当前矩阵和legacy18按impact map保留，独立实际raw归档回放、冷首屏请求预算及最终交付回执亦未被本简审关闭。T03不可由“static mustfix none”勾选，原五项/T04及用户真实再体验更不可提前complete。

[杠精代码／安全简审] 保留全部已知边界、实际失败和当前冻结执行身份；未发现新的必修代码／安全／依赖缺陷，未把静态无命中或黄金同值当性能、内存、原生或用户接受通过。无新scope／测试／审批建议。
