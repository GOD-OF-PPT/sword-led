# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: v4-navigation.spec.ts >> holding Enter on a sale cannot sell the next sword without a fresh press
- Location: tests/e2e/v4-navigation.spec.ts:3:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -  7
+ Received  + 15

@@ -23,45 +23,45 @@
        "base": 40,
        "bursts": 0,
        "charge": 0,
        "commissionId": null,
        "cracked": false,
-       "finalizedDay": null,
+       "finalizedDay": 1,
        "hits": 0,
        "id": "d1-2",
        "level": 0,
        "normalGreats": 0,
        "peak": 40,
        "recipe": "light",
        "slot": 2,
-       "status": "active",
+       "status": "sold",
        "successes": 0,
        "suppliedDay": 1,
        "value": 40,
      },
      Object {
        "base": 40,
        "bursts": 0,
        "charge": 0,
        "commissionId": null,
        "cracked": false,
-       "finalizedDay": null,
+       "finalizedDay": 1,
        "hits": 0,
        "id": "d1-3",
        "level": 0,
        "normalGreats": 0,
        "peak": 40,
        "recipe": "light",
        "slot": 3,
-       "status": "active",
+       "status": "sold",
        "successes": 0,
        "suppliedDay": 1,
        "value": 40,
      },
    ],
    "chapterChoices": Array [],
-   "coins": 40,
+   "coins": 120,
    "commissionOrder": Array [
      1,
      2,
      3,
      4,
@@ -80,11 +80,11 @@
      "loan": false,
      "shelter": false,
      "supplyPct": 100,
    },
    "dayRecovered": 0,
-   "daySales": 40,
+   "daySales": 120,
    "eventDeck": Array [
      "donation",
      "credit",
      "salvage",
      "rest",
@@ -109,10 +109,18 @@
      },
      Object {
        "pieceId": "d1-1",
        "type": "deliver",
      },
+     Object {
+       "pieceId": "d1-2",
+       "type": "deliver",
+     },
+     Object {
+       "pieceId": "d1-3",
+       "type": "deliver",
+     },
    ],
    "mode": "story",
    "modifications": Array [],
    "pardonUsed": false,
    "pending": Object {
@@ -121,11 +129,11 @@
      "supplyPct": 100,
    },
    "phase": "workshop",
    "repaired": false,
    "reserveId": null,
-   "revision": 2,
+   "revision": 4,
    "rng": Object {
      "content": Object {
        "draws": 0,
        "state": 1176869687,
      },
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - text: −
  - main "行脚灯炉" [ref=e4]:
    - generic [ref=e5]:
      - paragraph [ref=e6]: 第1天 · 灯从炉起
      - heading "阿岚 · 巡夜第一灯" [level=1] [ref=e7]
      - paragraph [ref=e8]: 一柄 · 无裂纹 · 身价≥100
      - paragraph [ref=e9]: 0/1
    - generic "契印与行囊" [ref=e10]:
      - generic [ref=e11]:
        - generic [ref=e12]: 契印
        - strong [ref=e13]: 3/3
      - generic [ref=e14]:
        - generic [ref=e15]: 铜钱
        - strong [ref=e16]: "120"
    - complementary "炉边剑架" [ref=e17]:
      - heading "候火的剑" [level=2] [ref=e18]
      - region "留给明天的剑" [ref=e19]:
        - heading "留一把，待明日" [level=3] [ref=e20]
        - generic [ref=e21]: 留一柄，给明天
      - generic [ref=e22]:
        - button "留给明天" [disabled] [ref=e23]
        - generic "配方选择"
    - generic "铁砧与当前兵器" [ref=e24]:
      - generic "空铁砧"
      - button "在剑身上落锤" [ref=e25]
    - region "当前剑的身价与状况":
      - paragraph:
        - generic: 剑价
        - strong: —
        - generic: 铁砧已空，安排这一炉收工
      - generic:
        - paragraph: 余剑已安排，可收工
        - paragraph: 锤势 0/6
      - button "这一炉，收工" [ref=e26] [cursor=pointer]
    - complementary "等剑的来客" [ref=e27]:
      - button "和来客聊聊" [ref=e28] [cursor=pointer]:
        - generic [ref=e29]:
          - generic [ref=e30]: 阿岚
          - generic [ref=e31]: 点来客，听听心愿
      - paragraph [ref=e32]: 巡夜的人要一柄无裂新剑，先点亮归家的第一站。
      - button "卖给行会" [disabled] [ref=e33]
    - region "随身手艺与炉具" [ref=e35]
    - button "回收这柄剑" [disabled] [ref=e36]
    - button "收工，封炉 看看今日的收成" [ref=e37] [cursor=pointer]:
      - text: 收工，封炉
      - generic [ref=e38]: 看看今日的收成
  - navigation "行旅工具" [ref=e39]:
    - button "暂停与行旅菜单" [ref=e40] [cursor=pointer]: 行囊
    - button "打开炉谱" [ref=e41] [cursor=pointer]: 炉谱
    - button "打开设置" [ref=e42] [cursor=pointer]: 设置
    - button "查看保存详情" [ref=e43] [cursor=pointer]: 进度已收好
  - region [ref=e44]:
    - generic [ref=e46]:
      - heading "炉火点着了" [level=2] [ref=e47]
      - paragraph [ref=e48]: 鼠标左键点剑身即可落锤。看见“交给阿岚”，就能保住今天的委托。
    - button "收起这条炉边消息" [ref=e49] [cursor=pointer]: ×
  - status [ref=e50]
```

# Test source

```ts
  1 | import {test,expect} from '@playwright/test';
  2 | import {startV4,commandV4,readV4,saveV4} from './v4-helpers.js';
  3 | test('holding Enter on a sale cannot sell the next sword without a fresh press',async({page})=>{
> 4 |  await startV4(page);await commandV4(page,{type:'continue'});await page.locator('#v4-deliver').focus();await page.keyboard.down('Enter');const one=await readV4(page);expect(one.coins).toBe(40);expect(one.blades.filter(b=>b.status==='sold')).toHaveLength(1);await page.keyboard.down('Enter');await page.keyboard.down('Enter');await page.keyboard.up('Enter');expect(await readV4(page)).toEqual(one);await page.keyboard.press('Enter');const two=await saveV4(page,'fresh-enter-sale');expect(two.coins).toBe(80);expect(two.blades.filter(b=>b.status==='sold')).toHaveLength(2);
    |                                                                                                                                                                                                                                                                                                                                                                                                 ^ Error: expect(received).toEqual(expected) // deep equality
  5 | });
  6 | 
```