# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: v4-compat-entry.spec.ts >> all four actual entries load and old saves remain byte-for-byte across new first-chapter start
- Location: tests/e2e/v4-compat-entry.spec.ts:4:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator:  locator('#v2-strike')
Expected: visible
Received: hidden
Timeout:  5000ms

Call log:
  - Expect "toBeVisible" locator('#v2-strike') with timeout 5000ms
  - waiting for locator('#v2-strike')
    14 × locator resolved to <button disabled tabindex="0" id="v2-strike" class="primary">…</button>
       - unexpected value "hidden"

```

```yaml
- banner:
  - button "锤下求生 行脚灯炉 · 主界面二版"
  - text: 第 1 / 12 轮 · 新交 0 + 信用 0 / 150 · 还差 150
  - progressbar "当轮交货与信用进度"
  - text: 金币 0 废料 0 煤 2 印记 3/3
  - button "暂停"
  - button "契约菜单"
- status: 本机契约已保存。
- heading "今天，接谁的委托？" [level=2]
- paragraph: 本轮最多接一单。合格成品额外增加交货额和金币；也可只做市场。
- button "巡卫的守夜剑 锋≥6，韧≥5；合格+40，两项各超3再+20。":
  - strong: 巡卫的守夜剑
  - text: 锋≥6，韧≥5；合格+40，两项各超3再+20。
- button "信使的随身剑 锋≥5，衡≥6；合格+40，两项各超3再+20。":
  - strong: 信使的随身剑
  - text: 锋≥5，衡≥6；合格+40，两项各超3再+20。
- button "这轮只做市场"
- contentinfo:
  - status: 已记录这次选择。
  - status
  - group: 操作与声音
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | import {startGame} from './helpers.js';
  3  | import {saveV4} from './v4-helpers.js';
  4  | test('all four actual entries load and old saves remain byte-for-byte across new first-chapter start',async({page})=>{
  5  |  const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()>=400)errors.push(`${r.status()} ${r.url()}`);});
  6  |  await page.goto('/legacy.html');await expect(page.locator('#new-game')).toBeEnabled();await startGame(page,'old-entry-b');await expect(page.locator('#strike')).toBeEnabled();
> 7  |  await page.goto('/v2.html');await expect(page.locator('#v2-new')).toBeEnabled();await page.locator('#v2-new').click();await page.locator('#v2-starters button').first().click();await expect(page.locator('#v2-strike')).toBeVisible();
     |                                                                                                                                                                                                                           ^ Error: expect(locator).toBeVisible() failed
  8  |  await page.goto('/v3.html?mode=3');await expect(page.locator('#v3-hit')).toBeEnabled();await page.locator('#v3-hit').click();await expect(page.locator('#v3-strike')).toHaveAttribute('aria-busy','false');const keys=['sword-led.save.v1','sword-led.save.v2','sword-led.save.v3'],before=await page.evaluate(keys=>keys.map(k=>localStorage.getItem(k)),keys);expect(before.every(Boolean)).toBe(true);
  9  |  await page.goto('/');await expect(page.locator('#v4-start')).toBeEnabled();await expect(page.locator('#v4-continue')).toBeHidden();await page.locator('#v4-start').click();await page.getByRole('button',{name:'点火开炉',exact:true}).click();await page.locator('#v4-hit').click({position:{x:250,y:170}});await expect(page.locator('#v4-strike')).toHaveAttribute('aria-busy','false');expect(await page.evaluate(keys=>keys.map(k=>localStorage.getItem(k)),keys)).toEqual(before);await saveV4(page,'all-entry-compatibility');expect(errors).toEqual([]);
  10 | });
  11 | 
```