# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: v4-chapter.spec.ts >> real first chapter connects four commissions, shop, event, bridge, modification, saved collection and a fresh journey
- Location: tests/e2e/v4-chapter.spec.ts:20:1

# Error details

```
Error: {"id":"windbox","expected":1.2941176470588236,"actual":2.5652173913043477,"error":0.9822134387351777}

expect(received).toBeLessThan(expected)

Expected: < 0.07
Received:   0.9822134387351777
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - text: −
  - region [ref=e4]:
    - generic [ref=e6]:
      - paragraph [ref=e7]: 灯炉行记
      - heading "渡口重新亮了" [active] [level=1] [ref=e8]
      - generic [ref=e10]:
        - paragraph [ref=e11]: 渡口亮起第一列灯，巡守与信使终于能在桥头碰面。
        - heading "给下一程，改一件炉具" [level=3] [ref=e12]
        - generic [ref=e13]:
          - article [ref=e14]:
            - heading "风箱" [level=3] [ref=e16]
            - paragraph [ref=e17]: 每柄首次普通大成，额外增加10%身价；从下一天起生效。
            - button "装上风箱" [ref=e18] [cursor=pointer]
          - article [ref=e19]:
            - heading "余温架" [level=3] [ref=e21]
            - paragraph [ref=e22]: 唯一留剑跨天增加15%身价，裂纹和锤势原样保留。
            - button "装上余温架" [ref=e23] [cursor=pointer]
      - generic [ref=e24]:
        - button "先看看炉谱" [ref=e25] [cursor=pointer]
        - button "回标题，保留选择" [ref=e26] [cursor=pointer]
  - navigation "行旅工具" [ref=e27]:
    - button "暂停与行旅菜单" [ref=e28] [cursor=pointer]: 行囊
    - button "打开炉谱" [ref=e29] [cursor=pointer]: 炉谱
    - button "打开设置" [ref=e30] [cursor=pointer]: 设置
    - button "查看保存详情" [ref=e31] [cursor=pointer]: 进度已收好
  - status [ref=e32]: 落锤 · 锻成 · 这一记后身价 273
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test';
  2  | import {readV4,startV4,commandV4,chapterActions,exitDelivery,saveV4,shotV4,activateV4} from './v4-helpers.js';
  3  | import type {Page} from '@playwright/test';
  4  | import {validateCollection} from '../../src/application/v4-collection.js';
  5  | 
  6  | const errors=new WeakMap<Page,string[]>();
  7  | test.beforeEach(({page})=>{const list:string[]=[];errors.set(page,list);page.on('pageerror',e=>list.push(e.message));page.on('response',r=>{if(r.status()>=400)list.push(`${r.status()} ${r.url()}`);});});
  8  | test.afterEach(({page})=>{expect(errors.get(page)).toEqual([]);});
  9  | async function bounds(page:Page,ids:string[]){const size=page.viewportSize()!;expect(await page.evaluate(()=>document.body.scrollWidth)).toBe(size.width);for(const id of ids){const loc=page.locator('#'+id);const b=await loc.boundingBox();expect(b,id).not.toBeNull();expect(b!.x,id).toBeGreaterThanOrEqual(0);expect(b!.y,id).toBeGreaterThanOrEqual(0);expect(b!.x+b!.width,id).toBeLessThanOrEqual(size.width);expect(b!.y+b!.height,id).toBeLessThanOrEqual(size.height);if(await loc.evaluate(e=>e.tagName==='BUTTON')){expect(b!.height,id).toBeGreaterThanOrEqual(44);expect(b!.width,id).toBeGreaterThanOrEqual(44);const top=await loc.evaluate(e=>{const r=e.getBoundingClientRect(),hit=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return hit===e||e.contains(hit);});expect(top,id+' occlusion').toBe(true);}}}
  10 | 
  11 | 
  12 | async function propProportions(page:Page){
  13 |  const ratios=await page.locator('#v4-stage canvas[data-prop]').evaluateAll(async nodes=>{
  14 |   const image=new Image();image.src='/assets/d/v07/modifications-v1.webp';await image.decode();const source=document.createElement('canvas');source.width=image.naturalWidth;source.height=image.naturalHeight;const ctx=source.getContext('2d')!;ctx.drawImage(image,0,0);
  15 |   const ratio=(data:Uint8ClampedArray,w:number,h:number)=>{let minX=w,minY=h,maxX=0,maxY=0;for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(data[(y*w+x)*4+3]!>32){minX=Math.min(minX,x);maxX=Math.max(maxX,x);minY=Math.min(minY,y);maxY=Math.max(maxY,y);}return(maxX-minX+1)/(maxY-minY+1);};
  16 |   return nodes.map(n=>{const c=n as HTMLCanvasElement,index=['windbox','warmRack','wideMouth'].indexOf(c.dataset.prop!),w=image.naturalWidth/3,h=image.naturalHeight,expected=ratio(ctx.getImageData(index*w,0,w,h).data,w,h),actual=ratio(c.getContext('2d')!.getImageData(0,0,c.width,c.height).data,c.width,c.height);return{id:c.dataset.prop,expected,actual,error:Math.abs(actual/expected-1)};});
> 17 |  });for(const r of ratios)expect(r.error,JSON.stringify(r)).toBeLessThan(.07);
     |                                                             ^ Error: {"id":"windbox","expected":1.2941176470588236,"actual":2.5652173913043477,"error":0.9822134387351777}
  18 | }
  19 | 
  20 | test('real first chapter connects four commissions, shop, event, bridge, modification, saved collection and a fresh journey',async({page},info)=>{
  21 |  await startV4(page);let final=await readV4(page);
  22 |  for(const action of chapterActions){final=await commandV4(page,action);
  23 |   if(action.type==='advance'||action.type==='continue'){await exitDelivery(page);await bounds(page,['v4-goal-name','v4-coins','v4-value','v4-risk','v4-strike','v4-deliver','v4-settle','v4-reserve']);await saveV4(page,`day-${final.day}-start`);}
  24 |   if(action.type==='strike'&&final.day===3&&final.blades.find(b=>b.id===action.pieceId)?.bursts){await expect(page.locator('#v4-traits [data-trait=ember]')).toHaveAttribute('data-triggered','true');}
  25 |   if(action.type==='buy'){await expect(page.locator('#v4-traits [data-trait=ember] .v3-trait-art')).toBeVisible();await shotV4(page,'first-chapter-traits');}
  26 |   if(action.type==='settle'&&final.day===3){await expect(page.locator('#v4-stage-copy')).toContainText('护送捐剑 · 已接受');await shotV4(page,'event-receipt');}
  27 |   if(action.type==='deliver'&&final.day===4&&final.blades.find(b=>b.id===action.pieceId)?.commissionId===4){await expect(page.locator('#v4-stage-image')).toHaveAttribute('src','/assets/d/v07/bridge-lit-v1.webp');await shotV4(page,'bridge-delivery');}
  28 |   if(action.type==='settle'&&final.day===4){await expect(page.locator('#v4-stage-title')).toHaveText('渡口重新亮了');await propProportions(page);for(const size of [{width:1280,height:720},{width:1920,height:1080}]){await page.setViewportSize(size);await shotV4(page,`chapter-choice-${size.width}`);await bounds(page,['v4-stage-title','v4-stage-actions']);}}
  29 |  }
  30 |  expect(final.day).toBe(4);expect(final.phase).toBe('summary');expect(final.history.every(h=>h.met)).toBe(true);expect(final.modifications).toEqual(['windbox']);await propProportions(page);await expect(page.locator('#v4-stage-title')).toHaveText('第一程，走完了');await expect(page.locator('#v4-stage-copy')).toContainText('当前可玩内容到第一章');await expect(page.getByRole('button',{name:'沿灯路，去下一天',exact:true})).toHaveCount(0);await saveV4(page,'chapter-complete');
  31 |  const raw=await page.evaluate(()=>localStorage.getItem('sword-led.collection.v1'));expect(raw).not.toBeNull();const collected=validateCollection(JSON.parse(raw!).state);expect(collected.ok).toBe(true);if(!collected.ok)throw Error(collected.detail);expect(collected.state.chapters).toEqual([1]);expect(collected.state.works).toHaveLength(4);
  32 |  const bytes=await page.evaluate(()=>localStorage.getItem('sword-led.save.v4'));await page.reload();await expect(page.locator('#v4-continue')).toBeEnabled();await page.locator('#v4-continue').click();expect(await readV4(page)).toEqual(final);await expect(page.locator('#v4-stage-title')).toHaveText('第一程，走完了');expect(await page.evaluate(()=>localStorage.getItem('sword-led.save.v4'))).toBe(bytes);
  33 |  await page.getByRole('button',{name:'翻开炉谱',exact:true}).click();await expect(page.locator('#v4-dialog-body [data-record] canvas')).toHaveCount(4);await expect(page.locator('#v4-dialog-body')).toContainText('护刃：可自由使用');await shotV4(page,'collection-real');await page.getByRole('button',{name:'收好炉谱'}).click();
  34 |  await page.getByRole('button',{name:'带着炉谱，再启一程'}).click();await page.locator('#v4-start').click();await page.getByRole('button',{name:'再想想',exact:true}).click();expect(await page.evaluate(()=>localStorage.getItem('sword-led.save.v4'))).toBe(bytes);await page.locator('#v4-start').click();await page.getByRole('button',{name:'确认',exact:true}).click();const fresh=await readV4(page);expect(fresh.initialEligibility.recipes).toEqual(['light','guard']);expect(fresh.coins).toBe(0);expect(fresh.runId).not.toBe(final.runId);await saveV4(page,'fresh-earned-eligibility');await info.attach('actual-chapter',{body:JSON.stringify({final,collected:collected.state,fresh},null,2),contentType:'application/json'});
  35 | });
  36 | 
  37 | test('keyboard-only first chapter and distinct real failure retain honest outcomes',async({page})=>{
  38 |  await page.addInitScript(()=>window.addEventListener('pointerdown',()=>{document.documentElement.dataset.v4Pointers=String(Number(document.documentElement.dataset.v4Pointers??0)+1);}));await startV4(page,'lantern-witness-0',true);
  39 |  for(const action of chapterActions)await commandV4(page,action,true);
  40 |  expect(Number(await page.locator('html').getAttribute('data-v4-pointers'))).toBe(0);await saveV4(page,'keyboard-chapter');
  41 |  await activateV4(page,page.getByRole('button',{name:'带着炉谱，再启一程'}),true);await activateV4(page,page.locator('#v4-start'),true);await activateV4(page,page.getByRole('button',{name:'确认',exact:true}),true);await commandV4(page,{type:'continue'},true);
  42 |  for(let day=1;day<=3;day++){await commandV4(page,{type:'settle'},true);if(day<3)await commandV4(page,{type:'advance'},true);}const s=await saveV4(page,'keyboard-defeat');expect(s.phase).toBe('defeat');expect(s.seals).toBe(0);await expect(page.locator('#v4-stage-title')).toHaveText('炉火暂熄');expect(Number(await page.locator('html').getAttribute('data-v4-pointers'))).toBe(0);await shotV4(page,'real-defeat');
  43 | });
  44 | 
  45 | test('unfulfilled bridge is dark; missed chapter retains growth, and recipe and reserve choices have real consequences',async({page})=>{
  46 |  await startV4(page);for(const action of chapterActions){if(action.type==='advance'&&(await readV4(page)).day===3)break;await commandV4(page,action);}await commandV4(page,{type:'advance'});let s=await readV4(page);expect(s.blades.find(b=>b.id==='d4-1')!.recipe).toBe('guard');
  47 |  await commandV4(page,{type:'setRecipe',pieceId:'d4-1',recipe:'light'});await commandV4(page,{type:'strike',pieceId:'d4-1'});await expect(page.locator('#v4-recipes button')).toHaveCount(0);await commandV4(page,{type:'reserve',pieceId:'d4-1'});await commandV4(page,{type:'scrap',pieceId:'d4-2'});await commandV4(page,{type:'settle'});await expect(page.locator('#v4-stage-image')).toHaveAttribute('src','/assets/d/v07/bridge-dark-v1.webp');await expect(page.locator('#v4-stage-title')).toContainText('仍有缺口');await shotV4(page,'bridge-unfulfilled');await commandV4(page,{type:'chooseModification',modification:'warmRack'});s=await saveV4(page,'bridge-missed-growth');expect(s.history.at(-1)!.met).toBe(false);expect(s.reserveId).toBe('d4-1');expect(s.modifications).toEqual(['warmRack']);await expect(page.locator('#v4-stage-copy')).toContainText('渡口的遗憾');
  48 | });
  49 | 
```