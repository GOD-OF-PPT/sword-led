# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: v4-forge.spec.ts >> v4 left-click lands the real flat hammer face on opaque steel at both desktop sizes
- Location: tests/e2e/v4-forge.spec.ts:19:1

# Error details

```
Test timeout of 45000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - region [ref=f1e4]:
    - generic [ref=f1e5]:
      - paragraph [ref=f1e6]: 重燃十二盏灯 · 第一章
      - heading "锤下求生" [level=1] [ref=f1e7]
      - paragraph [ref=f1e8]: 一炉火，一柄剑，一程未熄的灯。
      - button "启程" [ref=f1e10] [cursor=pointer]
      - generic [ref=f1e11]:
        - button "翻开炉谱" [ref=f1e12] [cursor=pointer]
        - button "炉边设置" [ref=f1e13] [cursor=pointer]
      - group [ref=f1e14]:
        - generic "+ 行旅种子与旧路" [ref=f1e15] [cursor=pointer]
    - paragraph [ref=f1e16]: 左键落锤，见好就收。好剑总有它要去的地方。
  - navigation "行旅工具" [ref=f1e17]:
    - button "查看保存详情" [ref=f1e18] [cursor=pointer]: 本机存档
  - status [ref=f1e19]
```