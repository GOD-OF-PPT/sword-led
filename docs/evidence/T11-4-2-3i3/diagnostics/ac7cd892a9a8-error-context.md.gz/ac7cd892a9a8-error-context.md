# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: v4-recovery.spec.ts >> combined chapter write faults retain accepted work and never claim pending collection as saved
- Location: tests/e2e/v4-recovery.spec.ts:7:1

# Error details

```
Error: Expected bounded plain JSON with safe integer fields.
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - text: −
  - region [ref=e4]:
    - generic [ref=e6]:
      - paragraph [ref=e7]: 灯炉行记
      - heading "渡口重新亮了" [level=1] [ref=e8]
      - generic [ref=e10]:
        - paragraph [ref=e11]: 渡口亮起第一列灯，巡守与信使终于能在桥头碰面。
        - heading "给下一程，改一件炉具" [level=3] [ref=e12]
        - generic [ref=e13]:
          - article [ref=e14]:
            - heading "风箱" [level=3] [ref=e16]
            - paragraph [ref=e17]: 每柄首次普通大成，额外增加10%身价；从下一天起生效。
            - button "装上风箱" [ref=e18] [cursor=pointer]
          - article [ref=e19]:
            - heading "余温架" [level=3] [ref=e21]
            - paragraph [ref=e22]: 唯一留剑跨天增加15%身价，裂纹和锤势原样保留。
            - button "装上余温架" [ref=e23] [cursor=pointer]
      - generic [ref=e24]:
        - button "先看看炉谱" [ref=e25] [cursor=pointer]
        - button "回标题，保留选择" [ref=e26] [cursor=pointer]
  - navigation "行旅工具" [ref=e27]:
    - button "暂停与行旅菜单" [ref=e28] [cursor=pointer]: 行囊
    - button "打开炉谱" [ref=e29] [cursor=pointer]: 炉谱
    - button "打开设置" [ref=e30] [cursor=pointer]: 设置
    - button "查看保存详情" [ref=e31] [cursor=pointer]: 保存详情 !
  - region "保存状态" [ref=e32]:
    - paragraph [ref=e33]: 当前行程尚未保存 · 炉谱请先保存当前局，再保存新成长
    - button "查看保存详情" [ref=e34] [cursor=pointer]
  - status [ref=e35]: 落锤 · 锻成 · 这一记后身价 273
  - dialog [ref=e36]:
    - heading "把行程收好" [level=2] [ref=e37]
    - generic [ref=e39]:
      - heading "当前行程" [level=3] [ref=e40]
      - paragraph [ref=e41]: 当前行程尚未保存 · 炉谱请先保存当前局，再保存新成长
      - button "重试保存本局" [ref=e42] [cursor=pointer]
      - button "重试保存炉谱" [ref=e43] [cursor=pointer]
      - button "重新取得保存权 / 读取最新" [ref=e44] [cursor=pointer]
      - button "导出当前行程" [active] [ref=e45] [cursor=pointer]
      - button "导出炉谱和原文" [ref=e46] [cursor=pointer]
      - paragraph [ref=e47]: 炉谱备份：2件作品 · 保存于2026/10/20 18:31:17
      - button "恢复这份炉谱备份" [disabled] [ref=e48]
      - heading "不保存试玩" [level=3] [ref=e49]
      - paragraph [ref=e50]: 当前磁盘进度保持原样。明确转为不保存后，关闭/刷新会失去本次内存试玩，请先导出。
      - button "保留当前局，不保存续玩" [ref=e51] [cursor=pointer]
      - button "不保存，另开一炉" [ref=e52] [cursor=pointer]
    - button "回到当前页面" [ref=e54] [cursor=pointer]
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test';
  2  | import {startV4,readV4,commandV4,chapterActions,confirmV4,saveV4,shotV4} from './v4-helpers.js';
  3  | import {applyCommand,createRun,validateRun} from '../../src/core-v4/index.js';
  4  | import type {Page} from '@playwright/test';
  5  | import {readFile} from 'node:fs/promises';
> 6  | async function exported(page:Page){await page.locator('#v4-save-open').click();const promise=page.waitForEvent('download');await page.getByRole('button',{name:'导出当前行程',exact:true}).click();const dl=await promise,path=await dl.path();if(!path)throw Error('Missing export');const envelope=JSON.parse(await readFile(path,'utf8'));const result=validateRun(envelope.state);if(!result.ok)throw Error(result.detail);return result.state;}
     |                                                                                                                                                                                                                                                                                                                                                                                                     ^ Error: Expected bounded plain JSON with safe integer fields.
  7  | test('combined chapter write faults retain accepted work and never claim pending collection as saved',async({page},info)=>{
  8  |  await startV4(page);for(const action of chapterActions.slice(0,61))await commandV4(page,action);
  9  |  const before=await readV4(page),bytes=await page.evaluate(()=>localStorage.getItem('sword-led.save.v4'));
  10 |  await page.evaluate(()=>{const set=Storage.prototype.setItem;Object.assign(window,{v4Deny:{run:true,collection:true,set}});Storage.prototype.setItem=function(k,v){const d=(window as unknown as {v4Deny:{run:boolean;collection:boolean}}).v4Deny;if(k==='sword-led.save.v4'&&d.run||k==='sword-led.collection.v1'&&d.collection)throw new DOMException('quota','QuotaExceededError');return set.call(this,k,v);};});
  11 |  await page.locator('#v4-settle').click();await confirmV4(page);await expect(page.locator('#v4-stage-title')).toHaveText('渡口重新亮了');await expect(page.locator('#v4-save-summary')).toContainText('尚未保存');expect(await page.evaluate(()=>localStorage.getItem('sword-led.save.v4'))).toBe(bytes);
  12 |  let expected=applyCommand(before,{runId:before.runId,expectedRevision:before.revision,action:{type:'settle'}});if(!expected.ok)throw Error(expected.error);expect(await exported(page)).toEqual(expected.state);await page.getByRole('button',{name:'重试保存本局',exact:true}).click();await page.evaluate(()=>{(window as unknown as {v4Deny:{run:boolean}}).v4Deny.run=false;});await page.getByRole('button',{name:'重试保存本局',exact:true}).click();expect(await readV4(page)).toEqual(expected.state);await page.getByRole('button',{name:'回到当前页面',exact:true}).click();
  13 |  await page.getByRole('button',{name:'装上风箱',exact:true}).click();expected=applyCommand(expected.state,{runId:expected.state.runId,expectedRevision:expected.state.revision,action:{type:'chooseModification',modification:'windbox'}});if(!expected.ok)throw Error(expected.error);expect(await readV4(page)).toEqual(expected.state);await expect(page.locator('#v4-stage-copy')).toContainText('成果等待安全保存');await expect(page.locator('#v4-stage-copy')).not.toContainText('炉谱已记下第一章');await shotV4(page,'pending-chapter');
  14 |  await page.locator('#v4-save-open').click();await page.evaluate(()=>{(window as unknown as {v4Deny:{collection:boolean}}).v4Deny.collection=false;});await page.getByRole('button',{name:'重试保存炉谱',exact:true}).click();await page.getByRole('button',{name:'回到当前页面',exact:true}).click();await expect(page.locator('#v4-stage-copy')).toContainText('炉谱已记下第一章');const s=await saveV4(page,'chapter-retried');await info.attach('accepted-fault-chapter',{body:JSON.stringify(s,null,2),contentType:'application/json'});
  15 | });
  16 | 
  17 | test('corrupt main exposes dated backup; cancellation preserves bytes and confirmed recovery restores exact state',async({page})=>{
  18 |  await startV4(page);await commandV4(page,{type:'continue'});await commandV4(page,{type:'strike',pieceId:'d1-1'});await commandV4(page,{type:'strike',pieceId:'d1-1'});const backup=await page.evaluate(()=>JSON.parse(localStorage.getItem('sword-led.save.backup.v4')!).state);
  19 |  await page.evaluate(()=>localStorage.setItem('sword-led.save.v4','{broken'));await page.reload();await page.locator('#v4-save-open').click();await page.getByRole('button',{name:'恢复这份局备份',exact:true}).click();await expect(page.locator('#v4-dialog-body')).toContainText('保存于');await page.getByRole('button',{name:'再想想',exact:true}).click();expect(await page.evaluate(()=>localStorage.getItem('sword-led.save.v4'))).toBe('{broken');await page.locator('#v4-save-open').click();await page.getByRole('button',{name:'恢复这份局备份',exact:true}).click();await confirmV4(page);expect(await readV4(page)).toEqual(backup);await expect(page.locator('#v4-workshop')).toBeVisible();await saveV4(page,'recovered-backup');
  20 | });
  21 | 
  22 | test('old v3 writer and new scene share a lease; handoff retains old bytes and enables explicit new play',async({page,context})=>{
  23 |  const old=await context.newPage();await old.goto('/v3.html?mode=3');await expect(old.locator('#v3-strike')).toBeEnabled();const bytes=await old.evaluate(()=>localStorage.getItem('sword-led.save.v3'));await page.goto('/');await expect(page.locator('#v4-start')).toBeDisabled();await expect(page.locator('#v4-save-summary')).toContainText('只读');await old.close();await page.locator('#v4-save-open').click();await page.getByRole('button',{name:'重新取得保存权 / 读取最新',exact:true}).click();await confirmV4(page);await expect(page.locator('#v4-start')).toBeEnabled();await page.locator('#v4-start').click();await commandV4(page,{type:'continue'});await commandV4(page,{type:'strike',pieceId:'d1-1'});expect(await page.evaluate(()=>localStorage.getItem('sword-led.save.v3'))).toBe(bytes);await saveV4(page,'writer-handoff');
  24 | });
  25 | 
  26 | test('new external save on empty title requires reread and never implicit replacement',async({page,context})=>{
  27 |  await page.goto('/');await expect(page.locator('#v4-start')).toBeEnabled();const made=createRun({runId:'external-legitimate',seed:'external-legitimate'});if(!made.ok)throw Error(made.error);const bytes=JSON.stringify({schemaVersion:4,rulesVersion:'forge-v4',savedAt:Date.now(),state:made.state});const other=await context.newPage();await other.goto('/');await other.evaluate(bytes=>localStorage.setItem('sword-led.save.v4',bytes),bytes);await expect(page.locator('#v4-start')).toBeDisabled();expect(await page.evaluate(()=>localStorage.getItem('sword-led.save.v4'))).toBe(bytes);await other.close();await page.locator('#v4-save-open').click();await page.getByRole('button',{name:'重新取得保存权 / 读取最新',exact:true}).click();await confirmV4(page);await expect(page.locator('#v4-start')).toBeEnabled();await page.locator('#v4-start').click();await expect(page.locator('#v4-dialog-title')).toContainText('另启一程');await page.getByRole('button',{name:'再想想',exact:true}).click();expect(await readV4(page)).toEqual(made.state);
  28 | });
  29 | 
  30 | test('missing locks has explicit memory escape and neither game nor collection writes',async({page})=>{
  31 |  await page.addInitScript(()=>Object.defineProperty(navigator,'locks',{configurable:true,value:undefined}));await page.goto('/');await expect(page.locator('#v4-start')).toBeDisabled();await page.locator('#v4-save-open').click();await page.getByRole('button',{name:'不保存，开一炉试玩',exact:true}).click();await confirmV4(page);await page.getByRole('button',{name:'点火开炉',exact:true}).click();await page.locator('#v4-hit').click({position:{x:250,y:170}});await expect(page.locator('#v4-value')).not.toHaveText('40');await expect(page.locator('#v4-save-summary')).toContainText('不保存');const s=await exported(page);expect(s.rng.forge.draws).toBe(1);expect(await page.evaluate(()=>['sword-led.save.v4','sword-led.collection.v1'].map(k=>localStorage.getItem(k)))).toEqual([null,null]);
  32 | });
  33 | 
```