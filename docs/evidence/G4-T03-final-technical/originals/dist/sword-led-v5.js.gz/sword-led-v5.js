//#region src/core/immutable.ts
function e(t) {
	if (typeof t != "object" || !t || Object.isFrozen(t)) return t;
	let n = Array.isArray(t) ? t.map((t) => e(t)) : Object.fromEntries(Object.entries(t).map(([t, n]) => [t, e(n)]));
	return Object.freeze(n);
}
//#endregion
//#region src/core-v3/rules.ts
var t = Object.freeze({
	steady: {
		name: "稳手护符",
		text: "首次裂损保住身价，剑仍会留下裂纹。"
	},
	ember: {
		name: "炉心余烬",
		text: "连锻多一记安全锤。"
	},
	inherit: {
		name: "余温铁夹",
		text: "碎剑峰值的20%传给下轮第一柄，最多增加普通底价的4倍。"
	},
	echo: {
		name: "回响锤纹",
		text: "每第三次普通成功，身价额外增长25%。"
	},
	crackedEdge: {
		name: "裂锋印",
		text: "裂纹剑的大成率增加10个百分点，裂损率不变。"
	},
	pardon: {
		name: "护炉契",
		text: "本局首次失约免扣印记；卸下再装备也不会恢复次数。"
	}
});
Object.keys(t);
//#endregion
//#region src/core-v4/content.ts
var n = Object.freeze([
	"steady",
	"ember",
	"inherit",
	"echo",
	"crackedEdge",
	"pardon"
]), r = Object.freeze([
	"light",
	"guard",
	"heavy"
]), i = Object.freeze([
	"windbox",
	"warmRack",
	"wideMouth"
]), a = Object.freeze([
	"donation",
	"loan",
	"salvage",
	"credit",
	"shelter",
	"rest"
]), o = e({
	light: {
		name: "轻刃",
		success: 155,
		great: 210,
		greatOdds: 150,
		cracks: [
			80,
			120,
			180,
			260,
			340,
			420,
			500,
			550,
			600
		]
	},
	guard: {
		name: "护刃",
		success: 140,
		great: 195,
		greatOdds: 150,
		cracks: [
			30,
			50,
			80,
			120,
			180,
			240,
			320,
			400,
			480
		]
	},
	heavy: {
		name: "重锋",
		success: 145,
		great: 240,
		greatOdds: 200,
		cracks: [
			60,
			100,
			150,
			220,
			300,
			380,
			460,
			540,
			600
		]
	}
}), s = e({
	windbox: {
		name: "风箱",
		text: "每柄首次普通大成，额外增加10%身价；从下一天起生效。"
	},
	warmRack: {
		name: "余温架",
		text: "唯一留剑跨天增加15%身价，裂纹和锤势原样保留。"
	},
	wideMouth: {
		name: "宽口炉",
		text: "每柄第一次安全连锻多一记，可与炉心余烬叠加。"
	}
}), c = e([
	{
		id: 1,
		title: "第一章 · 灯从炉起",
		days: [1, 4],
		base: 40,
		opening: "山路第一盏灯熄了。阿岚把旧巡剑放到铁砧旁：先让巡夜的人回家。",
		letter: "阿禾捎来第一封信：驿路有人等灯，也有人等一把好剑。",
		success: "渡口亮起第一列灯，巡守与信使终于能在桥头碰面。",
		failure: "渡口还没有完全守住。你带着未完成的委托继续上路，炉火仍在。"
	},
	{
		id: 2,
		title: "第二章 · 风雪同行",
		days: [5, 8],
		base: 80,
		opening: "山路渐陡。留下的旧剑、新学的手艺，都要在风雪里派上用场。",
		letter: "杜伯说，裂纹也能记住炉火。阿禾却要两柄轻剑，分给两条驿路。",
		success: "双驿的灯先后回应，雪中的救援队看见了归路。",
		failure: "双驿仍有一条路未通。已救回的人与遗憾，都记在这本炉谱里。"
	},
	{
		id: 3,
		title: "第三章 · 山口守灯",
		days: [9, 12],
		base: 160,
		opening: "最后一位商人在山口等候。决定带上什么，再锻最后几炉。",
		letter: "阿岚守着缺口，阿禾赶来接力。杜伯等一柄真正能留名的护灯剑。",
		success: "护灯剑送到山口，三人的灯火终于相连。",
		failure: "山口仍有未完成的事。好剑与遗憾会一同陪你归来。"
	}
]), l = e([
	{
		day: 3,
		upgrade: 180,
		repair: 150,
		pool: [
			"steady",
			"ember",
			"echo"
		]
	},
	{
		day: 6,
		upgrade: 700,
		repair: 350,
		pool: [
			"inherit",
			"crackedEdge",
			"pardon"
		]
	},
	{
		day: 9,
		upgrade: 1600,
		repair: 800,
		pool: [
			"steady",
			"ember",
			"inherit",
			"echo",
			"crackedEdge",
			"pardon"
		]
	}
]), u = e({
	donation: {
		name: "护送捐剑",
		request: "巡守愿替你护送下一批铁料，代价是一柄现在能带走的剑。",
		cost: [
			0,
			0,
			0
		],
		piece: "active",
		result: "这柄剑交给护送队。下一天的三个铁坯底价增加20%。"
	},
	loan: {
		name: "借锤",
		request: "杜伯愿借出老锤。付60金币，让明天第一柄前三记普通锤的正收益额多10%。",
		cost: [
			60,
			60,
			60
		],
		piece: "none",
		result: "借锤的钱已记清，明日第一柄会带上这份手感。"
	},
	salvage: {
		name: "旧刃回收",
		request: "行商愿用160金币换走架上的旧剑。交出去，就没有这柄旧剑可作下一轮委托。",
		cost: [
			0,
			0,
			0
		],
		piece: "reserve",
		result: "160金币入袋，旧剑离开剑架，不再兼作交差或保险。"
	},
	credit: {
		name: "商人赊护",
		request: "付清护炉钱，下一次完好剑出现裂纹时保住身价；再次裂损仍会断。",
		cost: [
			90,
			180,
			360
		],
		piece: "none",
		result: "保价资格已备好。下一次首次裂损会消耗，不会恢复断剑。"
	},
	shelter: {
		name: "雨夜修棚",
		request: "花80金币修好炉棚，明天第一柄在当天的裂损率降低3个百分点。",
		cost: [
			80,
			80,
			80
		],
		piece: "none",
		result: "炉棚补好了。明天第一柄能少受一点风雨，之后不再额外生效。"
	},
	rest: {
		name: "守炉",
		request: "今夜不添交易。守着炉火，保留眼前的剑与金币。",
		cost: [
			0,
			0,
			0
		],
		piece: "none",
		result: "没有额外得失，这一炉的选择原样保留。"
	}
}), d = e([
	{
		id: 1,
		title: "巡夜第一灯",
		customer: "guard",
		name: "阿岚",
		request: "巡夜的人要一柄无裂新剑，先点亮归家的第一站。",
		success: "阿岚点亮第一座灯站，巡夜的人看见了家门。",
		failure: "第一站还在等可靠的新剑。",
		scene: "night-watch",
		routes: [{
			id: "intact",
			count: 1,
			value: 100,
			crack: "intact"
		}]
	},
	{
		id: 2,
		title: "重开驿路",
		customer: "courier",
		name: "阿禾",
		request: "四记普通锤内的无裂轻刃，跑山路才轻快。",
		success: "阿禾带轻刃穿过驿路，第一封信准时送达。",
		failure: "驿路还没有等到轻快的剑。",
		scene: "courier-road",
		routes: [{
			id: "light",
			count: 1,
			value: 160,
			recipe: "light",
			crack: "intact",
			maxHits: 4
		}]
	},
	{
		id: 3,
		title: "修炉试锋",
		customer: "smith",
		name: "杜伯",
		request: "让一柄剑经历一次安全连锻，看看这座炉的火候。",
		success: "杜伯听过成品的回响，替你重新接好了炉火。",
		failure: "这次还没有交出连锻的成品。",
		scene: "rekindle",
		routes: [{
			id: "burst",
			count: 1,
			value: 260,
			minBursts: 1
		}]
	},
	{
		id: 4,
		title: "守住渡口",
		customer: "guard",
		name: "阿岚",
		request: "渡口需要一柄无裂护刃，守住来往的人。",
		success: "护刃送上桥头，渡口恢复了巡守。",
		failure: "渡口仍有缺口，阿岚把未竟的事记在纸上。",
		scene: "bridge",
		routes: [{
			id: "guard",
			count: 1,
			value: 360,
			recipe: "guard",
			crack: "intact"
		}]
	},
	{
		id: 5,
		title: "故剑归程",
		customer: "courier",
		name: "阿禾",
		request: "带一柄昨日留下的旧剑；若没有，就用更好的新剑接替。",
		success: "一柄剑接住了前一程的约定，阿禾又能赶路。",
		failure: "这一程的旧剑与新剑都还差一点。",
		scene: "returning-blade",
		routes: [{
			id: "old",
			count: 1,
			value: 420,
			age: "old"
		}, {
			id: "new",
			count: 1,
			value: 630,
			age: "new"
		}]
	},
	{
		id: 6,
		title: "逆火修行",
		customer: "smith",
		name: "杜伯",
		request: "带裂纹也能成器，锻一柄有故事的剑。",
		success: "杜伯接过裂剑：它记得你何时肯收手。",
		failure: "裂纹的手艺还需下一炉。",
		scene: "cracked-work",
		routes: [{
			id: "cracked",
			count: 1,
			value: 520,
			crack: "cracked"
		}]
	},
	{
		id: 7,
		title: "救援重锋",
		customer: "guard",
		name: "阿岚",
		request: "救援队要重锋，劈开山路上的阻碍。",
		success: "重锋开出救援道，山里的灯又亮了一站。",
		failure: "救援道还没有完全打开。",
		scene: "rescue",
		routes: [{
			id: "heavy",
			count: 1,
			value: 760,
			recipe: "heavy"
		}]
	},
	{
		id: 8,
		title: "风雪双驿",
		customer: "courier",
		name: "阿禾",
		request: "两条驿路，两柄各自合格的无裂轻刃。",
		success: "两柄轻刃分赴双驿，雪中的灯彼此回应。",
		failure: "双驿尚未全部接通，不能把一柄剑算作两柄。",
		scene: "twin-stations",
		routes: [{
			id: "two-light",
			count: 2,
			value: 420,
			recipe: "light",
			crack: "intact"
		}]
	},
	{
		id: 9,
		title: "炉火回响",
		customer: "smith",
		name: "杜伯",
		request: "让一柄剑经历两次安全连锻，再听一次炉火回响。",
		success: "两次连锻的锻纹交在一起，杜伯记下了这门手艺。",
		failure: "两次炉火的成品还未交出。",
		scene: "double-fire",
		routes: [{
			id: "two-bursts",
			count: 1,
			value: 1e3,
			minBursts: 2
		}]
	},
	{
		id: 10,
		title: "缺口之剑",
		customer: "guard",
		name: "阿岚",
		request: "带裂护刃也可守缺口，或用更高身价的完好护刃。",
		success: "阿岚把护刃举在缺口前，身后的人继续前行。",
		failure: "缺口尚未补上，这次的风险与收手都留在记录中。",
		scene: "mountain-gap",
		routes: [{
			id: "cracked",
			count: 1,
			value: 1150,
			recipe: "guard",
			crack: "cracked"
		}, {
			id: "intact",
			count: 1,
			value: 1800,
			recipe: "guard",
			crack: "intact"
		}]
	},
	{
		id: 11,
		title: "最后的接力",
		customer: "courier",
		name: "阿禾",
		request: "一柄同行的旧剑，或两柄新剑，接完最后一程。",
		success: "阿禾把剑交到接力的人手里，山口已在眼前。",
		failure: "接力还缺最后的一柄，归程也会记住这件事。",
		scene: "relay",
		routes: [{
			id: "old",
			count: 1,
			value: 1300,
			age: "old"
		}, {
			id: "two-new",
			count: 2,
			value: 850,
			age: "new"
		}]
	},
	{
		id: 12,
		title: "山口护灯",
		customer: "smith",
		name: "杜伯",
		request: "无裂名器重锋，送到山口，护住最后的灯。",
		success: "护灯剑送到山口，三人抬头看见了相连的灯火。",
		failure: "护灯剑还没有完成，不能说十二灯已经复明。",
		scene: "last-lantern",
		routes: [{
			id: "finale",
			count: 1,
			value: 2500,
			recipe: "heavy",
			crack: "intact",
			minLevel: 9
		}]
	}
]), f = e({
	victory: {
		title: "十二灯复明",
		text: "关键的剑都送到了，十二站的灯在归路上依次亮起。"
	},
	return: {
		title: "灯下归途",
		text: "炉火还在，有些约定仍未完成。带着这次的作品与手艺再上路。"
	},
	defeat: {
		title: "炉火暂熄",
		text: "契约印记用尽了。已经做成的作品与学会的炉谱会留下。"
	}
}), p = 1e9, m = 99, h = 1900, g = 2048, _ = (e) => e <= 4 ? 1 : e <= 8 ? 2 : 3, v = (e) => Math.floor(e.base / 4), y = (e) => e.value >= 1e9 || e.level >= 99, b = (e, t) => Math.min(p, Math.floor(e * t / 100));
function x(e) {
	let t = _(e.day);
	return t === 1 ? {
		baseFee: 100,
		budget: 60
	} : t === 2 ? {
		baseFee: 250,
		budget: 150
	} : {
		baseFee: 600,
		budget: 300
	};
}
var S = (e) => Math.max(0, x(e).budget - e.marketSpent);
function C(e, t) {
	let n = 0, r = 1;
	for (let t of e.routes) {
		let e = Math.min(t.count, t.required);
		e * r > n * t.required && (n = e, r = t.required);
	}
	return Math.floor(t * n / r);
}
function w(e, t, n) {
	return Math.floor(c[_(t) - 1].base * 3 ** e.upgradeCount / 2 ** e.upgradeCount * n / 100);
}
function T(e) {
	return d[e.commissionOrder[e.day - 1] - 1];
}
function E(e) {
	let t = new Set(e.initialEligibility.recipes);
	e.history.some((e) => e.day === 4 && e.sealsAfter > 0) && t.add("guard"), e.history.some((e) => e.day === 8 && e.sealsAfter > 0) && t.add("heavy");
	for (let n of T(e).routes) n.recipe && t.add(n.recipe);
	return [
		"light",
		"guard",
		"heavy"
	].filter((e) => t.has(e));
}
function D(e) {
	return T(e).routes.find((e) => e.recipe)?.recipe || (E(e).includes("guard") ? "guard" : "light");
}
function ee(e, t) {
	let n = o[t.recipe], r = e.dayBuffs.shelter && t.suppliedDay === e.day && t.slot === 1, i = Math.max(0, (t.hits < 3 ? 0 : n.cracks[Math.min(t.hits - 3, 8)]) - (r ? 30 : 0)), a = t.charge === 6, s = a ? 350 : n.greatOdds + (t.cracked && e.traits.includes("crackedEdge") ? 100 : 0);
	return {
		burst: a,
		crack: a ? 0 : i,
		great: s,
		success: 1e3 - s - (a ? 0 : i),
		afterBurstCrack: i
	};
}
function O(e, t, n) {
	let r = [];
	return n.recipe && t.recipe !== n.recipe && r.push(`需要${o[n.recipe].name}`), n.crack === "intact" && t.cracked && r.push("需要无裂纹"), n.crack === "cracked" && !t.cracked && r.push("需要带裂纹"), n.age === "old" && t.suppliedDay >= e.day && r.push("需要此前留下的旧剑"), n.age === "new" && t.suppliedDay !== e.day && r.push("需要本日新剑"), n.maxHits !== void 0 && t.hits > n.maxHits && r.push(`普通锤不得超过${n.maxHits}次`), n.minLevel !== void 0 && t.level < n.minLevel && r.push(`需要等级${n.minLevel}`), n.minBursts !== void 0 && t.bursts < n.minBursts && r.push(`需要${n.minBursts}次连锻`), t.value < n.value && r.push(`还差${n.value - t.value}身价`), {
		matches: r.length === 0,
		missing: r
	};
}
function k(e) {
	let t = T(e), n = e.blades.filter((n) => n.status === "commissioned" && n.commissionId === t.id && n.finalizedDay === e.day), r = new Map(e.journal.flatMap((e, t) => e.type === "deliver" ? [[e.pieceId, t]] : []));
	n.sort((e, t) => (r.get(e.id) ?? 2 ** 53 - 1) - (r.get(t.id) ?? 2 ** 53 - 1));
	let i = t.routes.map((t) => {
		let r = n.filter((n) => O(e, n, t).matches).map((e) => e.id);
		return {
			id: t.id,
			required: t.count,
			count: r.length,
			pieceIds: r,
			complete: r.length >= t.count
		};
	}), a = i.find((e) => e.complete);
	return {
		commissionId: t.id,
		complete: !!a,
		routeId: a?.id ?? null,
		pieceIds: a?.pieceIds.slice(0, a.required) ?? [],
		routes: i
	};
}
function te(e, t) {
	let n = T(e).routes.map((n) => ({
		id: n.id,
		...O(e, t, n)
	}));
	return {
		canDeliver: e.phase === "workshop" && t.status === "active" && t.id !== e.reserveId,
		qualifies: n.some((e) => e.matches),
		routes: n
	};
}
function ne(e, t) {
	let n = T(e), r = k(e), i = te(e, t), a = !r.complete && i.qualifies, o = i.routes.filter((e) => e.matches).map((e) => e.id), s = n.routes.filter((e) => o.includes(e.id)).map((e) => e.value), c = s.length ? Math.min(...s) : null, { baseFee: l } = x(e), u = S(e), d = { routes: r.routes.map((e) => ({
		...e,
		count: e.count + +!!o.includes(e.id)
	})) }, f = a ? C(d, l) - C(r, l) : 0, p = a && c !== null ? Math.min(Math.floor(Math.max(0, t.value - c) / 5), u) : 0, m = Math.min(Math.floor(t.value / 4), u), h = a ? f + p : m, g = a ? p : m, _ = null;
	return e.phase === "workshop" ? e.journal.length >= 2048 ? _ = "record_limit" : t.status === "active" ? t.id === e.reserveId ? _ = "reserved_piece" : !a && m === 0 && (_ = "market_exhausted") : _ = "piece_unavailable" : _ = "wrong_phase", {
		pieceValue: t.value,
		matched: a,
		matchedRouteIds: o,
		threshold: c,
		baseFeeDelta: f,
		qualityBonus: p,
		saleQuote: m,
		amount: h,
		marketCost: g,
		allowed: _ === null,
		error: _
	};
}
var A = (e, t) => Math.min(v(t), S(e));
function re(e, t) {
	let n = null;
	return e.phase === "workshop" ? e.journal.length >= 1900 ? n = "record_limit" : t.status === "active" ? t.id === e.reserveId ? n = "reserved_piece" : t.level < 3 && (n = "blade_unworked") : n = "piece_unavailable" : n = "wrong_phase", {
		allowed: n === null,
		error: n
	};
}
function ie(e) {
	let t = e.blades.filter((t) => t.status === "active" && t.id !== e.reserveId), n = k(e), r = S(e), i = t.map((e) => {
		let t = Math.min(v(e), r);
		return r -= t, {
			pieceId: e.id,
			amount: t
		};
	}), a = !n.complete && e.traits.includes("pardon") && !e.pardonUsed;
	return {
		...n,
		remaining: t,
		recoveries: i,
		recovered: i.reduce((e, t) => e + t.amount, 0),
		protected: a,
		sealsAfter: e.seals - (n.complete || a ? 0 : 1)
	};
}
var j = (e) => l.find((t) => t.day === e.day) ?? null, M = (e) => e.phase === "workshop" && j(e) !== null;
function N(e, t) {
	let n = e.eventId ? u[e.eventId] : null, r = n?.cost[_(e.day) - 1] ?? 0, i = null;
	if (e.phase !== "workshop" || e.eventStatus !== "available" || !n) i = "unavailable";
	else if (e.coins < r) i = "insufficient_coins";
	else if (e.eventId === "credit" && e.crackGuard) i = "already_owned";
	else if (n.piece !== "none") {
		let r = e.blades.find((e) => e.id === t);
		(!r || r.status !== "active" || (n.piece === "reserve" ? e.reserveId !== r.id : e.reserveId === r.id)) && (i = "piece_unavailable");
	} else t !== void 0 && (i = "invalid_command");
	return {
		eventId: e.eventId,
		cost: r,
		requiresPiece: n?.piece ?? "none",
		allowed: i === null,
		error: i
	};
}
e([
	120,
	150,
	180,
	210,
	250,
	290,
	340,
	390,
	450,
	520,
	600,
	700
]), e([
	3,
	6,
	9
]), e([
	{
		name: "粗坯",
		progress: 0,
		multiplier: 10
	},
	{
		name: "整形",
		progress: 2,
		multiplier: 16
	},
	{
		name: "淬炼",
		progress: 5,
		multiplier: 25
	},
	{
		name: "成刃",
		progress: 9,
		multiplier: 38
	},
	{
		name: "精工",
		progress: 14,
		multiplier: 56
	},
	{
		name: "上品",
		progress: 20,
		multiplier: 80
	},
	{
		name: "名作",
		progress: 27,
		multiplier: 115
	},
	{
		name: "传世",
		progress: 35,
		multiplier: 160
	}
]), e({
	iron: {
		name: "熟铁",
		baseValue: 18,
		integrity: 4,
		risk: 2,
		scrap: 3
	},
	steel: {
		name: "精钢",
		baseValue: 22,
		integrity: 3,
		risk: 6,
		scrap: 4
	},
	meteorite: {
		name: "陨铁",
		baseValue: 28,
		integrity: 2,
		risk: 10,
		scrap: 5
	}
}), e({
	light: {
		label: "轻锤",
		progress: 1,
		heat: 8,
		stress: 3,
		risk: -2,
		periodMs: 1600
	},
	standard: {
		label: "标准锤",
		progress: 2,
		heat: 12,
		stress: 7,
		risk: 2,
		periodMs: 1400
	},
	heavy: {
		label: "重锤",
		progress: 3,
		heat: 18,
		stress: 12,
		risk: 7,
		periodMs: 1200
	}
});
//#endregion
//#region src/core/guards.ts
function P(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
//#endregion
//#region src/core/random.ts
function F(e) {
	let t = 2166136261;
	for (let n of new TextEncoder().encode(e)) t = Math.imul(t ^ n, 16777619) >>> 0;
	return t;
}
function I(e) {
	let t = e.state + 1831565813 >>> 0, n = Math.imul(t ^ t >>> 15, t | 1);
	return n ^= n + Math.imul(n ^ n >>> 7, n | 61), {
		value: ((n ^ n >>> 14) >>> 0) / 4294967296,
		stream: {
			state: t,
			draws: e.draws + 1
		}
	};
}
e({
	handle: {
		label: "配重锤柄",
		effect: "精准区每级向两侧各扩大 2 个百分点",
		prices: [{
			coins: 100,
			scrap: 3
		}, {
			coins: 180,
			scrap: 5
		}]
	},
	bellows: {
		label: "强化风箱",
		effect: "每级令下一轮煤炭配给 +1",
		prices: [{
			coins: 120,
			scrap: 4
		}, {
			coins: 220,
			scrap: 6
		}]
	},
	anvil: {
		label: "稳固砧台",
		effect: "每级裂损概率 -3 个百分点",
		prices: [{
			coins: 160,
			scrap: 6
		}, {
			coins: 260,
			scrap: 8
		}]
	},
	repair: {
		label: "契约修补",
		effect: "恢复一枚契约印记，本次来访限一次",
		prices: [{
			coins: 240,
			scrap: 6
		}]
	}
}), e([
	"handle",
	"bellows",
	"anvil",
	"repair"
]), Object.freeze([]);
function L(e) {
	let t = 0, n = 0, r = (e, i) => {
		if (++t > 5e4 || i > 16) return null;
		if (e === null || typeof e == "boolean" || typeof e == "number" && Number.isSafeInteger(e)) {
			let t = JSON.stringify(e);
			return n += t.length, n <= 262144 ? t : null;
		}
		if (typeof e == "string") {
			if (e.length > 262144) return null;
			let t = JSON.stringify(e);
			return n += t.length, n <= 262144 ? t : null;
		}
		if (typeof e != "object") return null;
		let a = Array.isArray(e), o = Object.getPrototypeOf(e);
		if (a ? o !== Array.prototype : o !== Object.prototype && o !== null) return null;
		let s = Reflect.ownKeys(e);
		if (s.some((e) => typeof e != "string") || s.length > 1e4) return null;
		let c = [];
		if (a) {
			if (e.length > 2048 || s.length !== e.length + 1) return null;
			for (let t = 0; t < e.length; t++) {
				let n = Object.getOwnPropertyDescriptor(e, String(t));
				if (!n || !("value" in n) || !n.enumerable) return null;
				let a = n.value, o = r(a, i + 1);
				if (o === null) return null;
				c.push(o);
			}
			return `[${c.join(",")}]`;
		}
		let l = Object.getOwnPropertyNames(e).sort();
		for (let t of l) {
			let a = Object.getOwnPropertyDescriptor(e, t);
			if (!a || !("value" in a) || !a.enumerable || (n += t.length + 3, n > 262144)) return null;
			let o = a.value, s = r(o, i + 1);
			if (s === null) return null;
			c.push(`${JSON.stringify(t)}:${s}`);
		}
		return `{${c.join(",")}}`;
	};
	try {
		let t = r(e, 0);
		return t !== null && new TextEncoder().encode(t).byteLength <= 262144 ? t : null;
	} catch {
		return null;
	}
}
//#endregion
//#region src/core-v5/game.ts
var R = (e) => structuredClone(e), z = (e, t) => ({
	ok: !1,
	state: e,
	error: t,
	events: []
}), ae = () => ({
	supplyPct: 100,
	loan: !1,
	shelter: !1
}), B = (e, t) => typeof e == "string" && t.some((t) => t === e), V = (e, t) => Object.keys(e).sort().join(",") === [...t].sort().join(",");
function oe(e, t, n) {
	let r = I(e.rng[t]);
	return e.rng[t] = r.stream, Math.floor(r.value * n);
}
function se(e, t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = oe(e, t, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function ce(e) {
	e.supplyBase = w(e, e.day, e.dayBuffs.supplyPct);
	let t = Math.min(e.supplyBase * 4, e.inheritance), n = D(e);
	e.inheritance = 0;
	let r = e.blades.some((t) => t.id === e.reserveId && t.status === "active") ? 2 : 3;
	e.marketSpent = 0;
	for (let i = 1; i <= r; i++) {
		let r = e.supplyBase + (i === 1 ? t : 0);
		e.blades.push({
			id: `d${e.day}-${i}`,
			slot: i,
			suppliedDay: e.day,
			recipe: n,
			status: "active",
			base: r,
			value: r,
			peak: r,
			level: 0,
			cracked: !1,
			hits: 0,
			charge: 0,
			successes: 0,
			normalGreats: 0,
			bursts: 0,
			finalizedDay: null,
			commissionId: null
		});
	}
	e.shop = [], e.sold = [], e.upgraded = !1, e.repaired = !1;
	let i = l.find((t) => t.day === e.day);
	if (i) {
		let t = i.pool.filter((t) => !e.traits.includes(t));
		for (; t.length && e.shop.length < 2;) e.shop.push(t.splice(oe(e, "shop", t.length), 1)[0]);
	}
	let a = [
		3,
		5,
		7,
		9,
		11
	].indexOf(e.day);
	e.eventId = a < 0 ? null : e.eventDeck[a], e.eventStatus = e.eventId ? "available" : "none";
}
function le(t) {
	let n = L(t);
	if (!n) return {
		ok: !1,
		error: "invalid_command"
	};
	let i = JSON.parse(n);
	if (!P(i)) return {
		ok: !1,
		error: "invalid_command"
	};
	if (typeof i.runId != "string" || !/^[A-Za-z0-9_-]{1,80}$/.test(i.runId)) return {
		ok: !1,
		error: "invalid_run_id"
	};
	if (typeof i.seed != "string") return {
		ok: !1,
		error: "invalid_seed"
	};
	let o = i.seed.normalize("NFC").trim();
	if (!o || Array.from(o).length > 64) return {
		ok: !1,
		error: "invalid_seed"
	};
	if (i.mode !== void 0 && i.mode !== "story" && i.mode !== "challenge" || !V(i, [
		"runId",
		"seed",
		...i.mode === void 0 ? [] : ["mode"],
		...i.eligibility === void 0 ? [] : ["eligibility"]
	])) return {
		ok: !1,
		error: "invalid_command"
	};
	let s = {
		recipes: ["light"],
		challenge: !1
	};
	if (i.eligibility !== void 0) {
		let e = i.eligibility;
		if (!P(e) || !V(e, ["recipes", "challenge"]) || !Array.isArray(e.recipes) || e.recipes.length > 3 || !e.recipes.every((e) => B(e, r)) || typeof e.challenge != "boolean") return {
			ok: !1,
			error: "invalid_command"
		};
		let t = e.recipes;
		s = {
			recipes: r.filter((n) => n === "light" || e.challenge || t.includes(n)),
			challenge: e.challenge
		};
	}
	if (i.mode === "challenge" && !s.challenge) return {
		ok: !1,
		error: "challenge_locked"
	};
	let c = (e) => ({
		state: F(`${o}|v5|${e}`),
		draws: 0
	}), l = {
		rulesVersion: "forge-v5",
		runId: i.runId,
		seed: o,
		mode: i.mode ?? "story",
		initialEligibility: R(s),
		revision: 0,
		phase: "opening",
		day: 1,
		commissionOrder: Array.from({ length: 12 }, (e, t) => t + 1),
		coins: 0,
		seals: 3,
		supplyBase: 40,
		upgradeCount: 0,
		inheritance: 0,
		blades: [],
		reserveId: null,
		daySales: 0,
		dayRecovered: 0,
		marketSpent: 0,
		traits: [],
		gift: "locked",
		pardonUsed: !1,
		crackGuard: !1,
		modifications: [],
		chapterChoices: [],
		shop: [],
		sold: [],
		upgraded: !1,
		repaired: !1,
		dayBuffs: R(ae()),
		pending: R(ae()),
		eventDeck: [],
		eventId: null,
		eventStatus: "none",
		eventHistory: [],
		history: [],
		rng: {
			forge: c("forge"),
			shop: c("shop"),
			events: c("events"),
			content: c("content")
		},
		journal: []
	};
	if (l.eventDeck = se(l, "events", a), l.mode === "challenge") for (let e of [[
		5,
		6,
		7
	], [
		9,
		10,
		11
	]]) {
		let t = se(l, "content", e);
		for (let n = 0; n < e.length; n++) l.commissionOrder[e[n] - 1] = t[n];
	}
	return ce(l), e({
		ok: !0,
		state: l
	});
}
function ue(e) {
	if (!P(e)) return null;
	let t = typeof e.pieceId == "string" && e.pieceId.length <= 32;
	switch (e.type) {
		case "continue":
		case "upgrade":
		case "repair":
		case "settle":
		case "advance": return V(e, ["type"]) ? { type: e.type } : null;
		case "strike":
		case "deliver":
		case "scrap":
		case "reserve": return t && V(e, ["type", "pieceId"]) ? {
			type: e.type,
			pieceId: e.pieceId
		} : null;
		case "setRecipe": return t && B(e.recipe, r) && V(e, [
			"type",
			"pieceId",
			"recipe"
		]) ? {
			type: e.type,
			pieceId: e.pieceId,
			recipe: e.recipe
		} : null;
		case "chooseModification": return B(e.modification, i) && V(e, ["type", "modification"]) ? {
			type: e.type,
			modification: e.modification
		} : null;
		case "chooseEvent": return (e.choice === "accept" || e.choice === "decline") && (e.pieceId === void 0 || t) && V(e, [
			"type",
			"choice",
			...e.pieceId === void 0 ? [] : ["pieceId"]
		]) ? {
			type: e.type,
			choice: e.choice,
			...e.pieceId === void 0 ? {} : { pieceId: e.pieceId }
		} : null;
		case "buy":
		case "claimGift": return e.type === "buy" && !t || !B(e.traitId, n) && (e.type !== "claimGift" || e.traitId !== null) || e.replaceId !== void 0 && !B(e.replaceId, n) || !V(e, [
			"type",
			"traitId",
			...e.type === "buy" ? ["pieceId"] : [],
			...e.replaceId === void 0 ? [] : ["replaceId"]
		]) ? null : e;
		default: return null;
	}
}
function de(e, t, n) {
	if (e.traits.includes(t)) return "already_owned";
	if (e.traits.length === 3) {
		if (!n || !e.traits.includes(n)) return "invalid_replacement";
		e.traits.splice(e.traits.indexOf(n), 1);
	} else if (n !== void 0) return "invalid_replacement";
	return e.traits.push(t), null;
}
function fe(e, t, n) {
	let r = ee(e, t), i = oe(e, "forge", 1e3), a = t.value, s = [], c = 0, l = i < (n ? 350 : r.great) ? "great" : !n && i < r.great + r.crack ? "crack" : "success";
	if (n || t.hits++, !n && e.dayBuffs.shelter && t.slot === 1 && t.suppliedDay === e.day && s.push("shelter"), l === "crack") {
		if (t.cracked) {
			l = "broken", t.value = 0, t.status = "broken", t.finalizedDay = e.day;
			let n = A(e, t);
			e.coins += n, e.dayRecovered += n, e.marketSpent += n, c = n, e.traits.includes("inherit") && (e.inheritance += Math.floor(t.peak / 5), s.push("inherit"));
		} else {
			t.cracked = !0;
			let n = e.traits.includes("steady"), r = e.crackGuard;
			n && s.push("steady"), r && (s.push("credit"), e.crackGuard = !1), !n && !r && (t.value = b(t.value, 80));
		}
	} else {
		let r = o[t.recipe];
		t.value = b(t.value, l === "great" ? r.great : r.success), t.level = Math.min(99, t.level + (l === "great" ? 2 : 1)), n || (l === "great" && (t.normalGreats === 0 && e.modifications.includes("windbox") && (t.value = b(t.value, 110), s.push("windbox")), t.normalGreats++), t.successes++, e.traits.includes("echo") && t.successes % 3 == 0 && (t.value = b(t.value, 125), s.push("echo")), e.dayBuffs.loan && t.suppliedDay === e.day && t.slot === 1 && t.hits <= 3 && (t.value = Math.min(p, t.value + Math.floor((t.value - a) * 10 / 100)), s.push("loan")), t.cracked && l === "great" && e.traits.includes("crackedEdge") && s.push("crackedEdge"));
	}
	return t.peak = Math.max(t.peak, t.value), !n && t.status === "active" && (t.charge = Math.min(6, t.charge + 1)), {
		result: l,
		before: a,
		after: t.value,
		level: t.level,
		triggers: s,
		recoveryAmount: c
	};
}
function pe(e, t, n, r) {
	let i = e.eventId, a = 0;
	if (t === "accept") {
		let t = N(e, n);
		switch (a = t.cost === 0 ? 0 : -t.cost, e.coins -= t.cost, i) {
			case "donation": {
				let t = e.blades.find((e) => e.id === n);
				t.status = "donated", t.finalizedDay = e.day, e.pending.supplyPct = 120;
				break;
			}
			case "loan":
				e.pending.loan = !0;
				break;
			case "salvage": {
				let t = e.blades.find((e) => e.id === n);
				t.status = "bartered", t.finalizedDay = e.day, e.reserveId = null, e.coins += 160, a += 160;
				break;
			}
			case "credit":
				e.crackGuard = !0;
				break;
			case "shelter": e.pending.shelter = !0;
		}
	}
	let o = {
		day: e.day,
		id: i,
		choice: t,
		pieceId: n ?? null,
		coins: a
	};
	e.eventHistory.push(R(o)), e.eventStatus = t === "accept" ? "accepted" : "declined", r.push({
		type: "EventChoice",
		record: o
	});
}
function me(t, n) {
	if (t.rulesVersion !== "forge-v5") return z(t, "wrong_rules");
	let r = L(n);
	if (!r) return z(t, "invalid_command");
	let a = JSON.parse(r);
	if (!P(a) || !V(a, [
		"runId",
		"expectedRevision",
		"action"
	])) return z(t, "invalid_command");
	if (a.runId !== t.runId) return z(t, "wrong_run");
	if (a.expectedRevision !== t.revision) return z(t, "stale_revision");
	let o = ue(a.action);
	if (!o) return z(t, "invalid_command");
	let s = o.type === "continue" ? "opening" : o.type === "chooseModification" ? "chapter" : o.type === "advance" ? "summary" : "workshop";
	if (t.phase !== s) return z(t, "wrong_phase");
	if (t.journal.length >= 2048 || t.journal.length >= 1900 && ([
		"strike",
		"setRecipe",
		"buy",
		"claimGift",
		"upgrade",
		"repair"
	].includes(o.type) || o.type === "reserve" && t.reserveId !== o.pieceId || o.type === "chooseEvent" && o.choice === "accept")) return z(t, "record_limit");
	let c = {
		...R({
			...t,
			journal: []
		}),
		journal: [...t.journal]
	}, l = [], u = "pieceId" in o ? c.blades.find((e) => e.id === o.pieceId) : void 0;
	if ("pieceId" in o && o.type !== "chooseEvent" && (!u || u.status !== "active")) return z(t, "piece_unavailable");
	if ("pieceId" in o && o.type !== "chooseEvent" && o.type !== "reserve" && c.reserveId === o.pieceId) return z(t, "reserved_piece");
	switch (o.type) {
		case "continue":
			c.phase = "workshop", l.push({ type: "Opened" });
			break;
		case "setRecipe":
			if (!u) return z(t, "piece_unavailable");
			if (u.hits > 0) return z(t, "recipe_locked");
			if (!E(c).includes(o.recipe)) return z(t, "recipe_unavailable");
			if (u.recipe === o.recipe) return z(t, "unavailable");
			u.recipe = o.recipe, l.push({
				type: "Recipe",
				pieceId: u.id,
				recipe: u.recipe
			});
			break;
		case "strike": {
			if (!u) return z(t, "piece_unavailable");
			if (y(u)) return z(t, "at_cap");
			let e = u.charge === 6, n = [];
			if (e) {
				let e = u.bursts === 0 && c.modifications.includes("wideMouth"), t = c.traits.includes("ember"), r = 2 + Number(e) + Number(t);
				u.charge = 0, u.bursts++;
				for (let i = 0; i < r && !y(u); i++) {
					let r = fe(c, u, !0);
					n.push({
						...r,
						triggers: [
							...r.triggers,
							...e ? ["wideMouth"] : [],
							...t ? ["ember"] : []
						]
					});
				}
			} else n.push(fe(c, u, !1));
			l.push({
				type: "Strike",
				pieceId: u.id,
				burst: e,
				hits: n
			});
			break;
		}
		case "deliver": {
			if (!u) return z(t, "piece_unavailable");
			let e = k(c), n = ne(c, u);
			if (!n.allowed) return z(t, n.error);
			let r = n.matched;
			u.status = r ? "commissioned" : "sold", u.finalizedDay = c.day, u.commissionId = r ? T(c).id : null, c.coins += n.amount, c.daySales += n.amount, c.marketSpent += n.marketCost, l.push({
				type: "Delivered",
				pieceId: u.id,
				amount: n.amount,
				matched: r,
				commissionId: T(c).id,
				pieceValue: u.value,
				baseFeeDelta: n.baseFeeDelta,
				qualityBonus: n.qualityBonus,
				marketRemaining: S(c)
			});
			let i = k(c);
			!e.complete && i.complete && (l.push({
				type: "MainCompleted",
				commissionId: i.commissionId,
				routeId: i.routeId,
				pieceIds: i.pieceIds
			}), c.gift === "locked" && (c.gift = "available", l.push({ type: "GiftAvailable" })));
			break;
		}
		case "scrap": {
			if (!u) return z(t, "piece_unavailable");
			let e = A(c, u);
			u.status = "recycled", u.finalizedDay = c.day, c.coins += e, c.dayRecovered += e, c.marketSpent += e, l.push({
				type: "Disposed",
				pieceId: u.id,
				disposition: u.status,
				amount: e,
				marketRemaining: S(c)
			});
			break;
		}
		case "reserve":
			if (!u) return z(t, "piece_unavailable");
			{
				let e = c.reserveId;
				c.reserveId = e === u.id ? null : u.id, l.push({
					type: "Reserved",
					pieceId: u.id,
					previousId: e
				});
			}
			break;
		case "claimGift": {
			if (c.gift !== "available") return z(t, "unavailable");
			let e = 0, n = ["steady", "ember"].filter((e) => !c.traits.includes(e));
			if (n.length) {
				if (o.traitId === null || !n.some((e) => e === o.traitId)) return z(t, "unavailable");
				let e = de(c, o.traitId, o.replaceId);
				if (e) return z(t, e);
			} else {
				if (o.traitId !== null || o.replaceId !== void 0) return z(t, "unavailable");
				c.coins += 40, e = 40;
			}
			c.gift = "claimed", l.push({
				type: "Trait",
				traitId: o.traitId,
				compensation: e
			});
			break;
		}
		case "buy":
			if (!M(c)) return z(t, "no_shop");
			if (!c.shop.includes(o.traitId) || c.sold.includes(o.traitId)) return z(t, "sold_out");
			if (!u) return z(t, "piece_unavailable");
			{
				let e = re(c, u);
				if (!e.allowed) return z(t, e.error);
			}
			{
				let e = de(c, o.traitId, o.replaceId);
				if (e) return z(t, e);
			}
			u.status = "traded", u.finalizedDay = c.day, c.sold.push(o.traitId), l.push({
				type: "Disposed",
				pieceId: u.id,
				disposition: u.status,
				amount: 0,
				marketRemaining: S(c)
			}, {
				type: "Trait",
				traitId: o.traitId,
				compensation: 0
			});
			break;
		case "upgrade":
		case "repair": {
			let e = j(c);
			if (!M(c) || !e) return z(t, "no_shop");
			if (o.type === "upgrade" ? c.upgraded : c.repaired || c.seals === 3) return z(t, "unavailable");
			let n = o.type === "upgrade" ? e.upgrade : e.repair;
			if (c.coins < n) return z(t, "insufficient_coins");
			c.coins -= n, o.type === "upgrade" ? (c.upgradeCount++, c.upgraded = !0, l.push({ type: "Upgraded" })) : (c.seals++, c.repaired = !0, l.push({ type: "Repaired" }));
			break;
		}
		case "chooseEvent":
			if (c.eventStatus !== "available" || c.eventId === null) return z(t, "unavailable");
			if (o.choice === "decline" && o.pieceId !== void 0) return z(t, "invalid_command");
			if (o.choice === "accept") {
				let e = N(c, o.pieceId);
				if (e.error) return z(t, e.error);
			}
			pe(c, o.choice, o.pieceId, l);
			break;
		case "settle": {
			c.eventStatus === "available" && pe(c, "decline", void 0, l);
			let e = ie(c), t = {
				day: c.day,
				commissionId: T(c).id,
				met: e.complete,
				routeId: e.routeId,
				pieceIds: e.pieceIds,
				sales: c.daySales,
				recovered: c.dayRecovered + e.recovered,
				baseFees: C(e, x(c).baseFee),
				marketSpent: c.marketSpent + e.recovered,
				recoveredIds: e.remaining.map((e) => e.id),
				reserveId: c.reserveId,
				sealsBefore: c.seals,
				sealsAfter: e.sealsAfter,
				protected: e.protected,
				modification: null
			};
			for (let e of c.blades) t.recoveredIds.includes(e.id) && (e.status = "recycled", e.finalizedDay = c.day);
			c.coins += e.recovered, c.dayRecovered += e.recovered, c.marketSpent += e.recovered, c.seals = e.sealsAfter, e.protected && (c.pardonUsed = !0), c.history.push(t), c.phase = c.seals === 0 ? "defeat" : c.day === 12 ? c.history.filter((e) => e.met).length >= 10 && [
				4,
				8,
				12
			].every((e) => c.history.some((t) => t.day === e && t.met)) ? "victory" : "return" : c.day === 4 || c.day === 8 ? "chapter" : "summary", c.phase === "chapter" && (c.chapterChoices = c.day === 4 ? ["windbox", "warmRack"] : i.filter((e) => !c.modifications.includes(e))), l.push({
				type: "Settled",
				record: t
			});
			break;
		}
		case "chooseModification":
			if (!c.chapterChoices.includes(o.modification) || c.modifications.includes(o.modification)) return z(t, "unavailable");
			c.modifications.push(o.modification), c.history.at(-1).modification = o.modification, c.chapterChoices = [], c.phase = "summary", l.push({
				type: "Modification",
				modification: o.modification
			});
			break;
		case "advance": {
			let e = c.blades.find((e) => e.id === c.reserveId);
			e && c.modifications.includes("warmRack") && (e.value = b(e.value, 115), e.peak = Math.max(e.peak, e.value)), c.day++, c.phase = "workshop", c.daySales = 0, c.dayRecovered = 0, c.dayBuffs = R(c.pending), c.pending = R(ae()), ce(c), l.push({ type: "Advanced" });
			break;
		}
	}
	return c.revision++, c.journal.push(o), e({
		ok: !0,
		state: c,
		events: l
	});
}
//#endregion
//#region src/core-v5/validate.ts
function he(e) {
	let t = L(e);
	if (!t) return {
		ok: !1,
		error: "invalid_state",
		detail: "Expected bounded plain JSON with safe integer fields."
	};
	let n = JSON.parse(t);
	if (!P(n) || n.rulesVersion !== "forge-v5") return {
		ok: !1,
		error: "invalid_rules_version",
		detail: "Expected forge-v5."
	};
	if (typeof n.runId != "string" || typeof n.seed != "string" || !Array.isArray(n.journal) || n.journal.length > 2048) return {
		ok: !1,
		error: "invalid_state",
		detail: "Missing identity or bounded Accepted journal."
	};
	let r = le({
		runId: n.runId,
		seed: n.seed,
		mode: n.mode,
		eligibility: n.initialEligibility
	});
	if (!r.ok) return {
		ok: !1,
		error: "invalid_state",
		detail: r.error
	};
	let i = r.state;
	for (let [e, t] of n.journal.entries()) {
		let n = me(i, {
			runId: i.runId,
			expectedRevision: i.revision,
			action: t
		});
		if (!n.ok) return {
			ok: !1,
			error: "invalid_journal",
			detail: `Command ${e}: ${n.error}`
		};
		i = n.state;
	}
	return L(i) === t ? {
		ok: !0,
		state: i
	} : {
		ok: !1,
		error: "invalid_state",
		detail: "Snapshot differs from full deterministic replay."
	};
}
//#endregion
//#region src/core-v5/view.ts
var ge = (e) => ({
	...e,
	request: e.request.replaceAll("昨日", "此前")
});
function _e(e) {
	return [
		e.count > 1 ? `${e.count}柄各自合格` : "一柄",
		...e.recipe ? [o[e.recipe].name] : [],
		...e.crack ? [e.crack === "intact" ? "无裂纹" : "带裂纹"] : [],
		...e.age ? [e.age === "old" ? "此前留剑" : "本日新剑"] : [],
		...e.maxHits === void 0 ? [] : [`普通锤≤${e.maxHits}`],
		...e.minLevel === void 0 ? [] : [`等级≥${e.minLevel}`],
		...e.minBursts === void 0 ? [] : [`连锻≥${e.minBursts}次`],
		`身价≥${e.value}`
	].join(" · ");
}
function ve(t) {
	let n = t.history.filter((e) => [
		4,
		8,
		12
	].includes(e.day) && e.sealsAfter > 0).map((e) => _(e.day)), i = ["light"];
	n.includes(1) && i.push("guard"), n.includes(2) && i.push("heavy");
	let a = t.history.filter((e) => e.met).map((e) => ({
		commissionId: e.commissionId,
		day: e.day,
		routeId: e.routeId,
		blades: e.pieceIds.map((e) => t.blades.find((t) => t.id === e)),
		runId: t.runId
	})), o = r.filter((e) => a.some((t) => t.blades.some((t) => t.recipe === e && t.level >= 9))), s = [...new Set(t.journal.flatMap((e) => (e.type === "buy" || e.type === "claimGift") && e.traitId ? [e.traitId] : []))];
	return e({
		chapters: n,
		recipes: i,
		challenge: t.phase === "victory",
		mastery: o,
		traits: s,
		works: a
	});
}
function ye(n) {
	let r = ge(T(n)), i = k(n), a = n.phase === "workshop", p = n.journal.length < h, m = j(n), g = x(n), v = n.blades.find((e) => e.id === n.reserveId && e.status === "active"), P = n.day < 12 ? ge(d[n.commissionOrder[n.day] - 1]) : null, F = v && P ? (() => {
		let e = n.modifications.includes("warmRack") ? b(v.value, 115) : v.value, t = {
			...v,
			value: e,
			peak: Math.max(v.peak, e)
		}, r = P.routes.map((e) => ({
			id: e.id,
			...O({ day: n.day + 1 }, t, e)
		}));
		return {
			...t,
			recipeName: o[t.recipe].name,
			assessment: {
				qualifies: r.some((e) => e.matches),
				routes: r
			}
		};
	})() : null, I = P ? {
		day: n.day + 1,
		commission: P,
		normalBase: w(n, n.day + 1, n.pending.supplyPct),
		merchant: l.some((e) => e.day === n.day + 1),
		reserve: F,
		newCount: F ? 2 : 3,
		oldCount: +!!F,
		totalCount: 3
	} : null, L = I ? {
		...I,
		inheritanceBonus: Math.min(I.normalBase * 4, n.inheritance),
		firstBase: I.normalBase + Math.min(I.normalBase * 4, n.inheritance)
	} : null, R = [
		4,
		8,
		12
	].filter((e) => !n.history.some((t) => t.day === e && t.met)), z = n.eventId ? {
		id: n.eventId,
		...u[n.eventId],
		status: n.eventStatus,
		quote: N(n),
		canDecline: a && n.eventStatus === "available"
	} : null;
	return e({
		rulesVersion: n.rulesVersion,
		revision: n.revision,
		phase: n.phase,
		day: n.day,
		chapter: c[_(n.day) - 1],
		mode: n.mode,
		coins: n.coins,
		seals: n.seals,
		commission: {
			...r,
			progress: i,
			routes: r.routes.map((e) => ({
				...e,
				description: _e(e)
			})),
			outcome: i.complete ? r.success : r.failure
		},
		market: {
			...g,
			spent: n.marketSpent,
			remaining: S(n),
			baseFeesPaid: C(i, g.baseFee)
		},
		recipes: E(n).map((e) => ({
			id: e,
			...o[e]
		})),
		recommendedRecipe: D(n),
		blades: n.blades.filter((e) => e.status === "active").map((e) => {
			let t = ne(n, e), r = te(n, e);
			return {
				blade: e,
				reserved: e.id === n.reserveId,
				assessment: {
					...r,
					canDeliver: t.allowed
				},
				quote: t,
				odds: ee(n, e),
				recovery: A(n, e),
				barter: re(n, e),
				willCommission: t.matched,
				canStrike: a && p && e.id !== n.reserveId && !y(e),
				canChangeRecipe: a && p && e.id !== n.reserveId && e.hits === 0
			};
		}),
		traits: n.traits.map((e) => ({
			id: e,
			...t[e],
			used: e === "pardon" && n.pardonUsed
		})),
		modifications: n.modifications.map((e) => ({
			id: e,
			...s[e]
		})),
		chapterChoices: n.chapterChoices.map((e) => ({
			id: e,
			...s[e]
		})),
		growth: {
			supplyBase: n.supplyBase,
			upgradeCount: n.upgradeCount,
			inheritance: n.inheritance,
			crackGuard: n.crackGuard,
			dayBuffs: n.dayBuffs,
			pending: n.pending
		},
		event: z && z.id === "donation" ? {
			...z,
			result: "明天实际发出的新坯底价增加20%：留剑时两柄，否则三柄。"
		} : z,
		merchant: M(n) && m ? {
			...m,
			offers: n.shop.map((e) => ({
				id: e,
				...t[e],
				sold: n.sold.includes(e),
				owned: n.traits.includes(e)
			})),
			canUpgrade: p && !n.upgraded && n.coins >= m.upgrade,
			canRepair: p && !n.repaired && n.seals < 3 && n.coins >= m.repair
		} : null,
		gift: {
			status: n.gift,
			canClaim: a && p && n.gift === "available"
		},
		next: L,
		settlement: ie(n),
		canContinue: n.phase === "opening",
		canSettle: a,
		canAdvance: n.phase === "summary",
		ending: n.phase === "victory" || n.phase === "return" || n.phase === "defeat" ? {
			...f[n.phase],
			missingCritical: R,
			completed: n.history.filter((e) => e.met).length,
			finalBladeMade: n.history.some((e) => e.day === 12 && e.met)
		} : null,
		history: n.history,
		eventHistory: n.eventHistory,
		collection: ve(n)
	});
}
//#endregion
//#region src/application/persistent-session.ts
function be(t, n, r) {
	let i = r.isTerminal ?? ((e) => e.phase === "victory" || e.phase === "defeat"), a = 0, o = 0, s = "inactive", c = !1, l = null, u = !1, d = !1, f = null, p = null, m, h = /* @__PURE__ */ new Set(), g = () => e({
		generation: a,
		mode: s,
		active: c,
		state: l,
		dirty: u,
		conflict: d,
		load: f,
		lastSave: p
	}), _ = () => {
		let e = g();
		for (let t of h) try {
			t(e);
		} catch {}
	}, v = (e) => ({
		ok: !1,
		error: e,
		snapshot: g()
	}), y = () => ({
		ok: !0,
		snapshot: g()
	}), b = () => {
		a++, o++;
	}, x = () => {
		d = !0, u = l !== null, b(), _();
	}, S = (e) => e.main.status === "valid" && !i(e.main.state) || e.main.status === "invalid" || e.main.status === "empty" && e.backup.status === "valid", C = (e, t = !1) => s === "disposed" ? "disposed" : e === a ? c ? s === "memory" ? null : s === "unsupported" ? "locks_unsupported" : s !== "writer" || !n.owns() ? "readonly" : d && !t ? "save_conflict" : null : "not_active" : "stale_session", w = () => l === null || s === "memory" ? (u = l !== null, p = null, null) : (p = n.owns() ? t.write(l, { raw: m }) : {
		ok: !1,
		error: "storage_conflict",
		detail: "Writer lease was lost."
	}, u = !p.ok, p.ok && (m = t.token()), !p.ok && p.error === "storage_conflict" && (d = !0), p);
	return {
		getSnapshot: g,
		subscribe: (e) => {
			h.add(e);
			try {
				e(g());
			} catch {}
			return () => {
				h.delete(e);
			};
		},
		activate: async () => {
			if (s === "disposed") return g();
			let e = ++o;
			if (a++, s === "memory") return c = !0, _(), g();
			c = !1;
			let r = l, i = u, h = m, v = await n.acquire();
			return e === o && (c = v !== "cancelled" && v !== "disposed", s = v === "writer" ? "writer" : v === "readonly" ? "readonly" : v === "unsupported" ? "unsupported" : "error", f = t.load(), r && (i || f.main.status !== "valid") ? (l = r, u = !0, d = h !== t.token()) : (l = f.main.status === "valid" ? f.main.state : null, m = t.token(), u = !1, d = !1), p = null, _()), g();
		},
		startNewGame: (e, n) => {
			let a = C(n.generation, !0);
			if (a) return v(a);
			let o = r.createRun(e);
			if (!o.ok) return v(o.error);
			if (s === "memory") {
				if (l && n.confirmed !== !0) return v("confirmation_required");
			} else {
				let e = t.inspect();
				if (e.main.status === "unavailable") return v("save_unavailable");
				let r = l !== null && !i(l);
				if ((S(e) || r || u) && n.confirmed !== !0) return v("confirmation_required");
				if (f = t.load(), f.main.status === "unavailable") return x(), v("save_unavailable");
				if (S(f) && n.confirmed !== !0) return x(), v("confirmation_required");
			}
			return b(), l = o.state, m = s === "memory" ? void 0 : t.token(), u = !0, d = !1, w(), _(), y();
		},
		resume: (e) => {
			let n = C(e.generation, !0);
			return n ? v(n) : s === "memory" ? v("save_unavailable") : u && e.confirmed !== !0 ? v("confirmation_required") : t.inspect().main.status === "valid" ? (f = t.load(), f.main.status === "valid" ? (l = f.main.state, m = t.token(), u = !1, d = !1, p = null, b(), _(), y()) : (x(), v("save_unavailable"))) : v("save_unavailable");
		},
		recoverBackup: (e) => {
			let n = C(e.generation, !0);
			if (n) return v(n);
			if (s === "memory") return v("save_unavailable");
			if (e.confirmed !== !0) return v("confirmation_required");
			let r = t.inspect();
			return r.main.status === "valid" ? v("main_available") : r.main.status === "unavailable" || r.backup.status !== "valid" ? v("backup_unavailable") : (f = t.load(), f.main.status === "valid" ? (x(), v("main_available")) : f.main.status === "unavailable" || f.backup.status !== "valid" ? (x(), v("backup_unavailable")) : (l = f.backup.state, m = t.token(), d = !1, u = !0, b(), w(), _(), y()));
		},
		useMemory: (e, t) => {
			if (s === "disposed") return v("disposed");
			if (t.generation !== a) return v("stale_session");
			if (e !== null && l && t.confirmed !== !0) return v("confirmation_required");
			let i = e === null ? null : r.createRun(e);
			return i && !i.ok ? v(i.error) : !i && !l ? v("no_run") : (b(), n.release(), i?.ok && (l = i.state), m = void 0, s = "memory", c = !0, u = !0, d = !1, p = null, _(), y());
		},
		dispatch: (e, t) => {
			let n = C(t);
			if (n || l === null) return {
				ok: !1,
				state: l,
				error: n ?? "no_run",
				events: [],
				snapshot: g()
			};
			let i = r.applyCommand(l, e);
			if (!i.ok) return {
				...i,
				snapshot: g()
			};
			l = i.state, u = !0;
			let a = w();
			return _(), {
				...i,
				persistence: a,
				snapshot: g()
			};
		},
		retrySave: (e) => {
			let t = C(e);
			return t ? v(t) : s === "memory" ? v("save_unavailable") : l ? (u && (w(), _()), u ? v(d ? "save_conflict" : "save_unavailable") : y()) : v("no_run");
		},
		notifyExternalChange: () => {
			s !== "disposed" && s !== "memory" && (t.isCurrent({ raw: m }) || (d = !0, a++), _());
		},
		suspend: () => {
			b(), c = !1, s !== "disposed" && s !== "memory" && (s = "inactive");
			let e = n.release();
			return _(), e;
		},
		dispose: () => {
			b(), c = !1, s = "disposed";
			let e = n.dispose();
			return _(), h.clear(), e;
		}
	};
}
//#endregion
//#region src/platform/storage.ts
function xe(e) {
	if (typeof e != "string" || e.length !== 24) return !1;
	try {
		return new Date(e).toISOString() === e;
	} catch {
		return !1;
	}
}
function H(e, t) {
	if (e === null) return { status: "empty" };
	if (e.length > 262144 || new TextEncoder().encode(e).byteLength > 262144) return {
		status: "invalid",
		error: "save_too_large",
		detail: "Save exceeds 256 KiB."
	};
	let n;
	try {
		n = JSON.parse(e);
	} catch {
		return {
			status: "invalid",
			error: "invalid_json",
			detail: "Save is not valid JSON."
		};
	}
	if (!P(n) || Object.keys(n).sort().join(",") !== "rulesVersion,savedAt,schemaVersion,state" || n.schemaVersion !== t.schemaVersion) return {
		status: "invalid",
		error: "unsupported_schema",
		detail: "Unsupported save envelope/schema."
	};
	if (n.rulesVersion !== t.rulesVersion) return {
		status: "invalid",
		error: "unsupported_rules",
		detail: "Save uses different rules."
	};
	if (!xe(n.savedAt)) return {
		status: "invalid",
		error: "invalid_timestamp",
		detail: "Invalid save timestamp."
	};
	let r = t.validate(n.state);
	return r.ok ? {
		status: "valid",
		state: r.state,
		savedAt: n.savedAt
	} : {
		status: "invalid",
		error: r.error === "invalid_rules_version" ? "unsupported_rules" : "invalid_state",
		detail: r.detail
	};
}
function Se(e, t, n = () => (/* @__PURE__ */ new Date()).toISOString()) {
	let r, i, a = (e) => H(e, t), o = (n) => {
		let o, s, c, l;
		try {
			l = e();
		} catch {
			let e = {
				status: "unavailable",
				error: "storage_read_failed",
				detail: "Storage access was denied."
			};
			return n && (r = void 0, i = void 0), {
				main: e,
				backup: e
			};
		}
		try {
			o = l.getItem(t.key), s = a(o);
		} catch {
			s = {
				status: "unavailable",
				error: "storage_read_failed",
				detail: "Primary save could not be read."
			};
		}
		try {
			c = a(l.getItem(t.backupKey));
		} catch {
			c = {
				status: "unavailable",
				error: "storage_read_failed",
				detail: "Backup could not be read."
			};
		}
		return n && (r = o, i = s.status === "valid" ? o ?? void 0 : void 0), {
			main: s,
			backup: c
		};
	};
	return {
		load: () => o(!0),
		inspect: () => o(!1),
		token: () => r,
		isCurrent: (n) => {
			let i = n ? n.raw : r;
			try {
				return i !== void 0 && e().getItem(t.key) === i;
			} catch {
				return !1;
			}
		},
		write: (o, s) => {
			let c = s ? s.raw : r;
			if (c === void 0) return {
				ok: !1,
				error: "storage_read_failed",
				detail: "Load the slot before writing."
			};
			let l, u;
			try {
				if (l = e(), u = l.getItem(t.key), u !== c) return {
					ok: !1,
					error: "storage_conflict",
					detail: "Another writer changed the save."
				};
			} catch {
				return {
					ok: !1,
					error: "storage_read_failed",
					detail: "Primary save could not be checked."
				};
			}
			let d, f;
			try {
				if (f = n(), !xe(f)) return {
					ok: !1,
					error: "serialization_failed",
					detail: "Clock returned an invalid timestamp."
				};
				if (d = JSON.stringify({
					schemaVersion: t.schemaVersion,
					rulesVersion: t.rulesVersion,
					savedAt: f,
					state: o
				}), new TextEncoder().encode(d).byteLength > 262144) return {
					ok: !1,
					error: "save_too_large",
					detail: "Save exceeds 256 KiB."
				};
			} catch {
				return {
					ok: !1,
					error: "serialization_failed",
					detail: "Save could not be serialized."
				};
			}
			let p = !1, m = u !== null && (u === i || a(u).status === "valid") ? u : void 0;
			if (m !== void 0 && m !== d) try {
				l.setItem(t.backupKey, m);
			} catch {
				p = !0;
			}
			try {
				l.setItem(t.key, d);
			} catch {
				return {
					ok: !1,
					error: "storage_write_failed",
					detail: "Primary write failed; in-memory progress is not saved."
				};
			}
			return r = d, i = d, {
				ok: !0,
				savedAt: f,
				backupWarning: p
			};
		}
	};
}
//#endregion
//#region src/platform/writer-lease.ts
var Ce = "sword-led.writer";
function we(e) {
	let t = 0, n = !1, r = !1, i, a = Promise.resolve(), o = null, s = () => (t++, n = !1, i?.(), i = void 0, o = null, a);
	return {
		owns: () => n && !r,
		release: s,
		dispose: () => (r = !0, s()),
		acquire: () => {
			if (r) return Promise.resolve("disposed");
			if (!e) return Promise.resolve("unsupported");
			if (n) return Promise.resolve("writer");
			if (o) return o;
			let s = ++t, c = a.then(() => new Promise((o) => {
				if (r || s !== t) o("cancelled");
				else try {
					a = e.request(Ce, {
						mode: "exclusive",
						ifAvailable: !0
					}, async (e) => {
						if (r || s !== t) {
							o("cancelled");
							return;
						}
						if (e === null) {
							o("readonly");
							return;
						}
						let a = new Promise((e) => {
							i = e;
						});
						n = !0, o("writer"), await a, s === t && (n = !1, i = void 0);
					}).catch(() => {
						s === t && (n = !1, i?.(), i = void 0), o("error");
					});
				} catch {
					o("error");
				}
			}));
			return o = c, c.then(() => {
				o === c && (o = null);
			}), c;
		}
	};
}
//#endregion
//#region src/platform/browser-session.ts
function Te(e, t, n) {
	let r;
	try {
		if (e.isSecureContext && e.navigator.locks) {
			let t = e.navigator.locks;
			r = { request: (e, n, r) => t.request(e, n, r) };
		}
	} catch {
		r = void 0;
	}
	let i = n(r), a = () => {
		i.suspend();
	}, o = (e) => {
		e.persisted && i.activate();
	}, s = (e) => {
		(e.key === t || e.key === null) && i.notifyExternalChange();
	};
	return e.addEventListener("pagehide", a), e.addEventListener("pageshow", o), e.addEventListener("storage", s), {
		...i,
		dispose: () => (e.removeEventListener("pagehide", a), e.removeEventListener("pageshow", o), e.removeEventListener("storage", s), i.dispose())
	};
}
//#endregion
//#region src/core-v4/rules.ts
var Ee = 1e9, De = (e) => e <= 4 ? 1 : e <= 8 ? 2 : 3, U = (e) => Math.floor(e.base / 4), Oe = (e) => e.value >= 1e9 || e.level >= 99, W = (e, t) => Math.min(Ee, Math.floor(e * t / 100));
function ke(e, t, n) {
	return Math.floor(c[De(t) - 1].base * 3 ** e.upgradeCount / 2 ** e.upgradeCount * n / 100);
}
function G(e) {
	return d[e.commissionOrder[e.day - 1] - 1];
}
function Ae(e) {
	let t = new Set(e.initialEligibility.recipes);
	e.history.some((e) => e.day === 4 && e.sealsAfter > 0) && t.add("guard"), e.history.some((e) => e.day === 8 && e.sealsAfter > 0) && t.add("heavy");
	for (let n of G(e).routes) n.recipe && t.add(n.recipe);
	return [
		"light",
		"guard",
		"heavy"
	].filter((e) => t.has(e));
}
function je(e) {
	return G(e).routes.find((e) => e.recipe)?.recipe || (Ae(e).includes("guard") ? "guard" : "light");
}
function Me(e, t) {
	let n = o[t.recipe], r = e.dayBuffs.shelter && t.suppliedDay === e.day && t.slot === 1, i = Math.max(0, (t.hits < 3 ? 0 : n.cracks[Math.min(t.hits - 3, 8)]) - (r ? 30 : 0)), a = t.charge === 6, s = a ? 350 : n.greatOdds + (t.cracked && e.traits.includes("crackedEdge") ? 100 : 0);
	return {
		burst: a,
		crack: a ? 0 : i,
		great: s,
		success: 1e3 - s - (a ? 0 : i),
		afterBurstCrack: i
	};
}
function Ne(e, t, n) {
	let r = [];
	return n.recipe && t.recipe !== n.recipe && r.push(`需要${o[n.recipe].name}`), n.crack === "intact" && t.cracked && r.push("需要无裂纹"), n.crack === "cracked" && !t.cracked && r.push("需要带裂纹"), n.age === "old" && t.suppliedDay >= e.day && r.push("需要昨日留下的旧剑"), n.age === "new" && t.suppliedDay !== e.day && r.push("需要本日新剑"), n.maxHits !== void 0 && t.hits > n.maxHits && r.push(`普通锤不得超过${n.maxHits}次`), n.minLevel !== void 0 && t.level < n.minLevel && r.push(`需要等级${n.minLevel}`), n.minBursts !== void 0 && t.bursts < n.minBursts && r.push(`需要${n.minBursts}次连锻`), t.value < n.value && r.push(`还差${n.value - t.value}身价`), {
		matches: r.length === 0,
		missing: r
	};
}
function Pe(e) {
	let t = G(e), n = e.blades.filter((n) => n.status === "commissioned" && n.commissionId === t.id && n.finalizedDay === e.day), r = new Map(e.journal.flatMap((e, t) => e.type === "deliver" ? [[e.pieceId, t]] : []));
	n.sort((e, t) => (r.get(e.id) ?? 2 ** 53 - 1) - (r.get(t.id) ?? 2 ** 53 - 1));
	let i = t.routes.map((t) => {
		let r = n.filter((n) => Ne(e, n, t).matches).map((e) => e.id);
		return {
			id: t.id,
			required: t.count,
			count: r.length,
			pieceIds: r,
			complete: r.length >= t.count
		};
	}), a = i.find((e) => e.complete);
	return {
		commissionId: t.id,
		complete: !!a,
		routeId: a?.id ?? null,
		pieceIds: a?.pieceIds.slice(0, a.required) ?? [],
		routes: i
	};
}
function Fe(e, t) {
	let n = G(e).routes.map((n) => ({
		id: n.id,
		...Ne(e, t, n)
	}));
	return {
		canDeliver: e.phase === "workshop" && t.status === "active" && t.id !== e.reserveId,
		qualifies: n.some((e) => e.matches),
		routes: n
	};
}
function Ie(e) {
	let t = e.blades.filter((t) => t.status === "active" && t.id !== e.reserveId), n = Pe(e), r = !n.complete && e.traits.includes("pardon") && !e.pardonUsed;
	return {
		...n,
		remaining: t,
		recovered: t.reduce((e, t) => e + U(t), 0),
		protected: r,
		sealsAfter: e.seals - (n.complete || r ? 0 : 1)
	};
}
var Le = (e) => l.find((t) => t.day === e.day) ?? null, Re = (e) => e.phase === "workshop" && Le(e) !== null;
function ze(e, t) {
	let n = e.eventId ? u[e.eventId] : null, r = n?.cost[De(e.day) - 1] ?? 0, i = null;
	if (e.phase !== "workshop" || e.eventStatus !== "available" || !n) i = "unavailable";
	else if (e.coins < r) i = "insufficient_coins";
	else if (e.eventId === "credit" && e.crackGuard) i = "already_owned";
	else if (n.piece !== "none") {
		let r = e.blades.find((e) => e.id === t);
		(!r || r.status !== "active" || (n.piece === "reserve" ? e.reserveId !== r.id : e.reserveId === r.id)) && (i = "piece_unavailable");
	} else t !== void 0 && (i = "invalid_command");
	return {
		eventId: e.eventId,
		cost: r,
		requiresPiece: n?.piece ?? "none",
		allowed: i === null,
		error: i
	};
}
//#endregion
//#region src/core-v4/game.ts
var K = (e) => structuredClone(e), q = (e, t) => ({
	ok: !1,
	state: e,
	error: t,
	events: []
}), Be = () => ({
	supplyPct: 100,
	loan: !1,
	shelter: !1
}), J = (e, t) => typeof e == "string" && t.some((t) => t === e), Y = (e, t) => Object.keys(e).sort().join(",") === [...t].sort().join(",");
function Ve(e, t, n) {
	let r = I(e.rng[t]);
	return e.rng[t] = r.stream, Math.floor(r.value * n);
}
function He(e, t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = Ve(e, t, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function Ue(e) {
	e.supplyBase = ke(e, e.day, e.dayBuffs.supplyPct);
	let t = Math.min(e.supplyBase * 4, e.inheritance), n = je(e);
	e.inheritance = 0;
	for (let r = 1; r <= 3; r++) {
		let i = e.supplyBase + (r === 1 ? t : 0);
		e.blades.push({
			id: `d${e.day}-${r}`,
			slot: r,
			suppliedDay: e.day,
			recipe: n,
			status: "active",
			base: i,
			value: i,
			peak: i,
			level: 0,
			cracked: !1,
			hits: 0,
			charge: 0,
			successes: 0,
			normalGreats: 0,
			bursts: 0,
			finalizedDay: null,
			commissionId: null
		});
	}
	e.shop = [], e.sold = [], e.upgraded = !1, e.repaired = !1;
	let r = l.find((t) => t.day === e.day);
	if (r) {
		let t = r.pool.filter((t) => !e.traits.includes(t));
		for (; t.length && e.shop.length < 2;) e.shop.push(t.splice(Ve(e, "shop", t.length), 1)[0]);
	}
	let i = [
		3,
		5,
		7,
		9,
		11
	].indexOf(e.day);
	e.eventId = i < 0 ? null : e.eventDeck[i], e.eventStatus = e.eventId ? "available" : "none";
}
function We(t) {
	let n = L(t);
	if (!n) return {
		ok: !1,
		error: "invalid_command"
	};
	let i = JSON.parse(n);
	if (!P(i)) return {
		ok: !1,
		error: "invalid_command"
	};
	if (typeof i.runId != "string" || !/^[A-Za-z0-9_-]{1,80}$/.test(i.runId)) return {
		ok: !1,
		error: "invalid_run_id"
	};
	if (typeof i.seed != "string") return {
		ok: !1,
		error: "invalid_seed"
	};
	let o = i.seed.normalize("NFC").trim();
	if (!o || Array.from(o).length > 64) return {
		ok: !1,
		error: "invalid_seed"
	};
	if (i.mode !== void 0 && i.mode !== "story" && i.mode !== "challenge" || !Y(i, [
		"runId",
		"seed",
		...i.mode === void 0 ? [] : ["mode"],
		...i.eligibility === void 0 ? [] : ["eligibility"]
	])) return {
		ok: !1,
		error: "invalid_command"
	};
	let s = {
		recipes: ["light"],
		challenge: !1
	};
	if (i.eligibility !== void 0) {
		let e = i.eligibility;
		if (!P(e) || !Y(e, ["recipes", "challenge"]) || !Array.isArray(e.recipes) || e.recipes.length > 3 || !e.recipes.every((e) => J(e, r)) || typeof e.challenge != "boolean") return {
			ok: !1,
			error: "invalid_command"
		};
		let t = e.recipes;
		s = {
			recipes: r.filter((n) => n === "light" || e.challenge || t.includes(n)),
			challenge: e.challenge
		};
	}
	if (i.mode === "challenge" && !s.challenge) return {
		ok: !1,
		error: "challenge_locked"
	};
	let c = (e) => ({
		state: F(`${o}|v4|${e}`),
		draws: 0
	}), l = {
		rulesVersion: "forge-v4",
		runId: i.runId,
		seed: o,
		mode: i.mode ?? "story",
		initialEligibility: K(s),
		revision: 0,
		phase: "opening",
		day: 1,
		commissionOrder: Array.from({ length: 12 }, (e, t) => t + 1),
		coins: 0,
		seals: 3,
		supplyBase: 40,
		upgradeCount: 0,
		inheritance: 0,
		blades: [],
		reserveId: null,
		daySales: 0,
		dayRecovered: 0,
		traits: [],
		gift: "locked",
		pardonUsed: !1,
		crackGuard: !1,
		modifications: [],
		chapterChoices: [],
		shop: [],
		sold: [],
		upgraded: !1,
		repaired: !1,
		dayBuffs: K(Be()),
		pending: K(Be()),
		eventDeck: [],
		eventId: null,
		eventStatus: "none",
		eventHistory: [],
		history: [],
		rng: {
			forge: c("forge"),
			shop: c("shop"),
			events: c("events"),
			content: c("content")
		},
		journal: []
	};
	if (l.eventDeck = He(l, "events", a), l.mode === "challenge") for (let e of [[
		5,
		6,
		7
	], [
		9,
		10,
		11
	]]) {
		let t = He(l, "content", e);
		for (let n = 0; n < e.length; n++) l.commissionOrder[e[n] - 1] = t[n];
	}
	return Ue(l), e({
		ok: !0,
		state: l
	});
}
function Ge(e) {
	if (!P(e)) return null;
	let t = typeof e.pieceId == "string" && e.pieceId.length <= 32;
	switch (e.type) {
		case "continue":
		case "upgrade":
		case "repair":
		case "settle":
		case "advance": return Y(e, ["type"]) ? { type: e.type } : null;
		case "strike":
		case "deliver":
		case "scrap":
		case "reserve": return t && Y(e, ["type", "pieceId"]) ? {
			type: e.type,
			pieceId: e.pieceId
		} : null;
		case "setRecipe": return t && J(e.recipe, r) && Y(e, [
			"type",
			"pieceId",
			"recipe"
		]) ? {
			type: e.type,
			pieceId: e.pieceId,
			recipe: e.recipe
		} : null;
		case "chooseModification": return J(e.modification, i) && Y(e, ["type", "modification"]) ? {
			type: e.type,
			modification: e.modification
		} : null;
		case "chooseEvent": return (e.choice === "accept" || e.choice === "decline") && (e.pieceId === void 0 || t) && Y(e, [
			"type",
			"choice",
			...e.pieceId === void 0 ? [] : ["pieceId"]
		]) ? {
			type: e.type,
			choice: e.choice,
			...e.pieceId === void 0 ? {} : { pieceId: e.pieceId }
		} : null;
		case "buy":
		case "claimGift": return e.type === "buy" && !t || !J(e.traitId, n) && (e.type !== "claimGift" || e.traitId !== null) || e.replaceId !== void 0 && !J(e.replaceId, n) || !Y(e, [
			"type",
			"traitId",
			...e.type === "buy" ? ["pieceId"] : [],
			...e.replaceId === void 0 ? [] : ["replaceId"]
		]) ? null : e;
		default: return null;
	}
}
function Ke(e, t, n) {
	if (e.traits.includes(t)) return "already_owned";
	if (e.traits.length === 3) {
		if (!n || !e.traits.includes(n)) return "invalid_replacement";
		e.traits.splice(e.traits.indexOf(n), 1);
	} else if (n !== void 0) return "invalid_replacement";
	return e.traits.push(t), null;
}
function qe(e, t, n) {
	let r = Me(e, t), i = Ve(e, "forge", 1e3), a = t.value, s = [], c = i < (n ? 350 : r.great) ? "great" : !n && i < r.great + r.crack ? "crack" : "success";
	if (n || t.hits++, !n && e.dayBuffs.shelter && t.slot === 1 && t.suppliedDay === e.day && s.push("shelter"), c === "crack") {
		if (t.cracked) {
			c = "broken", t.value = 0, t.status = "broken", t.finalizedDay = e.day;
			let n = U(t);
			e.coins += n, e.dayRecovered += n, e.traits.includes("inherit") && (e.inheritance += Math.floor(t.peak / 5), s.push("inherit"));
		} else {
			t.cracked = !0;
			let n = e.traits.includes("steady"), r = e.crackGuard;
			n && s.push("steady"), r && (s.push("credit"), e.crackGuard = !1), !n && !r && (t.value = W(t.value, 80));
		}
	} else {
		let r = o[t.recipe];
		t.value = W(t.value, c === "great" ? r.great : r.success), t.level = Math.min(99, t.level + (c === "great" ? 2 : 1)), n || (c === "great" && (t.normalGreats === 0 && e.modifications.includes("windbox") && (t.value = W(t.value, 110), s.push("windbox")), t.normalGreats++), t.successes++, e.traits.includes("echo") && t.successes % 3 == 0 && (t.value = W(t.value, 125), s.push("echo")), e.dayBuffs.loan && t.suppliedDay === e.day && t.slot === 1 && t.hits <= 3 && (t.value = Math.min(Ee, t.value + Math.floor((t.value - a) * 10 / 100)), s.push("loan")), t.cracked && c === "great" && e.traits.includes("crackedEdge") && s.push("crackedEdge"));
	}
	return t.peak = Math.max(t.peak, t.value), !n && t.status === "active" && (t.charge = Math.min(6, t.charge + 1)), {
		result: c,
		before: a,
		after: t.value,
		level: t.level,
		triggers: s
	};
}
function Je(e, t, n, r) {
	let i = e.eventId, a = 0;
	if (t === "accept") {
		let t = ze(e, n);
		switch (a = t.cost === 0 ? 0 : -t.cost, e.coins -= t.cost, i) {
			case "donation": {
				let t = e.blades.find((e) => e.id === n);
				t.status = "donated", t.finalizedDay = e.day, e.pending.supplyPct = 120;
				break;
			}
			case "loan":
				e.pending.loan = !0;
				break;
			case "salvage": {
				let t = e.blades.find((e) => e.id === n);
				t.status = "bartered", t.finalizedDay = e.day, e.reserveId = null, e.coins += 160, a += 160;
				break;
			}
			case "credit":
				e.crackGuard = !0;
				break;
			case "shelter": e.pending.shelter = !0;
		}
	}
	let o = {
		day: e.day,
		id: i,
		choice: t,
		pieceId: n ?? null,
		coins: a
	};
	e.eventHistory.push(K(o)), e.eventStatus = t === "accept" ? "accepted" : "declined", r.push({
		type: "EventChoice",
		record: o
	});
}
function Ye(t, n) {
	if (t.rulesVersion !== "forge-v4") return q(t, "wrong_rules");
	let r = L(n);
	if (!r) return q(t, "invalid_command");
	let a = JSON.parse(r);
	if (!P(a) || !Y(a, [
		"runId",
		"expectedRevision",
		"action"
	])) return q(t, "invalid_command");
	if (a.runId !== t.runId) return q(t, "wrong_run");
	if (a.expectedRevision !== t.revision) return q(t, "stale_revision");
	let o = Ge(a.action);
	if (!o) return q(t, "invalid_command");
	let s = o.type === "continue" ? "opening" : o.type === "chooseModification" ? "chapter" : o.type === "advance" ? "summary" : "workshop";
	if (t.phase !== s) return q(t, "wrong_phase");
	if (t.journal.length >= 2048 || t.journal.length >= 1900 && ([
		"strike",
		"setRecipe",
		"buy",
		"claimGift",
		"upgrade",
		"repair"
	].includes(o.type) || o.type === "reserve" && t.reserveId !== o.pieceId || o.type === "chooseEvent" && o.choice === "accept")) return q(t, "record_limit");
	let c = K(t), l = [], u = "pieceId" in o ? c.blades.find((e) => e.id === o.pieceId) : void 0;
	if ("pieceId" in o && o.type !== "chooseEvent" && (!u || u.status !== "active")) return q(t, "piece_unavailable");
	if ("pieceId" in o && o.type !== "chooseEvent" && o.type !== "reserve" && c.reserveId === o.pieceId) return q(t, "reserved_piece");
	switch (o.type) {
		case "continue":
			c.phase = "workshop", l.push({ type: "Opened" });
			break;
		case "setRecipe":
			if (!u) return q(t, "piece_unavailable");
			if (u.hits > 0) return q(t, "recipe_locked");
			if (!Ae(c).includes(o.recipe)) return q(t, "recipe_unavailable");
			if (u.recipe === o.recipe) return q(t, "unavailable");
			u.recipe = o.recipe, l.push({
				type: "Recipe",
				pieceId: u.id,
				recipe: u.recipe
			});
			break;
		case "strike": {
			if (!u) return q(t, "piece_unavailable");
			if (Oe(u)) return q(t, "at_cap");
			let e = u.charge === 6, n = [];
			if (e) {
				let e = u.bursts === 0 && c.modifications.includes("wideMouth"), t = c.traits.includes("ember"), r = 2 + Number(e) + Number(t);
				u.charge = 0, u.bursts++;
				for (let i = 0; i < r && !Oe(u); i++) {
					let r = qe(c, u, !0);
					n.push({
						...r,
						triggers: [
							...r.triggers,
							...e ? ["wideMouth"] : [],
							...t ? ["ember"] : []
						]
					});
				}
			} else n.push(qe(c, u, !1));
			l.push({
				type: "Strike",
				pieceId: u.id,
				burst: e,
				hits: n
			});
			break;
		}
		case "deliver": {
			if (!u) return q(t, "piece_unavailable");
			let e = Pe(c), n = !e.complete && Fe(c, u).qualifies;
			u.status = n ? "commissioned" : "sold", u.finalizedDay = c.day, u.commissionId = n ? G(c).id : null, c.coins += u.value, c.daySales += u.value, l.push({
				type: "Delivered",
				pieceId: u.id,
				amount: u.value,
				matched: n,
				commissionId: G(c).id
			});
			let r = Pe(c);
			!e.complete && r.complete && (l.push({
				type: "MainCompleted",
				commissionId: r.commissionId,
				routeId: r.routeId,
				pieceIds: r.pieceIds
			}), c.gift === "locked" && (c.gift = "available", l.push({ type: "GiftAvailable" })));
			break;
		}
		case "scrap":
			if (!u) return q(t, "piece_unavailable");
			u.status = "recycled", u.finalizedDay = c.day, c.coins += U(u), c.dayRecovered += U(u), l.push({
				type: "Disposed",
				pieceId: u.id,
				disposition: u.status,
				amount: U(u)
			});
			break;
		case "reserve":
			if (!u) return q(t, "piece_unavailable");
			{
				let e = c.reserveId;
				c.reserveId = e === u.id ? null : u.id, l.push({
					type: "Reserved",
					pieceId: u.id,
					previousId: e
				});
			}
			break;
		case "claimGift": {
			if (c.gift !== "available") return q(t, "unavailable");
			let e = ["steady", "ember"].filter((e) => !c.traits.includes(e));
			if (e.length) {
				if (o.traitId === null || !e.some((e) => e === o.traitId)) return q(t, "unavailable");
				let n = Ke(c, o.traitId, o.replaceId);
				if (n) return q(t, n);
			} else {
				if (o.traitId !== null || o.replaceId !== void 0) return q(t, "unavailable");
				c.coins += 40;
			}
			c.gift = "claimed", l.push({
				type: "Trait",
				traitId: o.traitId
			});
			break;
		}
		case "buy":
			if (!Re(c)) return q(t, "no_shop");
			if (!c.shop.includes(o.traitId) || c.sold.includes(o.traitId)) return q(t, "sold_out");
			{
				let e = Ke(c, o.traitId, o.replaceId);
				if (e) return q(t, e);
			}
			if (!u) return q(t, "piece_unavailable");
			u.status = "traded", u.finalizedDay = c.day, c.sold.push(o.traitId), l.push({
				type: "Disposed",
				pieceId: u.id,
				disposition: u.status,
				amount: 0
			}, {
				type: "Trait",
				traitId: o.traitId
			});
			break;
		case "upgrade":
		case "repair": {
			let e = Le(c);
			if (!Re(c) || !e) return q(t, "no_shop");
			if (o.type === "upgrade" ? c.upgraded : c.repaired || c.seals === 3) return q(t, "unavailable");
			let n = o.type === "upgrade" ? e.upgrade : e.repair;
			if (c.coins < n) return q(t, "insufficient_coins");
			c.coins -= n, o.type === "upgrade" ? (c.upgradeCount++, c.upgraded = !0, l.push({ type: "Upgraded" })) : (c.seals++, c.repaired = !0, l.push({ type: "Repaired" }));
			break;
		}
		case "chooseEvent":
			if (c.eventStatus !== "available" || c.eventId === null) return q(t, "unavailable");
			if (o.choice === "decline" && o.pieceId !== void 0) return q(t, "invalid_command");
			if (o.choice === "accept") {
				let e = ze(c, o.pieceId);
				if (e.error) return q(t, e.error);
			}
			Je(c, o.choice, o.pieceId, l);
			break;
		case "settle": {
			c.eventStatus === "available" && Je(c, "decline", void 0, l);
			let e = Ie(c), t = {
				day: c.day,
				commissionId: G(c).id,
				met: e.complete,
				routeId: e.routeId,
				pieceIds: e.pieceIds,
				sales: c.daySales,
				recovered: c.dayRecovered + e.recovered,
				recoveredIds: e.remaining.map((e) => e.id),
				reserveId: c.reserveId,
				sealsBefore: c.seals,
				sealsAfter: e.sealsAfter,
				protected: e.protected,
				modification: null
			};
			for (let e of c.blades) t.recoveredIds.includes(e.id) && (e.status = "recycled", e.finalizedDay = c.day);
			c.coins += e.recovered, c.dayRecovered += e.recovered, c.seals = e.sealsAfter, e.protected && (c.pardonUsed = !0), c.history.push(t), c.phase = c.seals === 0 ? "defeat" : c.day === 12 ? c.history.filter((e) => e.met).length >= 10 && [
				4,
				8,
				12
			].every((e) => c.history.some((t) => t.day === e && t.met)) ? "victory" : "return" : c.day === 4 || c.day === 8 ? "chapter" : "summary", c.phase === "chapter" && (c.chapterChoices = c.day === 4 ? ["windbox", "warmRack"] : i.filter((e) => !c.modifications.includes(e))), l.push({
				type: "Settled",
				record: t
			});
			break;
		}
		case "chooseModification":
			if (!c.chapterChoices.includes(o.modification) || c.modifications.includes(o.modification)) return q(t, "unavailable");
			c.modifications.push(o.modification), c.history.at(-1).modification = o.modification, c.chapterChoices = [], c.phase = "summary", l.push({
				type: "Modification",
				modification: o.modification
			});
			break;
		case "advance": {
			let e = c.blades.find((e) => e.id === c.reserveId);
			e && c.modifications.includes("warmRack") && (e.value = W(e.value, 115), e.peak = Math.max(e.peak, e.value)), c.day++, c.phase = "workshop", c.daySales = 0, c.dayRecovered = 0, c.dayBuffs = K(c.pending), c.pending = K(Be()), Ue(c), l.push({ type: "Advanced" });
			break;
		}
	}
	return c.revision++, c.journal.push(o), e({
		ok: !0,
		state: c,
		events: l
	});
}
//#endregion
//#region src/core-v4/validate.ts
function Xe(e) {
	let t = L(e);
	if (!t) return {
		ok: !1,
		error: "invalid_state",
		detail: "Expected bounded plain JSON with safe integer fields."
	};
	let n = JSON.parse(t);
	if (!P(n) || n.rulesVersion !== "forge-v4") return {
		ok: !1,
		error: "invalid_rules_version",
		detail: "Expected forge-v4."
	};
	if (typeof n.runId != "string" || typeof n.seed != "string" || !Array.isArray(n.journal) || n.journal.length > 2048) return {
		ok: !1,
		error: "invalid_state",
		detail: "Missing identity or bounded Accepted journal."
	};
	let r = We({
		runId: n.runId,
		seed: n.seed,
		mode: n.mode,
		eligibility: n.initialEligibility
	});
	if (!r.ok) return {
		ok: !1,
		error: "invalid_state",
		detail: r.error
	};
	let i = r.state;
	for (let [e, t] of n.journal.entries()) {
		let n = Ye(i, {
			runId: i.runId,
			expectedRevision: i.revision,
			action: t
		});
		if (!n.ok) return {
			ok: !1,
			error: "invalid_journal",
			detail: `Command ${e}: ${n.error}`
		};
		i = n.state;
	}
	return L(i) === t ? {
		ok: !0,
		state: i
	} : {
		ok: !1,
		error: "invalid_state",
		detail: "Snapshot differs from full deterministic replay."
	};
}
//#endregion
//#region src/core-v4/view.ts
function Ze(t) {
	let n = t.history.filter((e) => [
		4,
		8,
		12
	].includes(e.day) && e.sealsAfter > 0).map((e) => De(e.day)), i = ["light"];
	n.includes(1) && i.push("guard"), n.includes(2) && i.push("heavy");
	let a = t.history.filter((e) => e.met).map((e) => ({
		commissionId: e.commissionId,
		day: e.day,
		routeId: e.routeId,
		blades: e.pieceIds.map((e) => t.blades.find((t) => t.id === e)),
		runId: t.runId
	})), o = r.filter((e) => a.some((t) => t.blades.some((t) => t.recipe === e && t.level >= 9))), s = [...new Set(t.journal.flatMap((e) => (e.type === "buy" || e.type === "claimGift") && e.traitId ? [e.traitId] : []))];
	return e({
		chapters: n,
		recipes: i,
		challenge: t.phase === "victory",
		mastery: o,
		traits: s,
		works: a
	});
}
//#endregion
//#region src/application/v4-collection.ts
var Qe = "sword-led.collection.v1", $e = "sword-led.collection.backup.v1", et = (e, t) => Object.keys(e).sort().join(",") === [...t].sort().join(","), X = (e, t, n) => Number.isSafeInteger(e) && Number(e) >= t && Number(e) <= n, tt = (e, t) => L(e) === L(t), nt = (e) => typeof e == "string" && /^[A-Za-z0-9_-]{1,80}$/.test(e), rt = () => e({
	chapters: [],
	mastery: [],
	traits: [],
	challenge: !1,
	works: []
});
function it(e, t) {
	return !P(e) || !et(e, [
		"id",
		"slot",
		"suppliedDay",
		"recipe",
		"status",
		"base",
		"value",
		"peak",
		"level",
		"cracked",
		"hits",
		"charge",
		"successes",
		"normalGreats",
		"bursts",
		"finalizedDay",
		"commissionId"
	]) || !X(e.slot, 1, 3) || !X(e.suppliedDay, 1, t.day) || e.id !== `d${e.suppliedDay}-${e.slot}` || !r.some((t) => t === e.recipe) || e.status !== "commissioned" || e.finalizedDay !== t.day || e.commissionId !== t.commissionId || typeof e.cracked != "boolean" || !X(e.base, 1, 1e9) || !X(e.value, 1, 1e9) || !X(e.peak, e.value, 1e9) || !X(e.level, 0, 99) || !X(e.hits, 0, 2048) || !X(e.charge, 0, 6) || !X(e.bursts, 0, 2048) || !X(e.successes, 0, e.hits) || !X(e.normalGreats, 0, e.successes) ? !1 : e.hits === e.bursts * 6 + e.charge;
}
function at(e) {
	if (!P(e) || !et(e, [
		"commissionId",
		"day",
		"routeId",
		"runId",
		"blades"
	]) || !X(e.commissionId, 1, 12) || !X(e.day, 1, 12) || !nt(e.runId)) return !1;
	let t = d[e.commissionId - 1].routes.find((t) => t.id === e.routeId);
	if (!t || !Array.isArray(e.blades) || e.blades.length !== t.count || !(e.commissionId <= 4 || e.commissionId === 8 || e.commissionId === 12 ? [e.commissionId] : e.commissionId < 8 ? [
		5,
		6,
		7
	] : [
		9,
		10,
		11
	]).includes(e.day)) return !1;
	let n = {
		day: e.day,
		commissionId: e.commissionId
	};
	return e.blades.every((e) => it(e, n) && Ne({ day: n.day }, e, t).matches) && new Set(e.blades.map((e) => e.id)).size === t.count;
}
var ot = (e) => e.blades.reduce((e, t) => e + t.value, 0);
function st(e, t) {
	let n = ot(e) - ot(t);
	return n > 0 ? e : n < 0 ? t : L(e) <= L(t) ? e : t;
}
function ct(t, i) {
	let a = /* @__PURE__ */ new Map();
	for (let e of [...t.works, ...i.works]) a.set(e.commissionId, a.has(e.commissionId) ? st(a.get(e.commissionId), e) : e);
	return e({
		chapters: [.../* @__PURE__ */ new Set([...t.chapters, ...i.chapters])].sort((e, t) => e - t),
		mastery: r.filter((e) => t.mastery.includes(e) || i.mastery.includes(e)),
		traits: n.filter((e) => t.traits.includes(e) || i.traits.includes(e)),
		challenge: t.challenge || i.challenge,
		works: [...a.values()].sort((e, t) => e.commissionId - t.commissionId)
	});
}
function lt(e) {
	let t = () => ({
		ok: !1,
		error: "invalid_state",
		detail: "Expected bounded collection sets and valid commission receipts."
	}), i = L(e);
	if (!i) return t();
	let a = JSON.parse(i);
	if (!P(a) || !et(a, [
		"chapters",
		"mastery",
		"traits",
		"challenge",
		"works"
	]) || typeof a.challenge != "boolean" || !Array.isArray(a.chapters) || a.chapters.length > 3 || !a.chapters.every((e) => X(e, 1, 3)) || !Array.isArray(a.mastery) || a.mastery.length > 3 || !a.mastery.every((e) => r.some((t) => t === e)) || !Array.isArray(a.traits) || a.traits.length > 6 || !a.traits.every((e) => n.some((t) => t === e)) || !Array.isArray(a.works) || a.works.length > 12 || !a.works.every(at)) return t();
	let o = a, s = ct(rt(), o);
	return !tt(s, o) || o.chapters.some((e) => e > 1 && !o.chapters.includes(e - 1)) || o.challenge && (!o.chapters.includes(3) || o.works.length < 10 || ![
		4,
		8,
		12
	].every((e) => o.works.some((t) => t.commissionId === e))) ? t() : {
		ok: !0,
		state: s
	};
}
var ut = Object.freeze({
	key: Qe,
	backupKey: $e,
	schemaVersion: 1,
	rulesVersion: "forge-v4-collection-v1",
	validate: lt
}), dt = (e) => H(e, ut), ft = "sword-led.collection.v2", pt = "sword-led.collection.backup.v2", mt = Qe, ht = $e, gt = (e, t) => Object.keys(e).sort().join(",") === [...t].sort().join(","), _t = (e, t) => L(e) === L(t), Z = () => ({
	ok: !1,
	error: "invalid_state",
	detail: "Expected bounded collection sets and source-tagged commission receipts."
}), Q = () => e({
	chapters: [],
	mastery: [],
	traits: [],
	challenge: !1,
	works: []
}), vt = (e) => e.blades.reduce((e, t) => e + t.value, 0);
function yt(e, t) {
	let n = vt(e) - vt(t);
	return n > 0 ? e : n < 0 ? t : L(e) <= L(t) ? e : t;
}
function $(t, i) {
	let a = /* @__PURE__ */ new Map();
	for (let e of [...t.works, ...i.works]) a.set(e.commissionId, a.has(e.commissionId) ? yt(a.get(e.commissionId), e) : e);
	return e({
		chapters: [.../* @__PURE__ */ new Set([...t.chapters, ...i.chapters])].sort((e, t) => e - t),
		mastery: r.filter((e) => t.mastery.includes(e) || i.mastery.includes(e)),
		traits: n.filter((e) => t.traits.includes(e) || i.traits.includes(e)),
		challenge: t.challenge || i.challenge,
		works: [...a.values()].sort((e, t) => e.commissionId - t.commissionId)
	});
}
function bt(e) {
	let t = L(e);
	if (t === null) return Z();
	let n = JSON.parse(t);
	if (!P(n) || !gt(n, [
		"chapters",
		"mastery",
		"traits",
		"challenge",
		"works"
	]) || !Array.isArray(n.works) || n.works.length > 12) return Z();
	let r = [];
	for (let e of n.works) {
		if (!P(e) || !gt(e, [
			"commissionId",
			"day",
			"routeId",
			"runId",
			"blades",
			"rulesVersion"
		]) || e.rulesVersion !== "forge-v4" && e.rulesVersion !== "forge-v5") return Z();
		let { rulesVersion: t, ...n } = e;
		r.push(n);
	}
	if (!lt({
		...n,
		works: r
	}).ok) return Z();
	let i = n, a = $(Q(), i);
	return _t(a, i) ? {
		ok: !0,
		state: a
	} : Z();
}
function xt(e, t) {
	return $(Q(), {
		chapters: e.chapters,
		mastery: e.mastery,
		traits: e.traits,
		challenge: e.challenge,
		works: e.works.map((e) => ({
			...e,
			rulesVersion: t
		}))
	});
}
function St(e) {
	return xt(ve(e), "forge-v5");
}
function Ct(e) {
	let t = L(e);
	if (t === null) return Z();
	let n = JSON.parse(t);
	if (!P(n)) return Z();
	if (n.rulesVersion === "forge-v5") {
		let e = he(n);
		return e.ok ? {
			ok: !0,
			state: St(e.state)
		} : e;
	}
	if (n.rulesVersion === "forge-v4") {
		let e = Xe(n);
		return e.ok ? {
			ok: !0,
			state: xt(Ze(e.state), "forge-v4")
		} : e;
	}
	return {
		ok: !1,
		error: "invalid_rules_version",
		detail: "Collection awards require a replayable forge-v4 or forge-v5 run."
	};
}
function wt(e) {
	let t = lt(e);
	return t.ok ? {
		ok: !0,
		state: xt(t.state, "forge-v4")
	} : t;
}
var Tt = dt;
function Et(t) {
	return e({
		recipes: r.filter((e) => e === "light" || e === "guard" && t.chapters.includes(1) || e === "heavy" && t.chapters.includes(2)),
		challenge: t.challenge
	});
}
var Dt = Object.freeze({
	key: ft,
	backupKey: pt,
	schemaVersion: 2,
	rulesVersion: "forge-collection-v2",
	validate: bt
}), Ot = (e) => H(e, Dt);
function kt(e, t, n) {
	let r = (t) => {
		try {
			return {
				ok: !0,
				raw: e().getItem(t)
			};
		} catch {
			return { ok: !1 };
		}
	};
	return () => ({
		main: r(t),
		backup: r(n)
	});
}
function At(e, t) {
	return {
		...Se(e, Dt, t),
		readRaw: kt(e, ft, pt)
	};
}
function jt(e) {
	return { readRaw: kt(e, mt, ht) };
}
//#endregion
//#region src/application/v5-persistence.ts
var Mt = "sword-led.save.v5", Nt = "sword-led.save.backup.v5", Pt = Object.freeze({
	key: Mt,
	backupKey: Nt,
	schemaVersion: 5,
	rulesVersion: "forge-v5",
	validate: he
}), Ft = (e) => H(e, Pt), It = (e, t) => Se(e, Pt, t);
function Lt(t, n, r, i) {
	let a = Q(), o = null, s = null, c = !1, l = null, u = !1, d = !1, f = !1, p = !1, m = null, h = 0, g = null, _ = /* @__PURE__ */ new Set(), v = /* @__PURE__ */ new Set(), y = be(t, n, {
		createRun: (e) => {
			let t = L(e);
			if (!t) return {
				ok: !1,
				error: "invalid_command"
			};
			let n = JSON.parse(t);
			if (!P(n) || Object.keys(n).some((e) => ![
				"runId",
				"seed",
				"mode"
			].includes(e))) return {
				ok: !1,
				error: "invalid_command"
			};
			let r = Et(o?.main.status === "valid" ? o.main.state : Q());
			return le({
				...e,
				eligibility: r
			});
		},
		applyCommand: me,
		isTerminal: (e) => [
			"victory",
			"return",
			"defeat"
		].includes(e.phase)
	}), b = (e = y.getSnapshot()) => !u && e.mode === "writer" && e.active && !e.dirty && !e.conflict && n.owns() && t.isCurrent(), x = () => e({
		data: a,
		load: o,
		pending: c,
		lastSave: s,
		problem: l,
		writable: b()
	}), S = (e) => ({
		ok: !1,
		error: e,
		snapshot: y.getSnapshot()
	}), C = (e) => {
		let t = y.getSnapshot();
		return u ? "disposed" : e === t.generation ? t.active ? t.mode !== "writer" || !n.owns() ? "readonly" : null : "not_active" : "stale_session";
	};
	function w(e = !0) {
		if (u) return;
		let n = y.getSnapshot();
		o = r.load();
		let i = o.main, d = i.status === "valid" ? i.state : Q();
		a = $(a, d), b(n) && n.state && (a = $(a, St(n.state)));
		let f = L(a) !== L(d), p = n.dirty && n.mode !== "memory" && n.state !== null && L($(a, St(n.state))) !== L(a);
		c = f || p;
		let m = o.backup;
		l = i.status === "invalid" || i.status === "unavailable" ? i.error : i.status === "empty" && m.status !== "empty" ? m.status === "valid" ? "recovery_required" : m.error : null, p && l === null && (l = "run_unsaved"), f && l === null && e && (n.dirty ? l = "run_unsaved" : b(n) ? (s = r.write(a, { raw: r.token() }), c = !s.ok, s.ok ? o = {
			main: {
				status: "valid",
				state: a,
				savedAt: s.savedAt
			},
			backup: r.inspect().backup
		} : l = s.error) : n.active && n.mode === "writer" && !t.isCurrent() && (l = "run_changed"));
	}
	function T() {
		if (u && y.getSnapshot().mode !== "disposed") return;
		if (f) {
			p = !0;
			return;
		}
		f = !0;
		let e = y.getSnapshot(), t = x();
		try {
			for (let t of _) {
				if (y.getSnapshot().generation !== e.generation) break;
				try {
					t(e);
				} catch {}
			}
			for (let n of v) {
				if (y.getSnapshot().generation !== e.generation) break;
				try {
					n(t);
				} catch {}
			}
		} finally {
			f = !1, p && (p = !1, T());
		}
	}
	function E(e) {
		if (d || f) return S("session_busy");
		d = !0;
		try {
			return e();
		} finally {
			d = !1;
		}
	}
	let D = y.subscribe(() => {
		w(), T();
	});
	return {
		getSnapshot: y.getSnapshot,
		getCollectionSnapshot: x,
		subscribe: (e) => {
			_.add(e);
			try {
				e(y.getSnapshot());
			} catch {}
			return () => {
				_.delete(e);
			};
		},
		subscribeCollection: (e) => {
			v.add(e);
			try {
				e(x());
			} catch {}
			return () => {
				v.delete(e);
			};
		},
		activate: async () => d || f ? y.getSnapshot() : y.activate(),
		startNewGame: (e, t) => E(() => {
			let n = C(t.generation);
			return n && y.getSnapshot().mode !== "memory" ? S(n) : t.generation === y.getSnapshot().generation ? (w(), y.getSnapshot().mode !== "memory" && c ? S("collection_pending") : y.startNewGame(e, t)) : S("stale_session");
		}),
		resume: (e) => E(() => y.resume(e)),
		recoverBackup: (e) => E(() => y.recoverBackup(e)),
		useMemory: (e, t) => E(() => (w(!1), y.useMemory(e, t))),
		dispatch: (e, t) => {
			if (d || f) return {
				ok: !1,
				error: "session_busy",
				state: y.getSnapshot().state,
				events: [],
				snapshot: y.getSnapshot()
			};
			d = !0;
			try {
				return y.dispatch(e, t);
			} finally {
				d = !1;
			}
		},
		retrySave: (e) => E(() => y.retrySave(e)),
		retryCollection: (e) => E(() => {
			let t = C(e);
			return t ? S(t) : (w(), T(), c || l ? S("collection_unavailable") : {
				ok: !0,
				snapshot: y.getSnapshot()
			});
		}),
		recoverCollectionBackup: (e) => E(() => {
			let t = C(e.generation);
			if (t) return S(t);
			if (!e.confirmed) return S("confirmation_required");
			if (o = r.load(), o.main.status === "valid") return S("main_available");
			if (o.main.status === "unavailable" || o.backup.status !== "valid") return S("backup_unavailable");
			if (!b()) return S("collection_unavailable");
			a = $(a, o.backup.state);
			let n = y.getSnapshot();
			return n.state && (a = $(a, St(n.state))), s = r.write(a, { raw: r.token() }), c = !s.ok, l = s.ok ? null : s.error, s.ok && (o = {
				main: {
					status: "valid",
					state: a,
					savedAt: s.savedAt
				},
				backup: r.inspect().backup
			}), T(), s.ok ? {
				ok: !0,
				snapshot: y.getSnapshot()
			} : S("collection_unavailable");
		}),
		notifyExternalChange: () => {
			u || y.notifyExternalChange();
		},
		notifyCollectionChange: () => {
			u || d || f || (w(), T());
		},
		previewLegacyImport: (t = "main") => {
			if (d || f) return S("session_busy");
			g = null;
			let n = y.getSnapshot();
			if (u) return S("disposed");
			if (!n.active) return S("not_active");
			if (t !== "main" && t !== "backup") return S("invalid_command");
			if (!i) return S("legacy_unavailable");
			d = !0;
			try {
				let r = i.readRaw()[t];
				if (!r.ok || r.raw === null) return S("legacy_unavailable");
				let o = Tt(r.raw);
				if (o.status !== "valid") return S("legacy_unavailable");
				let s = wt(o.state);
				if (!s.ok) return S("legacy_unavailable");
				let c = e({
					id: ++h,
					generation: n.generation,
					source: t,
					savedAt: o.savedAt,
					collection: s.state,
					merged: $(a, s.state)
				});
				return g = {
					preview: c,
					raw: r.raw,
					runId: n.state?.runId ?? null,
					revision: n.state?.revision ?? null
				}, {
					ok: !0,
					preview: c,
					snapshot: n
				};
			} catch {
				return S("legacy_unavailable");
			} finally {
				d = !1;
			}
		},
		importLegacyCollection: (e) => E(() => {
			let t = L(e), n = t ? JSON.parse(t) : null;
			if (!P(n) || Object.keys(n).sort().join(",") !== "confirmed,generation,previewId" || typeof n.confirmed != "boolean" || typeof n.generation != "number" || !Number.isSafeInteger(n.generation) || typeof n.previewId != "number" || !Number.isSafeInteger(n.previewId)) return S("invalid_command");
			let r = C(n.generation);
			if (r) return S(r);
			if (n.confirmed !== !0) return S("confirmation_required");
			let o = y.getSnapshot(), s = g;
			if (!s || s.preview.id !== n.previewId || s.preview.generation !== o.generation || s.runId !== (o.state?.runId ?? null) || s.revision !== (o.state?.revision ?? null)) return g = null, S("legacy_changed");
			if (!b(o) || (w(!1), l !== null)) return S("collection_unavailable");
			try {
				let e = i?.readRaw()[s.preview.source];
				if (!e?.ok) return S("legacy_unavailable");
				if (e.raw !== s.raw) return g = null, S("legacy_changed");
			} catch {
				return S("legacy_unavailable");
			}
			return a = $(a, s.preview.collection), g = null, w(), T(), c || l ? S("collection_unavailable") : {
				ok: !0,
				snapshot: y.getSnapshot()
			};
		}),
		cancelLegacyImport: () => {
			g = null;
		},
		notifyLegacyCollectionChange: () => {
			g = null;
		},
		exportRun: () => {
			let e = y.getSnapshot().state;
			return e ? JSON.stringify(e, null, 2) : null;
		},
		exportCollection: () => JSON.stringify({
			format: "sword-led.collection-export.v2",
			collection: a,
			stored: r.readRaw()
		}, null, 2),
		suspend: () => f && !y.getSnapshot().active ? Promise.resolve() : y.suspend(),
		dispose: () => {
			if (u) return m ?? Promise.resolve();
			u = !0, g = null, m = y.dispose(), D();
			let e = () => {
				_.clear(), v.clear();
			};
			return f ? m.then(e, e) : e(), m;
		}
	};
}
function Rt(e = window) {
	let t = Te(e, Mt, (t) => Lt(It(() => e.localStorage), we(t), At(() => e.localStorage), jt(() => e.localStorage))), n = (e) => {
		(e.key === "sword-led.collection.v2" || e.key === "sword-led.collection.backup.v2" || e.key === null) && t.notifyCollectionChange(), (e.key === mt || e.key === ht || e.key === null) && t.notifyLegacyCollectionChange();
	};
	return e.addEventListener("storage", n), {
		...t,
		dispose: () => (e.removeEventListener("storage", n), t.dispose())
	};
}
//#endregion
export { c as CHAPTERS, pt as COLLECTION_BACKUP_KEY, Dt as COLLECTION_CODEC, ft as COLLECTION_KEY, d as COMMISSIONS, f as ENDINGS, u as EVENTS, a as EVENT_IDS, g as JOURNAL_LIMIT, h as JOURNAL_SOFT_LIMIT, ht as LEGACY_COLLECTION_BACKUP_KEY, mt as LEGACY_COLLECTION_KEY, m as LEVEL_CAP, l as MERCHANTS, s as MODIFICATIONS, i as MODIFICATION_IDS, o as RECIPES, r as RECIPE_IDS, t as TRAITS, n as TRAIT_IDS, Nt as V5_BACKUP_KEY, Pt as V5_CODEC, Mt as V5_SAVE_KEY, p as VALUE_CAP, me as applyCommand, te as assessBlade, y as atCap, re as barterAssessment, _ as chapterFor, Et as collectionEligibility, wt as collectionFromLegacy, Ct as collectionFromRun, T as commissionFor, k as commissionProgress, At as createCollectionRepository, jt as createLegacyCollectionSource, le as createRun, Rt as createV5BrowserSession, It as createV5SaveRepository, Lt as createV5Session, C as cumulativeBaseFee, Ot as decodeCollection, Tt as decodeLegacyCollection, Ft as decodeV5Save, ne as deliveryQuote, _e as describeRoute, Q as emptyCollection, N as eventQuote, ve as getCollectionAwards, ye as getRunView, x as marketFor, S as marketRemaining, j as merchantFor, M as merchantPresent, $ as mergeCollections, ue as parseAction, b as percent, D as recommendedRecipe, v as recovery, A as recoveryQuote, O as routeAssessment, ie as settlementPreview, ee as strikeOdds, w as supplyBaseFor, E as unlockedRecipes, bt as validateCollection, he as validateRun };
