# T03现行门与历史诊断：结项前只读审计

基线 `a4b622f30ae2e03769b7eec2aa5b111f5f14a0bb`，工作树读取时干净。依据goal-4三文件、原预算／impact map、实际report/process/end指纹及发布回执；本审计未运行SDK、浏览器、构建、旧矩阵或新测试，只写tmp。

**结论：没有发现另一个尚未执行的必需矩阵或新增产品修补缺口。现行数值门已有分批证据；旧v3 Chromium销毁是仍失败的当前关闭检查。原81ms则是已调查但未归因的历史诊断，不能直接计作当前产品数值失败，也不能宣称已修／test-only。** 现行plan/tasks仍明确保留其调查责任，不能通过这一分类悄悄删除。

| 必需责任 | 现有实际证据与精确边界 |
| --- | --- |
| 系统Chrome最小化／BFCache／writer／旧输入6项 | native04=6/6，可信事件／同堆／实际主档与内存／新旧输入门。随后产品差分仅已有试听按钮回调加silence，共享生命周期、保存、renderer均未变；保原构建身份＋明确差分依据，无需改称新跑6项 |
| 原音频23×6 | audio02的15个非defer逻辑90次原通过保身份；8个受影响defer逻辑48次由正确原手势native调用／仅延迟完成的新轴覆盖。该轴另含新试听重试1逻辑，共54/54；WK1标题另预定3/3。256FFT／8ms／wave门、旧声0、graph、原文和六项目未删；不拼成一次“最新138全绿”，旧clock0／复合注入红保原身份 |
| 资源／动效／往返与可读性 | non-audio-current02实际21×6：8resilience＋5accessibility＋8native performance，125过1红；资源／往返／20同realm mounts／两尺寸12px、contrast4.5、target44均过。它未重跑near-limit与2049两逻辑，见下行，不是把10resilience漏数成8 |
| 合法1898→1900出口、2049原文保留 | 原两逻辑×6实际通过；保存／拒读／原文导出机制不变，golden02对当前game分配例外作完整结果／codec／collection／所有权同值桥。独立replay-current01核5471合法state／1512保存／828capture；本批没遇2049或collection-export格式，不能冒称由独立回放新覆盖，但也不抹除既有UI负样本证据 |
| 输入4×6、受控Hz3×6 | 旧24＋18保原版本；direct-input／hammer机制不再变化，core golden与实际像素对照支撑已记录差分依据。受控60/120/144是调度／命令数证明，不是物理刷新率。无新增理由重跑原384 |
| 原生性能8×6 | 原当前批其余47项通过；FF2 pressure1920旧81红，校准后同一预定逻辑无profile通过，三路径各6Accepted，p95=8/7/6、max=14/24/21、contact≤138。同项目四连锻校准另1/1通过，保3恢复／3Accepted／12contact与≥60真实回调。其余项保原consumer身份，不叫新完整48批 |
| 共享旧入口18项 | legacy-current02为14过4红，late-arm修正后三个v2目标原门全过；余下v3 Chromium业务body完成但context销毁180s失败，protocol149等到browser.close才回复。四个静态Clock／Audio控制28–44ms关闭仅未复现，不替原游戏关闭通过 |

原数值标准继续：callback样本≥60、p95<16.7ms、max≥50ms须定位；短handler p95<50/max<100，长<100/<200；input→Accepted≤150、普通contact≤200；load≤3000；尾核800＋500ms无孤儿rAF／pending／运行scene动画／active声音。四连锻原本没有普通contact200门，不补删；第一锤、Continue冷成本、原文全值均保留。实际冷首屏图片2,557,210B≤3MiB及当时JS gzip100,698B≤150KiB已有记录；当前只改试听回调，同图片／闭包依赖不变，本审计另静态gzip level6四JS合计99,513B（方法不同、不是新网络测量），同样远低于153,600B。

**历史81的处置限界：** profile02有开销，未重现81；该次17ms p95／228ms接触红保留。实际栈和安装版expect源码证明“未满足busy属性matcher会做ARIA／布局工作”，据此移除反复matcher而保MO、后置属性、raw RPC、原所有门，是有证据的消费者校准。它证明当前校准测量达门，未证明原81某一函数／GC／OS根因。plan:67原文“max≥50ms必须定位”及tasks末尾仍列历史调查待办；若按该文字要求调查完成，原尖峰的定位结果仍欠，不能以新绿代替。这是现有未结调查，不是另加性能测试或批准门，也不要求继续盲跑求绿。

**三task review／保护／harness：** 已有正式 `G4-T03-current-progress.md` 的T01–T03联合复核，涵盖原五项、C端付款、代码／保存／安全／依赖，后续试听与探针校准有单独报告。当前没有新增生产delta或静态mustfix；最终只需并入最后关闭结论及本次身份校正，T04“全目标最大审计”仍另任务，不重复命名为T03尚未做整轮review。独立本次逐字节复核：110/113旧源、6/7core、8/9SDK、85/85原件保持；input/audio/forge/game四例外与原件／声明全等，保留ref仍0316e071…；当前82文件与build22不可变试玩快照全等。

harness须准确表述：entry与JS `006b9dfc…`／CSS `7fb28d9a…` 仍与non-audio-current02实测相同，**没有重新编译当前app**。该批app为58da…，当前46c0…的唯一差分是原试听callback加已有silence；无新listener、资源／timer或dispose分支，共享audio／forge均同字节。因此可保20mount与正常往返原结果，并明确此单回调差分依据；不能写成最新源码已重编译、重新20mount通过。完整字节依据见 [t03-closure-audit-bindings.json](goal4-T03/t03-closure-audit-bindings.json)。

按当前未完成记录，T03仍不可先勾选：旧v3关闭须有原用例的有据修复／消费者问题分类与相应终态；原81调查须保留上述未归因限界和既定处置责任；最后联合结论应绑定当前保护／harness差分、归档及真实提交推送回执。没有依据要求重跑无关384／完整新矩阵／再请同一玩法批准。用户金额困惑已答且修补实际发布；后来可选反馈未答既不等于接受，也不是新增审批或技术工作许可前提，更不阻塞T03独立技术收尾。T03结项也不等于T04或整个goal完成。
