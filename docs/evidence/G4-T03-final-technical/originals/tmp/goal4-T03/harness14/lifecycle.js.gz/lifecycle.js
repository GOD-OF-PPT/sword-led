//#region src/core/immutable.ts
function e(t) {
	if (typeof t != "object" || !t || Object.isFrozen(t)) return t;
	let n = Array.isArray(t) ? t.map((t) => e(t)) : Object.fromEntries(Object.entries(t).map(([t, n]) => [t, e(n)]));
	return Object.freeze(n);
}
e([
	120,
	150,
	180,
	210,
	250,
	290,
	340,
	390,
	450,
	520,
	600,
	700
]), e([
	3,
	6,
	9
]), e([
	{
		name: "粗坯",
		progress: 0,
		multiplier: 10
	},
	{
		name: "整形",
		progress: 2,
		multiplier: 16
	},
	{
		name: "淬炼",
		progress: 5,
		multiplier: 25
	},
	{
		name: "成刃",
		progress: 9,
		multiplier: 38
	},
	{
		name: "精工",
		progress: 14,
		multiplier: 56
	},
	{
		name: "上品",
		progress: 20,
		multiplier: 80
	},
	{
		name: "名作",
		progress: 27,
		multiplier: 115
	},
	{
		name: "传世",
		progress: 35,
		multiplier: 160
	}
]), e({
	iron: {
		name: "熟铁",
		baseValue: 18,
		integrity: 4,
		risk: 2,
		scrap: 3
	},
	steel: {
		name: "精钢",
		baseValue: 22,
		integrity: 3,
		risk: 6,
		scrap: 4
	},
	meteorite: {
		name: "陨铁",
		baseValue: 28,
		integrity: 2,
		risk: 10,
		scrap: 5
	}
}), e({
	light: {
		label: "轻锤",
		progress: 1,
		heat: 8,
		stress: 3,
		risk: -2,
		periodMs: 1600
	},
	standard: {
		label: "标准锤",
		progress: 2,
		heat: 12,
		stress: 7,
		risk: 2,
		periodMs: 1400
	},
	heavy: {
		label: "重锤",
		progress: 3,
		heat: 18,
		stress: 12,
		risk: 7,
		periodMs: 1200
	}
});
//#endregion
//#region src/core/guards.ts
function t(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
//#endregion
//#region src/core/random.ts
function n(e) {
	let t = 2166136261;
	for (let n of new TextEncoder().encode(e)) t = Math.imul(t ^ n, 16777619) >>> 0;
	return t;
}
function r(e) {
	let t = e.state + 1831565813 >>> 0, n = Math.imul(t ^ t >>> 15, t | 1);
	return n ^= n + Math.imul(n ^ n >>> 7, n | 61), {
		value: ((n ^ n >>> 14) >>> 0) / 4294967296,
		stream: {
			state: t,
			draws: e.draws + 1
		}
	};
}
e({
	handle: {
		label: "配重锤柄",
		effect: "精准区每级向两侧各扩大 2 个百分点",
		prices: [{
			coins: 100,
			scrap: 3
		}, {
			coins: 180,
			scrap: 5
		}]
	},
	bellows: {
		label: "强化风箱",
		effect: "每级令下一轮煤炭配给 +1",
		prices: [{
			coins: 120,
			scrap: 4
		}, {
			coins: 220,
			scrap: 6
		}]
	},
	anvil: {
		label: "稳固砧台",
		effect: "每级裂损概率 -3 个百分点",
		prices: [{
			coins: 160,
			scrap: 6
		}, {
			coins: 260,
			scrap: 8
		}]
	},
	repair: {
		label: "契约修补",
		effect: "恢复一枚契约印记，本次来访限一次",
		prices: [{
			coins: 240,
			scrap: 6
		}]
	}
}), e([
	"handle",
	"bellows",
	"anvil",
	"repair"
]), Object.freeze([]);
function i(e) {
	let t = 0, n = 0, r = (e, i) => {
		if (++t > 5e4 || i > 16) return null;
		if (e === null || typeof e == "boolean" || typeof e == "number" && Number.isSafeInteger(e)) {
			let t = JSON.stringify(e);
			return n += t.length, n <= 262144 ? t : null;
		}
		if (typeof e == "string") {
			if (e.length > 262144) return null;
			let t = JSON.stringify(e);
			return n += t.length, n <= 262144 ? t : null;
		}
		if (typeof e != "object") return null;
		let a = Array.isArray(e), o = Object.getPrototypeOf(e);
		if (a ? o !== Array.prototype : o !== Object.prototype && o !== null) return null;
		let s = Reflect.ownKeys(e);
		if (s.some((e) => typeof e != "string") || s.length > 1e4) return null;
		let c = [];
		if (a) {
			if (e.length > 2048 || s.length !== e.length + 1) return null;
			for (let t = 0; t < e.length; t++) {
				let n = Object.getOwnPropertyDescriptor(e, String(t));
				if (!n || !("value" in n) || !n.enumerable) return null;
				let a = n.value, o = r(a, i + 1);
				if (o === null) return null;
				c.push(o);
			}
			return `[${c.join(",")}]`;
		}
		let l = Object.getOwnPropertyNames(e).sort();
		for (let t of l) {
			let a = Object.getOwnPropertyDescriptor(e, t);
			if (!a || !("value" in a) || !a.enumerable || (n += t.length + 3, n > 262144)) return null;
			let o = a.value, s = r(o, i + 1);
			if (s === null) return null;
			c.push(`${JSON.stringify(t)}:${s}`);
		}
		return `{${c.join(",")}}`;
	};
	try {
		let t = r(e, 0);
		return t !== null && new TextEncoder().encode(t).byteLength <= 262144 ? t : null;
	} catch {
		return null;
	}
}
//#endregion
//#region src/application/persistent-session.ts
function a(t, n, r) {
	let i = r.isTerminal ?? ((e) => e.phase === "victory" || e.phase === "defeat"), a = 0, o = 0, s = "inactive", c = !1, l = null, u = !1, d = !1, f = null, p = null, m, h = /* @__PURE__ */ new Set(), g = () => e({
		generation: a,
		mode: s,
		active: c,
		state: l,
		dirty: u,
		conflict: d,
		load: f,
		lastSave: p
	}), _ = () => {
		let e = g();
		for (let t of h) try {
			t(e);
		} catch {}
	}, v = (e) => ({
		ok: !1,
		error: e,
		snapshot: g()
	}), y = () => ({
		ok: !0,
		snapshot: g()
	}), b = () => {
		a++, o++;
	}, x = () => {
		d = !0, u = l !== null, b(), _();
	}, S = (e) => e.main.status === "valid" && !i(e.main.state) || e.main.status === "invalid" || e.main.status === "empty" && e.backup.status === "valid", C = (e, t = !1) => s === "disposed" ? "disposed" : e === a ? c ? s === "memory" ? null : s === "unsupported" ? "locks_unsupported" : s !== "writer" || !n.owns() ? "readonly" : d && !t ? "save_conflict" : null : "not_active" : "stale_session", w = () => l === null || s === "memory" ? (u = l !== null, p = null, null) : (p = n.owns() ? t.write(l, { raw: m }) : {
		ok: !1,
		error: "storage_conflict",
		detail: "Writer lease was lost."
	}, u = !p.ok, p.ok && (m = t.token()), !p.ok && p.error === "storage_conflict" && (d = !0), p);
	return {
		getSnapshot: g,
		subscribe: (e) => {
			h.add(e);
			try {
				e(g());
			} catch {}
			return () => {
				h.delete(e);
			};
		},
		activate: async () => {
			if (s === "disposed") return g();
			let e = ++o;
			if (a++, s === "memory") return c = !0, _(), g();
			c = !1;
			let r = l, i = u, h = m, v = await n.acquire();
			return e === o && (c = v !== "cancelled" && v !== "disposed", s = v === "writer" ? "writer" : v === "readonly" ? "readonly" : v === "unsupported" ? "unsupported" : "error", f = t.load(), r && (i || f.main.status !== "valid") ? (l = r, u = !0, d = h !== t.token()) : (l = f.main.status === "valid" ? f.main.state : null, m = t.token(), u = !1, d = !1), p = null, _()), g();
		},
		startNewGame: (e, n) => {
			let a = C(n.generation, !0);
			if (a) return v(a);
			let o = r.createRun(e);
			if (!o.ok) return v(o.error);
			if (s === "memory") {
				if (l && n.confirmed !== !0) return v("confirmation_required");
			} else {
				let e = t.inspect();
				if (e.main.status === "unavailable") return v("save_unavailable");
				let r = l !== null && !i(l);
				if ((S(e) || r || u) && n.confirmed !== !0) return v("confirmation_required");
				if (f = t.load(), f.main.status === "unavailable") return x(), v("save_unavailable");
				if (S(f) && n.confirmed !== !0) return x(), v("confirmation_required");
			}
			return b(), l = o.state, m = s === "memory" ? void 0 : t.token(), u = !0, d = !1, w(), _(), y();
		},
		resume: (e) => {
			let n = C(e.generation, !0);
			return n ? v(n) : s === "memory" ? v("save_unavailable") : u && e.confirmed !== !0 ? v("confirmation_required") : t.inspect().main.status === "valid" ? (f = t.load(), f.main.status === "valid" ? (l = f.main.state, m = t.token(), u = !1, d = !1, p = null, b(), _(), y()) : (x(), v("save_unavailable"))) : v("save_unavailable");
		},
		recoverBackup: (e) => {
			let n = C(e.generation, !0);
			if (n) return v(n);
			if (s === "memory") return v("save_unavailable");
			if (e.confirmed !== !0) return v("confirmation_required");
			let r = t.inspect();
			return r.main.status === "valid" ? v("main_available") : r.main.status === "unavailable" || r.backup.status !== "valid" ? v("backup_unavailable") : (f = t.load(), f.main.status === "valid" ? (x(), v("main_available")) : f.main.status === "unavailable" || f.backup.status !== "valid" ? (x(), v("backup_unavailable")) : (l = f.backup.state, m = t.token(), d = !1, u = !0, b(), w(), _(), y()));
		},
		useMemory: (e, t) => {
			if (s === "disposed") return v("disposed");
			if (t.generation !== a) return v("stale_session");
			if (e !== null && l && t.confirmed !== !0) return v("confirmation_required");
			let i = e === null ? null : r.createRun(e);
			return i && !i.ok ? v(i.error) : !i && !l ? v("no_run") : (b(), n.release(), i?.ok && (l = i.state), m = void 0, s = "memory", c = !0, u = !0, d = !1, p = null, _(), y());
		},
		dispatch: (e, t) => {
			let n = C(t);
			if (n || l === null) return {
				ok: !1,
				state: l,
				error: n ?? "no_run",
				events: [],
				snapshot: g()
			};
			let i = r.applyCommand(l, e);
			if (!i.ok) return {
				...i,
				snapshot: g()
			};
			l = i.state, u = !0;
			let a = w();
			return _(), {
				...i,
				persistence: a,
				snapshot: g()
			};
		},
		retrySave: (e) => {
			let t = C(e);
			return t ? v(t) : s === "memory" ? v("save_unavailable") : l ? (u && (w(), _()), u ? v(d ? "save_conflict" : "save_unavailable") : y()) : v("no_run");
		},
		notifyExternalChange: () => {
			s !== "disposed" && s !== "memory" && (t.isCurrent({ raw: m }) || (d = !0, a++), _());
		},
		suspend: () => {
			b(), c = !1, s !== "disposed" && s !== "memory" && (s = "inactive");
			let e = n.release();
			return _(), e;
		},
		dispose: () => {
			b(), c = !1, s = "disposed";
			let e = n.dispose();
			return _(), h.clear(), e;
		}
	};
}
//#endregion
//#region src/platform/storage.ts
function o(e) {
	if (typeof e != "string" || e.length !== 24) return !1;
	try {
		return new Date(e).toISOString() === e;
	} catch {
		return !1;
	}
}
function s(e, n) {
	if (e === null) return { status: "empty" };
	if (e.length > 262144 || new TextEncoder().encode(e).byteLength > 262144) return {
		status: "invalid",
		error: "save_too_large",
		detail: "Save exceeds 256 KiB."
	};
	let r;
	try {
		r = JSON.parse(e);
	} catch {
		return {
			status: "invalid",
			error: "invalid_json",
			detail: "Save is not valid JSON."
		};
	}
	if (!t(r) || Object.keys(r).sort().join(",") !== "rulesVersion,savedAt,schemaVersion,state" || r.schemaVersion !== n.schemaVersion) return {
		status: "invalid",
		error: "unsupported_schema",
		detail: "Unsupported save envelope/schema."
	};
	if (r.rulesVersion !== n.rulesVersion) return {
		status: "invalid",
		error: "unsupported_rules",
		detail: "Save uses different rules."
	};
	if (!o(r.savedAt)) return {
		status: "invalid",
		error: "invalid_timestamp",
		detail: "Invalid save timestamp."
	};
	let i = n.validate(r.state);
	return i.ok ? {
		status: "valid",
		state: i.state,
		savedAt: r.savedAt
	} : {
		status: "invalid",
		error: i.error === "invalid_rules_version" ? "unsupported_rules" : "invalid_state",
		detail: i.detail
	};
}
function c(e, t, n = () => (/* @__PURE__ */ new Date()).toISOString()) {
	let r, i, a = (e) => s(e, t), c = (n) => {
		let o, s, c, l;
		try {
			l = e();
		} catch {
			let e = {
				status: "unavailable",
				error: "storage_read_failed",
				detail: "Storage access was denied."
			};
			return n && (r = void 0, i = void 0), {
				main: e,
				backup: e
			};
		}
		try {
			o = l.getItem(t.key), s = a(o);
		} catch {
			s = {
				status: "unavailable",
				error: "storage_read_failed",
				detail: "Primary save could not be read."
			};
		}
		try {
			c = a(l.getItem(t.backupKey));
		} catch {
			c = {
				status: "unavailable",
				error: "storage_read_failed",
				detail: "Backup could not be read."
			};
		}
		return n && (r = o, i = s.status === "valid" ? o ?? void 0 : void 0), {
			main: s,
			backup: c
		};
	};
	return {
		load: () => c(!0),
		inspect: () => c(!1),
		token: () => r,
		isCurrent: (n) => {
			let i = n ? n.raw : r;
			try {
				return i !== void 0 && e().getItem(t.key) === i;
			} catch {
				return !1;
			}
		},
		write: (s, c) => {
			let l = c ? c.raw : r;
			if (l === void 0) return {
				ok: !1,
				error: "storage_read_failed",
				detail: "Load the slot before writing."
			};
			let u, d;
			try {
				if (u = e(), d = u.getItem(t.key), d !== l) return {
					ok: !1,
					error: "storage_conflict",
					detail: "Another writer changed the save."
				};
			} catch {
				return {
					ok: !1,
					error: "storage_read_failed",
					detail: "Primary save could not be checked."
				};
			}
			let f, p;
			try {
				if (p = n(), !o(p)) return {
					ok: !1,
					error: "serialization_failed",
					detail: "Clock returned an invalid timestamp."
				};
				if (f = JSON.stringify({
					schemaVersion: t.schemaVersion,
					rulesVersion: t.rulesVersion,
					savedAt: p,
					state: s
				}), new TextEncoder().encode(f).byteLength > 262144) return {
					ok: !1,
					error: "save_too_large",
					detail: "Save exceeds 256 KiB."
				};
			} catch {
				return {
					ok: !1,
					error: "serialization_failed",
					detail: "Save could not be serialized."
				};
			}
			let m = !1, h = d !== null && (d === i || a(d).status === "valid") ? d : void 0;
			if (h !== void 0 && h !== f) try {
				u.setItem(t.backupKey, h);
			} catch {
				m = !0;
			}
			try {
				u.setItem(t.key, f);
			} catch {
				return {
					ok: !1,
					error: "storage_write_failed",
					detail: "Primary write failed; in-memory progress is not saved."
				};
			}
			return r = f, i = f, {
				ok: !0,
				savedAt: p,
				backupWarning: m
			};
		}
	};
}
//#endregion
//#region src/platform/writer-lease.ts
var l = "sword-led.writer";
function u(e) {
	let t = 0, n = !1, r = !1, i, a = Promise.resolve(), o = null, s = () => (t++, n = !1, i?.(), i = void 0, o = null, a);
	return {
		owns: () => n && !r,
		release: s,
		dispose: () => (r = !0, s()),
		acquire: () => {
			if (r) return Promise.resolve("disposed");
			if (!e) return Promise.resolve("unsupported");
			if (n) return Promise.resolve("writer");
			if (o) return o;
			let s = ++t, c = a.then(() => new Promise((o) => {
				if (r || s !== t) o("cancelled");
				else try {
					a = e.request(l, {
						mode: "exclusive",
						ifAvailable: !0
					}, async (e) => {
						if (r || s !== t) {
							o("cancelled");
							return;
						}
						if (e === null) {
							o("readonly");
							return;
						}
						let a = new Promise((e) => {
							i = e;
						});
						n = !0, o("writer"), await a, s === t && (n = !1, i = void 0);
					}).catch(() => {
						s === t && (n = !1, i?.(), i = void 0), o("error");
					});
				} catch {
					o("error");
				}
			}));
			return o = c, c.then(() => {
				o === c && (o = null);
			}), c;
		}
	};
}
//#endregion
//#region src/platform/browser-session.ts
function d(e, t, n) {
	let r;
	try {
		if (e.isSecureContext && e.navigator.locks) {
			let t = e.navigator.locks;
			r = { request: (e, n, r) => t.request(e, n, r) };
		}
	} catch {
		r = void 0;
	}
	let i = n(r), a = () => {
		i.suspend();
	}, o = (e) => {
		e.persisted && i.activate();
	}, s = (e) => {
		(e.key === t || e.key === null) && i.notifyExternalChange();
	};
	return e.addEventListener("pagehide", a), e.addEventListener("pageshow", o), e.addEventListener("storage", s), {
		...i,
		dispose: () => (e.removeEventListener("pagehide", a), e.removeEventListener("pageshow", o), e.removeEventListener("storage", s), i.dispose())
	};
}
//#endregion
//#region src/core-v3/rules.ts
var f = Object.freeze({
	steady: {
		name: "稳手护符",
		text: "首次裂损保住身价，剑仍会留下裂纹。"
	},
	ember: {
		name: "炉心余烬",
		text: "连锻多一记安全锤。"
	},
	inherit: {
		name: "余温铁夹",
		text: "碎剑峰值的20%传给下轮第一柄，最多增加普通底价的4倍。"
	},
	echo: {
		name: "回响锤纹",
		text: "每第三次普通成功，身价额外增长25%。"
	},
	crackedEdge: {
		name: "裂锋印",
		text: "裂纹剑的大成率增加10个百分点，裂损率不变。"
	},
	pardon: {
		name: "护炉契",
		text: "本局首次失约免扣印记；卸下再装备也不会恢复次数。"
	}
});
Object.keys(f);
//#endregion
//#region src/core-v4/content.ts
var p = Object.freeze([
	"steady",
	"ember",
	"inherit",
	"echo",
	"crackedEdge",
	"pardon"
]), m = Object.freeze([
	"light",
	"guard",
	"heavy"
]), h = Object.freeze([
	"windbox",
	"warmRack",
	"wideMouth"
]), g = Object.freeze([
	"donation",
	"loan",
	"salvage",
	"credit",
	"shelter",
	"rest"
]), _ = e({
	light: {
		name: "轻刃",
		success: 155,
		great: 210,
		greatOdds: 150,
		cracks: [
			80,
			120,
			180,
			260,
			340,
			420,
			500,
			550,
			600
		]
	},
	guard: {
		name: "护刃",
		success: 140,
		great: 195,
		greatOdds: 150,
		cracks: [
			30,
			50,
			80,
			120,
			180,
			240,
			320,
			400,
			480
		]
	},
	heavy: {
		name: "重锋",
		success: 145,
		great: 240,
		greatOdds: 200,
		cracks: [
			60,
			100,
			150,
			220,
			300,
			380,
			460,
			540,
			600
		]
	}
}), v = e({
	windbox: {
		name: "风箱",
		text: "每柄首次普通大成，额外增加10%身价；从下一天起生效。"
	},
	warmRack: {
		name: "余温架",
		text: "唯一留剑跨天增加15%身价，裂纹和锤势原样保留。"
	},
	wideMouth: {
		name: "宽口炉",
		text: "每柄第一次安全连锻多一记，可与炉心余烬叠加。"
	}
}), y = e([
	{
		id: 1,
		title: "第一章 · 灯从炉起",
		days: [1, 4],
		base: 40,
		opening: "山路第一盏灯熄了。阿岚把旧巡剑放到铁砧旁：先让巡夜的人回家。",
		letter: "阿禾捎来第一封信：驿路有人等灯，也有人等一把好剑。",
		success: "渡口亮起第一列灯，巡守与信使终于能在桥头碰面。",
		failure: "渡口还没有完全守住。你带着未完成的委托继续上路，炉火仍在。"
	},
	{
		id: 2,
		title: "第二章 · 风雪同行",
		days: [5, 8],
		base: 80,
		opening: "山路渐陡。留下的旧剑、新学的手艺，都要在风雪里派上用场。",
		letter: "杜伯说，裂纹也能记住炉火。阿禾却要两柄轻剑，分给两条驿路。",
		success: "双驿的灯先后回应，雪中的救援队看见了归路。",
		failure: "双驿仍有一条路未通。已救回的人与遗憾，都记在这本炉谱里。"
	},
	{
		id: 3,
		title: "第三章 · 山口守灯",
		days: [9, 12],
		base: 160,
		opening: "最后一位商人在山口等候。决定带上什么，再锻最后几炉。",
		letter: "阿岚守着缺口，阿禾赶来接力。杜伯等一柄真正能留名的护灯剑。",
		success: "护灯剑送到山口，三人的灯火终于相连。",
		failure: "山口仍有未完成的事。好剑与遗憾会一同陪你归来。"
	}
]), b = e([
	{
		day: 3,
		upgrade: 180,
		repair: 150,
		pool: [
			"steady",
			"ember",
			"echo"
		]
	},
	{
		day: 6,
		upgrade: 700,
		repair: 350,
		pool: [
			"inherit",
			"crackedEdge",
			"pardon"
		]
	},
	{
		day: 9,
		upgrade: 1600,
		repair: 800,
		pool: [
			"steady",
			"ember",
			"inherit",
			"echo",
			"crackedEdge",
			"pardon"
		]
	}
]), x = e({
	donation: {
		name: "护送捐剑",
		request: "巡守愿替你护送下一批铁料，代价是一柄现在能带走的剑。",
		cost: [
			0,
			0,
			0
		],
		piece: "active",
		result: "这柄剑交给护送队。下一天的三个铁坯底价增加20%。"
	},
	loan: {
		name: "借锤",
		request: "杜伯愿借出老锤。付60金币，让明天第一柄前三记普通锤的正收益额多10%。",
		cost: [
			60,
			60,
			60
		],
		piece: "none",
		result: "借锤的钱已记清，明日第一柄会带上这份手感。"
	},
	salvage: {
		name: "旧刃回收",
		request: "行商愿用160金币换走架上的旧剑。交出去，就没有这柄旧剑可作下一轮委托。",
		cost: [
			0,
			0,
			0
		],
		piece: "reserve",
		result: "160金币入袋，旧剑离开剑架，不再兼作交差或保险。"
	},
	credit: {
		name: "商人赊护",
		request: "付清护炉钱，下一次完好剑出现裂纹时保住身价；再次裂损仍会断。",
		cost: [
			90,
			180,
			360
		],
		piece: "none",
		result: "保价资格已备好。下一次首次裂损会消耗，不会恢复断剑。"
	},
	shelter: {
		name: "雨夜修棚",
		request: "花80金币修好炉棚，明天第一柄在当天的裂损率降低3个百分点。",
		cost: [
			80,
			80,
			80
		],
		piece: "none",
		result: "炉棚补好了。明天第一柄能少受一点风雨，之后不再额外生效。"
	},
	rest: {
		name: "守炉",
		request: "今夜不添交易。守着炉火，保留眼前的剑与金币。",
		cost: [
			0,
			0,
			0
		],
		piece: "none",
		result: "没有额外得失，这一炉的选择原样保留。"
	}
}), S = e([
	{
		id: 1,
		title: "巡夜第一灯",
		customer: "guard",
		name: "阿岚",
		request: "巡夜的人要一柄无裂新剑，先点亮归家的第一站。",
		success: "阿岚点亮第一座灯站，巡夜的人看见了家门。",
		failure: "第一站还在等可靠的新剑。",
		scene: "night-watch",
		routes: [{
			id: "intact",
			count: 1,
			value: 100,
			crack: "intact"
		}]
	},
	{
		id: 2,
		title: "重开驿路",
		customer: "courier",
		name: "阿禾",
		request: "四记普通锤内的无裂轻刃，跑山路才轻快。",
		success: "阿禾带轻刃穿过驿路，第一封信准时送达。",
		failure: "驿路还没有等到轻快的剑。",
		scene: "courier-road",
		routes: [{
			id: "light",
			count: 1,
			value: 160,
			recipe: "light",
			crack: "intact",
			maxHits: 4
		}]
	},
	{
		id: 3,
		title: "修炉试锋",
		customer: "smith",
		name: "杜伯",
		request: "让一柄剑经历一次安全连锻，看看这座炉的火候。",
		success: "杜伯听过成品的回响，替你重新接好了炉火。",
		failure: "这次还没有交出连锻的成品。",
		scene: "rekindle",
		routes: [{
			id: "burst",
			count: 1,
			value: 260,
			minBursts: 1
		}]
	},
	{
		id: 4,
		title: "守住渡口",
		customer: "guard",
		name: "阿岚",
		request: "渡口需要一柄无裂护刃，守住来往的人。",
		success: "护刃送上桥头，渡口恢复了巡守。",
		failure: "渡口仍有缺口，阿岚把未竟的事记在纸上。",
		scene: "bridge",
		routes: [{
			id: "guard",
			count: 1,
			value: 360,
			recipe: "guard",
			crack: "intact"
		}]
	},
	{
		id: 5,
		title: "故剑归程",
		customer: "courier",
		name: "阿禾",
		request: "带一柄昨日留下的旧剑；若没有，就用更好的新剑接替。",
		success: "一柄剑接住了前一程的约定，阿禾又能赶路。",
		failure: "这一程的旧剑与新剑都还差一点。",
		scene: "returning-blade",
		routes: [{
			id: "old",
			count: 1,
			value: 420,
			age: "old"
		}, {
			id: "new",
			count: 1,
			value: 630,
			age: "new"
		}]
	},
	{
		id: 6,
		title: "逆火修行",
		customer: "smith",
		name: "杜伯",
		request: "带裂纹也能成器，锻一柄有故事的剑。",
		success: "杜伯接过裂剑：它记得你何时肯收手。",
		failure: "裂纹的手艺还需下一炉。",
		scene: "cracked-work",
		routes: [{
			id: "cracked",
			count: 1,
			value: 520,
			crack: "cracked"
		}]
	},
	{
		id: 7,
		title: "救援重锋",
		customer: "guard",
		name: "阿岚",
		request: "救援队要重锋，劈开山路上的阻碍。",
		success: "重锋开出救援道，山里的灯又亮了一站。",
		failure: "救援道还没有完全打开。",
		scene: "rescue",
		routes: [{
			id: "heavy",
			count: 1,
			value: 760,
			recipe: "heavy"
		}]
	},
	{
		id: 8,
		title: "风雪双驿",
		customer: "courier",
		name: "阿禾",
		request: "两条驿路，两柄各自合格的无裂轻刃。",
		success: "两柄轻刃分赴双驿，雪中的灯彼此回应。",
		failure: "双驿尚未全部接通，不能把一柄剑算作两柄。",
		scene: "twin-stations",
		routes: [{
			id: "two-light",
			count: 2,
			value: 420,
			recipe: "light",
			crack: "intact"
		}]
	},
	{
		id: 9,
		title: "炉火回响",
		customer: "smith",
		name: "杜伯",
		request: "让一柄剑经历两次安全连锻，再听一次炉火回响。",
		success: "两次连锻的锻纹交在一起，杜伯记下了这门手艺。",
		failure: "两次炉火的成品还未交出。",
		scene: "double-fire",
		routes: [{
			id: "two-bursts",
			count: 1,
			value: 1e3,
			minBursts: 2
		}]
	},
	{
		id: 10,
		title: "缺口之剑",
		customer: "guard",
		name: "阿岚",
		request: "带裂护刃也可守缺口，或用更高身价的完好护刃。",
		success: "阿岚把护刃举在缺口前，身后的人继续前行。",
		failure: "缺口尚未补上，这次的风险与收手都留在记录中。",
		scene: "mountain-gap",
		routes: [{
			id: "cracked",
			count: 1,
			value: 1150,
			recipe: "guard",
			crack: "cracked"
		}, {
			id: "intact",
			count: 1,
			value: 1800,
			recipe: "guard",
			crack: "intact"
		}]
	},
	{
		id: 11,
		title: "最后的接力",
		customer: "courier",
		name: "阿禾",
		request: "一柄同行的旧剑，或两柄新剑，接完最后一程。",
		success: "阿禾把剑交到接力的人手里，山口已在眼前。",
		failure: "接力还缺最后的一柄，归程也会记住这件事。",
		scene: "relay",
		routes: [{
			id: "old",
			count: 1,
			value: 1300,
			age: "old"
		}, {
			id: "two-new",
			count: 2,
			value: 850,
			age: "new"
		}]
	},
	{
		id: 12,
		title: "山口护灯",
		customer: "smith",
		name: "杜伯",
		request: "无裂名器重锋，送到山口，护住最后的灯。",
		success: "护灯剑送到山口，三人抬头看见了相连的灯火。",
		failure: "护灯剑还没有完成，不能说十二灯已经复明。",
		scene: "last-lantern",
		routes: [{
			id: "finale",
			count: 1,
			value: 2500,
			recipe: "heavy",
			crack: "intact",
			minLevel: 9
		}]
	}
]), C = e({
	victory: {
		title: "十二灯复明",
		text: "关键的剑都送到了，十二站的灯在归路上依次亮起。"
	},
	return: {
		title: "灯下归途",
		text: "炉火还在，有些约定仍未完成。带着这次的作品与手艺再上路。"
	},
	defeat: {
		title: "炉火暂熄",
		text: "契约印记用尽了。已经做成的作品与学会的炉谱会留下。"
	}
}), w = 1e9, T = 1900, E = (e) => e <= 4 ? 1 : e <= 8 ? 2 : 3, D = (e) => Math.floor(e.base / 4), O = (e) => e.value >= 1e9 || e.level >= 99, k = (e, t) => Math.min(w, Math.floor(e * t / 100));
function ee(e) {
	let t = E(e.day);
	return t === 1 ? {
		baseFee: 100,
		budget: 60
	} : t === 2 ? {
		baseFee: 250,
		budget: 150
	} : {
		baseFee: 600,
		budget: 300
	};
}
var A = (e) => Math.max(0, ee(e).budget - e.marketSpent);
function te(e, t) {
	let n = 0, r = 1;
	for (let t of e.routes) {
		let e = Math.min(t.count, t.required);
		e * r > n * t.required && (n = e, r = t.required);
	}
	return Math.floor(t * n / r);
}
function ne(e, t, n) {
	return Math.floor(y[E(t) - 1].base * 3 ** e.upgradeCount / 2 ** e.upgradeCount * n / 100);
}
function j(e) {
	return S[e.commissionOrder[e.day - 1] - 1];
}
function re(e) {
	let t = new Set(e.initialEligibility.recipes);
	e.history.some((e) => e.day === 4 && e.sealsAfter > 0) && t.add("guard"), e.history.some((e) => e.day === 8 && e.sealsAfter > 0) && t.add("heavy");
	for (let n of j(e).routes) n.recipe && t.add(n.recipe);
	return [
		"light",
		"guard",
		"heavy"
	].filter((e) => t.has(e));
}
function M(e) {
	return j(e).routes.find((e) => e.recipe)?.recipe || (re(e).includes("guard") ? "guard" : "light");
}
function ie(e, t) {
	let n = _[t.recipe], r = e.dayBuffs.shelter && t.suppliedDay === e.day && t.slot === 1, i = Math.max(0, (t.hits < 3 ? 0 : n.cracks[Math.min(t.hits - 3, 8)]) - (r ? 30 : 0)), a = t.charge === 6, o = a ? 350 : n.greatOdds + (t.cracked && e.traits.includes("crackedEdge") ? 100 : 0);
	return {
		burst: a,
		crack: a ? 0 : i,
		great: o,
		success: 1e3 - o - (a ? 0 : i),
		afterBurstCrack: i
	};
}
function N(e, t, n) {
	let r = [];
	return n.recipe && t.recipe !== n.recipe && r.push(`需要${_[n.recipe].name}`), n.crack === "intact" && t.cracked && r.push("需要无裂纹"), n.crack === "cracked" && !t.cracked && r.push("需要带裂纹"), n.age === "old" && t.suppliedDay >= e.day && r.push("需要此前留下的旧剑"), n.age === "new" && t.suppliedDay !== e.day && r.push("需要本日新剑"), n.maxHits !== void 0 && t.hits > n.maxHits && r.push(`普通锤不得超过${n.maxHits}次`), n.minLevel !== void 0 && t.level < n.minLevel && r.push(`需要等级${n.minLevel}`), n.minBursts !== void 0 && t.bursts < n.minBursts && r.push(`需要${n.minBursts}次连锻`), t.value < n.value && r.push(`还差${n.value - t.value}身价`), {
		matches: r.length === 0,
		missing: r
	};
}
function ae(e) {
	let t = j(e), n = e.blades.filter((n) => n.status === "commissioned" && n.commissionId === t.id && n.finalizedDay === e.day), r = new Map(e.journal.flatMap((e, t) => e.type === "deliver" ? [[e.pieceId, t]] : []));
	n.sort((e, t) => (r.get(e.id) ?? 2 ** 53 - 1) - (r.get(t.id) ?? 2 ** 53 - 1));
	let i = t.routes.map((t) => {
		let r = n.filter((n) => N(e, n, t).matches).map((e) => e.id);
		return {
			id: t.id,
			required: t.count,
			count: r.length,
			pieceIds: r,
			complete: r.length >= t.count
		};
	}), a = i.find((e) => e.complete);
	return {
		commissionId: t.id,
		complete: !!a,
		routeId: a?.id ?? null,
		pieceIds: a?.pieceIds.slice(0, a.required) ?? [],
		routes: i
	};
}
function oe(e, t) {
	let n = j(e).routes.map((n) => ({
		id: n.id,
		...N(e, t, n)
	}));
	return {
		canDeliver: e.phase === "workshop" && t.status === "active" && t.id !== e.reserveId,
		qualifies: n.some((e) => e.matches),
		routes: n
	};
}
function se(e, t) {
	let n = j(e), r = ae(e), i = oe(e, t), a = !r.complete && i.qualifies, o = i.routes.filter((e) => e.matches).map((e) => e.id), s = n.routes.filter((e) => o.includes(e.id)).map((e) => e.value), c = s.length ? Math.min(...s) : null, { baseFee: l } = ee(e), u = A(e), d = { routes: r.routes.map((e) => ({
		...e,
		count: e.count + +!!o.includes(e.id)
	})) }, f = a ? te(d, l) - te(r, l) : 0, p = a && c !== null ? Math.min(Math.floor(Math.max(0, t.value - c) / 5), u) : 0, m = Math.min(Math.floor(t.value / 4), u), h = a ? f + p : m, g = a ? p : m, _ = null;
	return e.phase === "workshop" ? e.journal.length >= 2048 ? _ = "record_limit" : t.status === "active" ? t.id === e.reserveId ? _ = "reserved_piece" : !a && m === 0 && (_ = "market_exhausted") : _ = "piece_unavailable" : _ = "wrong_phase", {
		pieceValue: t.value,
		matched: a,
		matchedRouteIds: o,
		threshold: c,
		baseFeeDelta: f,
		qualityBonus: p,
		saleQuote: m,
		amount: h,
		marketCost: g,
		allowed: _ === null,
		error: _
	};
}
var ce = (e, t) => Math.min(D(t), A(e));
function P(e, t) {
	let n = null;
	return e.phase === "workshop" ? e.journal.length >= 1900 ? n = "record_limit" : t.status === "active" ? t.id === e.reserveId ? n = "reserved_piece" : t.level < 3 && (n = "blade_unworked") : n = "piece_unavailable" : n = "wrong_phase", {
		allowed: n === null,
		error: n
	};
}
function le(e) {
	let t = e.blades.filter((t) => t.status === "active" && t.id !== e.reserveId), n = ae(e), r = A(e), i = t.map((e) => {
		let t = Math.min(D(e), r);
		return r -= t, {
			pieceId: e.id,
			amount: t
		};
	}), a = !n.complete && e.traits.includes("pardon") && !e.pardonUsed;
	return {
		...n,
		remaining: t,
		recoveries: i,
		recovered: i.reduce((e, t) => e + t.amount, 0),
		protected: a,
		sealsAfter: e.seals - (n.complete || a ? 0 : 1)
	};
}
var ue = (e) => b.find((t) => t.day === e.day) ?? null, de = (e) => e.phase === "workshop" && ue(e) !== null;
function fe(e, t) {
	let n = e.eventId ? x[e.eventId] : null, r = n?.cost[E(e.day) - 1] ?? 0, i = null;
	if (e.phase !== "workshop" || e.eventStatus !== "available" || !n) i = "unavailable";
	else if (e.coins < r) i = "insufficient_coins";
	else if (e.eventId === "credit" && e.crackGuard) i = "already_owned";
	else if (n.piece !== "none") {
		let r = e.blades.find((e) => e.id === t);
		(!r || r.status !== "active" || (n.piece === "reserve" ? e.reserveId !== r.id : e.reserveId === r.id)) && (i = "piece_unavailable");
	} else t !== void 0 && (i = "invalid_command");
	return {
		eventId: e.eventId,
		cost: r,
		requiresPiece: n?.piece ?? "none",
		allowed: i === null,
		error: i
	};
}
//#endregion
//#region src/core-v5/game.ts
var pe = (e) => structuredClone(e), F = (e, t) => ({
	ok: !1,
	state: e,
	error: t,
	events: []
}), me = () => ({
	supplyPct: 100,
	loan: !1,
	shelter: !1
}), he = (e, t) => typeof e == "string" && t.some((t) => t === e), ge = (e, t) => Object.keys(e).sort().join(",") === [...t].sort().join(",");
function _e(e, t, n) {
	let i = r(e.rng[t]);
	return e.rng[t] = i.stream, Math.floor(i.value * n);
}
function ve(e, t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = _e(e, t, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function ye(e) {
	e.supplyBase = ne(e, e.day, e.dayBuffs.supplyPct);
	let t = Math.min(e.supplyBase * 4, e.inheritance), n = M(e);
	e.inheritance = 0;
	let r = e.blades.some((t) => t.id === e.reserveId && t.status === "active") ? 2 : 3;
	e.marketSpent = 0;
	for (let i = 1; i <= r; i++) {
		let r = e.supplyBase + (i === 1 ? t : 0);
		e.blades.push({
			id: `d${e.day}-${i}`,
			slot: i,
			suppliedDay: e.day,
			recipe: n,
			status: "active",
			base: r,
			value: r,
			peak: r,
			level: 0,
			cracked: !1,
			hits: 0,
			charge: 0,
			successes: 0,
			normalGreats: 0,
			bursts: 0,
			finalizedDay: null,
			commissionId: null
		});
	}
	e.shop = [], e.sold = [], e.upgraded = !1, e.repaired = !1;
	let i = b.find((t) => t.day === e.day);
	if (i) {
		let t = i.pool.filter((t) => !e.traits.includes(t));
		for (; t.length && e.shop.length < 2;) e.shop.push(t.splice(_e(e, "shop", t.length), 1)[0]);
	}
	let a = [
		3,
		5,
		7,
		9,
		11
	].indexOf(e.day);
	e.eventId = a < 0 ? null : e.eventDeck[a], e.eventStatus = e.eventId ? "available" : "none";
}
function be(r) {
	let a = i(r);
	if (!a) return {
		ok: !1,
		error: "invalid_command"
	};
	let o = JSON.parse(a);
	if (!t(o)) return {
		ok: !1,
		error: "invalid_command"
	};
	if (typeof o.runId != "string" || !/^[A-Za-z0-9_-]{1,80}$/.test(o.runId)) return {
		ok: !1,
		error: "invalid_run_id"
	};
	if (typeof o.seed != "string") return {
		ok: !1,
		error: "invalid_seed"
	};
	let s = o.seed.normalize("NFC").trim();
	if (!s || Array.from(s).length > 64) return {
		ok: !1,
		error: "invalid_seed"
	};
	if (o.mode !== void 0 && o.mode !== "story" && o.mode !== "challenge" || !ge(o, [
		"runId",
		"seed",
		...o.mode === void 0 ? [] : ["mode"],
		...o.eligibility === void 0 ? [] : ["eligibility"]
	])) return {
		ok: !1,
		error: "invalid_command"
	};
	let c = {
		recipes: ["light"],
		challenge: !1
	};
	if (o.eligibility !== void 0) {
		let e = o.eligibility;
		if (!t(e) || !ge(e, ["recipes", "challenge"]) || !Array.isArray(e.recipes) || e.recipes.length > 3 || !e.recipes.every((e) => he(e, m)) || typeof e.challenge != "boolean") return {
			ok: !1,
			error: "invalid_command"
		};
		let n = e.recipes;
		c = {
			recipes: m.filter((t) => t === "light" || e.challenge || n.includes(t)),
			challenge: e.challenge
		};
	}
	if (o.mode === "challenge" && !c.challenge) return {
		ok: !1,
		error: "challenge_locked"
	};
	let l = (e) => ({
		state: n(`${s}|v5|${e}`),
		draws: 0
	}), u = {
		rulesVersion: "forge-v5",
		runId: o.runId,
		seed: s,
		mode: o.mode ?? "story",
		initialEligibility: pe(c),
		revision: 0,
		phase: "opening",
		day: 1,
		commissionOrder: Array.from({ length: 12 }, (e, t) => t + 1),
		coins: 0,
		seals: 3,
		supplyBase: 40,
		upgradeCount: 0,
		inheritance: 0,
		blades: [],
		reserveId: null,
		daySales: 0,
		dayRecovered: 0,
		marketSpent: 0,
		traits: [],
		gift: "locked",
		pardonUsed: !1,
		crackGuard: !1,
		modifications: [],
		chapterChoices: [],
		shop: [],
		sold: [],
		upgraded: !1,
		repaired: !1,
		dayBuffs: pe(me()),
		pending: pe(me()),
		eventDeck: [],
		eventId: null,
		eventStatus: "none",
		eventHistory: [],
		history: [],
		rng: {
			forge: l("forge"),
			shop: l("shop"),
			events: l("events"),
			content: l("content")
		},
		journal: []
	};
	if (u.eventDeck = ve(u, "events", g), u.mode === "challenge") for (let e of [[
		5,
		6,
		7
	], [
		9,
		10,
		11
	]]) {
		let t = ve(u, "content", e);
		for (let n = 0; n < e.length; n++) u.commissionOrder[e[n] - 1] = t[n];
	}
	return ye(u), e({
		ok: !0,
		state: u
	});
}
function xe(e) {
	if (!t(e)) return null;
	let n = typeof e.pieceId == "string" && e.pieceId.length <= 32;
	switch (e.type) {
		case "continue":
		case "upgrade":
		case "repair":
		case "settle":
		case "advance": return ge(e, ["type"]) ? { type: e.type } : null;
		case "strike":
		case "deliver":
		case "scrap":
		case "reserve": return n && ge(e, ["type", "pieceId"]) ? {
			type: e.type,
			pieceId: e.pieceId
		} : null;
		case "setRecipe": return n && he(e.recipe, m) && ge(e, [
			"type",
			"pieceId",
			"recipe"
		]) ? {
			type: e.type,
			pieceId: e.pieceId,
			recipe: e.recipe
		} : null;
		case "chooseModification": return he(e.modification, h) && ge(e, ["type", "modification"]) ? {
			type: e.type,
			modification: e.modification
		} : null;
		case "chooseEvent": return (e.choice === "accept" || e.choice === "decline") && (e.pieceId === void 0 || n) && ge(e, [
			"type",
			"choice",
			...e.pieceId === void 0 ? [] : ["pieceId"]
		]) ? {
			type: e.type,
			choice: e.choice,
			...e.pieceId === void 0 ? {} : { pieceId: e.pieceId }
		} : null;
		case "buy":
		case "claimGift": return e.type === "buy" && !n || !he(e.traitId, p) && (e.type !== "claimGift" || e.traitId !== null) || e.replaceId !== void 0 && !he(e.replaceId, p) || !ge(e, [
			"type",
			"traitId",
			...e.type === "buy" ? ["pieceId"] : [],
			...e.replaceId === void 0 ? [] : ["replaceId"]
		]) ? null : e;
		default: return null;
	}
}
function Se(e, t, n) {
	if (e.traits.includes(t)) return "already_owned";
	if (e.traits.length === 3) {
		if (!n || !e.traits.includes(n)) return "invalid_replacement";
		e.traits.splice(e.traits.indexOf(n), 1);
	} else if (n !== void 0) return "invalid_replacement";
	return e.traits.push(t), null;
}
function Ce(e, t, n) {
	let r = ie(e, t), i = _e(e, "forge", 1e3), a = t.value, o = [], s = 0, c = i < (n ? 350 : r.great) ? "great" : !n && i < r.great + r.crack ? "crack" : "success";
	if (n || t.hits++, !n && e.dayBuffs.shelter && t.slot === 1 && t.suppliedDay === e.day && o.push("shelter"), c === "crack") {
		if (t.cracked) {
			c = "broken", t.value = 0, t.status = "broken", t.finalizedDay = e.day;
			let n = ce(e, t);
			e.coins += n, e.dayRecovered += n, e.marketSpent += n, s = n, e.traits.includes("inherit") && (e.inheritance += Math.floor(t.peak / 5), o.push("inherit"));
		} else {
			t.cracked = !0;
			let n = e.traits.includes("steady"), r = e.crackGuard;
			n && o.push("steady"), r && (o.push("credit"), e.crackGuard = !1), !n && !r && (t.value = k(t.value, 80));
		}
	} else {
		let r = _[t.recipe];
		t.value = k(t.value, c === "great" ? r.great : r.success), t.level = Math.min(99, t.level + (c === "great" ? 2 : 1)), n || (c === "great" && (t.normalGreats === 0 && e.modifications.includes("windbox") && (t.value = k(t.value, 110), o.push("windbox")), t.normalGreats++), t.successes++, e.traits.includes("echo") && t.successes % 3 == 0 && (t.value = k(t.value, 125), o.push("echo")), e.dayBuffs.loan && t.suppliedDay === e.day && t.slot === 1 && t.hits <= 3 && (t.value = Math.min(w, t.value + Math.floor((t.value - a) * 10 / 100)), o.push("loan")), t.cracked && c === "great" && e.traits.includes("crackedEdge") && o.push("crackedEdge"));
	}
	return t.peak = Math.max(t.peak, t.value), !n && t.status === "active" && (t.charge = Math.min(6, t.charge + 1)), {
		result: c,
		before: a,
		after: t.value,
		level: t.level,
		triggers: o,
		recoveryAmount: s
	};
}
function we(e, t, n, r) {
	let i = e.eventId, a = 0;
	if (t === "accept") {
		let t = fe(e, n);
		switch (a = t.cost === 0 ? 0 : -t.cost, e.coins -= t.cost, i) {
			case "donation": {
				let t = e.blades.find((e) => e.id === n);
				t.status = "donated", t.finalizedDay = e.day, e.pending.supplyPct = 120;
				break;
			}
			case "loan":
				e.pending.loan = !0;
				break;
			case "salvage": {
				let t = e.blades.find((e) => e.id === n);
				t.status = "bartered", t.finalizedDay = e.day, e.reserveId = null, e.coins += 160, a += 160;
				break;
			}
			case "credit":
				e.crackGuard = !0;
				break;
			case "shelter": e.pending.shelter = !0;
		}
	}
	let o = {
		day: e.day,
		id: i,
		choice: t,
		pieceId: n ?? null,
		coins: a
	};
	e.eventHistory.push(pe(o)), e.eventStatus = t === "accept" ? "accepted" : "declined", r.push({
		type: "EventChoice",
		record: o
	});
}
function I(n, r) {
	if (n.rulesVersion !== "forge-v5") return F(n, "wrong_rules");
	let a = i(r);
	if (!a) return F(n, "invalid_command");
	let o = JSON.parse(a);
	if (!t(o) || !ge(o, [
		"runId",
		"expectedRevision",
		"action"
	])) return F(n, "invalid_command");
	if (o.runId !== n.runId) return F(n, "wrong_run");
	if (o.expectedRevision !== n.revision) return F(n, "stale_revision");
	let s = xe(o.action);
	if (!s) return F(n, "invalid_command");
	let c = s.type === "continue" ? "opening" : s.type === "chooseModification" ? "chapter" : s.type === "advance" ? "summary" : "workshop";
	if (n.phase !== c) return F(n, "wrong_phase");
	if (n.journal.length >= 2048 || n.journal.length >= 1900 && ([
		"strike",
		"setRecipe",
		"buy",
		"claimGift",
		"upgrade",
		"repair"
	].includes(s.type) || s.type === "reserve" && n.reserveId !== s.pieceId || s.type === "chooseEvent" && s.choice === "accept")) return F(n, "record_limit");
	let l = {
		...pe({
			...n,
			journal: []
		}),
		journal: [...n.journal]
	}, u = [], d = "pieceId" in s ? l.blades.find((e) => e.id === s.pieceId) : void 0;
	if ("pieceId" in s && s.type !== "chooseEvent" && (!d || d.status !== "active")) return F(n, "piece_unavailable");
	if ("pieceId" in s && s.type !== "chooseEvent" && s.type !== "reserve" && l.reserveId === s.pieceId) return F(n, "reserved_piece");
	switch (s.type) {
		case "continue":
			l.phase = "workshop", u.push({ type: "Opened" });
			break;
		case "setRecipe":
			if (!d) return F(n, "piece_unavailable");
			if (d.hits > 0) return F(n, "recipe_locked");
			if (!re(l).includes(s.recipe)) return F(n, "recipe_unavailable");
			if (d.recipe === s.recipe) return F(n, "unavailable");
			d.recipe = s.recipe, u.push({
				type: "Recipe",
				pieceId: d.id,
				recipe: d.recipe
			});
			break;
		case "strike": {
			if (!d) return F(n, "piece_unavailable");
			if (O(d)) return F(n, "at_cap");
			let e = d.charge === 6, t = [];
			if (e) {
				let e = d.bursts === 0 && l.modifications.includes("wideMouth"), n = l.traits.includes("ember"), r = 2 + Number(e) + Number(n);
				d.charge = 0, d.bursts++;
				for (let i = 0; i < r && !O(d); i++) {
					let r = Ce(l, d, !0);
					t.push({
						...r,
						triggers: [
							...r.triggers,
							...e ? ["wideMouth"] : [],
							...n ? ["ember"] : []
						]
					});
				}
			} else t.push(Ce(l, d, !1));
			u.push({
				type: "Strike",
				pieceId: d.id,
				burst: e,
				hits: t
			});
			break;
		}
		case "deliver": {
			if (!d) return F(n, "piece_unavailable");
			let e = ae(l), t = se(l, d);
			if (!t.allowed) return F(n, t.error);
			let r = t.matched;
			d.status = r ? "commissioned" : "sold", d.finalizedDay = l.day, d.commissionId = r ? j(l).id : null, l.coins += t.amount, l.daySales += t.amount, l.marketSpent += t.marketCost, u.push({
				type: "Delivered",
				pieceId: d.id,
				amount: t.amount,
				matched: r,
				commissionId: j(l).id,
				pieceValue: d.value,
				baseFeeDelta: t.baseFeeDelta,
				qualityBonus: t.qualityBonus,
				marketRemaining: A(l)
			});
			let i = ae(l);
			!e.complete && i.complete && (u.push({
				type: "MainCompleted",
				commissionId: i.commissionId,
				routeId: i.routeId,
				pieceIds: i.pieceIds
			}), l.gift === "locked" && (l.gift = "available", u.push({ type: "GiftAvailable" })));
			break;
		}
		case "scrap": {
			if (!d) return F(n, "piece_unavailable");
			let e = ce(l, d);
			d.status = "recycled", d.finalizedDay = l.day, l.coins += e, l.dayRecovered += e, l.marketSpent += e, u.push({
				type: "Disposed",
				pieceId: d.id,
				disposition: d.status,
				amount: e,
				marketRemaining: A(l)
			});
			break;
		}
		case "reserve":
			if (!d) return F(n, "piece_unavailable");
			{
				let e = l.reserveId;
				l.reserveId = e === d.id ? null : d.id, u.push({
					type: "Reserved",
					pieceId: d.id,
					previousId: e
				});
			}
			break;
		case "claimGift": {
			if (l.gift !== "available") return F(n, "unavailable");
			let e = 0, t = ["steady", "ember"].filter((e) => !l.traits.includes(e));
			if (t.length) {
				if (s.traitId === null || !t.some((e) => e === s.traitId)) return F(n, "unavailable");
				let e = Se(l, s.traitId, s.replaceId);
				if (e) return F(n, e);
			} else {
				if (s.traitId !== null || s.replaceId !== void 0) return F(n, "unavailable");
				l.coins += 40, e = 40;
			}
			l.gift = "claimed", u.push({
				type: "Trait",
				traitId: s.traitId,
				compensation: e
			});
			break;
		}
		case "buy":
			if (!de(l)) return F(n, "no_shop");
			if (!l.shop.includes(s.traitId) || l.sold.includes(s.traitId)) return F(n, "sold_out");
			if (!d) return F(n, "piece_unavailable");
			{
				let e = P(l, d);
				if (!e.allowed) return F(n, e.error);
			}
			{
				let e = Se(l, s.traitId, s.replaceId);
				if (e) return F(n, e);
			}
			d.status = "traded", d.finalizedDay = l.day, l.sold.push(s.traitId), u.push({
				type: "Disposed",
				pieceId: d.id,
				disposition: d.status,
				amount: 0,
				marketRemaining: A(l)
			}, {
				type: "Trait",
				traitId: s.traitId,
				compensation: 0
			});
			break;
		case "upgrade":
		case "repair": {
			let e = ue(l);
			if (!de(l) || !e) return F(n, "no_shop");
			if (s.type === "upgrade" ? l.upgraded : l.repaired || l.seals === 3) return F(n, "unavailable");
			let t = s.type === "upgrade" ? e.upgrade : e.repair;
			if (l.coins < t) return F(n, "insufficient_coins");
			l.coins -= t, s.type === "upgrade" ? (l.upgradeCount++, l.upgraded = !0, u.push({ type: "Upgraded" })) : (l.seals++, l.repaired = !0, u.push({ type: "Repaired" }));
			break;
		}
		case "chooseEvent":
			if (l.eventStatus !== "available" || l.eventId === null) return F(n, "unavailable");
			if (s.choice === "decline" && s.pieceId !== void 0) return F(n, "invalid_command");
			if (s.choice === "accept") {
				let e = fe(l, s.pieceId);
				if (e.error) return F(n, e.error);
			}
			we(l, s.choice, s.pieceId, u);
			break;
		case "settle": {
			l.eventStatus === "available" && we(l, "decline", void 0, u);
			let e = le(l), t = {
				day: l.day,
				commissionId: j(l).id,
				met: e.complete,
				routeId: e.routeId,
				pieceIds: e.pieceIds,
				sales: l.daySales,
				recovered: l.dayRecovered + e.recovered,
				baseFees: te(e, ee(l).baseFee),
				marketSpent: l.marketSpent + e.recovered,
				recoveredIds: e.remaining.map((e) => e.id),
				reserveId: l.reserveId,
				sealsBefore: l.seals,
				sealsAfter: e.sealsAfter,
				protected: e.protected,
				modification: null
			};
			for (let e of l.blades) t.recoveredIds.includes(e.id) && (e.status = "recycled", e.finalizedDay = l.day);
			l.coins += e.recovered, l.dayRecovered += e.recovered, l.marketSpent += e.recovered, l.seals = e.sealsAfter, e.protected && (l.pardonUsed = !0), l.history.push(t), l.phase = l.seals === 0 ? "defeat" : l.day === 12 ? l.history.filter((e) => e.met).length >= 10 && [
				4,
				8,
				12
			].every((e) => l.history.some((t) => t.day === e && t.met)) ? "victory" : "return" : l.day === 4 || l.day === 8 ? "chapter" : "summary", l.phase === "chapter" && (l.chapterChoices = l.day === 4 ? ["windbox", "warmRack"] : h.filter((e) => !l.modifications.includes(e))), u.push({
				type: "Settled",
				record: t
			});
			break;
		}
		case "chooseModification":
			if (!l.chapterChoices.includes(s.modification) || l.modifications.includes(s.modification)) return F(n, "unavailable");
			l.modifications.push(s.modification), l.history.at(-1).modification = s.modification, l.chapterChoices = [], l.phase = "summary", u.push({
				type: "Modification",
				modification: s.modification
			});
			break;
		case "advance": {
			let e = l.blades.find((e) => e.id === l.reserveId);
			e && l.modifications.includes("warmRack") && (e.value = k(e.value, 115), e.peak = Math.max(e.peak, e.value)), l.day++, l.phase = "workshop", l.daySales = 0, l.dayRecovered = 0, l.dayBuffs = pe(l.pending), l.pending = pe(me()), ye(l), u.push({ type: "Advanced" });
			break;
		}
	}
	return l.revision++, l.journal.push(s), e({
		ok: !0,
		state: l,
		events: u
	});
}
//#endregion
//#region src/core-v5/validate.ts
function Te(e) {
	let n = i(e);
	if (!n) return {
		ok: !1,
		error: "invalid_state",
		detail: "Expected bounded plain JSON with safe integer fields."
	};
	let r = JSON.parse(n);
	if (!t(r) || r.rulesVersion !== "forge-v5") return {
		ok: !1,
		error: "invalid_rules_version",
		detail: "Expected forge-v5."
	};
	if (typeof r.runId != "string" || typeof r.seed != "string" || !Array.isArray(r.journal) || r.journal.length > 2048) return {
		ok: !1,
		error: "invalid_state",
		detail: "Missing identity or bounded Accepted journal."
	};
	let a = be({
		runId: r.runId,
		seed: r.seed,
		mode: r.mode,
		eligibility: r.initialEligibility
	});
	if (!a.ok) return {
		ok: !1,
		error: "invalid_state",
		detail: a.error
	};
	let o = a.state;
	for (let [e, t] of r.journal.entries()) {
		let n = I(o, {
			runId: o.runId,
			expectedRevision: o.revision,
			action: t
		});
		if (!n.ok) return {
			ok: !1,
			error: "invalid_journal",
			detail: `Command ${e}: ${n.error}`
		};
		o = n.state;
	}
	return i(o) === n ? {
		ok: !0,
		state: o
	} : {
		ok: !1,
		error: "invalid_state",
		detail: "Snapshot differs from full deterministic replay."
	};
}
//#endregion
//#region src/core-v5/view.ts
var Ee = (e) => ({
	...e,
	request: e.request.replaceAll("昨日", "此前")
});
function L(e) {
	return [
		e.count > 1 ? `${e.count}柄各自合格` : "一柄",
		...e.recipe ? [_[e.recipe].name] : [],
		...e.crack ? [e.crack === "intact" ? "无裂纹" : "带裂纹"] : [],
		...e.age ? [e.age === "old" ? "此前留剑" : "本日新剑"] : [],
		...e.maxHits === void 0 ? [] : [`普通锤≤${e.maxHits}`],
		...e.minLevel === void 0 ? [] : [`等级≥${e.minLevel}`],
		...e.minBursts === void 0 ? [] : [`连锻≥${e.minBursts}次`],
		`身价≥${e.value}`
	].join(" · ");
}
function R(t) {
	let n = t.history.filter((e) => [
		4,
		8,
		12
	].includes(e.day) && e.sealsAfter > 0).map((e) => E(e.day)), r = ["light"];
	n.includes(1) && r.push("guard"), n.includes(2) && r.push("heavy");
	let i = t.history.filter((e) => e.met).map((e) => ({
		commissionId: e.commissionId,
		day: e.day,
		routeId: e.routeId,
		blades: e.pieceIds.map((e) => t.blades.find((t) => t.id === e)),
		runId: t.runId
	})), a = m.filter((e) => i.some((t) => t.blades.some((t) => t.recipe === e && t.level >= 9))), o = [...new Set(t.journal.flatMap((e) => (e.type === "buy" || e.type === "claimGift") && e.traitId ? [e.traitId] : []))];
	return e({
		chapters: n,
		recipes: r,
		challenge: t.phase === "victory",
		mastery: a,
		traits: o,
		works: i
	});
}
function z(t) {
	let n = Ee(j(t)), r = ae(t), i = t.phase === "workshop", a = t.journal.length < T, o = ue(t), s = ee(t), c = t.blades.find((e) => e.id === t.reserveId && e.status === "active"), l = t.day < 12 ? Ee(S[t.commissionOrder[t.day] - 1]) : null, u = c && l ? (() => {
		let e = t.modifications.includes("warmRack") ? k(c.value, 115) : c.value, n = {
			...c,
			value: e,
			peak: Math.max(c.peak, e)
		}, r = l.routes.map((e) => ({
			id: e.id,
			...N({ day: t.day + 1 }, n, e)
		}));
		return {
			...n,
			recipeName: _[n.recipe].name,
			assessment: {
				qualifies: r.some((e) => e.matches),
				routes: r
			}
		};
	})() : null, d = l ? {
		day: t.day + 1,
		commission: l,
		normalBase: ne(t, t.day + 1, t.pending.supplyPct),
		merchant: b.some((e) => e.day === t.day + 1),
		reserve: u,
		newCount: u ? 2 : 3,
		oldCount: +!!u,
		totalCount: 3
	} : null, p = d ? {
		...d,
		inheritanceBonus: Math.min(d.normalBase * 4, t.inheritance),
		firstBase: d.normalBase + Math.min(d.normalBase * 4, t.inheritance)
	} : null, m = [
		4,
		8,
		12
	].filter((e) => !t.history.some((t) => t.day === e && t.met)), h = t.eventId ? {
		id: t.eventId,
		...x[t.eventId],
		status: t.eventStatus,
		quote: fe(t),
		canDecline: i && t.eventStatus === "available"
	} : null;
	return e({
		rulesVersion: t.rulesVersion,
		revision: t.revision,
		phase: t.phase,
		day: t.day,
		chapter: y[E(t.day) - 1],
		mode: t.mode,
		coins: t.coins,
		seals: t.seals,
		commission: {
			...n,
			progress: r,
			routes: n.routes.map((e) => ({
				...e,
				description: L(e)
			})),
			outcome: r.complete ? n.success : n.failure
		},
		market: {
			...s,
			spent: t.marketSpent,
			remaining: A(t),
			baseFeesPaid: te(r, s.baseFee)
		},
		recipes: re(t).map((e) => ({
			id: e,
			..._[e]
		})),
		recommendedRecipe: M(t),
		blades: t.blades.filter((e) => e.status === "active").map((e) => {
			let n = se(t, e), r = oe(t, e);
			return {
				blade: e,
				reserved: e.id === t.reserveId,
				assessment: {
					...r,
					canDeliver: n.allowed
				},
				quote: n,
				odds: ie(t, e),
				recovery: ce(t, e),
				barter: P(t, e),
				willCommission: n.matched,
				canStrike: i && a && e.id !== t.reserveId && !O(e),
				canChangeRecipe: i && a && e.id !== t.reserveId && e.hits === 0
			};
		}),
		traits: t.traits.map((e) => ({
			id: e,
			...f[e],
			used: e === "pardon" && t.pardonUsed
		})),
		modifications: t.modifications.map((e) => ({
			id: e,
			...v[e]
		})),
		chapterChoices: t.chapterChoices.map((e) => ({
			id: e,
			...v[e]
		})),
		growth: {
			supplyBase: t.supplyBase,
			upgradeCount: t.upgradeCount,
			inheritance: t.inheritance,
			crackGuard: t.crackGuard,
			dayBuffs: t.dayBuffs,
			pending: t.pending
		},
		event: h && h.id === "donation" ? {
			...h,
			result: "明天实际发出的新坯底价增加20%：留剑时两柄，否则三柄。"
		} : h,
		merchant: de(t) && o ? {
			...o,
			offers: t.shop.map((e) => ({
				id: e,
				...f[e],
				sold: t.sold.includes(e),
				owned: t.traits.includes(e)
			})),
			canUpgrade: a && !t.upgraded && t.coins >= o.upgrade,
			canRepair: a && !t.repaired && t.seals < 3 && t.coins >= o.repair
		} : null,
		gift: {
			status: t.gift,
			canClaim: i && a && t.gift === "available"
		},
		next: p,
		settlement: le(t),
		canContinue: t.phase === "opening",
		canSettle: i,
		canAdvance: t.phase === "summary",
		ending: t.phase === "victory" || t.phase === "return" || t.phase === "defeat" ? {
			...C[t.phase],
			missingCritical: m,
			completed: t.history.filter((e) => e.met).length,
			finalBladeMade: t.history.some((e) => e.day === 12 && e.met)
		} : null,
		history: t.history,
		eventHistory: t.eventHistory,
		collection: R(t)
	});
}
//#endregion
//#region src/core-v4/rules.ts
var De = 1e9, Oe = (e) => e <= 4 ? 1 : e <= 8 ? 2 : 3, ke = (e) => Math.floor(e.base / 4), Ae = (e) => e.value >= 1e9 || e.level >= 99, B = (e, t) => Math.min(De, Math.floor(e * t / 100));
function je(e, t, n) {
	return Math.floor(y[Oe(t) - 1].base * 3 ** e.upgradeCount / 2 ** e.upgradeCount * n / 100);
}
function Me(e) {
	return S[e.commissionOrder[e.day - 1] - 1];
}
function V(e) {
	let t = new Set(e.initialEligibility.recipes);
	e.history.some((e) => e.day === 4 && e.sealsAfter > 0) && t.add("guard"), e.history.some((e) => e.day === 8 && e.sealsAfter > 0) && t.add("heavy");
	for (let n of Me(e).routes) n.recipe && t.add(n.recipe);
	return [
		"light",
		"guard",
		"heavy"
	].filter((e) => t.has(e));
}
function Ne(e) {
	return Me(e).routes.find((e) => e.recipe)?.recipe || (V(e).includes("guard") ? "guard" : "light");
}
function Pe(e, t) {
	let n = _[t.recipe], r = e.dayBuffs.shelter && t.suppliedDay === e.day && t.slot === 1, i = Math.max(0, (t.hits < 3 ? 0 : n.cracks[Math.min(t.hits - 3, 8)]) - (r ? 30 : 0)), a = t.charge === 6, o = a ? 350 : n.greatOdds + (t.cracked && e.traits.includes("crackedEdge") ? 100 : 0);
	return {
		burst: a,
		crack: a ? 0 : i,
		great: o,
		success: 1e3 - o - (a ? 0 : i),
		afterBurstCrack: i
	};
}
function H(e, t, n) {
	let r = [];
	return n.recipe && t.recipe !== n.recipe && r.push(`需要${_[n.recipe].name}`), n.crack === "intact" && t.cracked && r.push("需要无裂纹"), n.crack === "cracked" && !t.cracked && r.push("需要带裂纹"), n.age === "old" && t.suppliedDay >= e.day && r.push("需要昨日留下的旧剑"), n.age === "new" && t.suppliedDay !== e.day && r.push("需要本日新剑"), n.maxHits !== void 0 && t.hits > n.maxHits && r.push(`普通锤不得超过${n.maxHits}次`), n.minLevel !== void 0 && t.level < n.minLevel && r.push(`需要等级${n.minLevel}`), n.minBursts !== void 0 && t.bursts < n.minBursts && r.push(`需要${n.minBursts}次连锻`), t.value < n.value && r.push(`还差${n.value - t.value}身价`), {
		matches: r.length === 0,
		missing: r
	};
}
function U(e) {
	let t = Me(e), n = e.blades.filter((n) => n.status === "commissioned" && n.commissionId === t.id && n.finalizedDay === e.day), r = new Map(e.journal.flatMap((e, t) => e.type === "deliver" ? [[e.pieceId, t]] : []));
	n.sort((e, t) => (r.get(e.id) ?? 2 ** 53 - 1) - (r.get(t.id) ?? 2 ** 53 - 1));
	let i = t.routes.map((t) => {
		let r = n.filter((n) => H(e, n, t).matches).map((e) => e.id);
		return {
			id: t.id,
			required: t.count,
			count: r.length,
			pieceIds: r,
			complete: r.length >= t.count
		};
	}), a = i.find((e) => e.complete);
	return {
		commissionId: t.id,
		complete: !!a,
		routeId: a?.id ?? null,
		pieceIds: a?.pieceIds.slice(0, a.required) ?? [],
		routes: i
	};
}
function W(e, t) {
	let n = Me(e).routes.map((n) => ({
		id: n.id,
		...H(e, t, n)
	}));
	return {
		canDeliver: e.phase === "workshop" && t.status === "active" && t.id !== e.reserveId,
		qualifies: n.some((e) => e.matches),
		routes: n
	};
}
function G(e) {
	let t = e.blades.filter((t) => t.status === "active" && t.id !== e.reserveId), n = U(e), r = !n.complete && e.traits.includes("pardon") && !e.pardonUsed;
	return {
		...n,
		remaining: t,
		recovered: t.reduce((e, t) => e + ke(t), 0),
		protected: r,
		sealsAfter: e.seals - (n.complete || r ? 0 : 1)
	};
}
var Fe = (e) => b.find((t) => t.day === e.day) ?? null, Ie = (e) => e.phase === "workshop" && Fe(e) !== null;
function Le(e, t) {
	let n = e.eventId ? x[e.eventId] : null, r = n?.cost[Oe(e.day) - 1] ?? 0, i = null;
	if (e.phase !== "workshop" || e.eventStatus !== "available" || !n) i = "unavailable";
	else if (e.coins < r) i = "insufficient_coins";
	else if (e.eventId === "credit" && e.crackGuard) i = "already_owned";
	else if (n.piece !== "none") {
		let r = e.blades.find((e) => e.id === t);
		(!r || r.status !== "active" || (n.piece === "reserve" ? e.reserveId !== r.id : e.reserveId === r.id)) && (i = "piece_unavailable");
	} else t !== void 0 && (i = "invalid_command");
	return {
		eventId: e.eventId,
		cost: r,
		requiresPiece: n?.piece ?? "none",
		allowed: i === null,
		error: i
	};
}
//#endregion
//#region src/core-v4/game.ts
var Re = (e) => structuredClone(e), K = (e, t) => ({
	ok: !1,
	state: e,
	error: t,
	events: []
}), q = () => ({
	supplyPct: 100,
	loan: !1,
	shelter: !1
}), ze = (e, t) => typeof e == "string" && t.some((t) => t === e), Be = (e, t) => Object.keys(e).sort().join(",") === [...t].sort().join(",");
function Ve(e, t, n) {
	let i = r(e.rng[t]);
	return e.rng[t] = i.stream, Math.floor(i.value * n);
}
function He(e, t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = Ve(e, t, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function Ue(e) {
	e.supplyBase = je(e, e.day, e.dayBuffs.supplyPct);
	let t = Math.min(e.supplyBase * 4, e.inheritance), n = Ne(e);
	e.inheritance = 0;
	for (let r = 1; r <= 3; r++) {
		let i = e.supplyBase + (r === 1 ? t : 0);
		e.blades.push({
			id: `d${e.day}-${r}`,
			slot: r,
			suppliedDay: e.day,
			recipe: n,
			status: "active",
			base: i,
			value: i,
			peak: i,
			level: 0,
			cracked: !1,
			hits: 0,
			charge: 0,
			successes: 0,
			normalGreats: 0,
			bursts: 0,
			finalizedDay: null,
			commissionId: null
		});
	}
	e.shop = [], e.sold = [], e.upgraded = !1, e.repaired = !1;
	let r = b.find((t) => t.day === e.day);
	if (r) {
		let t = r.pool.filter((t) => !e.traits.includes(t));
		for (; t.length && e.shop.length < 2;) e.shop.push(t.splice(Ve(e, "shop", t.length), 1)[0]);
	}
	let i = [
		3,
		5,
		7,
		9,
		11
	].indexOf(e.day);
	e.eventId = i < 0 ? null : e.eventDeck[i], e.eventStatus = e.eventId ? "available" : "none";
}
function We(r) {
	let a = i(r);
	if (!a) return {
		ok: !1,
		error: "invalid_command"
	};
	let o = JSON.parse(a);
	if (!t(o)) return {
		ok: !1,
		error: "invalid_command"
	};
	if (typeof o.runId != "string" || !/^[A-Za-z0-9_-]{1,80}$/.test(o.runId)) return {
		ok: !1,
		error: "invalid_run_id"
	};
	if (typeof o.seed != "string") return {
		ok: !1,
		error: "invalid_seed"
	};
	let s = o.seed.normalize("NFC").trim();
	if (!s || Array.from(s).length > 64) return {
		ok: !1,
		error: "invalid_seed"
	};
	if (o.mode !== void 0 && o.mode !== "story" && o.mode !== "challenge" || !Be(o, [
		"runId",
		"seed",
		...o.mode === void 0 ? [] : ["mode"],
		...o.eligibility === void 0 ? [] : ["eligibility"]
	])) return {
		ok: !1,
		error: "invalid_command"
	};
	let c = {
		recipes: ["light"],
		challenge: !1
	};
	if (o.eligibility !== void 0) {
		let e = o.eligibility;
		if (!t(e) || !Be(e, ["recipes", "challenge"]) || !Array.isArray(e.recipes) || e.recipes.length > 3 || !e.recipes.every((e) => ze(e, m)) || typeof e.challenge != "boolean") return {
			ok: !1,
			error: "invalid_command"
		};
		let n = e.recipes;
		c = {
			recipes: m.filter((t) => t === "light" || e.challenge || n.includes(t)),
			challenge: e.challenge
		};
	}
	if (o.mode === "challenge" && !c.challenge) return {
		ok: !1,
		error: "challenge_locked"
	};
	let l = (e) => ({
		state: n(`${s}|v4|${e}`),
		draws: 0
	}), u = {
		rulesVersion: "forge-v4",
		runId: o.runId,
		seed: s,
		mode: o.mode ?? "story",
		initialEligibility: Re(c),
		revision: 0,
		phase: "opening",
		day: 1,
		commissionOrder: Array.from({ length: 12 }, (e, t) => t + 1),
		coins: 0,
		seals: 3,
		supplyBase: 40,
		upgradeCount: 0,
		inheritance: 0,
		blades: [],
		reserveId: null,
		daySales: 0,
		dayRecovered: 0,
		traits: [],
		gift: "locked",
		pardonUsed: !1,
		crackGuard: !1,
		modifications: [],
		chapterChoices: [],
		shop: [],
		sold: [],
		upgraded: !1,
		repaired: !1,
		dayBuffs: Re(q()),
		pending: Re(q()),
		eventDeck: [],
		eventId: null,
		eventStatus: "none",
		eventHistory: [],
		history: [],
		rng: {
			forge: l("forge"),
			shop: l("shop"),
			events: l("events"),
			content: l("content")
		},
		journal: []
	};
	if (u.eventDeck = He(u, "events", g), u.mode === "challenge") for (let e of [[
		5,
		6,
		7
	], [
		9,
		10,
		11
	]]) {
		let t = He(u, "content", e);
		for (let n = 0; n < e.length; n++) u.commissionOrder[e[n] - 1] = t[n];
	}
	return Ue(u), e({
		ok: !0,
		state: u
	});
}
function Ge(e) {
	if (!t(e)) return null;
	let n = typeof e.pieceId == "string" && e.pieceId.length <= 32;
	switch (e.type) {
		case "continue":
		case "upgrade":
		case "repair":
		case "settle":
		case "advance": return Be(e, ["type"]) ? { type: e.type } : null;
		case "strike":
		case "deliver":
		case "scrap":
		case "reserve": return n && Be(e, ["type", "pieceId"]) ? {
			type: e.type,
			pieceId: e.pieceId
		} : null;
		case "setRecipe": return n && ze(e.recipe, m) && Be(e, [
			"type",
			"pieceId",
			"recipe"
		]) ? {
			type: e.type,
			pieceId: e.pieceId,
			recipe: e.recipe
		} : null;
		case "chooseModification": return ze(e.modification, h) && Be(e, ["type", "modification"]) ? {
			type: e.type,
			modification: e.modification
		} : null;
		case "chooseEvent": return (e.choice === "accept" || e.choice === "decline") && (e.pieceId === void 0 || n) && Be(e, [
			"type",
			"choice",
			...e.pieceId === void 0 ? [] : ["pieceId"]
		]) ? {
			type: e.type,
			choice: e.choice,
			...e.pieceId === void 0 ? {} : { pieceId: e.pieceId }
		} : null;
		case "buy":
		case "claimGift": return e.type === "buy" && !n || !ze(e.traitId, p) && (e.type !== "claimGift" || e.traitId !== null) || e.replaceId !== void 0 && !ze(e.replaceId, p) || !Be(e, [
			"type",
			"traitId",
			...e.type === "buy" ? ["pieceId"] : [],
			...e.replaceId === void 0 ? [] : ["replaceId"]
		]) ? null : e;
		default: return null;
	}
}
function Ke(e, t, n) {
	if (e.traits.includes(t)) return "already_owned";
	if (e.traits.length === 3) {
		if (!n || !e.traits.includes(n)) return "invalid_replacement";
		e.traits.splice(e.traits.indexOf(n), 1);
	} else if (n !== void 0) return "invalid_replacement";
	return e.traits.push(t), null;
}
function qe(e, t, n) {
	let r = Pe(e, t), i = Ve(e, "forge", 1e3), a = t.value, o = [], s = i < (n ? 350 : r.great) ? "great" : !n && i < r.great + r.crack ? "crack" : "success";
	if (n || t.hits++, !n && e.dayBuffs.shelter && t.slot === 1 && t.suppliedDay === e.day && o.push("shelter"), s === "crack") {
		if (t.cracked) {
			s = "broken", t.value = 0, t.status = "broken", t.finalizedDay = e.day;
			let n = ke(t);
			e.coins += n, e.dayRecovered += n, e.traits.includes("inherit") && (e.inheritance += Math.floor(t.peak / 5), o.push("inherit"));
		} else {
			t.cracked = !0;
			let n = e.traits.includes("steady"), r = e.crackGuard;
			n && o.push("steady"), r && (o.push("credit"), e.crackGuard = !1), !n && !r && (t.value = B(t.value, 80));
		}
	} else {
		let r = _[t.recipe];
		t.value = B(t.value, s === "great" ? r.great : r.success), t.level = Math.min(99, t.level + (s === "great" ? 2 : 1)), n || (s === "great" && (t.normalGreats === 0 && e.modifications.includes("windbox") && (t.value = B(t.value, 110), o.push("windbox")), t.normalGreats++), t.successes++, e.traits.includes("echo") && t.successes % 3 == 0 && (t.value = B(t.value, 125), o.push("echo")), e.dayBuffs.loan && t.suppliedDay === e.day && t.slot === 1 && t.hits <= 3 && (t.value = Math.min(De, t.value + Math.floor((t.value - a) * 10 / 100)), o.push("loan")), t.cracked && s === "great" && e.traits.includes("crackedEdge") && o.push("crackedEdge"));
	}
	return t.peak = Math.max(t.peak, t.value), !n && t.status === "active" && (t.charge = Math.min(6, t.charge + 1)), {
		result: s,
		before: a,
		after: t.value,
		level: t.level,
		triggers: o
	};
}
function Je(e, t, n, r) {
	let i = e.eventId, a = 0;
	if (t === "accept") {
		let t = Le(e, n);
		switch (a = t.cost === 0 ? 0 : -t.cost, e.coins -= t.cost, i) {
			case "donation": {
				let t = e.blades.find((e) => e.id === n);
				t.status = "donated", t.finalizedDay = e.day, e.pending.supplyPct = 120;
				break;
			}
			case "loan":
				e.pending.loan = !0;
				break;
			case "salvage": {
				let t = e.blades.find((e) => e.id === n);
				t.status = "bartered", t.finalizedDay = e.day, e.reserveId = null, e.coins += 160, a += 160;
				break;
			}
			case "credit":
				e.crackGuard = !0;
				break;
			case "shelter": e.pending.shelter = !0;
		}
	}
	let o = {
		day: e.day,
		id: i,
		choice: t,
		pieceId: n ?? null,
		coins: a
	};
	e.eventHistory.push(Re(o)), e.eventStatus = t === "accept" ? "accepted" : "declined", r.push({
		type: "EventChoice",
		record: o
	});
}
function Ye(n, r) {
	if (n.rulesVersion !== "forge-v4") return K(n, "wrong_rules");
	let a = i(r);
	if (!a) return K(n, "invalid_command");
	let o = JSON.parse(a);
	if (!t(o) || !Be(o, [
		"runId",
		"expectedRevision",
		"action"
	])) return K(n, "invalid_command");
	if (o.runId !== n.runId) return K(n, "wrong_run");
	if (o.expectedRevision !== n.revision) return K(n, "stale_revision");
	let s = Ge(o.action);
	if (!s) return K(n, "invalid_command");
	let c = s.type === "continue" ? "opening" : s.type === "chooseModification" ? "chapter" : s.type === "advance" ? "summary" : "workshop";
	if (n.phase !== c) return K(n, "wrong_phase");
	if (n.journal.length >= 2048 || n.journal.length >= 1900 && ([
		"strike",
		"setRecipe",
		"buy",
		"claimGift",
		"upgrade",
		"repair"
	].includes(s.type) || s.type === "reserve" && n.reserveId !== s.pieceId || s.type === "chooseEvent" && s.choice === "accept")) return K(n, "record_limit");
	let l = Re(n), u = [], d = "pieceId" in s ? l.blades.find((e) => e.id === s.pieceId) : void 0;
	if ("pieceId" in s && s.type !== "chooseEvent" && (!d || d.status !== "active")) return K(n, "piece_unavailable");
	if ("pieceId" in s && s.type !== "chooseEvent" && s.type !== "reserve" && l.reserveId === s.pieceId) return K(n, "reserved_piece");
	switch (s.type) {
		case "continue":
			l.phase = "workshop", u.push({ type: "Opened" });
			break;
		case "setRecipe":
			if (!d) return K(n, "piece_unavailable");
			if (d.hits > 0) return K(n, "recipe_locked");
			if (!V(l).includes(s.recipe)) return K(n, "recipe_unavailable");
			if (d.recipe === s.recipe) return K(n, "unavailable");
			d.recipe = s.recipe, u.push({
				type: "Recipe",
				pieceId: d.id,
				recipe: d.recipe
			});
			break;
		case "strike": {
			if (!d) return K(n, "piece_unavailable");
			if (Ae(d)) return K(n, "at_cap");
			let e = d.charge === 6, t = [];
			if (e) {
				let e = d.bursts === 0 && l.modifications.includes("wideMouth"), n = l.traits.includes("ember"), r = 2 + Number(e) + Number(n);
				d.charge = 0, d.bursts++;
				for (let i = 0; i < r && !Ae(d); i++) {
					let r = qe(l, d, !0);
					t.push({
						...r,
						triggers: [
							...r.triggers,
							...e ? ["wideMouth"] : [],
							...n ? ["ember"] : []
						]
					});
				}
			} else t.push(qe(l, d, !1));
			u.push({
				type: "Strike",
				pieceId: d.id,
				burst: e,
				hits: t
			});
			break;
		}
		case "deliver": {
			if (!d) return K(n, "piece_unavailable");
			let e = U(l), t = !e.complete && W(l, d).qualifies;
			d.status = t ? "commissioned" : "sold", d.finalizedDay = l.day, d.commissionId = t ? Me(l).id : null, l.coins += d.value, l.daySales += d.value, u.push({
				type: "Delivered",
				pieceId: d.id,
				amount: d.value,
				matched: t,
				commissionId: Me(l).id
			});
			let r = U(l);
			!e.complete && r.complete && (u.push({
				type: "MainCompleted",
				commissionId: r.commissionId,
				routeId: r.routeId,
				pieceIds: r.pieceIds
			}), l.gift === "locked" && (l.gift = "available", u.push({ type: "GiftAvailable" })));
			break;
		}
		case "scrap":
			if (!d) return K(n, "piece_unavailable");
			d.status = "recycled", d.finalizedDay = l.day, l.coins += ke(d), l.dayRecovered += ke(d), u.push({
				type: "Disposed",
				pieceId: d.id,
				disposition: d.status,
				amount: ke(d)
			});
			break;
		case "reserve":
			if (!d) return K(n, "piece_unavailable");
			{
				let e = l.reserveId;
				l.reserveId = e === d.id ? null : d.id, u.push({
					type: "Reserved",
					pieceId: d.id,
					previousId: e
				});
			}
			break;
		case "claimGift": {
			if (l.gift !== "available") return K(n, "unavailable");
			let e = ["steady", "ember"].filter((e) => !l.traits.includes(e));
			if (e.length) {
				if (s.traitId === null || !e.some((e) => e === s.traitId)) return K(n, "unavailable");
				let t = Ke(l, s.traitId, s.replaceId);
				if (t) return K(n, t);
			} else {
				if (s.traitId !== null || s.replaceId !== void 0) return K(n, "unavailable");
				l.coins += 40;
			}
			l.gift = "claimed", u.push({
				type: "Trait",
				traitId: s.traitId
			});
			break;
		}
		case "buy":
			if (!Ie(l)) return K(n, "no_shop");
			if (!l.shop.includes(s.traitId) || l.sold.includes(s.traitId)) return K(n, "sold_out");
			{
				let e = Ke(l, s.traitId, s.replaceId);
				if (e) return K(n, e);
			}
			if (!d) return K(n, "piece_unavailable");
			d.status = "traded", d.finalizedDay = l.day, l.sold.push(s.traitId), u.push({
				type: "Disposed",
				pieceId: d.id,
				disposition: d.status,
				amount: 0
			}, {
				type: "Trait",
				traitId: s.traitId
			});
			break;
		case "upgrade":
		case "repair": {
			let e = Fe(l);
			if (!Ie(l) || !e) return K(n, "no_shop");
			if (s.type === "upgrade" ? l.upgraded : l.repaired || l.seals === 3) return K(n, "unavailable");
			let t = s.type === "upgrade" ? e.upgrade : e.repair;
			if (l.coins < t) return K(n, "insufficient_coins");
			l.coins -= t, s.type === "upgrade" ? (l.upgradeCount++, l.upgraded = !0, u.push({ type: "Upgraded" })) : (l.seals++, l.repaired = !0, u.push({ type: "Repaired" }));
			break;
		}
		case "chooseEvent":
			if (l.eventStatus !== "available" || l.eventId === null) return K(n, "unavailable");
			if (s.choice === "decline" && s.pieceId !== void 0) return K(n, "invalid_command");
			if (s.choice === "accept") {
				let e = Le(l, s.pieceId);
				if (e.error) return K(n, e.error);
			}
			Je(l, s.choice, s.pieceId, u);
			break;
		case "settle": {
			l.eventStatus === "available" && Je(l, "decline", void 0, u);
			let e = G(l), t = {
				day: l.day,
				commissionId: Me(l).id,
				met: e.complete,
				routeId: e.routeId,
				pieceIds: e.pieceIds,
				sales: l.daySales,
				recovered: l.dayRecovered + e.recovered,
				recoveredIds: e.remaining.map((e) => e.id),
				reserveId: l.reserveId,
				sealsBefore: l.seals,
				sealsAfter: e.sealsAfter,
				protected: e.protected,
				modification: null
			};
			for (let e of l.blades) t.recoveredIds.includes(e.id) && (e.status = "recycled", e.finalizedDay = l.day);
			l.coins += e.recovered, l.dayRecovered += e.recovered, l.seals = e.sealsAfter, e.protected && (l.pardonUsed = !0), l.history.push(t), l.phase = l.seals === 0 ? "defeat" : l.day === 12 ? l.history.filter((e) => e.met).length >= 10 && [
				4,
				8,
				12
			].every((e) => l.history.some((t) => t.day === e && t.met)) ? "victory" : "return" : l.day === 4 || l.day === 8 ? "chapter" : "summary", l.phase === "chapter" && (l.chapterChoices = l.day === 4 ? ["windbox", "warmRack"] : h.filter((e) => !l.modifications.includes(e))), u.push({
				type: "Settled",
				record: t
			});
			break;
		}
		case "chooseModification":
			if (!l.chapterChoices.includes(s.modification) || l.modifications.includes(s.modification)) return K(n, "unavailable");
			l.modifications.push(s.modification), l.history.at(-1).modification = s.modification, l.chapterChoices = [], l.phase = "summary", u.push({
				type: "Modification",
				modification: s.modification
			});
			break;
		case "advance": {
			let e = l.blades.find((e) => e.id === l.reserveId);
			e && l.modifications.includes("warmRack") && (e.value = B(e.value, 115), e.peak = Math.max(e.peak, e.value)), l.day++, l.phase = "workshop", l.daySales = 0, l.dayRecovered = 0, l.dayBuffs = Re(l.pending), l.pending = Re(q()), Ue(l), u.push({ type: "Advanced" });
			break;
		}
	}
	return l.revision++, l.journal.push(s), e({
		ok: !0,
		state: l,
		events: u
	});
}
//#endregion
//#region src/core-v4/validate.ts
function Xe(e) {
	let n = i(e);
	if (!n) return {
		ok: !1,
		error: "invalid_state",
		detail: "Expected bounded plain JSON with safe integer fields."
	};
	let r = JSON.parse(n);
	if (!t(r) || r.rulesVersion !== "forge-v4") return {
		ok: !1,
		error: "invalid_rules_version",
		detail: "Expected forge-v4."
	};
	if (typeof r.runId != "string" || typeof r.seed != "string" || !Array.isArray(r.journal) || r.journal.length > 2048) return {
		ok: !1,
		error: "invalid_state",
		detail: "Missing identity or bounded Accepted journal."
	};
	let a = We({
		runId: r.runId,
		seed: r.seed,
		mode: r.mode,
		eligibility: r.initialEligibility
	});
	if (!a.ok) return {
		ok: !1,
		error: "invalid_state",
		detail: a.error
	};
	let o = a.state;
	for (let [e, t] of r.journal.entries()) {
		let n = Ye(o, {
			runId: o.runId,
			expectedRevision: o.revision,
			action: t
		});
		if (!n.ok) return {
			ok: !1,
			error: "invalid_journal",
			detail: `Command ${e}: ${n.error}`
		};
		o = n.state;
	}
	return i(o) === n ? {
		ok: !0,
		state: o
	} : {
		ok: !1,
		error: "invalid_state",
		detail: "Snapshot differs from full deterministic replay."
	};
}
//#endregion
//#region src/application/v4-collection.ts
var Ze = "sword-led.collection.v1", Qe = "sword-led.collection.backup.v1", $e = (e, t) => Object.keys(e).sort().join(",") === [...t].sort().join(","), et = (e, t, n) => Number.isSafeInteger(e) && Number(e) >= t && Number(e) <= n, tt = (e, t) => i(e) === i(t), nt = (e) => typeof e == "string" && /^[A-Za-z0-9_-]{1,80}$/.test(e), rt = () => e({
	chapters: [],
	mastery: [],
	traits: [],
	challenge: !1,
	works: []
});
function it(e, n) {
	return !t(e) || !$e(e, [
		"id",
		"slot",
		"suppliedDay",
		"recipe",
		"status",
		"base",
		"value",
		"peak",
		"level",
		"cracked",
		"hits",
		"charge",
		"successes",
		"normalGreats",
		"bursts",
		"finalizedDay",
		"commissionId"
	]) || !et(e.slot, 1, 3) || !et(e.suppliedDay, 1, n.day) || e.id !== `d${e.suppliedDay}-${e.slot}` || !m.some((t) => t === e.recipe) || e.status !== "commissioned" || e.finalizedDay !== n.day || e.commissionId !== n.commissionId || typeof e.cracked != "boolean" || !et(e.base, 1, 1e9) || !et(e.value, 1, 1e9) || !et(e.peak, e.value, 1e9) || !et(e.level, 0, 99) || !et(e.hits, 0, 2048) || !et(e.charge, 0, 6) || !et(e.bursts, 0, 2048) || !et(e.successes, 0, e.hits) || !et(e.normalGreats, 0, e.successes) ? !1 : e.hits === e.bursts * 6 + e.charge;
}
function at(e) {
	if (!t(e) || !$e(e, [
		"commissionId",
		"day",
		"routeId",
		"runId",
		"blades"
	]) || !et(e.commissionId, 1, 12) || !et(e.day, 1, 12) || !nt(e.runId)) return !1;
	let n = S[e.commissionId - 1].routes.find((t) => t.id === e.routeId);
	if (!n || !Array.isArray(e.blades) || e.blades.length !== n.count || !(e.commissionId <= 4 || e.commissionId === 8 || e.commissionId === 12 ? [e.commissionId] : e.commissionId < 8 ? [
		5,
		6,
		7
	] : [
		9,
		10,
		11
	]).includes(e.day)) return !1;
	let r = {
		day: e.day,
		commissionId: e.commissionId
	};
	return e.blades.every((e) => it(e, r) && H({ day: r.day }, e, n).matches) && new Set(e.blades.map((e) => e.id)).size === n.count;
}
var ot = (e) => e.blades.reduce((e, t) => e + t.value, 0);
function st(e, t) {
	let n = ot(e) - ot(t);
	return n > 0 ? e : n < 0 ? t : i(e) <= i(t) ? e : t;
}
function ct(t, n) {
	let r = /* @__PURE__ */ new Map();
	for (let e of [...t.works, ...n.works]) r.set(e.commissionId, r.has(e.commissionId) ? st(r.get(e.commissionId), e) : e);
	return e({
		chapters: [.../* @__PURE__ */ new Set([...t.chapters, ...n.chapters])].sort((e, t) => e - t),
		mastery: m.filter((e) => t.mastery.includes(e) || n.mastery.includes(e)),
		traits: p.filter((e) => t.traits.includes(e) || n.traits.includes(e)),
		challenge: t.challenge || n.challenge,
		works: [...r.values()].sort((e, t) => e.commissionId - t.commissionId)
	});
}
function J(e) {
	let n = () => ({
		ok: !1,
		error: "invalid_state",
		detail: "Expected bounded collection sets and valid commission receipts."
	}), r = i(e);
	if (!r) return n();
	let a = JSON.parse(r);
	if (!t(a) || !$e(a, [
		"chapters",
		"mastery",
		"traits",
		"challenge",
		"works"
	]) || typeof a.challenge != "boolean" || !Array.isArray(a.chapters) || a.chapters.length > 3 || !a.chapters.every((e) => et(e, 1, 3)) || !Array.isArray(a.mastery) || a.mastery.length > 3 || !a.mastery.every((e) => m.some((t) => t === e)) || !Array.isArray(a.traits) || a.traits.length > 6 || !a.traits.every((e) => p.some((t) => t === e)) || !Array.isArray(a.works) || a.works.length > 12 || !a.works.every(at)) return n();
	let o = a, s = ct(rt(), o);
	return !tt(s, o) || o.chapters.some((e) => e > 1 && !o.chapters.includes(e - 1)) || o.challenge && (!o.chapters.includes(3) || o.works.length < 10 || ![
		4,
		8,
		12
	].every((e) => o.works.some((t) => t.commissionId === e))) ? n() : {
		ok: !0,
		state: s
	};
}
var lt = Object.freeze({
	key: Ze,
	backupKey: Qe,
	schemaVersion: 1,
	rulesVersion: "forge-v4-collection-v1",
	validate: J
}), ut = (e) => s(e, lt), dt = "sword-led.collection.v2", ft = "sword-led.collection.backup.v2", pt = Ze, mt = Qe, ht = (e, t) => Object.keys(e).sort().join(",") === [...t].sort().join(","), gt = (e, t) => i(e) === i(t), _t = () => ({
	ok: !1,
	error: "invalid_state",
	detail: "Expected bounded collection sets and source-tagged commission receipts."
}), vt = () => e({
	chapters: [],
	mastery: [],
	traits: [],
	challenge: !1,
	works: []
}), yt = (e) => e.blades.reduce((e, t) => e + t.value, 0);
function bt(e, t) {
	let n = yt(e) - yt(t);
	return n > 0 ? e : n < 0 ? t : i(e) <= i(t) ? e : t;
}
function xt(t, n) {
	let r = /* @__PURE__ */ new Map();
	for (let e of [...t.works, ...n.works]) r.set(e.commissionId, r.has(e.commissionId) ? bt(r.get(e.commissionId), e) : e);
	return e({
		chapters: [.../* @__PURE__ */ new Set([...t.chapters, ...n.chapters])].sort((e, t) => e - t),
		mastery: m.filter((e) => t.mastery.includes(e) || n.mastery.includes(e)),
		traits: p.filter((e) => t.traits.includes(e) || n.traits.includes(e)),
		challenge: t.challenge || n.challenge,
		works: [...r.values()].sort((e, t) => e.commissionId - t.commissionId)
	});
}
function St(e) {
	let n = i(e);
	if (n === null) return _t();
	let r = JSON.parse(n);
	if (!t(r) || !ht(r, [
		"chapters",
		"mastery",
		"traits",
		"challenge",
		"works"
	]) || !Array.isArray(r.works) || r.works.length > 12) return _t();
	let a = [];
	for (let e of r.works) {
		if (!t(e) || !ht(e, [
			"commissionId",
			"day",
			"routeId",
			"runId",
			"blades",
			"rulesVersion"
		]) || e.rulesVersion !== "forge-v4" && e.rulesVersion !== "forge-v5") return _t();
		let { rulesVersion: n, ...r } = e;
		a.push(r);
	}
	if (!J({
		...r,
		works: a
	}).ok) return _t();
	let o = r, s = xt(vt(), o);
	return gt(s, o) ? {
		ok: !0,
		state: s
	} : _t();
}
function Ct(e, t) {
	return xt(vt(), {
		chapters: e.chapters,
		mastery: e.mastery,
		traits: e.traits,
		challenge: e.challenge,
		works: e.works.map((e) => ({
			...e,
			rulesVersion: t
		}))
	});
}
function wt(e) {
	return Ct(R(e), "forge-v5");
}
function Tt(e) {
	let t = J(e);
	return t.ok ? {
		ok: !0,
		state: Ct(t.state, "forge-v4")
	} : t;
}
var Et = ut;
function Dt(t) {
	return e({
		recipes: m.filter((e) => e === "light" || e === "guard" && t.chapters.includes(1) || e === "heavy" && t.chapters.includes(2)),
		challenge: t.challenge
	});
}
var Ot = Object.freeze({
	key: dt,
	backupKey: ft,
	schemaVersion: 2,
	rulesVersion: "forge-collection-v2",
	validate: St
}), kt = (e) => s(e, Ot);
function At(e, t, n) {
	let r = (t) => {
		try {
			return {
				ok: !0,
				raw: e().getItem(t)
			};
		} catch {
			return { ok: !1 };
		}
	};
	return () => ({
		main: r(t),
		backup: r(n)
	});
}
function jt(e, t) {
	return {
		...c(e, Ot, t),
		readRaw: At(e, dt, ft)
	};
}
function Mt(e) {
	return { readRaw: At(e, pt, mt) };
}
//#endregion
//#region src/application/v5-persistence.ts
var Nt = "sword-led.save.v5", Pt = "sword-led.save.backup.v5", Ft = Object.freeze({
	key: Nt,
	backupKey: Pt,
	schemaVersion: 5,
	rulesVersion: "forge-v5",
	validate: Te
}), It = (e) => s(e, Ft), Lt = (e, t) => c(e, Ft, t);
function Rt(n, r, o, s) {
	let c = vt(), l = null, u = null, d = !1, f = null, p = !1, m = !1, h = !1, g = !1, _ = null, v = 0, y = null, b = /* @__PURE__ */ new Set(), x = /* @__PURE__ */ new Set(), S = a(n, r, {
		createRun: (e) => {
			let n = i(e);
			if (!n) return {
				ok: !1,
				error: "invalid_command"
			};
			let r = JSON.parse(n);
			if (!t(r) || Object.keys(r).some((e) => ![
				"runId",
				"seed",
				"mode"
			].includes(e))) return {
				ok: !1,
				error: "invalid_command"
			};
			let a = Dt(l?.main.status === "valid" ? l.main.state : vt());
			return be({
				...e,
				eligibility: a
			});
		},
		applyCommand: I,
		isTerminal: (e) => [
			"victory",
			"return",
			"defeat"
		].includes(e.phase)
	}), C = (e = S.getSnapshot()) => !p && e.mode === "writer" && e.active && !e.dirty && !e.conflict && r.owns() && n.isCurrent(), w = () => e({
		data: c,
		load: l,
		pending: d,
		lastSave: u,
		problem: f,
		writable: C()
	}), T = (e) => ({
		ok: !1,
		error: e,
		snapshot: S.getSnapshot()
	}), E = (e) => {
		let t = S.getSnapshot();
		return p ? "disposed" : e === t.generation ? t.active ? t.mode !== "writer" || !r.owns() ? "readonly" : null : "not_active" : "stale_session";
	};
	function D(e = !0) {
		if (p) return;
		let t = S.getSnapshot();
		l = o.load();
		let r = l.main, a = r.status === "valid" ? r.state : vt();
		c = xt(c, a), C(t) && t.state && (c = xt(c, wt(t.state)));
		let s = i(c) !== i(a), m = t.dirty && t.mode !== "memory" && t.state !== null && i(xt(c, wt(t.state))) !== i(c);
		d = s || m;
		let h = l.backup;
		f = r.status === "invalid" || r.status === "unavailable" ? r.error : r.status === "empty" && h.status !== "empty" ? h.status === "valid" ? "recovery_required" : h.error : null, m && f === null && (f = "run_unsaved"), s && f === null && e && (t.dirty ? f = "run_unsaved" : C(t) ? (u = o.write(c, { raw: o.token() }), d = !u.ok, u.ok ? l = {
			main: {
				status: "valid",
				state: c,
				savedAt: u.savedAt
			},
			backup: o.inspect().backup
		} : f = u.error) : t.active && t.mode === "writer" && !n.isCurrent() && (f = "run_changed"));
	}
	function O() {
		if (p && S.getSnapshot().mode !== "disposed") return;
		if (h) {
			g = !0;
			return;
		}
		h = !0;
		let e = S.getSnapshot(), t = w();
		try {
			for (let t of b) {
				if (S.getSnapshot().generation !== e.generation) break;
				try {
					t(e);
				} catch {}
			}
			for (let n of x) {
				if (S.getSnapshot().generation !== e.generation) break;
				try {
					n(t);
				} catch {}
			}
		} finally {
			h = !1, g && (g = !1, O());
		}
	}
	function k(e) {
		if (m || h) return T("session_busy");
		m = !0;
		try {
			return e();
		} finally {
			m = !1;
		}
	}
	let ee = S.subscribe(() => {
		D(), O();
	});
	return {
		getSnapshot: S.getSnapshot,
		getCollectionSnapshot: w,
		subscribe: (e) => {
			b.add(e);
			try {
				e(S.getSnapshot());
			} catch {}
			return () => {
				b.delete(e);
			};
		},
		subscribeCollection: (e) => {
			x.add(e);
			try {
				e(w());
			} catch {}
			return () => {
				x.delete(e);
			};
		},
		activate: async () => m || h ? S.getSnapshot() : S.activate(),
		startNewGame: (e, t) => k(() => {
			let n = E(t.generation);
			return n && S.getSnapshot().mode !== "memory" ? T(n) : t.generation === S.getSnapshot().generation ? (D(), S.getSnapshot().mode !== "memory" && d ? T("collection_pending") : S.startNewGame(e, t)) : T("stale_session");
		}),
		resume: (e) => k(() => S.resume(e)),
		recoverBackup: (e) => k(() => S.recoverBackup(e)),
		useMemory: (e, t) => k(() => (D(!1), S.useMemory(e, t))),
		dispatch: (e, t) => {
			if (m || h) return {
				ok: !1,
				error: "session_busy",
				state: S.getSnapshot().state,
				events: [],
				snapshot: S.getSnapshot()
			};
			m = !0;
			try {
				return S.dispatch(e, t);
			} finally {
				m = !1;
			}
		},
		retrySave: (e) => k(() => S.retrySave(e)),
		retryCollection: (e) => k(() => {
			let t = E(e);
			return t ? T(t) : (D(), O(), d || f ? T("collection_unavailable") : {
				ok: !0,
				snapshot: S.getSnapshot()
			});
		}),
		recoverCollectionBackup: (e) => k(() => {
			let t = E(e.generation);
			if (t) return T(t);
			if (!e.confirmed) return T("confirmation_required");
			if (l = o.load(), l.main.status === "valid") return T("main_available");
			if (l.main.status === "unavailable" || l.backup.status !== "valid") return T("backup_unavailable");
			if (!C()) return T("collection_unavailable");
			c = xt(c, l.backup.state);
			let n = S.getSnapshot();
			return n.state && (c = xt(c, wt(n.state))), u = o.write(c, { raw: o.token() }), d = !u.ok, f = u.ok ? null : u.error, u.ok && (l = {
				main: {
					status: "valid",
					state: c,
					savedAt: u.savedAt
				},
				backup: o.inspect().backup
			}), O(), u.ok ? {
				ok: !0,
				snapshot: S.getSnapshot()
			} : T("collection_unavailable");
		}),
		notifyExternalChange: () => {
			p || S.notifyExternalChange();
		},
		notifyCollectionChange: () => {
			p || m || h || (D(), O());
		},
		previewLegacyImport: (t = "main") => {
			if (m || h) return T("session_busy");
			y = null;
			let n = S.getSnapshot();
			if (p) return T("disposed");
			if (!n.active) return T("not_active");
			if (t !== "main" && t !== "backup") return T("invalid_command");
			if (!s) return T("legacy_unavailable");
			m = !0;
			try {
				let r = s.readRaw()[t];
				if (!r.ok || r.raw === null) return T("legacy_unavailable");
				let i = Et(r.raw);
				if (i.status !== "valid") return T("legacy_unavailable");
				let a = Tt(i.state);
				if (!a.ok) return T("legacy_unavailable");
				let o = e({
					id: ++v,
					generation: n.generation,
					source: t,
					savedAt: i.savedAt,
					collection: a.state,
					merged: xt(c, a.state)
				});
				return y = {
					preview: o,
					raw: r.raw,
					runId: n.state?.runId ?? null,
					revision: n.state?.revision ?? null
				}, {
					ok: !0,
					preview: o,
					snapshot: n
				};
			} catch {
				return T("legacy_unavailable");
			} finally {
				m = !1;
			}
		},
		importLegacyCollection: (e) => k(() => {
			let n = i(e), r = n ? JSON.parse(n) : null;
			if (!t(r) || Object.keys(r).sort().join(",") !== "confirmed,generation,previewId" || typeof r.confirmed != "boolean" || typeof r.generation != "number" || !Number.isSafeInteger(r.generation) || typeof r.previewId != "number" || !Number.isSafeInteger(r.previewId)) return T("invalid_command");
			let a = E(r.generation);
			if (a) return T(a);
			if (r.confirmed !== !0) return T("confirmation_required");
			let o = S.getSnapshot(), l = y;
			if (!l || l.preview.id !== r.previewId || l.preview.generation !== o.generation || l.runId !== (o.state?.runId ?? null) || l.revision !== (o.state?.revision ?? null)) return y = null, T("legacy_changed");
			if (!C(o) || (D(!1), f !== null)) return T("collection_unavailable");
			try {
				let e = s?.readRaw()[l.preview.source];
				if (!e?.ok) return T("legacy_unavailable");
				if (e.raw !== l.raw) return y = null, T("legacy_changed");
			} catch {
				return T("legacy_unavailable");
			}
			return c = xt(c, l.preview.collection), y = null, D(), O(), d || f ? T("collection_unavailable") : {
				ok: !0,
				snapshot: S.getSnapshot()
			};
		}),
		cancelLegacyImport: () => {
			y = null;
		},
		notifyLegacyCollectionChange: () => {
			y = null;
		},
		exportRun: () => {
			let e = S.getSnapshot().state;
			return e ? JSON.stringify(e, null, 2) : null;
		},
		exportCollection: () => JSON.stringify({
			format: "sword-led.collection-export.v2",
			collection: c,
			stored: o.readRaw()
		}, null, 2),
		suspend: () => h && !S.getSnapshot().active ? Promise.resolve() : S.suspend(),
		dispose: () => {
			if (p) return _ ?? Promise.resolve();
			p = !0, y = null, _ = S.dispose(), ee();
			let e = () => {
				b.clear(), x.clear();
			};
			return h ? _.then(e, e) : e(), _;
		}
	};
}
function zt(e = window) {
	let t = d(e, Nt, (t) => Rt(Lt(() => e.localStorage), u(t), jt(() => e.localStorage), Mt(() => e.localStorage))), n = (e) => {
		(e.key === "sword-led.collection.v2" || e.key === "sword-led.collection.backup.v2" || e.key === null) && t.notifyCollectionChange(), (e.key === pt || e.key === mt || e.key === null) && t.notifyLegacyCollectionChange();
	};
	return e.addEventListener("storage", n), {
		...t,
		dispose: () => (e.removeEventListener("storage", n), t.dispose())
	};
}
//#endregion
//#region src/application/v4-persistence.ts
var Bt = "sword-led.save.v4", Vt = Object.freeze({
	key: Bt,
	backupKey: "sword-led.save.backup.v4",
	schemaVersion: 4,
	rulesVersion: "forge-v4",
	validate: Xe
}), Ht = (e) => s(e, Vt);
//#endregion
//#region src/platform/timing.ts
function Ut(e, t) {
	return t !== null && e.runId === t.runId && e.revision === t.revision && e.generation === t.generation && e.epoch === t.epoch && e.pieceId === t.pieceId && e.mode === t.mode && e.periodMs === t.periodMs && e.rulesVersion === t.rulesVersion && e.node === t.node;
}
//#endregion
//#region src/platform/direct-strike-input.ts
function Wt(e, t) {
	let n = null, r = null, i = null, a = null, o = !1, s = () => {
		if (n !== null && r) try {
			r.hasPointerCapture(n) && r.releasePointerCapture(n);
		} catch {}
		n = null, r = null;
	}, c = () => {
		a = null, s(), t.preparing(!1);
	}, l = (o) => {
		let s = o.currentTarget;
		if (o.button !== 0 || !o.isPrimary || o.ctrlKey || o.metaKey || o.altKey || s.disabled) return;
		if (n !== null || a) {
			o.preventDefault(), i = s;
			return;
		}
		let c = t.context(), l = c ? null : t.navigationContext();
		o.preventDefault(), s.focus({ preventScroll: !0 }), n = o.pointerId, r = s, i = s;
		try {
			s.setPointerCapture(n);
		} catch {}
		c && Ut(c, t.context()) ? t.commit(Object.freeze({ ...c }), s === e[0] ? {
			clientX: o.clientX,
			clientY: o.clientY
		} : null) : l && Ut(l, t.navigationContext()) && t.navigate();
	}, u = (e) => {
		e.pointerId === n && s();
	}, d = (n) => {
		!o && n.currentTarget === e[0] && n.pointerType !== "touch" && t.aim({
			clientX: n.clientX,
			clientY: n.clientY
		});
	}, f = () => t.aim(null), p = (e) => e.preventDefault(), m = (e) => {
		let r = e.currentTarget;
		if (i === r && e.detail !== 0) {
			i = null, e.preventDefault(), e.stopImmediatePropagation();
			return;
		}
		if (e.detail !== 0 || a || n !== null) return;
		let o = t.context();
		o ? (e.preventDefault(), e.stopImmediatePropagation(), t.commit(o, null)) : t.navigationContext() && (e.preventDefault(), e.stopImmediatePropagation(), t.navigate());
	}, h = (e) => {
		let r = e.code === "Space" || e.key === " " ? "Space" : e.key === "Enter" ? "Enter" : null;
		if (!r) return;
		if (e.ctrlKey || e.metaKey || e.altKey) {
			c();
			return;
		}
		if (e.repeat || a || n !== null) {
			e.preventDefault();
			return;
		}
		e.preventDefault();
		let o = t.context(), s = o ?? t.navigationContext();
		s && (i = null, a = {
			code: r,
			identity: Object.freeze({ ...s }),
			kind: o ? "forge" : "navigate"
		}, r === "Enter" ? o ? t.commit(a.identity, null) : t.navigate() : o && t.preparing(!0));
	}, g = (e) => {
		let n = e.code === "Space" || e.key === " " ? "Space" : e.key === "Enter" ? "Enter" : null;
		if (!a || a.code !== n) return;
		e.preventDefault();
		let r = a;
		a = null, t.preparing(!1);
		let i = r.kind === "forge" ? t.context() : t.navigationContext();
		n === "Space" && !e.ctrlKey && !e.metaKey && !e.altKey && Ut(r.identity, i) && (r.kind === "forge" ? t.commit(r.identity, null) : t.navigate());
	}, _ = () => {
		document.hidden && c();
	}, v = () => {
		a = null, t.preparing(!1);
	};
	for (let t of e) t.addEventListener("pointerdown", l), t.addEventListener("pointermove", d), t.addEventListener("pointerleave", f), t.addEventListener("contextmenu", p), t.addEventListener("click", m), t.addEventListener("keydown", h), t.addEventListener("blur", v);
	return window.addEventListener("pointerup", u, !0), window.addEventListener("pointercancel", u, !0), window.addEventListener("keyup", g, !0), window.addEventListener("blur", c), document.addEventListener("visibilitychange", _), {
		cancel: c,
		refresh() {
			a?.code === "Space" && !Ut(a.identity, a.kind === "forge" ? t.context() : t.navigationContext()) && (a = null, t.preparing(!1));
		},
		dispose() {
			o = !0, c();
			for (let t of e) t.removeEventListener("pointerdown", l), t.removeEventListener("pointermove", d), t.removeEventListener("pointerleave", f), t.removeEventListener("contextmenu", p), t.removeEventListener("click", m), t.removeEventListener("keydown", h), t.removeEventListener("blur", v);
			window.removeEventListener("pointerup", u, !0), window.removeEventListener("pointercancel", u, !0), window.removeEventListener("keyup", g, !0), window.removeEventListener("blur", c), document.removeEventListener("visibilitychange", _);
		}
	};
}
//#endregion
//#region src/platform/settings.ts
var Gt = "sword-led.settings.v1", Kt = Object.freeze({
	muted: !1,
	volume: 55,
	slow: !1,
	reducedMotion: !1
});
function qt(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) return !1;
	let t = e;
	return Object.keys(t).sort().join(",") === "muted,reducedMotion,slow,volume" && typeof t.muted == "boolean" && typeof t.slow == "boolean" && typeof t.reducedMotion == "boolean" && typeof t.volume == "number" && Number.isInteger(t.volume) && t.volume >= 0 && t.volume <= 100;
}
function Jt(e) {
	if (e === null) return Kt;
	if (e.length > 4096 || new TextEncoder().encode(e).byteLength > 4096) return null;
	try {
		let t = JSON.parse(e);
		if (!t || typeof t != "object" || Array.isArray(t) || !("schemaVersion" in t) || t.schemaVersion !== 1) return null;
		let { schemaVersion: n, ...r } = t;
		return qt(r) ? Object.freeze(r) : null;
	} catch {
		return null;
	}
}
function Yt(e) {
	let t = Object.freeze({
		value: Kt,
		dirty: !1,
		persisted: !1,
		problem: null
	}), n = /* @__PURE__ */ new Set(), r = () => {
		for (let e of n) e(t);
	}, i = () => {
		if (!t.dirty) {
			try {
				let n = e().getItem(Gt), r = Jt(n);
				t = Object.freeze({
					value: r ?? t.value,
					dirty: !1,
					persisted: n !== null && r !== null,
					problem: r ? null : "invalid"
				});
			} catch {
				t = Object.freeze({
					value: t.value,
					dirty: !1,
					persisted: !1,
					problem: "read_failed"
				});
			}
			r();
		}
	}, a = () => {
		try {
			e().setItem(Gt, JSON.stringify({
				schemaVersion: 1,
				...t.value
			})), t = Object.freeze({
				...t,
				dirty: !1,
				persisted: !0,
				problem: null
			});
		} catch {
			t = Object.freeze({
				...t,
				dirty: !0,
				persisted: !1,
				problem: "write_failed"
			});
		}
		return r(), !t.dirty;
	};
	return i(), {
		getSnapshot: () => t,
		subscribe(e) {
			return n.add(e), e(t), () => {
				n.delete(e);
			};
		},
		update(e) {
			let n = {
				...t.value,
				...e
			};
			return qt(n) ? (t = Object.freeze({
				value: Object.freeze(n),
				dirty: !0,
				persisted: !1,
				problem: null
			}), a()) : !1;
		},
		retry: a,
		reload: i
	};
}
//#endregion
//#region src/platform/audio.ts
function Xt(e) {
	let t = e.find((e) => e.type === "RunEnded");
	if (t?.type === "RunEnded") return t.outcome;
	let n = e.find((e) => e.type === "RoundSettled");
	if (n?.type === "RoundSettled") return n.summary.metQuota ? "met" : "missed";
	let r = e.find((e) => e.type === "StrikeResolved");
	return r?.type === "StrikeResolved" ? r.outcome === "success" ? r.mode : r.outcome : e.some((e) => e.type === "PurchaseMade") ? "purchase" : e.some((e) => e.type === "PieceDelivered") ? "delivery" : e.some((e) => e.type === "PieceRecycled") ? "recycle" : e.some((e) => e.type === "Heated") ? "heat" : null;
}
var Zt = {
	light: {
		tones: [
			1117,
			1733,
			2411
		],
		duration: .16
	},
	standard: {
		tones: [
			719,
			1193,
			1777
		],
		duration: .22
	},
	heavy: {
		tones: [
			431,
			731,
			1153
		],
		duration: .3
	},
	damage: {
		tones: [183, 271],
		duration: .2,
		type: "triangle"
	},
	broken: {
		tones: [
			677,
			359,
			193
		],
		duration: .38,
		fall: .3
	},
	heat: {
		tones: [73, 109],
		duration: .28,
		type: "triangle"
	},
	delivery: {
		tones: [523, 784],
		duration: .32
	},
	recycle: {
		tones: [311, 467],
		duration: .18
	},
	purchase: {
		tones: [659, 988],
		duration: .3
	},
	met: {
		tones: [
			523,
			659,
			784
		],
		duration: .4
	},
	missed: {
		tones: [220, 261],
		duration: .35,
		type: "triangle"
	},
	victory: {
		tones: [
			523,
			659,
			784
		],
		duration: .65
	},
	defeat: {
		tones: [
			196,
			233,
			294
		],
		duration: .6,
		type: "triangle",
		fall: .65
	}
};
function Qt(e = () => new AudioContext({ latencyHint: "interactive" }), t = {}) {
	let n = null, r = null, i = null, a = 0, o = null, s = null, c = "silent", l = !1, u = 55, d = 0, f = !1, p = "", m = null, h = /* @__PURE__ */ new Set(), g = /* @__PURE__ */ new Set(), _ = /* @__PURE__ */ new Set(), v = () => !f && !l && u > 0, y = () => v() ? m ?? (n?.state === "running" && c !== "silent" ? "ready" : "waiting") : "muted", b = () => {
		if (!f) for (let e of _) e(y());
	}, x = () => {
		h.clear();
		for (let e of [...g]) e.stop();
	}, S = (e) => {
		if (e.state === "closed") return;
		let t = e.suspend().catch(() => {}), r = {
			context: e,
			promise: t
		};
		e === n && (s = r), t.finally(() => {
			s === r && (s = null);
		});
	}, C = () => {
		x(), n && S(n);
	}, w = () => {
		if (!n || !r) return;
		let e = n.currentTime;
		r.gain.cancelScheduledValues(e), v() ? r.gain.setTargetAtTime(.6 * (u / 100) ** 2, e, .01) : r.gain.setValueAtTime(0, e);
	}, T = () => {
		(!v() || c === "silent") && n?.state === "running" && C(), b();
	};
	function E() {
		if (!v() || c === "silent") return Promise.resolve(!1);
		if (i?.context === n && i.epoch === d) return i.promise;
		try {
			if (!n || n.state === "closed") {
				n?.removeEventListener("statechange", T), r?.disconnect(), n = null, r = null;
				let t = e();
				try {
					let e = t.createGain();
					e.gain.value = 0, e.connect(t.destination), n = t, r = e, n.addEventListener("statechange", T), w();
				} catch {
					throw t.close().catch(() => {}), Error("Audio output unavailable");
				}
			}
			let t = n, l = {
				context: t,
				epoch: d,
				serial: ++a
			};
			if (o = l, t.state === "running" && s?.context !== t && i?.context !== t) return m = null, b(), Promise.resolve(!0);
			let u, p = t.resume().then(() => f || l.epoch !== d || !v() || c === "silent" || n !== t || o !== l ? (o?.context === t && o.epoch === d && o.serial > l.serial && v() && c !== "silent" && n === t || S(t), !1) : (m = t.state === "running" ? null : "blocked", b(), t.state === "running")).catch(() => (!f && l.epoch === d && o === l && (m = "blocked", b()), !1)).finally(() => {
				i === u && (i = null);
			});
			return u = {
				...l,
				promise: p
			}, i = u, p;
		} catch {
			return m = n ? "blocked" : "unavailable", b(), Promise.resolve(!1);
		}
	}
	function D(e) {
		if (!v() || c === "silent" || !n || !r || n.state !== "running") return;
		for (; g.size >= 4;) g.values().next().value?.stop();
		let i = t[e] ?? Zt[e], a = [], o = [], s = 0, l = !1, u = () => {
			if (!l) {
				l = !0;
				for (let e of a) e.onended = null, e.disconnect();
				for (let e of o) e.disconnect();
				g.delete(d);
			}
		}, d = { stop() {
			for (let e of a) try {
				e.stop();
			} catch {}
			u();
		} };
		g.add(d);
		try {
			let e = n.currentTime;
			for (let t of i.tones) {
				let c = n.createOscillator(), l = n.createGain();
				a.push(c), o.push(l), c.type = i.type ?? "sine", c.frequency.setValueAtTime(t, e), i.fall && c.frequency.exponentialRampToValueAtTime(t * i.fall, e + i.duration), l.gain.setValueAtTime(0, e), l.gain.linearRampToValueAtTime(.22 / i.tones.length, e + .003), l.gain.exponentialRampToValueAtTime(1e-4, e + i.duration), c.connect(l), l.connect(r), c.onended = () => {
					++s === a.length && u();
				}, c.start(e), c.stop(e + i.duration + .01);
			}
		} catch {
			d.stop(), m = "blocked", b();
		}
	}
	function O(e) {
		if (!v() || c !== "game" || !n || !r) return;
		let t = i;
		if (!t || t.context !== n || t.epoch !== d) {
			n.state === "running" && D(e);
			return;
		}
		let a = {
			cue: e,
			context: n,
			epoch: d,
			mode: c
		};
		for (; h.size >= 4;) {
			let e = h.values().next().value;
			e && h.delete(e);
		}
		h.add(a), t.promise.then((e) => {
			h.delete(a) && e && v() && c === a.mode && d === a.epoch && n === a.context && D(a.cue);
		}).catch(() => {
			h.delete(a);
		});
	}
	return {
		getStatus: y,
		identify(e) {
			p !== e && !f && (p = e, d++, x());
		},
		subscribe(e) {
			return _.add(e), e(y()), () => {
				_.delete(e);
			};
		},
		configure(e) {
			l = e.muted, u = Number.isFinite(e.volume) ? Math.min(100, Math.max(0, e.volume)) : 0, (l || u === 0) && (d++, C()), w(), b();
		},
		setMode(e) {
			c === e || f || (d++, x(), c = e, c === "silent" && C(), b());
		},
		gesture: E,
		silence() {
			d++, x();
		},
		accepted(e) {
			if (c !== "game") return;
			let t = Xt(e);
			t && O(t);
		},
		acceptedCue: O,
		async preview() {
			let e = d;
			c === "preview" && await E() && e === d && D("standard");
		},
		async dispose() {
			if (!f) {
				if (f = !0, d++, c = "silent", x(), _.clear(), n) {
					n.removeEventListener("statechange", T), r?.disconnect();
					try {
						await n.close();
					} catch {}
				}
				n = null, r = null;
			}
		}
	};
}
//#endregion
//#region src/presentation/dom.ts
var $t = "button,input:not([type=hidden]),select,textarea,summary,a[href]";
function en(e) {
	for (let t of e.querySelectorAll($t)) t.hasAttribute("tabindex") || (t.tabIndex = 0);
}
function Y(e, t, n) {
	let r = document.createElement(e);
	return t !== void 0 && (r.textContent = t), n && (r.className = n), r.matches($t) && (r.tabIndex = 0), r;
}
//#endregion
//#region src/presentation-v3/hammer.ts
var tn = Object.freeze({
	width: 1536,
	height: 1024,
	face: {
		x: 200,
		y: 766
	},
	grip: {
		x: 1380,
		y: 515
	}
});
function nn(e, t, n) {
	let r = 0, i = /* @__PURE__ */ new Set();
	e.style.setProperty("--face-x", String(tn.face.x / tn.width)), e.style.setProperty("--face-y", String(tn.face.y / tn.width)), e.style.setProperty("--grip-x", `${tn.grip.x / tn.width * 100}%`), e.style.setProperty("--grip-y", `${tn.grip.y / tn.height * 100}%`);
	function a(e) {
		let t = requestAnimationFrame(() => {
			i.delete(t), e();
		});
		i.add(t);
	}
	function o() {
		r++;
		for (let e of i) cancelAnimationFrame(e);
		i.clear();
		for (let t of e.getAnimations()) t.cancel();
		e.style.transform = "", e.dataset.phase = "idle";
	}
	function s(i, s) {
		o();
		let c = r, l = () => c === r && !document.hidden && !t();
		if (t()) {
			s();
			return;
		}
		e.dataset.phase = "swing";
		let u = performance.now();
		n(e, [{ transform: "rotate(8deg)" }, { transform: "rotate(0deg)" }], 55, "ease-in");
		function d() {
			if (l()) {
				if (performance.now() - u < 55) a(d);
				else {
					for (let t of e.getAnimations()) t.cancel();
					e.style.transform = "rotate(0deg)", e.dataset.phase = "contact", s(), a(() => a(() => {
						l() && (e.dataset.phase = "rebound", n(e, [
							{ transform: "rotate(0deg)" },
							{
								transform: `rotate(${i ? 22 : 18}deg)`,
								offset: .58
							},
							{ transform: "rotate(8deg)" }
						], i ? 155 : 115, "ease-out"), e.style.transform = "", Promise.allSettled(e.getAnimations().map((e) => e.finished)).then(() => {
							c === r && (e.dataset.phase = "idle");
						}));
					}));
				}
			}
		}
		a(d);
	}
	return {
		reset: o,
		strike: s
	};
}
//#endregion
//#region src/presentation-v3/impact.ts
var rn = Object.freeze({
	standard: {
		tones: [
			139,
			947,
			2381
		],
		duration: .18,
		type: "triangle",
		fall: .72
	},
	heavy: {
		tones: [
			89,
			631,
			1723
		],
		duration: .29,
		type: "triangle",
		fall: .6
	},
	damage: {
		tones: [
			197,
			1499,
			3167
		],
		duration: .2,
		fall: .44
	},
	broken: {
		tones: [
			173,
			467,
			2279
		],
		duration: .4,
		type: "triangle",
		fall: .18
	}
});
function an(e, t) {
	return {
		x: Math.max(.27, Math.min(.85, t ? (t.clientX - e.left) / Math.max(1, e.width) : .58)),
		y: Math.max(.54, Math.min(.64, t ? (t.clientY - e.top) / Math.max(1, e.height) : .6))
	};
}
function on(e, t) {
	let n = {
		x: .58,
		y: .6
	}, r = null, i = nn(e.hammer, t.reduced, t.animate), a = Array.from({ length: 36 }, () => Y("i"));
	e.sparks.replaceChildren(...a);
	function o(r) {
		n = t.project?.(r) ?? r, e.scene.style.setProperty("--aim-x", `${n.x * 100}%`), e.scene.style.setProperty("--aim-y", `${n.y * 100}%`);
	}
	o(n);
	function s() {
		e.scene.classList.remove("bursting", "striking"), e.scene.removeAttribute("data-outcome"), e.badge.textContent = "", e.float.textContent = "";
	}
	function c() {
		r !== null && clearTimeout(r), r = null, i.reset(), e.scene.classList.remove("aiming"), s();
	}
	function l(e, t, n) {
		i.strike(e.result === "great", () => u(e, t, n));
	}
	function u(n, i, o) {
		r !== null && clearTimeout(r), r = setTimeout(() => {
			r = null, s();
		}, 600);
		let c = n.result === "great", l = n.result === "crack" || n.result === "broken", u = n.result === "broken";
		e.scene.dataset.outcome = n.result, e.scene.classList.add("striking");
		let d = n.after - n.before;
		if (e.badge.textContent = o > 1 ? `连锻 ${i + 1}/${o}` : c ? "大成！" : u ? "断裂" : l ? "裂纹警告" : "锻成", e.float.textContent = `${d >= 0 ? "+" : "−"}${Math.abs(d).toLocaleString("zh-CN")} 身价`, e.scene.style.setProperty("--hit-color", l ? "#ff7851" : c ? "#fff1a6" : "#ffba61"), t.cue(u ? "broken" : l ? "damage" : c ? "heavy" : "standard"), t.reduced()) {
			e.scene.classList.remove("striking");
			return;
		}
		t.animate(e.canvas, [
			{ transform: "translate(0,0)" },
			{
				transform: `translate(${l ? -4 : 3}px,4px)`,
				offset: .28
			},
			{
				transform: "translate(-2px,-2px)",
				offset: .43
			},
			{
				transform: "translate(1px,1px)",
				offset: .62
			},
			{ transform: "translate(0,0)" }
		], l ? 270 : 180), t.animate(e.glow, [
			{
				opacity: 0,
				transform: "translate(-50%,-50%) scale(.3)"
			},
			{
				opacity: c ? .95 : .65,
				offset: .18
			},
			{
				opacity: 0,
				transform: "translate(-50%,-50%) scale(1.25)"
			}
		], c ? 460 : 260), t.animate(e.ring, [{
			opacity: .9,
			transform: "translate(-50%,-50%) scale(.15)"
		}, {
			opacity: 0,
			transform: `translate(-50%,-50%) scale(${c ? 2.8 : 1.7})`
		}], c ? 420 : 260), t.animate(e.value, [
			{ transform: "scale(1)" },
			{
				transform: `scale(${c ? 1.14 : 1.065})`,
				offset: .24
			},
			{ transform: "scale(1)" }
		], c ? 350 : 230), t.animate(e.float, [
			{
				opacity: 0,
				transform: "translate(-50%,10px) scale(.8)"
			},
			{
				opacity: 1,
				offset: .18,
				transform: "translate(-50%,-8px) scale(1.12)"
			},
			{
				opacity: 1,
				offset: .68
			},
			{
				opacity: 0,
				transform: "translate(-50%,-70px) scale(1)"
			}
		], o > 1 ? 270 : 540), t.animate(e.badge, [
			{
				opacity: 0,
				transform: "translate(-50%,4px) scale(.8)"
			},
			{
				opacity: 1,
				offset: .15
			},
			{
				opacity: 1,
				offset: .75
			},
			{
				opacity: 0,
				transform: "translate(-50%,-18px) scale(1.1)"
			}
		], o > 1 ? 250 : 500);
		let f = u ? 28 : c ? 36 : 22;
		for (let [e, n] of a.entries()) {
			if (e >= f) continue;
			let r = -Math.PI + e / (f - 1) * Math.PI, i = 35 + e * 29 % 100 + (c ? 38 : 0), a = Math.cos(r) * i, o = Math.sin(r) * i + (u ? 60 : 0);
			n.style.background = u ? e % 2 ? "#66808b" : "#e1a76e" : l ? "#ef865e" : e % 3 ? "#ffca77" : "#fff3bf", n.style.width = `${u ? 5 + e % 7 : 2 + e % 3}px`, n.style.height = `${u ? 5 + e % 9 : 5 + e % 8}px`, t.animate(n, [
				{
					opacity: 0,
					transform: "translate(0,0) rotate(0deg)"
				},
				{
					opacity: 1,
					offset: .08
				},
				{
					opacity: 1,
					offset: .55
				},
				{
					opacity: 0,
					transform: `translate(${a}px,${o}px) rotate(${e * 73}deg)`
				}
			], u ? 600 : 270 + e % 4 * 50);
		}
	}
	return {
		position: o,
		refresh: () => o(n),
		point: () => n,
		reset: c,
		aim(t) {
			t ? (o(an(e.scene.getBoundingClientRect(), t)), e.scene.classList.add("aiming")) : (e.scene.classList.remove("aiming"), o({
				x: .58,
				y: .6
			}));
		},
		start(t, r) {
			o(an(e.scene.getBoundingClientRect(), t)), e.scene.style.setProperty("--hit-x", `${n.x * 100}%`), e.scene.style.setProperty("--hit-y", `${n.y * 100}%`), e.scene.classList.toggle("bursting", r);
		},
		contact: l
	};
}
//#endregion
//#region src/presentation-v3/art.ts
var sn = [
	"blade-jian-v2",
	"blade-dao-v2",
	"blade-cleaver-v1"
], cn = [
	"steady",
	"ember",
	"inherit",
	"echo",
	"crackedEdge",
	"pardon"
];
function ln(e) {
	let t = Y("span", void 0, `v3-trait-art trait-${e}`);
	t.setAttribute("aria-hidden", "true");
	let n = cn.indexOf(e);
	return t.style.backgroundPosition = `${n % 3 * 50}% ${Math.floor(n / 3) * 100}%`, t;
}
//#endregion
//#region src/presentation-v5/shell.ts
var un = "\n<div class=\"v4-app v5-app\" data-screen=\"title\" data-rules-version=\"forge-v5\">\n  <section id=\"v4-title\" class=\"v4-title-screen\" aria-labelledby=\"v4-main-title\">\n    <div class=\"v4-title-copy\">\n      <p class=\"v4-edition\">v0.8 炉边报价 · 三柄行囊</p>\n      <h1 id=\"v4-main-title\">锤下<span>求生</span></h1>\n      <p class=\"v4-title-line\">一炉火，一柄剑，一程未熄的灯。</p>\n      <div class=\"v4-title-actions\">\n        <button id=\"v4-start\" class=\"v4-primary\" type=\"button\">提灯启程<span>开一炉新火</span></button>\n        <button id=\"v4-continue\" class=\"v4-secondary\" type=\"button\" hidden>继续行旅</button>\n      </div>\n      <div class=\"v4-title-links\">\n        <button id=\"v4-title-collection\" class=\"v4-text-button\" type=\"button\">翻开炉谱</button>\n        <button id=\"v4-title-challenge\" class=\"v4-text-button\" type=\"button\" hidden>行脚挑战</button>\n        <button id=\"v4-title-settings\" class=\"v4-text-button\" type=\"button\">炉边设置</button>\n      </div>\n      <a id=\"v5-old-v4\" class=\"v5-old-journey\" href=\"/v4.html\">续走旧行程<span>保留原来的炉火与进度</span></a>\n      <details class=\"v4-journey-options\">\n        <summary>行旅种子与更早旧路</summary>\n        <label for=\"v4-seed\">行旅种子<span>相同种子会走过相同的际遇</span></label>\n        <input id=\"v4-seed\" maxlength=\"64\" autocomplete=\"off\" spellcheck=\"false\" placeholder=\"留空，踏上一条新路\">\n        <a id=\"v4-old-v3\" href=\"/v3.html\">续玩旧版契约</a>\n      </details>\n    </div>\n    <p class=\"v4-title-footnote\">左键落锤，拖剑交客。好剑总有它要去的地方。</p>\n  </section>\n\n  <main id=\"v4-workshop\" class=\"v4-workshop\" hidden aria-label=\"行脚灯炉\">\n    <div class=\"v4-bench-mark\" aria-hidden=\"true\"><strong>锤下求生</strong><span>v0.8 炉边报价 · 三柄行囊</span></div>\n    <div class=\"v4-purse\" aria-label=\"契印与行囊\">\n      <div class=\"v4-resource v4-resource-seals\"><span>契印</span><strong id=\"v4-seals\"></strong></div>\n      <div class=\"v4-resource v4-resource-coins\"><span>铜钱</span><strong id=\"v4-coins\"></strong></div>\n    </div>\n\n    <aside class=\"v4-rack\" aria-label=\"炉边剑架\">\n      <h2>候火的剑</h2>\n      <p class=\"v4-rack-hint\">拿起剑，拖给来客</p>\n      <div id=\"v4-inventory\" class=\"v4-inventory\"></div>\n      <section id=\"v4-reserve-zone\" class=\"v4-kept-sword\" data-handoff-target=\"rack\" aria-label=\"留给明天的剑\">\n        <h3 id=\"v5-rack-title\">留一把，待明日</h3>\n        <div id=\"v4-reserve-slot\"></div>\n        <p id=\"v5-slot-plan\" class=\"v5-slot-plan\"></p>\n        <button id=\"v4-next-plan\" class=\"v4-next-plan\" type=\"button\">明日打算</button>\n      </section>\n      <div class=\"v4-rack-actions\">\n        <button id=\"v4-reserve\" type=\"button\">挂上剑架</button>\n        <div id=\"v4-recipes\" aria-label=\"配方选择\"></div>\n      </div>\n    </aside>\n\n    <div id=\"v4-scene\" class=\"v4-scene\" aria-label=\"铁砧与当前兵器\">\n      <canvas id=\"v4-blade\" aria-label=\"当前兵器外观\"></canvas>\n      <button id=\"v4-hit\" type=\"button\" aria-label=\"在剑身上落锤\"></button>\n      <div id=\"v4-impact-glow\" aria-hidden=\"true\"></div>\n      <div id=\"v4-impact-ring\" aria-hidden=\"true\"></div>\n      <div id=\"v4-reticle\" aria-hidden=\"true\"></div>\n      <div id=\"v4-sparks\" aria-hidden=\"true\"></div>\n      <div id=\"v4-hammer\" aria-hidden=\"true\"><img alt=\"\" draggable=\"false\"></div>\n      <div id=\"v4-float\" aria-hidden=\"true\"></div>\n      <div id=\"v4-impact-badge\" aria-hidden=\"true\"></div>\n    </div>\n\n    <section class=\"v4-forge-plan\" aria-label=\"眼前的打造打算\">\n      <strong id=\"v4-plan-line\">这一锤，自己拿主意</strong>\n      <p id=\"v4-plan-copy\">敲出身价，也看清下一锤的风险。</p>\n    </section>\n\n    <section class=\"v4-blade-reading\" aria-label=\"当前剑的估值与状况\">\n      <p class=\"v4-value-line\"><span>作品估值</span><strong id=\"v4-value\"></strong><span id=\"v4-condition\"></span></p>\n      <p id=\"v5-value-meaning\" class=\"v5-value-meaning\">验剑看估值，收款看右侧报价</p>\n      <p id=\"v4-craft-record\"></p>\n      <div class=\"v4-next-hit\"><p id=\"v4-risk\"></p><p id=\"v4-charge\"></p></div>\n      <div id=\"v4-ember-meter\" class=\"v4-ember-meter\" aria-hidden=\"true\">\n        <i data-ember-index=\"0\"></i><i data-ember-index=\"1\"></i><i data-ember-index=\"2\"></i>\n        <i data-ember-index=\"3\"></i><i data-ember-index=\"4\"></i><i data-ember-index=\"5\"></i>\n      </div>\n      <button id=\"v4-strike\" class=\"v4-strike-button\" type=\"button\">落锤<span>左键剑身 / 空格</span></button>\n    </section>\n\n    <aside id=\"v4-customer-zone\" class=\"v4-customer\" data-handoff-target=\"customer\" aria-label=\"等剑的来客与委托\">\n      <button id=\"v4-customer-open\" class=\"v4-person-target\" type=\"button\" aria-haspopup=\"dialog\" aria-label=\"和来客聊聊\" aria-describedby=\"v4-talk\">\n        <span id=\"v4-customer-figure\" class=\"v4-customer-figure\" data-pose=\"waiting\" role=\"img\">\n          <span class=\"v4-customer-fallback\" aria-hidden=\"true\"></span>\n          <span class=\"v4-customer-sprite\" aria-hidden=\"true\"></span>\n        </span>\n        <span class=\"v4-customer-nameplate\"><b id=\"v4-customer-name\"></b><small>点来客，听听心愿</small></span>\n      </button>\n      <header class=\"v4-objective\">\n        <p id=\"v4-day\" class=\"v4-eyebrow\"></p>\n        <h1 id=\"v4-goal-name\"></h1>\n        <p id=\"v4-goal-condition\"></p>\n        <div id=\"v4-order-routes\"></div>\n        <p id=\"v4-goal-progress\" class=\"v4-goal-progress\"></p>\n        <p id=\"v5-order-pay\" class=\"v5-order-pay\"></p>\n      </header>\n      <p id=\"v4-talk\" class=\"v4-customer-wish\"></p>\n      <section id=\"v4-inline-delivery\" class=\"v4-inline-delivery\" hidden aria-live=\"polite\" aria-label=\"来客收剑回执\">\n        <img id=\"v4-inline-image\" alt=\"这次交出的兵器\">\n        <h2 id=\"v4-inline-title\"></h2>\n        <p id=\"v4-inline-copy\"></p>\n        <p id=\"v5-inline-payment\" class=\"v5-inline-payment\"></p>\n        <button id=\"v4-inline-review\" type=\"button\">回看这一站</button>\n        <button id=\"v4-inline-dismiss\" class=\"v4-close\" type=\"button\" aria-label=\"收好这张回执\">×</button>\n      </section>\n      <button id=\"v4-deliver\" class=\"v4-primary v4-deliver-button\" type=\"button\">把剑交给来客</button>\n      <button id=\"v5-delivery-quote\" class=\"v5-delivery-quote\" type=\"button\" aria-haspopup=\"dialog\" aria-label=\"查看估值与实收说明\"></button>\n      <button id=\"v5-arrange\" class=\"v5-arrange-link\" type=\"button\" hidden>钱袋已空 · 安排这柄剑</button>\n      <div class=\"v4-visiting-actions\">\n        <button id=\"v4-shop\" type=\"button\" hidden>行脚商人的摊子</button>\n        <button id=\"v4-event-open\" type=\"button\" hidden>炉边来信</button>\n      </div>\n      <p id=\"v4-shop-help\" class=\"v4-shop-help\"></p>\n    </aside>\n\n    <div id=\"v4-modifications\" class=\"v4-modifications v4-furnishings\" aria-label=\"已装炉具\"></div>\n    <section class=\"v4-travel-props\" aria-label=\"随身手艺与炉具\">\n      <div id=\"v4-traits\" class=\"v4-traits\"></div>\n      <div id=\"v4-gift\" class=\"v4-gift\"></div>\n    </section>\n    <button id=\"v4-scrap\" class=\"v4-ground-action\" type=\"button\">回收这柄剑</button>\n    <button id=\"v4-settle\" class=\"v4-settle-button\" type=\"button\">收工，封炉<span>看看今日的收成</span></button>\n  </main>\n\n  <section id=\"v4-stage\" class=\"v4-stage\" hidden aria-labelledby=\"v4-stage-title\">\n    <div class=\"v4-stage-view\"><img id=\"v4-stage-image\" alt=\"\"></div>\n    <div class=\"v4-stage-story\">\n      <p class=\"v4-eyebrow\">灯炉行记</p>\n      <h1 id=\"v4-stage-title\" tabindex=\"-1\"></h1>\n      <div id=\"v4-stage-copy\" class=\"v4-stage-copy\"></div>\n      <div id=\"v4-stage-actions\" class=\"v4-stage-actions\"></div>\n    </div>\n  </section>\n\n  <nav id=\"v4-tools\" class=\"v4-tools\" aria-label=\"行旅工具\">\n    <button id=\"v4-menu\" type=\"button\" aria-label=\"暂停与行旅菜单\">行囊</button>\n    <button id=\"v4-book\" type=\"button\" aria-label=\"打开炉谱\">炉谱</button>\n    <button id=\"v4-settings\" type=\"button\" aria-label=\"打开设置\">设置</button>\n    <button id=\"v4-save-open\" type=\"button\" aria-label=\"查看保存详情\">存档</button>\n  </nav>\n\n  <section id=\"v4-notice\" class=\"v4-notice\" hidden aria-labelledby=\"v4-notice-title\">\n    <div class=\"v4-notice-mark\" aria-hidden=\"true\"></div>\n    <div class=\"v4-notice-content\"><h2 id=\"v4-notice-title\"></h2><p id=\"v4-notice-copy\"></p><button id=\"v4-notice-action\" type=\"button\" hidden>查看</button></div>\n    <button id=\"v4-notice-dismiss\" class=\"v4-close\" type=\"button\" aria-label=\"收起这条炉边消息\">×</button>\n  </section>\n\n  <section id=\"v4-save-banner\" class=\"v4-save-banner\" hidden aria-label=\"保存状态\">\n    <p id=\"v4-save-summary\"></p><button id=\"v4-save-details\" class=\"v4-text-button\" type=\"button\">查看保存详情</button>\n  </section>\n  <p id=\"v4-status\" class=\"v4-status\" role=\"status\" aria-live=\"polite\" aria-atomic=\"true\"></p>\n\n  <dialog id=\"v4-dialog\" aria-labelledby=\"v4-dialog-title\">\n    <h2 id=\"v4-dialog-title\"></h2>\n    <div id=\"v4-dialog-body\"></div>\n    <div id=\"v4-dialog-actions\"></div>\n  </dialog>\n  <div id=\"v4-effects\" class=\"v4-effects\" aria-hidden=\"true\"></div>\n</div>";
//#endregion
//#region src/presentation-v3/appearance.ts
function dn(e) {
	let t = Math.max(0, Math.min(2, Number(e.id.split("-").at(-1)) - 1)), n = Number.isInteger(t) ? t : 0, r = e.level >= 9 ? 4 : e.level >= 6 ? 3 : e.level >= 3 ? 2 : +(e.level >= 1);
	return {
		family: n,
		stage: r,
		name: [
			"青云剑",
			"赤羽刀",
			"镇岳重剑"
		][n],
		rank: [
			"乌铁坯",
			"初开锋",
			"叠纹",
			"流火",
			"灯炉名器"
		][r]
	};
}
//#endregion
//#region src/presentation-v3/art-data.ts
var fn = [
	[
		[
			30,
			76,
			1488,
			146
		],
		[
			30,
			242,
			1488,
			168
		],
		[
			30,
			416,
			1488,
			180
		],
		[
			30,
			590,
			1488,
			182
		],
		[
			30,
			772,
			1488,
			183
		]
	],
	[
		[
			30,
			18,
			1490,
			180
		],
		[
			30,
			208,
			1490,
			188
		],
		[
			30,
			396,
			1490,
			202
		],
		[
			30,
			599,
			1490,
			197
		],
		[
			30,
			797,
			1490,
			202
		]
	],
	[
		[
			36,
			60,
			1474,
			144
		],
		[
			36,
			238,
			1474,
			160
		],
		[
			36,
			420,
			1474,
			173
		],
		[
			36,
			604,
			1474,
			173
		],
		[
			36,
			785,
			1474,
			185
		]
	]
];
//#endregion
//#region src/presentation-v3/blade.ts
function pn(e, t, n, r) {
	let i = e.clientWidth, a = e.clientHeight;
	if (!i || !a) return;
	let o = Math.min(2, devicePixelRatio || 1);
	e.width = Math.round(i * o), e.height = Math.round(a * o);
	let s = e.getContext("2d");
	if (!s || (s.scale(e.width / 1100, e.height / 400), s.clearRect(0, 0, 1100, 400), !t)) return;
	let c = dn(t);
	if (e.dataset.family = String(c.family), e.dataset.stage = String(c.stage), e.dataset.illustrated = String(!!r), e.dataset.condition = t.status === "broken" ? "broken" : t.cracked ? "cracked" : "intact", r) {
		let [e, n, i, a] = fn[c.family][c.stage], o = Math.min(174, 1e3 * a / i), l = 240 - o * .5;
		s.save(), s.shadowColor = "#000b", s.shadowBlur = 18, s.fillStyle = "#08121499", s.beginPath(), s.ellipse(575, 320, 440, 17, 0, 0, Math.PI * 2), s.fill(), s.restore();
		let u = () => s.drawImage(r, e, n, i, a, 32, l, 1e3, o);
		if (t.status === "broken" ? (s.save(), s.beginPath(), s.moveTo(0, 0), s.lineTo(644, 0), s.lineTo(644, 230), s.lineTo(623, 245), s.lineTo(657, 260), s.lineTo(638, 400), s.lineTo(0, 400), s.closePath(), s.clip(), u(), s.restore(), s.save(), s.translate(650, 255), s.rotate(.13), s.translate(-635, -203), s.beginPath(), s.moveTo(650, 0), s.lineTo(1100, 0), s.lineTo(1100, 400), s.lineTo(640, 400), s.lineTo(659, 260), s.lineTo(625, 245), s.lineTo(650, 230), s.closePath(), s.clip(), s.globalAlpha = .65, u(), s.restore()) : u(), t.cracked || t.status === "broken") {
			let e = t.status === "broken" ? 640 : 520 + c.family * 45;
			s.save(), s.strokeStyle = "#080c0e", s.lineWidth = 7, s.beginPath(), s.moveTo(e, l + 18), s.lineTo(e - 10, 230), s.lineTo(e + 16, 245), s.lineTo(e - 7, 259), s.lineTo(e + 5, l + o - 8), s.stroke(), s.strokeStyle = "#ff8253", s.lineWidth = 2, s.shadowBlur = 7, s.shadowColor = "#ff7536", s.stroke(), s.restore();
		}
		return;
	}
	let l = Math.min(5, Math.floor(t.level / 3)), u = l * 6, d = t.status === "broken" ? 650 : 1020;
	s.save(), s.shadowColor = "#000", s.shadowBlur = 24, s.fillStyle = "#0a1113bb", s.beginPath(), s.ellipse(590, 310, 450, 22, 0, 0, Math.PI * 2), s.fill(), s.restore(), s.fillStyle = "#4b2b20", s.strokeStyle = "#ba8850", s.lineWidth = 3, s.fillRect(32, 223, 170, 38), s.strokeRect(32, 223, 170, 38);
	for (let e = 40; e < 195; e += 17) s.strokeStyle = "#c0a175", s.beginPath(), s.moveTo(e, 224), s.lineTo(e - 12, 260), s.stroke();
	s.fillStyle = "#d6ab5f", s.beginPath(), s.roundRect(190, 204, 24, 78, 5), s.fill();
	let f = new Path2D();
	f.moveTo(211, 218 - u), f.lineTo(d - 90, 217 - u), f.quadraticCurveTo(d - 20, 206 - u, d, 188 - u), f.lineTo(d - 38, 263), f.quadraticCurveTo(640, 302 + u, 212, 263), f.closePath();
	let p = s.createLinearGradient(0, 190, 0, 295);
	p.addColorStop(0, "#d5e1de"), p.addColorStop(.3, "#475b69"), p.addColorStop(.55, "#293c4b"), p.addColorStop(.83, t.level > 0 ? "#e58c42" : "#9aa6a6"), p.addColorStop(1, t.level > 0 ? "#ffd8a0" : "#ded9c6"), s.fillStyle = p, s.strokeStyle = "#dccb9b", s.lineWidth = 3, s.fill(f), s.stroke(f), s.save(), s.clip(f), n && (s.globalAlpha = .3, s.globalCompositeOperation = "soft-light", s.drawImage(n, 210, 155, 830, 160), s.globalAlpha = 1, s.globalCompositeOperation = "source-over"), s.strokeStyle = t.level > 0 ? "#ffbc65" : "#607785", s.lineWidth = 2, s.shadowColor = "#f07826", s.shadowBlur = t.level > 0 ? 12 : 0;
	for (let e = 0; e < l + 1; e++) {
		s.beginPath(), s.moveTo(220, 258 - e * 4);
		for (let t = 240; t < 1040; t += 24) s.lineTo(t, 257 - e * 5 + Math.sin(t * .027 + e) * 5);
		s.stroke();
	}
	(t.cracked || t.status === "broken") && (s.shadowBlur = 0, s.strokeStyle = "#171717", s.lineWidth = 5, s.beginPath(), s.moveTo(490, 202 - u), s.lineTo(515, 229), s.lineTo(501, 238), s.lineTo(539, 265), s.lineTo(531, 297), s.stroke(), s.strokeStyle = "#ffa44b", s.lineWidth = 1, s.stroke()), s.restore(), t.status === "broken" && (s.fillStyle = "#68727a", s.beginPath(), s.moveTo(738, 279), s.lineTo(920, 266), s.lineTo(823, 301), s.lineTo(751, 304), s.closePath(), s.fill());
}
//#endregion
//#region src/presentation-v3/surface-data.ts
var mn = [
	[
		[
			.544556,
			.544556,
			.546237,
			.547917,
			.549597,
			.551277,
			.552957,
			.554637,
			.556317,
			.557997,
			.559677,
			.561358,
			.563038,
			.563038,
			.564718,
			.566398,
			.568078,
			.569758,
			.571438,
			.573118,
			.574798
		],
		[
			.539516,
			.541196,
			.542876,
			.542876,
			.544556,
			.546237,
			.547917,
			.547917,
			.549597,
			.549597,
			.551277,
			.552957,
			.552957,
			.554637,
			.556317,
			.556317,
			.557997,
			.559677,
			.561358,
			.561358,
			.563038
		],
		[
			.542876,
			.544556,
			.544556,
			.546237,
			.547917,
			.549597,
			.551277,
			.552957,
			.552957,
			.554637,
			.556317,
			.557997,
			.559677,
			.559677,
			.561358,
			.563038,
			.564718,
			.566398,
			.566398,
			.568078,
			.569758
		],
		[
			.537836,
			.539516,
			.541196,
			.542876,
			.544556,
			.546237,
			.547917,
			.549597,
			.551277,
			.552957,
			.554637,
			.556317,
			.556317,
			.557997,
			.559677,
			.561358,
			.563038,
			.564718,
			.566398,
			.569758,
			.571438
		],
		[
			.531956,
			.533636,
			.535316,
			.535316,
			.536996,
			.538676,
			.538676,
			.540356,
			.542036,
			.543716,
			.545397,
			.545397,
			.547077,
			.547077,
			.548757,
			.550437,
			.552117,
			.553797,
			.555477,
			.557157,
			.558837
		]
	],
	[
		[
			.558054,
			.563087,
			.566443,
			.571477,
			.57651,
			.581544,
			.584899,
			.588255,
			.593289,
			.596644,
			.6,
			.603356,
			.605034,
			.606711,
			.606711,
			.605034,
			.603356,
			.6,
			.594966,
			.589933,
			.583221
		],
		[
			.563087,
			.568121,
			.573154,
			.578188,
			.583221,
			.588255,
			.593289,
			.596644,
			.6,
			.603356,
			.605034,
			.606711,
			.608389,
			.608389,
			.606711,
			.605034,
			.603356,
			.6,
			.594966,
			.588255,
			.579866
		],
		[
			.566443,
			.573154,
			.578188,
			.583221,
			.589933,
			.594966,
			.6,
			.603356,
			.606711,
			.611745,
			.613423,
			.616779,
			.618456,
			.620134,
			.620134,
			.618456,
			.616779,
			.613423,
			.608389,
			.601678,
			.593289
		],
		[
			.54547,
			.552181,
			.558893,
			.567282,
			.573993,
			.580705,
			.585738,
			.59245,
			.597483,
			.602517,
			.60755,
			.610906,
			.612584,
			.61594,
			.61594,
			.614262,
			.612584,
			.609228,
			.604195,
			.597483,
			.589094
		],
		[
			.516107,
			.524497,
			.532886,
			.541275,
			.549664,
			.558054,
			.564765,
			.569799,
			.57651,
			.581544,
			.586577,
			.589933,
			.593289,
			.594966,
			.596644,
			.596644,
			.594966,
			.591611,
			.584899,
			.578188,
			.568121
		]
	],
	[
		[
			.511805,
			.511805,
			.515197,
			.511805,
			.511805,
			.511805,
			.511805,
			.510109,
			.510109,
			.513501,
			.511805,
			.511805,
			.513501,
			.513501,
			.513501,
			.515197,
			.515197,
			.515197,
			.515197,
			.516893,
			.516893
		],
		[
			.499932,
			.499932,
			.501628,
			.501628,
			.501628,
			.501628,
			.501628,
			.501628,
			.50502,
			.50502,
			.50502,
			.50502,
			.50502,
			.506716,
			.506716,
			.506716,
			.506716,
			.508412,
			.508412,
			.508412,
			.510109
		],
		[
			.509261,
			.509261,
			.509261,
			.509261,
			.510957,
			.510957,
			.510957,
			.512653,
			.512653,
			.512653,
			.512653,
			.512653,
			.514349,
			.514349,
			.514349,
			.514349,
			.516045,
			.516045,
			.516045,
			.516045,
			.516045
		],
		[
			.504172,
			.505868,
			.507564,
			.509261,
			.510957,
			.512653,
			.514349,
			.516045,
			.517741,
			.519437,
			.521133,
			.522829,
			.524525,
			.526221,
			.527917,
			.527917,
			.529613,
			.531309,
			.533005,
			.534701,
			.536398
		],
		[
			.495692,
			.497388,
			.50078,
			.502476,
			.504172,
			.507564,
			.509261,
			.510957,
			.512653,
			.516045,
			.517741,
			.519437,
			.521133,
			.522829,
			.524525,
			.526221,
			.527917,
			.529613,
			.531309,
			.531309,
			.533005
		]
	]
];
//#endregion
//#region src/presentation-v3/surface.ts
function hn(e, t, n) {
	let r = Math.max(.36, Math.min(.82, t.x));
	if (!e) return {
		x: r,
		y: .6
	};
	if (!n) return {
		x: r,
		y: (218 - 6 * Math.min(5, Math.floor(e.level / 3))) / 400
	};
	let i = dn(e), a = mn[i.family][i.stage], o = (r - .36) / .46 * 20, s = Math.min(19, Math.floor(o)), c = o - s;
	return {
		x: r,
		y: a[s] * (1 - c) + a[s + 1] * c
	};
}
//#endregion
//#region src/presentation-v4/forge.ts
var gn = Object.freeze({
	light: 0,
	guard: 1,
	heavy: 2
}), _n = [
	"windbox",
	"warmRack",
	"wideMouth"
], vn = [
	"donation",
	"loan",
	"salvage",
	"credit",
	"shelter",
	"rest"
];
function yn(e) {
	let t = gn[e.recipe], n = e.level >= 9 ? 4 : e.level >= 6 ? 3 : e.level >= 3 ? 2 : +(e.level >= 1);
	return {
		family: t,
		stage: n,
		name: [
			"青云轻刃",
			"巡灯护刃",
			"镇岳重锋"
		][t],
		rank: [
			"乌铁坯",
			"初开锋",
			"叠纹",
			"流火",
			"灯炉名器"
		][n]
	};
}
function bn(e) {
	return {
		id: `display-${gn[e.recipe] + 1}`,
		suppliedRound: e.suppliedDay,
		status: e.status === "broken" ? "broken" : e.status === "active" ? "active" : e.status === "recycled" ? "recycled" : e.status === "traded" ? "traded" : "delivered",
		base: e.base,
		value: e.value,
		peak: e.peak,
		level: e.level,
		cracked: e.cracked,
		hits: e.hits,
		charge: e.charge,
		successes: e.successes,
		finalizedRound: e.finalizedDay
	};
}
function xn(e, t, n, r, i) {
	let a = Math.max(1, r.width), o = Math.max(1, r.height), s = Math.max(1, i.width), c = Math.max(1, i.height), l = {
		x: (r.left + t.x * a - i.left) / s,
		y: t.y
	}, u = hn(e ? bn(e) : null, l, n);
	return {
		x: (i.left + u.x * s - r.left) / a,
		y: (i.top + u.y * c - r.top) / o
	};
}
function Sn(e, t) {
	let n = (t) => {
		let n = e.querySelector(`#${t}`);
		if (!n) throw Error(`Missing forge surface: ${t}`);
		return n;
	}, r = n("v4-scene"), i = n("v4-blade"), a = n("v4-hammer"), o = a.querySelector("img");
	if (!o) throw Error("Missing forge hammer image");
	let s = !1, c = 0, l = null, u = null, d = null, f = null, p = null, m = /* @__PURE__ */ new Set(), h = /* @__PURE__ */ new Map(), g = /* @__PURE__ */ new WeakMap(), _ = /* @__PURE__ */ new Map(), v = (e) => {
		let t = h.get(e);
		return _.get(e)?.status === "ready" && t?.complete && t.naturalWidth > 0 ? t : void 0;
	}, y = (e) => e ? v(sn[gn[e.recipe]]) : void 0, b = (e) => {
		let t = _.get(e), n = t?.image;
		return {
			name: e,
			attempt: t?.attempt ?? 0,
			status: t?.status ?? "absent",
			src: n?.getAttribute("src") ?? null,
			currentSrc: n?.currentSrc ?? "",
			complete: n?.complete ?? !1,
			width: n?.naturalWidth ?? 0,
			height: n?.naturalHeight ?? 0
		};
	};
	function x(e, t, n) {
		let r = e.clientWidth, i = e.clientHeight, a = devicePixelRatio || 1, o = Math.min(2, a);
		if (!r || !i) {
			g.delete(e), n();
			return;
		}
		let s = Math.round(r * o), c = Math.round(i * o), l = JSON.stringify([
			r,
			i,
			a,
			o,
			t
		]), u = g.get(e);
		(u?.key !== l || u.width !== s || u.height !== c || e.width !== s || e.height !== c) && (n(), e.width === s && e.height === c && e.getContext("2d") ? g.set(e, {
			key: l,
			width: s,
			height: c
		}) : g.delete(e));
	}
	function S(e, t) {
		let n = t ? bn(t) : null, r = t ? sn[gn[t.recipe]] : null;
		x(e, [
			"blade",
			n,
			b("metal-atlas-v1"),
			r ? b(r) : null
		], () => pn(e, n, v("metal-atlas-v1"), y(t)));
	}
	let C = on({
		scene: r,
		canvas: i,
		hammer: a,
		sparks: n("v4-sparks"),
		glow: n("v4-impact-glow"),
		ring: n("v4-impact-ring"),
		reticle: n("v4-reticle"),
		float: n("v4-float"),
		badge: n("v4-impact-badge"),
		value: n("v4-value")
	}, {
		reduced: t.reduced,
		animate: (e, n, r, i = "ease-out") => {
			if (!(s || t.reduced() || document.hidden)) try {
				let t = e.animate(n, {
					duration: r,
					easing: i
				});
				m.add(t), t.finished.then(() => m.delete(t), () => m.delete(t));
			} catch {}
		},
		cue: (e) => {
			if (s || !p) return;
			let n = p.event.hits[p.index];
			if (n && u) {
				let e = Object.freeze({ ...f ?? u });
				f = {
					...u,
					value: n.after,
					level: n.level,
					cracked: n.result === "crack" || n.result === "broken" || (f?.cracked ?? !1),
					status: n.result === "broken" ? "broken" : "active"
				}, A(), p.touched = !0, ee(), t.contact?.({
					pieceId: p.event.pieceId,
					hit: n,
					index: p.index,
					total: p.event.hits.length,
					burst: p.event.burst,
					before: e,
					after: Object.freeze({ ...f })
				});
			}
			t.cue(e);
		},
		project: (e) => xn(f, e, !!y(f), r.getBoundingClientRect(), i.getBoundingClientRect())
	}), w = document.createElement("canvas");
	w.className = "v4-hammer-fallback", w.width = 1536, w.height = 1024, w.setAttribute("aria-hidden", "true"), a.append(w);
	let T = w.getContext("2d");
	if (T) {
		let e = T.createLinearGradient(0, 455, 0, 575);
		e.addColorStop(0, "#a67c45"), e.addColorStop(.5, "#724d2c"), e.addColorStop(1, "#3d2c22"), T.fillStyle = e, T.strokeStyle = "#211e1b", T.lineWidth = 18, T.beginPath(), T.roundRect(270, 455, 1215, 120, 35), T.fill(), T.stroke(), T.strokeStyle = "#2b3940", T.lineWidth = 32;
		for (let e = 1175; e < 1450; e += 44) T.beginPath(), T.moveTo(e, 456), T.lineTo(e - 36, 574), T.stroke();
		let t = T.createLinearGradient(93, 0, 345, 0);
		t.addColorStop(0, "#b4b6a3"), t.addColorStop(.2, "#4b5555"), t.addColorStop(.75, "#303e44"), t.addColorStop(1, "#19292f"), T.fillStyle = t, T.strokeStyle = "#d9c69b", T.lineWidth = 12, T.beginPath(), T.roundRect(94, 309, 211, 457, 12), T.fill(), T.stroke(), T.strokeStyle = "#efa85d", T.lineWidth = 6, T.beginPath(), T.moveTo(110, 766), T.lineTo(289, 766), T.stroke();
	}
	function E(e, n = !1) {
		if (s || e.status === "loading") return;
		e.detach(), e.status = "loading";
		let r = ++e.attempt;
		e.image === o && (a.dataset.art = "loading");
		let i = () => !s && e.attempt === r && e.status === "loading", c = () => {
			i() && e.image.complete && e.image.naturalWidth !== 0 && (e.status = "ready", e.detach(), e.image === o && (a.dataset.art = "ready"), A(), t.ready());
		}, l = () => {
			!i() || !e.image.complete || e.image.naturalWidth > 0 || (e.status = "failed", e.detach(), e.image === o && (a.dataset.art = "fallback"), A(), t.problem());
		};
		e.image.addEventListener("load", c), e.image.addEventListener("error", l), e.detach = () => {
			e.image.removeEventListener("load", c), e.image.removeEventListener("error", l);
		}, e.image.src = e.url + (n ? `?retry=${r - 1}` : "");
	}
	function D(e, t) {
		let n = {
			name: e,
			url: `/assets/d/${e}.webp`,
			image: t,
			status: "idle",
			attempt: 0,
			detach: () => {}
		};
		_.set(e, n), E(n);
	}
	function O() {
		return {
			loading: !s && [..._.values()].some((e) => e.status === "loading"),
			failed: Object.freeze(s ? [] : [..._.values()].filter((e) => e.status === "failed").map((e) => e.url))
		};
	}
	function k() {
		if (!(s || O().loading)) for (let e of _.values()) e.status === "failed" && E(e, !0);
	}
	D("hammer-forge-v2", o);
	function ee() {
		let e = C.point();
		r.style.setProperty("--hit-x", `${e.x * 100}%`), r.style.setProperty("--hit-y", `${e.y * 100}%`);
	}
	function A() {
		if (s) return;
		let e = f ? yn(f) : null;
		if (r.dataset.empty = String(!f), r.dataset.reduced = String(t.reduced()), i.setAttribute("aria-label", f ? `${e.name}，${e.rank}，等级${f.level}，身价${f.value}，${f.status === "broken" ? "断裂" : f.cracked ? "有裂纹" : "完好"}；仅造型展示` : "空铁砧"), !f) for (let e of [
			"family",
			"stage",
			"illustrated",
			"condition"
		]) delete i.dataset[e];
		S(i, f), C.refresh();
	}
	for (let e of [
		...sn,
		"metal-atlas-v1",
		"v07/modifications-v1",
		"v07/events-v1"
	]) {
		let t = new Image();
		h.set(e, t), D(e, t);
	}
	let te = typeof ResizeObserver > "u" ? null : new ResizeObserver(() => {
		s || A();
	});
	te?.observe(r);
	let ne = () => {
		document.hidden && j();
	};
	document.addEventListener("visibilitychange", ne);
	function j() {
		if (!s) {
			c++, p = null, l !== null && cancelAnimationFrame(l), l = null;
			for (let e of m) e.cancel();
			m.clear(), C.reset(), a.classList.remove("preparing"), s || (f = u, A());
		}
	}
	function re() {
		let e = p;
		if (!e || s || e.epoch !== c) return;
		let t = e.event.hits[e.index];
		if (!t) return;
		e.touched = !1;
		let n = {
			result: t.result,
			before: t.before,
			after: t.after,
			level: t.level,
			triggers: []
		};
		C.contact(n, e.index, e.event.hits.length);
	}
	function M() {
		l = null;
		let e = p;
		if (e && !s && e.epoch === c) {
			if (document.hidden || t.reduced()) j();
			else {
				if (e.touched && a.dataset.phase === "idle") {
					if (e.index++, e.index === e.event.hits.length) {
						p = null, f = u, A(), e.done();
						return;
					}
					re();
				}
				p && (l = requestAnimationFrame(M));
			}
		}
	}
	function ie(e) {
		s || (p && e?.id !== p.event.pieceId && j(), u !== e && (d = u), u = e, p || (f = e, A()));
	}
	function N(e, n, r, i) {
		if (s) return;
		j();
		let a = ++c;
		if (!u || u.id !== e.pieceId || !e.hits.length) {
			t.problem(), queueMicrotask(() => {
				!s && a === c && r();
			});
			return;
		}
		let o = e.hits[0];
		if (f = (i?.id === u.id && i.value === o.before ? i : null) ?? (d?.id === u.id && d.value === o.before ? d : {
			...u,
			value: o.before,
			cracked: o.result === "crack" ? !1 : o.result === "broken" || u.cracked,
			status: "active"
		}), A(), C.start(n, e.burst), p = {
			event: e,
			index: 0,
			touched: !1,
			done: r,
			epoch: a
		}, document.hidden) j();
		else if (t.reduced()) {
			for (let t = 0; t < e.hits.length; t++) {
				if (!p || a !== c) return;
				p.index = t, re();
			}
			p && a === c && (p = null, f = u, A(), queueMicrotask(() => {
				!s && a === c && r();
			}));
		} else re(), l = requestAnimationFrame(M);
	}
	function ae(e, t) {
		s || S(e, t);
	}
	function oe(e, t) {
		if (s) return;
		let n = _n.indexOf(t), r = n < 0 ? vn.indexOf(t) : n, i = n < 0 ? 2 : 1, a = n < 0 ? "v07/events-v1" : "v07/modifications-v1", o = v(a);
		e.dataset.prop = t, e.dataset.illustrated = String(!!o), x(e, [
			"prop",
			t,
			r,
			i,
			b(a)
		], () => {
			let n = e.clientWidth || 96, a = e.clientHeight || 96, s = Math.min(2, devicePixelRatio || 1);
			e.width = Math.round(n * s), e.height = Math.round(a * s);
			let c = e.getContext("2d");
			if (!c) return;
			c.clearRect(0, 0, e.width, e.height);
			let l = Math.min(e.width, e.height) / 120;
			if (c.translate((e.width - 120 * l) / 2, (e.height - 120 * l) / 2), c.scale(l, l), o && r >= 0) {
				let e = o.naturalWidth / 3, t = o.naturalHeight / i, n = Math.min(112 / e, 112 / t), a = e * n, s = t * n;
				c.drawImage(o, r % 3 * e, Math.floor(r / 3) * t, e, t, (120 - a) / 2, (120 - s) / 2, a, s);
			} else Cn(c, t);
		});
	}
	return {
		draw: ie,
		paintThumb: ae,
		paintProp: oe,
		play: N,
		retryAssets: k,
		assetStatus: O,
		aim(e) {
			!s && !p && C.aim(e);
		},
		preparing(e) {
			s || a.classList.toggle("preparing", e && !p);
		},
		cancel: j,
		dispose() {
			if (!s) {
				j(), s = !0, te?.disconnect(), document.removeEventListener("visibilitychange", ne);
				for (let e of _.values()) e.detach(), e.attempt++, e.status === "loading" && e.image.removeAttribute("src");
				_.clear(), h.clear(), g = /* @__PURE__ */ new WeakMap(), w.remove();
			}
		}
	};
}
function Cn(e, t) {
	e.lineWidth = 5, e.lineCap = "round", e.lineJoin = "round", e.strokeStyle = "#dab575", e.fillStyle = "#263c3c";
	let n = (t) => {
		e.beginPath(), t.forEach(([t, n], r) => r ? e.lineTo(t, n) : e.moveTo(t, n)), e.stroke();
	}, r = () => {
		e.fillStyle = "#adbfc0", e.beginPath(), e.moveTo(58, 15), e.lineTo(70, 43), e.lineTo(65, 80), e.lineTo(51, 80), e.lineTo(48, 43), e.closePath(), e.fill(), n([[38, 82], [79, 82]]), n([[59, 83], [59, 106]]);
	};
	if (t === "windbox") {
		e.fillStyle = "#765333", e.fillRect(20, 34, 72, 57);
		for (let e = 31; e < 87; e += 13) n([
			[e, 40],
			[e - 5, 62],
			[e, 85]
		]);
		n([
			[91, 47],
			[108, 57],
			[108, 72],
			[91, 80]
		]);
	} else if (t === "warmRack") {
		e.fillStyle = "#744b30", e.fillRect(15, 39, 91, 13);
		for (let e = 25; e < 105; e += 18) n([[e, 52], [e, 79]]);
		n([[23, 52], [23, 103]]), n([[97, 52], [97, 103]]), e.fillStyle = "#e98140", e.fillRect(28, 84, 63, 7);
	} else t === "wideMouth" ? (e.beginPath(), e.roundRect(14, 27, 93, 77, 9), e.fill(), e.stroke(), e.fillStyle = "#e7803e", e.beginPath(), e.roundRect(29, 47, 63, 41, 13), e.fill(), e.fillStyle = "#ffd396", e.beginPath(), e.moveTo(45, 87), e.lineTo(53, 59), e.lineTo(64, 76), e.lineTo(76, 61), e.lineTo(81, 87), e.fill()) : t === "loan" ? (e.save(), e.translate(60, 60), e.rotate(-.4), e.fillStyle = "#96673c", e.fillRect(-6, -8, 12, 62), e.fillStyle = "#6f8386", e.fillRect(-34, -30, 68, 31), e.strokeRect(-34, -30, 68, 31), e.restore()) : t === "shelter" ? (n([
		[15, 51],
		[60, 19],
		[105, 51]
	]), n([
		[28, 48],
		[28, 103],
		[94, 103],
		[94, 48]
	]), e.fillStyle = "#d98343", e.beginPath(), e.moveTo(49, 94), e.lineTo(54, 67), e.lineTo(65, 81), e.lineTo(75, 65), e.lineTo(77, 95), e.fill()) : t === "rest" ? (n([
		[45, 29],
		[45, 18],
		[76, 18],
		[76, 29]
	]), e.fillStyle = "#ce8741", e.beginPath(), e.roundRect(30, 31, 60, 64, 12), e.fill(), e.stroke(), n([[23, 103], [97, 103]]), e.fillStyle = "#ffe0a2", e.fillRect(54, 43, 12, 36)) : t === "credit" ? (e.beginPath(), e.moveTo(60, 15), e.lineTo(97, 31), e.lineTo(91, 74), e.quadraticCurveTo(83, 96, 60, 108), e.quadraticCurveTo(36, 97, 29, 74), e.lineTo(23, 31), e.closePath(), e.fill(), e.stroke(), n([
		[43, 62],
		[56, 77],
		[81, 46]
	])) : (r(), t === "salvage" ? (e.fillStyle = "#b8934f", e.beginPath(), e.arc(87, 84, 22, 0, Math.PI * 2), e.fill(), e.stroke()) : (e.strokeStyle = "#c2a174", n([
		[28, 54],
		[17, 69],
		[26, 91],
		[41, 100]
	]), n([
		[89, 54],
		[103, 69],
		[94, 91],
		[78, 100]
	])));
}
//#endregion
//#region src/presentation-v5/workbench-feedback.ts
function wn(e, t) {
	let n = e.ownerDocument, r = n.defaultView, i = !1, a = 0, o = "", s = /* @__PURE__ */ new Set(), c = /* @__PURE__ */ new Set(), l = /* @__PURE__ */ new Map(), u = e.querySelector("#v4-customer-figure"), d = n.createElement("span");
	d.className = "v4-customer-held", d.hidden = !0, d.setAttribute("role", "img"), u?.append(d);
	function f(e) {
		if (!e || !e.isConnected || e.closest("[hidden]")) return null;
		let t = e.getBoundingClientRect();
		return t.width > 0 && t.height > 0 && [
			t.left,
			t.top,
			t.width,
			t.height
		].every(Number.isFinite) ? t : null;
	}
	function p(e) {
		return !!e && e.width > 0 && e.height > 0 && [
			e.left,
			e.top,
			e.width,
			e.height
		].every(Number.isFinite);
	}
	function m(e) {
		e.remove(), c.delete(e);
	}
	function h(e) {
		return e.setAttribute("aria-hidden", "true"), e.inert = !0, c.add(e), n.body.append(e), e;
	}
	function g(e, r, o, c) {
		if (i || t.reduced() || n.hidden || typeof e.animate != "function") {
			c();
			return;
		}
		let l = a;
		try {
			let t = e.animate(r, {
				duration: o,
				easing: "cubic-bezier(.18,.68,.27,1)",
				fill: "forwards"
			});
			s.add(t), t.finished.then(() => {
				s.delete(t), !i && l === a && c();
			}, () => {
				s.delete(t);
			});
		} catch {
			c();
		}
	}
	function v(e, n) {
		try {
			t.paintBlade(e, n);
		} catch {}
	}
	function y(e) {
		let t = n.createElement("canvas");
		return t.className = "v4-feedback-blade", t.width = 360, t.height = 132, t.setAttribute("aria-hidden", "true"), t.dataset.piece = e.id, t;
	}
	function b() {
		a++;
		for (let e of s) e.cancel();
		s.clear();
		for (let e of c) e.remove();
		c.clear();
		for (let [e, t] of l) e.style.visibility = t;
		l.clear();
	}
	function x() {
		if (d.hidden || !u) return;
		let e = f(u.querySelector(".v4-customer-sprite")), t = f(u);
		if (!e || !t) return;
		let n = u.dataset.pose === "receiving", r = u.dataset.customer, i = n ? r === "guard" ? .6 : .64 : r === "courier" ? .77 : .75;
		d.style.top = `${e.top + e.height * i - t.top - 12}px`;
	}
	function S(e) {
		if (i || !u) return;
		let t = e.commissionOrder[e.day - 1], n = e.blades.filter((n) => n.status === "commissioned" && n.finalizedDay === e.day && n.commissionId === t), r = JSON.stringify([
			e.runId,
			e.day,
			t,
			n.map((e) => [
				e.id,
				e.recipe,
				e.level,
				e.value,
				e.cracked
			])
		]);
		r !== o && (o = r, d.replaceChildren(...n.map((e) => y(e))), d.hidden = n.length === 0, d.dataset.count = String(n.length), u.dataset.holding = String(n.length > 0), d.setAttribute("aria-label", n.length ? `来客已收${n.length}柄：${n.map((e) => `${_[e.recipe].name}，身价${e.value}`).join("；")}` : "来客尚未收剑"));
		for (let [e, t] of [...d.querySelectorAll("canvas")].entries()) {
			let r = n[e];
			r && v(t, r);
		}
		x();
	}
	function C(t) {
		return t === "customer" ? f(d.hidden ? u : d) : t === "rack" ? f(e.querySelector("#v4-reserve-slot")) ?? f(e.querySelector("#v4-reserve-zone")) : f(e.querySelector("#v4-shop")) ?? f(e.querySelector("#v4-coins"));
	}
	function w(a) {
		if (i || !r || t.reduced() || n.hidden) return;
		let o = C(a.target), s = p(a.source) ? a.source : f(e.querySelector("#v4-blade"));
		if (!p(s) || !p(o)) return;
		let c = h(n.createElement("div"));
		c.className = "v4-accepted-transfer", c.dataset.target = a.target, c.dataset.piece = a.blade.id;
		let u = y(a.blade), _ = n.createElement("span");
		_.className = "v4-transfer-caption", _.textContent = a.copy ?? (a.target === "customer" ? "好剑，收到了。" : a.target === "rack" ? "留住这一炉的火。" : "一柄剑，换一门手艺。"), c.append(u, _);
		let b = Math.min(240, Math.max(130, s.width));
		c.style.width = `${b}px`, c.style.height = "72px", v(u, a.blade);
		let x = s.left + s.width / 2 - b / 2, S = s.top + s.height / 2 - 36, w = o.left + o.width / 2 - b / 2, T = o.top + o.height / 2 - 36;
		c.style.left = `${x}px`, c.style.top = `${S}px`;
		let E = a.target === "customer" ? [...d.querySelectorAll("canvas")].find((e) => e.dataset.piece === a.blade.id) : void 0;
		E && (l.set(E, E.style.visibility), E.style.visibility = "hidden"), g(c, [
			{
				opacity: .96,
				transform: "translate(0,0) rotate(-4deg) scale(1)"
			},
			{
				opacity: 1,
				offset: .68,
				transform: `translate(${(w - x) * .78}px,${(T - S) * .78 - 20}px) rotate(-9deg) scale(.9)`
			},
			{
				opacity: 0,
				transform: `translate(${w - x}px,${T - S}px) rotate(-13deg) scale(.68)`
			}
		], 430, () => {
			E && l.has(E) && (E.style.visibility = l.get(E), l.delete(E)), m(c);
		});
	}
	function T(a) {
		if (i || !r || n.hidden) return;
		if (a.hit.result === "crack" || a.hit.result === "broken") {
			for (let e of [...c]) e.classList.contains("v4-growth-reveal") && m(e);
			return;
		}
		let o = yn(a.before), s = yn(a.after);
		if (s.stage <= o.stage) return;
		for (let e of [...c]) e.classList.contains("v4-growth-reveal") && m(e);
		let l = e.querySelector("#v4-blade"), u = f(l);
		if (!l || !p(u)) return;
		let d = h(n.createElement("div"));
		d.className = "v4-growth-reveal", d.dataset.piece = a.pieceId, d.dataset.rank = s.rank, d.style.left = `${u.left}px`, d.style.top = `${u.top}px`, d.style.width = `${u.width}px`, d.style.height = `${u.height}px`;
		let _ = n.createElement("span");
		if (_.className = "v4-growth-caption", _.textContent = `${o.rank} → ${s.rank}`, d.append(_), t.reduced() || typeof d.animate != "function") {
			d.classList.add("v4-growth-static");
			return;
		}
		let v = n.createElement("canvas");
		v.className = "v4-growth-sheen", v.width = l.width, v.height = l.height;
		try {
			v.getContext("2d")?.drawImage(l, 0, 0), d.prepend(v);
		} catch {}
		g(v, [
			{
				opacity: 0,
				clipPath: "polygon(0 0, 0 0, 0 100%, 0 100%)"
			},
			{
				opacity: .75,
				offset: .15
			},
			{
				opacity: .75,
				offset: .72
			},
			{
				opacity: 0,
				clipPath: "polygon(90% 0, 100% 0, 100% 100%, 90% 100%)"
			}
		], 520, () => v.remove()), g(_, [
			{
				opacity: 0,
				transform: "translate(-50%,5px)"
			},
			{
				opacity: 1,
				offset: .17,
				transform: "translate(-50%,0)"
			},
			{
				opacity: 1,
				offset: .72
			},
			{
				opacity: 0,
				transform: "translate(-50%,-7px)"
			}
		], 1100, () => m(d));
	}
	let E = () => {
		n.hidden && b();
	}, D = () => b();
	return n.addEventListener("visibilitychange", E), r?.addEventListener("blur", D), r?.addEventListener("resize", x), {
		transfer: w,
		syncHeld: S,
		contact: T,
		cancel: b,
		dispose() {
			i || (b(), i = !0, d.remove(), u?.removeAttribute("data-holding"), n.removeEventListener("visibilitychange", E), r?.removeEventListener("blur", D), r?.removeEventListener("resize", x));
		}
	};
}
//#endregion
//#region src/presentation-v5/commission-paper.ts
var Tn = (e) => e.toLocaleString("zh-CN"), En = (e) => e === 1 ? "一柄" : e === 2 ? "两柄" : `${e}柄`;
function Dn(e, t) {
	return e.age === "old" ? `此前留剑${En(e.count)}` : e.age === "new" ? `本日新剑${En(e.count)}` : t && e.crack ? `${e.crack === "intact" ? "完好剑" : "裂剑"}${En(e.count)}` : e.count > 1 ? `${En(e.count)}分别交付` : "交付一柄";
}
function On(e, t) {
	let n = [];
	return e.recipe && n.push(_[e.recipe].name), e.crack && (!t || e.age) && n.push(e.crack === "intact" ? "无裂纹" : "带裂纹"), e.maxHits !== void 0 && n.push(`普通锤≤${e.maxHits}`), e.minLevel !== void 0 && n.push(`等级≥${e.minLevel}`), e.minBursts !== void 0 && n.push(`连锻≥${e.minBursts}次`), n.push(`${e.count > 1 ? "每柄" : ""}估值≥${Tn(e.value)}`), n.join(" · ");
}
function kn(e, t, n) {
	let r = [], i = !1;
	return e.recipe && t.recipe !== e.recipe && (r.push(`要${_[e.recipe].name}`), i ||= t.hits > 0), e.crack === "intact" && t.cracked && (r.push("须另换无裂剑"), i = !0), e.crack === "cracked" && !t.cracked && r.push("还未带裂纹"), e.age === "old" && t.suppliedDay >= n && (r.push("这是新剑，不能作留剑"), i = !0), e.age === "new" && t.suppliedDay !== n && (r.push("这是留剑，不能作新剑"), i = !0), e.maxHits !== void 0 && t.hits > e.maxHits && (r.push(`已超过${e.maxHits}次普通锤`), i = !0), e.minLevel !== void 0 && t.level < e.minLevel && r.push(`还差${e.minLevel - t.level}级`), e.minBursts !== void 0 && t.bursts < e.minBursts && r.push(`还差${e.minBursts - t.bursts}次连锻`), t.value < e.value && r.push(`还差${Tn(e.value - t.value)}估值`), {
		missing: r,
		blocked: i
	};
}
function An(e, t) {
	let n = e.commission, r = n.routes.length > 1, i = e.blades.find((e) => e.blade.id === t), a = n.progress.complete, o = n.routes.map((t) => {
		let o = n.progress.routes.find((e) => e.id === t.id), s = o?.pieceIds.slice(0, t.count) ?? [], c = o?.complete ?? !1, l = a && !c, u = null;
		if (i && !a) {
			let n = i.assessment.routes.find((e) => e.id === t.id), { missing: r, blocked: a } = kn(t, i.blade, e.day), o = n?.matches ?? !1, s = o && i.assessment.canDeliver && !i.reserved, c = o ? i.reserved ? "这柄合格 · 先从剑架取回" : "这柄合格 · 可以交给来客" : `${r[0] ?? "这柄尚不合纸单"}${r.length > 1 ? `，另有${r.length - 1}项` : ""}`;
			u = {
				pieceId: i.blade.id,
				matches: o,
				canDeliver: s,
				blocked: a,
				reserved: i.reserved,
				missing: r,
				copy: c
			};
		}
		return {
			id: t.id,
			label: Dn(t, r),
			requirement: On(t, r),
			required: t.count,
			complete: c,
			inactive: l,
			deliveredIds: s,
			selected: u
		};
	}), s = o.some((e) => e.required > 1), c = o.find((e) => e.deliveredIds.length > 0 && !e.complete), l;
	return l = a ? s && o.some((e) => e.complete && e.required > 1) ? "✓ 两柄均已交妥" : "✓ 这份约定已经交妥" : c ? r ? "已收一柄；还可改走另一条路线" : "已收一柄，还等另一柄" : r ? "" : s ? "每柄各自合格，不能一剑算两柄" : "合格后递给来客，才算交妥", {
		commissionId: n.id,
		complete: a,
		alternative: r,
		multiple: s,
		summary: r ? "两条路，任选其一" : s ? "两柄剑，各赴一程" : "好剑有它要去的地方",
		progressCopy: l,
		routes: o
	};
}
function jn(e, t) {
	let n = e.ownerDocument, r = e.querySelector("#v4-order-routes"), i = e.querySelector("#v4-goal-condition"), a = e.querySelector("#v4-goal-progress"), o = e.querySelector("#v4-customer-zone"), s = r?.closest(".v4-objective");
	if (!r || !i || !a || !o || !s) throw Error("Commission paper DOM is incomplete.");
	let c = r, l = i, u = a, d = o, f = s, p = !1, m = "";
	function h(e, t, r) {
		let i = n.createElement(e);
		return i.className = t, r !== void 0 && (i.textContent = r), i;
	}
	function g(e, t) {
		e.textContent !== t && (e.textContent = t);
	}
	function _(e, r, i = "") {
		if (p) return;
		let a = An(e, r), o = JSON.stringify([i, a]);
		if (g(l, a.summary), g(u, a.progressCopy), d.dataset.paperLayout = a.alternative ? "double" : "single", d.dataset.paperMulti = String(a.multiple), f.dataset.paperComplete = String(a.complete), o === m) return;
		m = o;
		let s = n.createDocumentFragment();
		for (let [e, n] of a.routes.entries()) {
			e > 0 && s.append(h("p", "v4-order-or", "或"));
			let r = h("section", "v4-order-route");
			r.dataset.route = n.id, r.dataset.complete = String(n.complete), r.dataset.inactive = String(n.inactive), r.dataset.selectedState = n.selected?.matches ? n.selected.reserved ? "reserved" : "ready" : n.selected?.blocked ? "blocked" : "missing";
			let i = h("div", "v4-order-row"), a = h("div", "v4-order-copy"), o = h("p", "v4-order-title");
			o.append(h("strong", "v4-order-label", n.label), h("span", "v4-order-requirement", n.requirement));
			let c = n.inactive ? "另一条已履约，这条不必再交" : n.complete ? "这条路线已经交妥" : n.selected?.copy ?? "挑一柄，看看还差什么";
			a.append(o, h("p", "v4-order-selected", c));
			let l = h("div", "v4-order-sockets");
			l.dataset.required = String(n.required);
			for (let e = 0; e < n.required; e++) {
				let r = n.deliveredIds[e], i = h("span", "v4-order-socket");
				if (i.dataset.received = String(!!r), i.setAttribute("role", "img"), i.setAttribute("aria-label", `第${e + 1}柄${r ? "已收讫" : "尚未交付"}`), r) {
					i.dataset.piece = r;
					let e = null;
					try {
						e = t.thumb(r);
					} catch {}
					e && (e.setAttribute("aria-hidden", "true"), i.append(e));
				}
				i.append(h("small", "v4-order-socket-caption", r ? "收讫" : "待交")), l.append(i);
			}
			i.append(a, l), r.append(i), s.append(r);
		}
		c.replaceChildren(s);
	}
	return {
		render: _,
		dispose() {
			p || (p = !0, c.replaceChildren(), d.removeAttribute("data-paper-layout"), d.removeAttribute("data-paper-multi"), f.removeAttribute("data-paper-complete"));
		}
	};
}
//#endregion
//#region src/presentation-v4/handoff.ts
function Mn(e, t) {
	let n = e.ownerDocument, r = n.defaultView;
	if (!r) return {
		cancel() {},
		isDragging() {
			return !1;
		},
		dispose() {}
	};
	let i = r, a = !1, o = null, s = null, c = null, l = null, u = /* @__PURE__ */ new Set(), d = (e) => e.dataset.handoffTarget === "customer" ? "customer" : e.dataset.handoffTarget === "rack" ? "rack" : null;
	function f() {
		for (let e of u) e.removeAttribute("data-handoff-state");
		u.clear();
	}
	function p(e) {
		l = {
			pointerId: e,
			until: i.performance.now() + 800
		};
	}
	function m() {
		i.removeEventListener("pointermove", b, !0), i.removeEventListener("pointerup", x, !0), i.removeEventListener("pointercancel", S, !0), i.removeEventListener("keydown", w, !0), i.removeEventListener("blur", g), n.removeEventListener("visibilitychange", T), e.removeEventListener("lostpointercapture", C, !0);
	}
	function h() {
		let t = o;
		if (o = null, m(), f(), s?.remove(), s = null, c = null, e.classList.remove("v4-handoff-dragging"), t?.dragging) try {
			e.hasPointerCapture(t.pointerId) && e.releasePointerCapture(t.pointerId);
		} catch {}
	}
	function g() {
		o?.dragging && p(o.pointerId), h();
	}
	function _(e) {
		let t = n.createElement("div"), r = e.cloneNode(!0);
		t.className = "v4-handoff-ghost", t.setAttribute("aria-hidden", "true"), t.inert = !0, t.style.position = "fixed", t.style.left = "0", t.style.top = "0", t.style.pointerEvents = "none", r.classList.add("v4-handoff-source"), r.tabIndex = -1, r.removeAttribute("id");
		for (let e of r.querySelectorAll("[id]")) e.removeAttribute("id");
		let i = e.querySelectorAll("canvas"), a = r.querySelectorAll("canvas");
		for (let e = 0; e < i.length; e++) {
			let t = i[e], n = a[e];
			if (n) {
				n.width = t.width, n.height = t.height;
				try {
					t.width && t.height && n.getContext("2d")?.drawImage(t, 0, 0);
				} catch {
					n.remove();
				}
			}
		}
		return c = n.createElement("span"), c.className = "v4-handoff-label", t.append(r, c), n.body.append(t), t;
	}
	function v(e, t) {
		if (!s) return;
		let n = s.getBoundingClientRect(), r = Math.max(8, Math.min(e + 16, i.innerWidth - n.width - 8)), a = Math.max(8, Math.min(t + 14, i.innerHeight - n.height - 8));
		s.style.transform = `translate3d(${r}px,${a}px,0)`;
	}
	function y(r, i) {
		let a = o;
		if (!a?.dragging) return null;
		f();
		let s = /* @__PURE__ */ new Map();
		for (let n of e.querySelectorAll("[data-handoff-target]")) {
			let e = d(n);
			if (!e) continue;
			let r = s.get(e);
			if (r || (r = t.preview(a.token, e), s.set(e, r)), o !== a) return null;
			n.dataset.handoffState = r.allowed ? "allowed" : "blocked", u.add(n);
		}
		let l = n.elementFromPoint(r, i)?.closest("[data-handoff-target]"), p = l && e.contains(l) ? d(l) : null;
		return c && (c.textContent = p ? (s.get(p) ?? t.preview(a.token, p)).label : "拖向来客，或留在剑架"), p;
	}
	function b(t) {
		let n = o;
		if (n && t.pointerId === n.pointerId) {
			if (!e.isConnected) g();
			else {
				if (!n.dragging) {
					if (Math.hypot(t.clientX - n.startX, t.clientY - n.startY) <= 7) return;
					n.dragging = !0, e.classList.add("v4-handoff-dragging"), s = _(n.source);
					try {
						e.setPointerCapture(n.pointerId);
					} catch {}
				}
				t.preventDefault(), t.stopPropagation();
				try {
					y(t.clientX, t.clientY), v(t.clientX, t.clientY);
				} catch (e) {
					throw g(), e;
				}
			}
		}
	}
	function x(n) {
		let r = o;
		if (!r || n.pointerId !== r.pointerId || n.button !== 0) return;
		if (!r.dragging) {
			h();
			return;
		}
		n.preventDefault(), n.stopPropagation();
		let i = null, c;
		try {
			if (e.isConnected) {
				i = y(n.clientX, n.clientY);
				let e = s?.getBoundingClientRect();
				e && (c = {
					left: e.left,
					top: e.top,
					width: e.width,
					height: e.height
				});
			}
		} finally {
			h();
		}
		try {
			i && !a && t.commit(r.token, i, c);
		} finally {
			a || p(r.pointerId);
		}
	}
	function S(e) {
		o?.pointerId === e.pointerId && g();
	}
	function C(e) {
		o?.dragging && o.pointerId === e.pointerId && g();
	}
	function w(e) {
		e.key === "Escape" && o && (e.preventDefault(), e.stopPropagation(), g());
	}
	function T() {
		n.hidden && g();
	}
	function E() {
		l = null;
	}
	function D(e) {
		if (!l) return;
		if (i.performance.now() > l.until) {
			l = null;
			return;
		}
		let t = "pointerId" in e ? e.pointerId : null;
		e.button !== 0 || e.detail === 0 || t !== null && t !== l.pointerId || (l = null, e.preventDefault(), e.stopImmediatePropagation());
	}
	function O(r) {
		if (a || r.button !== 0 || !r.isPrimary || r.pointerType === "touch" || r.ctrlKey || r.metaKey || r.altKey) return;
		let s = r.target instanceof Element ? r.target.closest("#v4-inventory button[data-piece]") : null;
		if (!s || !e.contains(s) || s.disabled) return;
		let c = s.dataset.piece;
		if (!c) return;
		let u = t.capture(c);
		if (!u || u.pieceId !== c) return;
		g(), l = null;
		let d = Object.freeze({
			runId: u.runId,
			revision: u.revision,
			generation: u.generation,
			epoch: u.epoch,
			pieceId: u.pieceId
		});
		o = {
			pointerId: r.pointerId,
			startX: r.clientX,
			startY: r.clientY,
			source: s,
			token: d,
			dragging: !1
		}, i.addEventListener("pointermove", b, {
			capture: !0,
			passive: !1
		}), i.addEventListener("pointerup", x, {
			capture: !0,
			passive: !1
		}), i.addEventListener("pointercancel", S, !0), i.addEventListener("keydown", w, !0), i.addEventListener("blur", g), n.addEventListener("visibilitychange", T), e.addEventListener("lostpointercapture", C, !0);
	}
	function k(e) {
		o && e.preventDefault();
	}
	return e.addEventListener("pointerdown", O), e.addEventListener("dragstart", k, !0), i.addEventListener("pointerdown", E, !0), i.addEventListener("click", D, !0), {
		cancel: g,
		isDragging: () => o?.dragging === !0,
		dispose() {
			a || (a = !0, h(), l = null, e.removeEventListener("pointerdown", O), e.removeEventListener("dragstart", k, !0), i.removeEventListener("pointerdown", E, !0), i.removeEventListener("click", D, !0));
		}
	};
}
//#endregion
//#region src/presentation-v5/decisions.ts
var Nn = (e) => e.toLocaleString("zh-CN"), Pn = (e, t) => e.traits.some((e) => e.id === t), Fn = (e) => _[e].name;
function In(e, t, n) {
	return !!(e.recipe && e.recipe !== t.recipe && t.hits > 0 || e.crack === "intact" && t.cracked || e.age === "old" && t.suppliedDay >= n || e.age === "new" && t.suppliedDay !== n || e.maxHits !== void 0 && t.hits > e.maxHits);
}
function Ln(e, t) {
	return e.commission.routes.map((n) => ({
		route: n,
		missing: t.assessment.routes.find((e) => e.id === n.id)?.missing ?? [],
		blocked: In(n, t.blade, e.day)
	})).sort((e, t) => Number(e.blocked) - Number(t.blocked) || e.missing.length - t.missing.length)[0];
}
function Rn(e) {
	let t = e.odds.crack / 10;
	return t === 0 ? e.blade.cracked ? "这一记普通锤不会再裂，已有裂纹仍在。" : "下一记普通锤不会裂，不代表之后也一直安全。" : e.blade.cracked ? `下一记普通锤有${t}%会断；断后只回收${Nn(e.recovery)}铜钱。` : `下一记普通锤裂损率${t}%；继续敲要承担这份风险。`;
}
function zn(e) {
	return e.quote.matched ? `现在交剑实收${Nn(e.quote.amount)}铜钱。` : `行会可收${Nn(e.quote.amount)}铜钱。`;
}
function Bn(e, t) {
	let n = e.merchant ? t.barter.allowed ? "可献给商人换手艺。" : "等级3的成器可换手艺。" : "";
	return `${e.next ? "留到明日会占一位新坯。" : ""}${n}回收实得${Nn(t.recovery)}铜钱。`;
}
function Vn(e, t, n, r, i = []) {
	return {
		...e,
		action: n,
		actionLabel: r,
		pieceId: t?.blade.id ?? null,
		missing: i,
		ordinaryToBurst: t ? Math.max(0, 6 - t.blade.charge) : null
	};
}
function Hn(e, t) {
	let n = e.blades.find((e) => e.blade.id === t);
	if (e.ending) return Vn({
		headline: e.ending.title,
		copy: "这一程已经收束，看看留下的炉谱，再决定下一次启程。",
		tone: "neutral"
	}, void 0, "none", "");
	if (e.phase !== "workshop") return Vn({
		headline: "先收好这一程",
		copy: "沿灯路继续，回到铁砧再决定下一柄。",
		tone: "neutral"
	}, void 0, "none", "");
	if (!n) {
		let n = e.blades.find((e) => !e.reserved);
		if (n) return Vn({
			headline: t ? "这柄已离开铁砧" : "挑一柄，接着打造",
			copy: "选另一柄继续；已经交出或碎掉的剑不会再回来。",
			tone: "neutral"
		}, n, "select", "换下一柄");
		let r = e.blades.find((e) => e.reserved);
		return r ? Vn({
			headline: "只剩剑架上的这一柄",
			copy: e.next ? "可以取回再锻，也可以收工，把它带到明天。" : "这是最后一炉，可取回安排交付、出售或回收；留在剑架的兵器不会带入新局。",
			tone: "neutral"
		}, r, "retrieve", "取回留剑") : Vn({
			headline: "这一炉的剑都安排好了",
			copy: "看看收成与契印，收工后再启程。",
			tone: "neutral"
		}, void 0, "settle", "收工，封炉");
	}
	if (n.reserved) return Vn({
		headline: "先取回，才能敲这柄",
		copy: e.next ? "挂起的剑留给明天；取回后，才可继续打造或交给来客。" : "这柄暂放在本局剑架，不会带入新局；取回后可继续打造或交付。",
		tone: "neutral"
	}, n, "retrieve", "取回留剑");
	if (e.commission.progress.complete) return Vn({
		headline: e.market.remaining === 0 ? "约定已交妥，今日收购钱袋已空" : "今天的约定已经交妥",
		copy: `${e.market.remaining === 0 ? "这柄现在无法出售。" : zn(n)}${Bn(e, n)}`,
		tone: "ready"
	}, n, e.next ? "plan" : "settle", e.next ? "看看明日纸单" : "收工，封炉");
	if (n.willCommission) {
		let t = e.commission.routes.filter((e) => n.assessment.routes.some((t) => t.id === e.id && t.matches)).some((t) => (e.commission.progress.routes.find((e) => e.id === t.id)?.count ?? 0) + 1 >= t.count);
		return Vn({
			headline: t ? `现在交给${e.commission.name}，今天就交妥` : `这柄合格，先交给${e.commission.name}`,
			copy: `${zn(n)}${e.market.remaining === 0 ? "收购钱袋虽已用尽，合格委托仍可交；酬劳按真实进度结算。" : ""}${t ? "现在交能保住这份约定；再敲仍会承担新风险。" : "交出后，还要另一柄各自合格的剑。"}`,
			tone: "ready"
		}, n, "deliver", `交给${e.commission.name}`);
	}
	let r = Ln(e, n), i = r.missing;
	if (r.blocked) return Vn({
		headline: "这柄接不了今天的这份约定",
		copy: `${i.join("、")}。${zn(n)}${e.market.remaining === 0 ? "今日收购钱袋已空，剑仍在你手里。" : ""}${Bn(e, n)}`,
		tone: "risk"
	}, n, e.blades.some((e) => e !== n && !e.reserved) ? "select" : "plan", "看看其他选择", i);
	if (!n.canStrike) return Vn({
		headline: n.blade.value >= 1e9 || n.blade.level >= 99 ? "这柄已到锻造上限" : "先安排这一炉的成品",
		copy: `${i.join("、")}。现在可交剑、回收或收工。`,
		tone: "neutral"
	}, n, "settle", "看看收工结果", i);
	if (r.route.recipe && r.route.recipe !== n.blade.recipe && n.canChangeRecipe) return Vn({
		headline: `先把这柄定成${Fn(r.route.recipe)}`,
		copy: `首锤之前还能换配方；今天这条路线${i.join("、")}。`,
		tone: "neutral"
	}, n, "recipe", "选择配方", i);
	if (n.odds.burst) return Vn({
		headline: "下一锤是安全连锻",
		copy: `最多${2 + Number(Pn(e, "ember")) + Number(n.blade.bursts === 0 && e.modifications.some((e) => e.id === "wideMouth"))}记安全锤，不会裂；一次连锻仍只算一次。当前${i.join("、")}。`,
		tone: "safe"
	}, n, "strike", "落下这记连锻", i);
	if (r.route.maxHits !== void 0) {
		let e = Math.max(0, r.route.maxHits - n.blade.hits);
		return Vn({
			headline: e ? `这条路线还容${e}记普通锤` : "这条路线没有再试锤的余地",
			copy: `${i.join("、")}。${e ? Rn(n) : "再敲会超过普通锤要求，可以换下一柄。"}`,
			tone: e ? "neutral" : "risk"
		}, n, e ? "strike" : "select", e ? "再落一锤" : "换下一柄", i);
	}
	if (n.blade.cracked) return Vn({
		headline: "带着裂纹，要想好何时收手",
		copy: `${i.join("、")}。${Rn(n)}`,
		tone: "danger"
	}, n, "strike", "看清风险，再落锤", i);
	let a = Math.max(0, 6 - n.blade.charge), o = Math.max(0, (r.route.minBursts ?? 0) - n.blade.bursts);
	return Vn({
		headline: o ? `今天还差${o}次连锻` : i[0] ?? "这柄还在成形",
		copy: `${i.slice(+!o).join("、")}${i.length > +!o ? "。" : ""}再攒${a}记普通锤，剑撑住后才有安全连锻。${Rn(n)}`,
		tone: n.odds.crack > 0 ? "risk" : "neutral"
	}, n, "strike", "再落一锤", i);
}
function Un(e) {
	let t = e.next;
	if (e.ending) return {
		day: null,
		title: e.ending.title,
		customer: "",
		headline: "这一程已经收束",
		copy: "没有可继续的明日纸单，留下的炉谱会陪你再启程。",
		tone: "neutral",
		routes: [],
		reserve: null,
		candidateIds: [],
		newCount: 0,
		oldCount: 0,
		totalCount: 0
	};
	if (!t) return {
		day: null,
		title: "最后一炉",
		customer: "",
		headline: "今天决定这一程的归途",
		copy: "已经没有明日来料。先交眼前的约定，再安排余剑与收工。",
		tone: "neutral",
		routes: [],
		reserve: null,
		candidateIds: [],
		newCount: 0,
		oldCount: 0,
		totalCount: 0
	};
	let n = t.reserve ? e.blades.find((e) => e.blade.id === t.reserve.id) : void 0, r = t.commission.routes.map((e) => {
		let n = t.reserve?.assessment.routes.find((t) => t.id === e.id);
		return {
			id: e.id,
			description: L(e),
			required: e.count,
			reserveMatches: n?.matches ?? !1,
			missing: n?.missing ?? []
		};
	}), i = e.blades.filter((e) => !e.reserved && t.commission.routes.some((n) => N({ day: t.day }, e.blade, n).matches)).map((e) => e.blade.id), a = null;
	if (n && t.reserve) {
		let e = r.filter((e) => e.reserveMatches), i = e[0], o = n.blade.value === t.reserve.value ? `跨天仍值${Nn(t.reserve.value)}` : `现在${Nn(n.blade.value)}，明日${Nn(t.reserve.value)}`, s = t.commission.routes.map((e, t) => ({
			route: e,
			assessment: r[t]
		})).sort((e, n) => Number(In(e.route, t.reserve, t.day)) - Number(In(n.route, t.reserve, t.day)) || e.assessment.missing.length - n.assessment.missing.length)[0];
		a = {
			id: n.blade.id,
			valueNow: n.blade.value,
			valueNext: t.reserve.value,
			matchingRoutes: e.map((e) => e.id),
			headline: i ? i.required > 1 ? "明日已有一柄合用的剑" : "明日已有可交的留剑" : "这柄还不能直接交明日的单",
			copy: `${o}；裂纹与锤势保留。${i ? i.required > 1 ? `取回后可算一柄，还需另外${i.required - 1}柄各自合格。` : `取回后可交给${t.commission.name}。` : `${s.assessment.missing.join("、")}。${In(s.route, t.reserve, t.day) ? "有不能靠多敲补回的条件，明日另开新坯更合适。" : "明日取回后可继续打造，也可另开新坯。"}`}留它后明日是${t.oldCount}柄旧剑＋${t.newCount}柄新坯，共${t.totalCount}柄，少领一柄新坯；明日取下也不会补发。`,
			tone: i ? "ready" : "risk"
		};
	}
	let o = t.commission.routes.find((e) => e.age === "old"), s = t.commission.routes.find((e) => e.age === "new"), c = o && s ? `留一柄达到${Nn(o.value)}的旧剑可走旧剑路线；也能用${s.count}柄各值${Nn(s.value)}的新剑接替。` : a ? a.copy : i.length ? "眼前已有剑符合明日的一柄要求，可以留住；也可卖出，再用新坯打造。" : "明日可以从新坯开始。留剑能保住已有锤势与成品，但不必每一炉都占住剑架。";
	return {
		day: t.day,
		title: t.commission.title,
		customer: t.commission.name,
		headline: `明日给${t.commission.name} · ${t.commission.title}`,
		copy: `${c}${a ? c === a.copy ? "" : `明日旧剑${t.oldCount}＋新坯${t.newCount}，共${t.totalCount}柄，留剑占一槽，取下不补坯。` : `明日领${t.newCount}柄新坯，共${t.totalCount}柄；若留一柄，会改为旧剑1＋新坯2，取下不补发第四柄。`}`,
		tone: a?.tone ?? "neutral",
		routes: r,
		reserve: a,
		candidateIds: i,
		newCount: t.newCount,
		oldCount: t.oldCount,
		totalCount: t.totalCount
	};
}
function Wn(e, t) {
	let n = Pn(t, e), r = !n && t.traits.length >= 3, i = t.gift.canClaim && (e === "steady" || e === "ember") && !n, a = n ? "已经带着这门手艺，无需再交剑。" : `${i ? "首单谢礼可免费学；商人交换仍需交出等级≥3、未挂剑架的一柄剑。" : "交出等级≥3、未挂剑架的一柄剑，不能再交差、卖钱或留给明日。"}这里要求兵器等级，不是敲满三锤。${r ? `手艺三槽已满，还要换下${t.traits.map((e) => e.name).join("、")}中的一门。` : `现有${t.traits.length}/3门手艺。`}`, o = t.blades.filter((e) => e.blade.cracked).length, s = t.commission.routes.some((e) => e.crack === "intact"), c = t.next?.commission.routes.some((e) => e.crack === "intact") ?? !1, l, u, d = n ? "neutral" : "ready";
	switch (e) {
		case "steady":
			l = "保住首裂的估值，保不住无裂条件", u = s || c ? "眼前或明日的无裂委托，裂了仍不合格；它只能减轻首裂掉价，不能修好裂纹。" : o === t.blades.length && o > 0 ? "手里的剑都已裂，不能靠护符治好；它主要照顾下一柄的首次裂损。" : "继续锻时，首次裂损可保住估值；剑仍留裂纹，再裂仍会断。", t.growth.crackGuard && (u += "现有赊护也会在同一次首裂用掉。");
			break;
		case "ember":
			l = "把一次连锻里的安全锤做厚", u = `${t.blades.some((e) => e.blade.charge === 6) ? "已有剑蓄满六格，下一次连锻就可用上。" : "先把六格锤势攒满，连锻时才用得上。"}最多多一记安全锤；一次不会变成两次连锻。`;
			break;
		case "inherit":
			l = t.next ? "碎剑的余温，留给明日首坯" : "最后一天已没有下一批来料", u = t.next ? `以后碎剑可把峰值20%传给明日首坯，最多增加普通底价4倍。${t.next.inheritanceBonus ? `明日已有${Nn(t.next.inheritanceBonus)}余温加料。` : "它不保住碎剑，也不保证冒险更赚。"}` : "这门手艺只给下一天的首坯加料；现在换来，已没有明日首坯可受益。", t.next || (d = "risk");
			break;
		case "echo": {
			let e = t.blades.filter((e) => !e.reserved).map((e) => 3 - e.blade.successes % 3).sort((e, t) => e - t)[0];
			l = "让普通成功接成三声回响", u = `${e ? `眼前最近一柄还需${e}次普通成功。` : "下一柄每第三次普通成功，可额外增值25%。"}安全连锻不计这三次；别为凑回声超过委托的普通锤限制。`;
			break;
		}
		case "crackedEdge":
			l = o ? `眼前${o}柄裂剑能用上裂锋` : "有裂纹以后，才用得上裂锋", u = "裂剑的普通大成率加10个百分点，裂损率不变，再裂仍会断。", s && !t.commission.routes.some((e) => e.crack === "cracked") && (u += "今天要无裂剑，不必为这门手艺故意造裂。");
			break;
		case "pardon": {
			let e = t.history.some((e) => e.protected) || t.traits.some((e) => e.id === "pardon" && e.used);
			l = e ? "这一程的护印机会已经用过" : "留一次失约后的继续机会", u = e ? "换下再换回也不会重置；不必再交一柄剑来买已经用过的次数。" : "首次失约只免扣一枚契印，不替你完成委托。第4、8、12天的关键缺口仍会留下。", e && (d = "risk");
			break;
		}
	}
	return {
		headline: l,
		copy: u,
		tone: d,
		costCopy: a,
		equipped: n,
		replacementRequired: r
	};
}
//#endregion
//#region src/presentation-v5/story.ts
function Gn(e, t, n) {
	let r = e.find((e) => e.type === "MainCompleted");
	if (r?.type === "MainCompleted") return {
		title: "这一站，有剑了",
		copy: S[r.commissionId - 1].success,
		action: t.gift === "available" ? "gift" : "settle",
		label: t.gift === "available" ? "领一门手艺" : "安排余剑与收工"
	};
	let i = e.find((e) => e.type === "Delivered");
	if (i?.type === "Delivered" && i.matched) {
		let e = z(t), n = e.commission.progress, r = e.commission.id === 11;
		return {
			title: r ? "接力的第一柄，已经交出" : "第一驿，接到剑了",
			copy: `${n.routes.map((e) => `${e.count}/${e.required}`).join(" 或 ")} · ${r ? "还可再交一柄合格新剑，或用一柄合格旧剑完成另一条路线。" : "还要一柄各自合格的剑，第二站才会亮灯。"}已经交出的剑不会重复计数。`,
			action: "journey",
			label: r ? "看看这次接力" : "看看驿路的灯"
		};
	}
	let a = e.find((e) => e.type === "Strike");
	if (a?.type === "Strike") {
		let e = a.hits.at(-1), n = t.blades.find((e) => e.id === a.pieceId), r = {
			runId: t.runId,
			day: t.day,
			revision: t.revision,
			pieceId: a.pieceId
		};
		if (e?.result === "broken") return {
			title: "剑断了，炉火还在",
			copy: `断剑实得${e.recoveryAmount}铜钱，受今日钱袋限制。左侧还有兵器可继续，也可保留现有成果收工。`,
			action: t.blades.some((e) => e.status === "active") ? "next" : "settle",
			label: t.blades.some((e) => e.status === "active") ? "回到铁砧" : "安排收工",
			subject: r
		};
		if (e?.result === "crack") return {
			title: "裂纹出现了",
			copy: `这一记后估值为${e.after}。再裂会断，先看看这柄是否仍合纸单。`,
			action: "inspect",
			label: "看看这柄的差项",
			subject: r
		};
		if (n?.charge === 6) return {
			title: "锤势已满",
			copy: "下一次落锤是安全连锻，不会出现裂损。",
			action: "none",
			label: "安全连锻",
			subject: r
		};
	}
	let o = e.find((e) => e.type === "Reserved");
	if (o?.type === "Reserved") return {
		title: t.reserveId === o.pieceId ? t.day === 12 ? "暂放在本局剑架" : "这一柄，留给明天" : "剑已从架上取回",
		copy: t.reserveId === o.pieceId ? t.day === 12 ? "这是最后一炉。剑架只保留本局记录，不会把兵器带入新局。" : "明日一柄旧剑＋两柄新坯。旧剑占一位，取下后也不补第四柄。" : "可以继续打造或交给来客；今天的铁坯不会因此补发。",
		action: "none",
		label: ""
	};
	let s = n ? `铜钱 ${n.coins} → ${t.coins}。` : "", c = e.find((e) => e.type === "EventChoice");
	if (c?.type === "EventChoice") return {
		title: c.record.choice === "accept" ? `${x[c.record.id].name} · 已记妥` : "这一晚，守住手里的剑",
		copy: c.record.choice === "accept" ? s + {
			donation: "明日实际新坯底价＋20%；留剑时两柄，不留三柄，旧剑不加料。",
			loan: "借锤留给明日第一柄新坯，前三记普通锤正收益＋10%。",
			salvage: "架上的剑已换出，不再带往明日；160铜钱独立入袋。",
			credit: "保价已待用，下次完好剑首裂保住估值；裂纹仍留下。",
			shelter: "炉棚照顾明日第一柄新坯，当天裂损率少3个百分点。",
			rest: "剑和铜钱保持，继续安排这一炉。"
		}[c.record.id] : "没有额外扣款，可以继续打造当前委托。",
		action: "none",
		label: ""
	};
	let l = e.find((e) => e.type === "Trait");
	if (l?.type === "Trait") return {
		title: l.traitId ? `${f[l.traitId].name} · 已入行囊` : "谢礼已折成旅费",
		copy: l.traitId ? `${n?.traits.find((e) => !t.traits.includes(e)) ? `换下${f[n.traits.find((e) => !t.traits.includes(e))].name}。` : ""}${f[l.traitId].text} 可点实物查看当前用途。` : s + `实收${l.compensation}铜钱。`,
		action: "none",
		label: ""
	};
	if (e.some((e) => e.type === "Upgraded")) {
		let e = n ? z(n).next : null, r = z(t).next;
		return {
			title: "下一批铁料，备好了",
			copy: s + `明日普通新坯底价${e?.normalBase ?? "—"} → ${r?.normalBase ?? "—"}，只用于新坯。眼前剑和留剑不会涨价。`,
			action: "shop",
			label: "再看炉边摊"
		};
	}
	return e.some((e) => e.type === "Repaired") ? {
		title: "一枚契印，补回来了",
		copy: s + `契印 ${n?.seals ?? t.seals - 1}/3 → ${t.seals}/3。修印不补回已经失约的约定。`,
		action: "shop",
		label: "再看炉边摊"
	} : null;
}
//#endregion
//#region src/presentation-v5/growth-options.ts
var X = (e) => e.toLocaleString("zh-CN"), Kn = (e, t) => t < 0 ? `需${X(e)}铜钱，当前还差${X(-t)}。` : `支付${X(e)}铜钱后，余${X(t)}。`;
function qn(t, n, r = !1) {
	let i = t.blades.find((e) => e.blade.id === n);
	if (!i) return null;
	let a = i.blade, o = t.next, s = o && t.modifications.some((e) => e.id === "warmRack") ? k(a.value, 115) : a.value, c = t.phase === "workshop" && !i.reserved && !r && i.barter.error !== "record_limit";
	if (!o) return e({
		id: n,
		blade: a,
		valueNow: a.value,
		valueNext: s,
		canReserve: c,
		matching: !1,
		missing: ["最后一炉，没有明日委托"],
		copy: "这是最后一炉。挂架只暂存本局，不带入新局；收工时也不会自动回收挂架剑。"
	});
	let l = {
		...a,
		value: s,
		peak: Math.max(a.peak, s)
	}, u = o.commission.routes.map((e) => ({
		route: e,
		...N({ day: o.day }, l, e)
	})), d = u.filter((e) => e.matches), f = d.length > 0, p = f ? [] : u.length === 1 ? u[0].missing : u.map((e) => `${L(e.route)}：${e.missing.join("、")}`), m = a.value === s ? `明日身价${X(s)}` : `余温架：${X(a.value)}→${X(s)}`, h = f ? `符合${o.commission.name}的${d.map((e) => e.route.count > 1 ? "其中一柄要求" : "一柄交付要求").join("或")}` : `尚不能直接交付：${p.join("；或")}`;
	return e({
		id: n,
		blade: a,
		valueNow: a.value,
		valueNext: s,
		canReserve: c,
		matching: f,
		missing: p,
		copy: `${m}，${h}。裂纹、配方与锤势保留；留它后是旧剑1＋新坯2，少一柄新坯，明日取下不补发。`
	});
}
function Jn(t, n) {
	let r = t.merchant, i = t.next, a = i?.normalBase ?? null;
	if (!r) return e({
		upgrade: {
			price: null,
			canBuy: !1,
			currentBase: a,
			afterBase: null,
			balanceAfter: null,
			reason: t.phase === "workshop" ? "行脚商人今天未到访。" : "回到商人到访的炉前，才能备料。",
			copy: i ? `按当前准备，下批${i.newCount}柄新坯的普通底价各${X(i.normalBase)}。` : "已经没有下一批来料。"
		},
		repair: {
			price: null,
			canBuy: !1,
			sealsBefore: t.seals,
			sealsAfter: t.seals,
			balanceAfter: null,
			reason: t.phase === "workshop" ? "行脚商人今天未到访。" : "回到商人到访的炉前，才能修印。",
			copy: "契印最多三枚；补印不能补完已经失约的关键约定。"
		}
	});
	let o = i ? y.find((e) => i.day >= e.days[0] && i.day <= e.days[1]) : void 0, s = t.growth.upgradeCount + 1, c = n?.upgraded || !i || !o || s > 3 ? null : Math.floor(o.base * 3 ** s / 2 ** s * t.growth.pending.supplyPct / 100), l = n?.upgraded ? null : t.coins - r.upgrade, u = "";
	n?.recordLimited ? u = `操作记录已到安全上限（${T}），不能再备料。` : n?.upgraded ? u = "本次到访已经备好铁料，不能重复购买。" : i ? t.coins < r.upgrade ? u = `还差${X(r.upgrade - t.coins)}铜钱。` : r.canUpgrade || (u = "这次暂不能再备料，请保留当前来料安排。") : u = "已经没有下一批来料。";
	let d = i && c !== null ? c + Math.min(c * 4, t.growth.inheritance) : null, f = n?.upgraded ? `下一批普通新坯底价已为${X(i?.normalBase ?? t.growth.supplyBase)}，手上已有的剑不再涨价。` : i && c !== null ? `下批${i.newCount}柄新坯：普通底价${X(i.normalBase)}→${X(c)}。${i.inheritanceBonus && d !== null ? `首柄另含余温，实际${X(i.firstBase)}→${X(d)}。` : ""}${i.oldCount ? "同行旧剑不涨价。" : "手上已有的剑不涨价。"}${Kn(r.upgrade, t.coins - r.upgrade)}` : "当前没有可再次购买的下一批来料；手上已有的剑保持原值。", p = "";
	n?.recordLimited ? p = `操作记录已到安全上限（${T}），不能再修印。` : n?.repaired ? p = "本次到访已经修过契印，不能重复修补。" : t.seals >= 3 ? p = "契印已满三枚，无需修补。" : t.coins < r.repair ? p = `还差${X(r.repair - t.coins)}铜钱。` : r.canRepair || (p = "这次暂不能再修印，请查看当前契印安排。");
	let m = n?.repaired ? t.seals : Math.min(3, t.seals + 1), h = n?.repaired || t.seals >= 3 ? null : t.coins - r.repair;
	return e({
		upgrade: {
			price: r.upgrade,
			canBuy: r.canUpgrade && !u,
			currentBase: a,
			afterBase: c,
			balanceAfter: l,
			reason: u,
			copy: f
		},
		repair: {
			price: r.repair,
			canBuy: r.canRepair && !p,
			sealsBefore: t.seals,
			sealsAfter: m,
			balanceAfter: h,
			reason: p,
			copy: `${n?.repaired ? "本次已修补；" : `契印${t.seals}→${m}；`}不补完失约或关键约定。${h === null ? "当前不会再次扣款。" : Kn(r.repair, h)}`
		}
	});
}
function Yn(t, n) {
	let r = t.blades.find((e) => e.blade.id === n);
	if (!r) return e({
		pieceId: n,
		allowed: !1,
		reason: "这柄已经离开炉边，请重新选剑。",
		opportunity: []
	});
	let i = {
		wrong_phase: "先回炉前，再决定献剑。",
		record_limit: "操作记录已到安全上限，仍可交剑或回收。",
		piece_unavailable: "这柄已经离开炉边。",
		reserved_piece: "先取回挂架剑，才能献艺。",
		blade_unworked: `当前等级${r.blade.level}；成器至少等级3，普通成功加1、大成加2。`
	}, a = r.barter.error ? i[r.barter.error] ?? "当前不能献出这柄剑。" : t.merchant ? "" : "行脚商人今天未到访。", o = [];
	r.quote.matched ? o.push(`${r.reserved ? "取回后按当前报价，" : ""}今天可交给${t.commission.name}，实收${X(r.quote.amount)}铜钱（酬劳${X(r.quote.baseFeeDelta)}＋品质${X(r.quote.qualityBonus)}）。`) : r.quote.allowed ? o.push(`今天卖给行会实收${X(r.quote.amount)}铜钱，不计主委托。`) : r.quote.error === "market_exhausted" ? o.push("今日收购钱袋已空，普通出售当前为0；剑仍保留。") : r.reserved && o.push(r.quote.amount > 0 ? `先取回挂架剑；按当前报价卖给行会可收${X(r.quote.amount)}铜钱，不计主委托。` : "这柄正在剑架上，不能直接交换；今日钱袋已空，取回后也不能普通出售。"), r.quote.matched && t.commission.routes.some((e) => e.count > 1) && o.push("献出去后不能再计入这份双剑或替代路线委托。");
	let s = qn(t, n);
	return s && t.next ? o.push(s.copy) : t.next || o.push("最后一炉没有明日来料；挂架也不会把兵器带入新局。"), o.push(`${r.reserved ? "先取回后，按当前钱袋" : "明确"}回收实得${X(r.recovery)}铜钱；献艺后不能再回收。`), e({
		pieceId: n,
		allowed: r.barter.allowed && !!t.merchant,
		reason: a,
		opportunity: o
	});
}
function Xn(e, t, n) {
	return Wn(e, {
		...t,
		blades: t.blades.filter((e) => e.blade.id !== n)
	});
}
//#endregion
//#region src/presentation-v5/market-stall.ts
var Zn = (e) => e.toLocaleString("zh-CN");
function Qn(e, t) {
	let n = Y("div", void 0, "v5-market-stall"), r = e.merchant;
	if (!r) return n.append(Y("p", "商人已经离开，回炉边继续这一程。")), n;
	let i = r.offers, a = Jn(e, t.growthControls), o = (e.blades.find((e) => e.blade.id === t.selectedPieceId) ?? e.blades.find((e) => e.barter.allowed) ?? e.blades.find((e) => !e.reserved) ?? e.blades[0])?.blade.id ?? null, s = i[0] ? {
		kind: "trait",
		id: i[0].id
	} : { kind: "upgrade" }, c = Y("header", void 0, "v5-stall-heading"), l = Y("div");
	l.append(Y("b", "炉边开摊"), Y("p", "手艺用剑换，备料与补印用铜钱。先挑一件，看看值不值得。"));
	let u = Y("p", void 0, "v5-stall-purse");
	u.append(Y("small", "行囊"), Y("strong", Zn(e.coins)), Y("span", "铜钱")), c.append(l, u), n.append(c);
	let d = Y("div", void 0, "v5-stall-goods");
	d.setAttribute("aria-label", "摊上的物件");
	let p = [], m = (e) => {
		let t = Y("span", void 0, `v5-stall-cash-art v5-stall-${e}`);
		if (t.setAttribute("aria-hidden", "true"), e === "upgrade") for (let e = 0; e < 3; e++) t.append(Y("i"));
		else for (let e = 0; e < 3; e++) t.append(Y("i", "契"));
		return t;
	}, h = (e, n, r, i) => {
		let a = t.action(n, () => {
			s = e, ue();
		});
		a.classList.add("v5-stall-good"), a.dataset.stallGood = e.kind, e.kind === "trait" && (a.dataset.stallTrait = e.id), a.replaceChildren(e.kind === "trait" ? ln(e.id) : m(e.kind), Y("b", n), Y("small", i || r)), a.setAttribute("aria-label", `${n} · ${i || r}，查看用途`), p.push({
			node: a,
			value: e
		}), d.append(a);
	};
	for (let e of i) h({
		kind: "trait",
		id: e.id
	}, e.name, "献一柄成器", e.sold ? "已换走" : e.owned ? "已经带着" : "");
	h({ kind: "upgrade" }, "下一批铁料", `${Zn(r.upgrade)}铜钱`, t.growthControls?.upgraded ? "本次已备好" : ""), h({ kind: "repair" }, "补一枚契印", `${Zn(r.repair)}铜钱`, t.growthControls?.repaired ? "本次已修补" : e.seals === 3 ? "契印已满" : ""), n.append(d);
	let g = Y("div", void 0, "v5-stall-main"), v = Y("section", void 0, "v5-stall-detail");
	v.setAttribute("aria-label", "所选物件的用途");
	let y = Y("div", void 0, "v5-stall-hero"), b = Y("div", void 0, "v5-stall-hero-art"), x = Y("div"), S = Y("small"), C = Y("h3"), w = Y("p", void 0, "v5-stall-rule");
	x.append(S, C, w), y.append(b, x);
	let T = Y("b", void 0, "v5-stall-purpose"), E = Y("p", void 0, "v5-stall-purpose-copy"), D = Y("p", void 0, "v5-stall-cost"), O = Y("p", void 0, "v5-stall-reason");
	O.setAttribute("role", "status");
	let k = Y("details", void 0, "v5-stall-rules"), ee = Y("p");
	k.append(Y("summary", "细看代价与规则"), ee);
	let A = t.action("", () => {
		if (s.kind === "upgrade") {
			a.upgrade.canBuy && t.upgrade();
			return;
		}
		if (s.kind === "repair") {
			a.repair.canBuy && t.repair();
			return;
		}
		let n = s.id, r = i.find((e) => e.id === n), c = Yn(e, o ?? "");
		r && !r.owned && !r.sold && c.allowed && o && t.buy(n, o);
	}, !0);
	A.classList.add("v5-stall-purchase"), v.append(y, T, E, D, A, O, k), g.append(v);
	let te = Y("section", void 0, "v5-stall-payment"), ne = Y("div", void 0, "v5-stall-swords"), j = Y("h3", "选一柄来换"), re = Y("div", void 0, "v5-stall-sword-list");
	re.setAttribute("aria-label", "摊内挑选献剑");
	let M = [];
	for (let n of e.blades) {
		let e = n.blade, r = t.action(`${_[e.recipe].name} · 等级${e.level}`, () => {
			o = e.id, ue();
		});
		r.classList.add("v5-stall-sword"), r.dataset.stallPiece = e.id, r.replaceChildren(t.thumb(e), Y("b", `${_[e.recipe].name} · 等级${e.level}`), Y("small", n.reserved ? "已挂剑架" : n.quote.matched ? `交委托实收${Zn(n.quote.amount)}` : `出售实收${Zn(n.quote.amount)}`)), M.push({
			id: e.id,
			node: r
		}), re.append(r);
	}
	let ie = Y("p", void 0, "v5-stall-trade-reason"), N = Y("ul", void 0, "v5-stall-opportunities");
	ne.append(j, re, ie, N), e.blades.length || ne.append(Y("p", "这一炉已没有可献的剑。仍可查看手艺，或用铜钱备料与补印。"));
	let ae = Y("div", void 0, "v5-stall-cash-payment"), oe = Y("h3", "从行囊里付"), se = Y("p"), ce = Y("p", void 0, "v5-stall-cash-after"), P = Y("p", void 0, "v5-stall-cash-note");
	ae.append(oe, se, ce, P), te.append(ne, ae), g.append(te), n.append(g);
	let le = Y("p", "今日收购钱袋余" + Zn(e.market.remaining) + "铜钱；交出主委托的基础酬劳另算。挑选和查看不花钱，也不移动炉前的剑。", "v5-stall-footnote");
	n.append(le);
	function ue() {
		n.dataset.selection = s.kind;
		for (let e of p) e.node.setAttribute("aria-pressed", String(e.value.kind === s.kind && (e.value.kind !== "trait" || s.kind === "trait" && e.value.id === s.id)));
		for (let e of M) e.node.setAttribute("aria-pressed", String(e.id === o));
		let r = s.kind === "trait";
		if (ne.hidden = !r, ae.hidden = r, O.hidden = !1, k.open = !1, s.kind === "trait") {
			let t = s.id, n = i.find((e) => e.id === t), r = f[t], a = Xn(t, e, o ?? ""), c = Yn(e, o ?? "");
			b.replaceChildren(ln(t)), S.textContent = "一柄成器，换一门手艺", C.textContent = r.name, w.textContent = r.text, T.textContent = a.headline, E.textContent = a.copy, v.dataset.tone = a.tone, D.textContent = a.replacementRequired ? "献出所选成器，并明确换下一门旧手艺。" : "献出所选成器，装进手艺行囊。", ee.textContent = a.costCopy, A.textContent = n.sold ? "这门手艺已换走" : n.owned ? "已经带着这门手艺" : o && c.allowed ? `献这柄，换${r.name}` : "先选可献的成器", A.disabled = n.sold || n.owned || !c.allowed, O.textContent = n.sold ? "本次摊位没有第二件。" : n.owned ? "无需再交一柄剑。" : c.allowed ? "确认前，仍可换一柄比较；剑只在最终确认后交出。" : c.reason, ie.textContent = c.allowed ? "所选剑可献，先看它原本能去哪里。" : c.reason, N.replaceChildren(...c.opportunity.map((e) => Y("li", e))), N.childElementCount || N.append(Y("li", "选一柄剑，查看它与今日委托、明日留剑的取舍。"));
		} else {
			let n = a[s.kind], r = s.kind === "upgrade";
			b.replaceChildren(m(s.kind)), S.textContent = r ? "给后面的炉火备料" : "让眼前的行旅继续", C.textContent = r ? "下一批更好的铁料" : "补回一枚契印", w.textContent = r ? a.upgrade.currentBase === null || a.upgrade.afterBase === null ? "查看后续来料的变化" : `明日普通底价 ${Zn(a.upgrade.currentBase)} → ${Zn(a.upgrade.afterBase)}` : `契印 ${a.repair.sealsBefore}/3 → ${a.repair.sealsAfter}/3`, T.textContent = r ? "只影响后续新坯，手上旧剑不涨价" : "补契印，保不回已经失约的那一单", E.textContent = n.copy, v.dataset.tone = n.canBuy ? "ready" : "neutral", D.textContent = n.price === null ? "商人此刻没有这项报价。" : `这次付${Zn(n.price)}铜钱 · 每次到访限一次`, ee.textContent = r ? "备料不改变手上已有剑的身价。留一柄时，明日发两柄新坯；不留则发三柄。旧剑占用一个总名额，明日取下也不会补第四柄。" : "最多三枚契印。补印不会替你完成第4、8、12天的关键约定，也不会补发未取得的作品或基础酬劳。", A.textContent = r ? t.growthControls?.upgraded ? "本次已备好" : "准备更好的铁料" : t.growthControls?.repaired ? "本次已修补" : "请商人修补", A.disabled = !n.canBuy, O.textContent = n.reason || "先看清付款后的行囊，再决定是否请商人动手。", se.textContent = `现在 ${Zn(e.coins)}铜钱`, ce.textContent = n.balanceAfter === null ? "暂无可确认的付款" : n.balanceAfter < 0 ? `还差 ${Zn(-n.balanceAfter)}铜钱` : `付后留下 ${Zn(n.balanceAfter)}铜钱`, P.textContent = r && e.next ? `按眼前剑架：明日${e.next.oldCount}柄旧剑＋${e.next.newCount}柄新坯。${e.next.inheritanceBonus ? "第一新坯还接余温加料；" : "首新坯的借锤、炉棚等另按实际准备；"}备料不会多发一柄。` : "铜钱从你的行囊支付，与今日收购钱袋分开；取消不会扣款。";
		}
	}
	return ue(), n;
}
//#endregion
//#region src/presentation-v5/raw-run-export.ts
function $n(e, t = () => (/* @__PURE__ */ new Date()).toISOString()) {
	let n = (t) => {
		try {
			return {
				key: t,
				ok: !0,
				raw: e().getItem(t)
			};
		} catch {
			return {
				key: t,
				ok: !1,
				error: "storage_read_failed"
			};
		}
	};
	return {
		format: "sword-led.disk-run-export.v1",
		capturedAt: t(),
		slots: {
			main: n(Nt),
			backup: n(Pt)
		}
	};
}
//#endregion
//#region src/presentation-v5/journey.ts
var er = "/assets/d/v07-chapter2/", tr = "/assets/d/v07-chapter3/", nr = "守住第4、8、12天的关键约定，至少完成10项，并带着契印归来，才能让十二灯复明。", rr = (e) => [
	4,
	8,
	12
].includes(e);
function ir(e, t = 12) {
	return e.day > t ? "future" : e.phase === "defeat" ? "defeat" : e.phase === "victory" || e.phase === "return" ? "ending" : e.phase === "opening" ? "opening" : e.phase === "chapter" ? "chapter" : e.phase === "summary" ? e.day === t ? "complete" : "receipt" : "workshop";
}
function ar(e, { complete: t, count: n = 0 }) {
	if (!S.some((t) => t.id === e)) throw RangeError("Unknown journey commission");
	return e === 4 ? `/assets/d/v07/bridge-${t ? "lit" : "dark"}-v1.webp` : e === 5 ? er + (t ? "returning-blade-v1.webp" : "winter-forge-v1.webp") : e === 6 ? er + (t ? "cracked-work-v1.webp" : "winter-forge-v1.webp") : e === 7 ? er + (t ? "rescue-path-v1.webp" : "winter-forge-v1.webp") : e === 8 ? `/assets/d/v07-chapter2/twin-stations-${t ? "lit" : n > 0 ? "one" : "dark"}-v1.webp` : e === 9 ? tr + (t ? "double-fire-work-v1.webp" : "mountain-pass-arrival-v1.webp") : e === 10 ? tr + (t ? "mountain-gap-held-v1.webp" : "mountain-pass-arrival-v1.webp") : e === 11 ? tr + (t ? "relay-complete-v1.webp" : n > 0 ? "relay-one-v1.webp" : "mountain-pass-arrival-v1.webp") : e === 12 ? tr + (t ? "last-lantern-delivered-v1.webp" : "mountain-pass-arrival-v1.webp") : "/assets/d/v07/lantern-road-v1.webp";
}
function or(t, n) {
	let r = y.find((e) => e.id === n);
	if (!r) throw RangeError("Unknown journey chapter");
	let [i, a] = r.days, o = t.history.filter((e) => e.day >= i && e.day <= a), s = o.find((e) => e.day === a);
	return e({
		chapterId: r.id,
		title: r.title,
		startDay: i,
		endDay: a,
		opening: r.opening,
		letter: r.letter,
		letterAvailable: t.day >= i + 2,
		completed: o.filter((e) => e.met).length,
		days: o.length,
		chapterEndMet: s?.met ?? !1,
		chapterResolved: !!s,
		chapterEarned: !!s && s.sealsAfter > 0,
		closing: s ? {
			...s,
			pieceIds: [...s.pieceIds],
			recoveredIds: [...s.recoveredIds]
		} : null,
		lamps: Array.from({ length: a - i + 1 }, (e, n) => {
			let r = i + n, a = t.commissionOrder[r - 1], s = o.find((e) => e.day === r);
			return {
				day: r,
				commissionId: a,
				title: S[a - 1].title,
				resolved: !!s,
				done: s?.met ?? !1
			};
		})
	});
}
function sr(t, n) {
	let r = S.find((e) => e.id === n), i = t.commissionOrder.indexOf(n);
	if (!r || i < 0) throw RangeError("Unknown journey commission");
	let a = {
		...r,
		request: r.request.replaceAll("昨日", "此前")
	}, o = i + 1, s = t.history.find((e) => e.day === o && e.commissionId === n), c = o === t.day && !s ? ae(t) : null, l = new Map(t.journal.flatMap((e, t) => e.type === "deliver" ? [[e.pieceId, t]] : [])), u = t.blades.filter((e) => e.status === "commissioned" && e.commissionId === n && e.finalizedDay === o).sort((e, t) => (l.get(e.id) ?? 2 ** 53 - 1) - (l.get(t.id) ?? 2 ** 53 - 1)), d = a.routes.map((e) => {
		let t = u.filter((t) => N({ day: o }, t, e).matches).map((e) => e.id);
		return {
			id: e.id,
			required: e.count,
			count: t.length,
			pieceIds: t,
			complete: t.length >= e.count
		};
	}), f = c?.routes ?? d, p = c?.complete ?? s?.met ?? !1, m = c?.routeId ?? s?.routeId ?? null, h = f.find((e) => e.id === m) ?? f.find((e) => e.complete) ?? f.reduce((e, t) => t.count > e.count ? t : e), g = c ? [...c.pieceIds] : s?.met ? [...s.pieceIds] : [], _ = [...new Set(f.flatMap((e) => e.pieceIds))].sort((e, t) => (l.get(e) ?? 2 ** 53 - 1) - (l.get(t) ?? 2 ** 53 - 1)), v = g.map((e) => ({ ...t.blades.find((t) => t.id === e) })), y = _.map((e) => ({ ...t.blades.find((t) => t.id === e) })), b = h.count, x = h.required;
	return e({
		commissionId: n,
		day: o,
		commission: a,
		complete: p,
		routeId: m,
		count: b,
		required: x,
		pieceIds: g,
		matchedPieceIds: _,
		blades: v,
		matchedBlades: y,
		image: ar(n, {
			complete: p,
			routeId: m,
			count: b,
			required: x
		}),
		settled: !!s,
		met: s?.met ?? p,
		routes: f.map((e, t) => ({
			...e,
			description: L(a.routes[t])
		})),
		progressText: f.map((e) => `${e.count}/${e.required}`).join(" 或 ")
	});
}
function cr(t) {
	if (t.phase !== "victory" && t.phase !== "return" && t.phase !== "defeat") return null;
	let n = structuredClone(t), r = z(n), i = r.ending, a = n.commissionOrder.map((e) => {
		let t = sr(n, e);
		return {
			...t,
			status: t.settled ? t.met ? "met" : "missed" : "unreached"
		};
	}), o = [
		{
			name: "阿岚",
			customer: "guard",
			commissionIds: [
				1,
				4,
				7,
				10
			]
		},
		{
			name: "阿禾",
			customer: "courier",
			commissionIds: [
				2,
				5,
				8,
				11
			]
		},
		{
			name: "杜伯",
			customer: "smith",
			commissionIds: [
				3,
				6,
				9,
				12
			]
		}
	].map((e) => {
		let t = e.commissionIds.map((e) => a.find((t) => t.commissionId === e)), n = t.filter((e) => e.status === "met").length, r = (e) => t.find((t) => t.commissionId === e)?.status === "met", i = (e) => t.find((t) => t.commissionId === e)?.status !== "unreached", o = "";
		return e.customer === "guard" && (o = r(4) && r(10) ? "渡口有人巡守，山口也有剑守着。你送来的每一柄，我都交到了等它的人手里。" : r(4) ? "渡口的灯守住了。山口还没接上的那一段，我会记着，等你下次来。" : r(10) ? "缺口前的护刃已经在岗。渡口留下的遗憾，也不会因为这一柄好剑被抹去。" : n ? "你已经做成的巡剑，我会继续带着。还没点亮的地方，等下一炉。" : "这一程还没等到合格的巡剑。灯站还在这里，等你下一炉再来。"), e.customer === "courier" && (o = r(8) && r(11) ? "两条驿路都有了剑，最后的接力也送到了。归去的信，这回可以走同一条灯路。" : r(8) ? "双驿的两柄轻刃都到了。最后的接力还没接完，我会把这封信留着。" : r(11) ? "最后的接力接上了。双驿没能齐亮的那一夜，也留在信里。" : t.some((e) => e.commissionId === 8 && e.matchedBlades.length > 0) ? "你送到双驿的那一柄已经有人带走；另一站还在等，不能把一柄剑说成两柄。" : n ? "送到过的剑和信，我都收妥了。没有走完的路，留待下一程。" : "这次驿路还没等到合格的剑。信留着，下一程再接。"), e.customer === "smith" && (o = r(12) ? "护灯剑已经送到。锻纹、火候，还有你肯停手的那一刻，这柄剑都记住了。" : i(12) ? r(9) ? "两次连锻的回响我听见了。最后的护灯剑还差一点，但学会的火候不会白费。" : n ? "护灯剑还没有做成。已经交来的作品我会留下，让下一炉有个可回看的起点。" : "这次还没有收到合格的作品。炉火可以再起，不必把没做成的剑说成成品。" : "这一程还没走到护灯的山口。炉谱只记已经学会的手艺，不替你写下尚未走到的结果。"), {
			...e,
			records: t,
			afterword: o,
			completed: n,
			missed: t.filter((e) => e.status === "missed").length,
			unreached: t.filter((e) => e.status === "unreached").length
		};
	}), s = tr + (n.phase === "victory" ? "ending-twelve-lights-v1.webp" : n.phase === "return" ? "ending-homeward-v1.webp" : "ending-embers-v1.webp");
	return e({
		...i,
		phase: n.phase,
		image: s,
		lamps: a,
		people: o,
		works: a.filter((e) => e.met).map((e) => ({
			commissionId: e.commissionId,
			day: e.day,
			routeId: e.routeId,
			pieceIds: [...e.pieceIds],
			blades: e.blades.map((e) => ({ ...e }))
		})),
		chapters: r.collection.chapters.slice(),
		mastery: r.collection.mastery.slice(),
		traits: r.collection.traits.slice()
	});
}
//#endregion
//#region src/presentation-v5/stages.ts
var Z = (e) => e.toLocaleString("zh-CN"), lr = "/assets/d/v07-chapter3/";
function ur(e, t) {
	let n = structuredClone(e), r = z(n), i = or(n, r.chapter.id), a = n.history.at(-1), o = ir(n, t.throughDay), s = o === "future" || o === "ending" || o === "defeat" ? o : t.delivery ? "delivery" : t.chapterIntro ? "intro" : o, c = Y("div", void 0, "v4-journey-copy"), l = [], u = "", d = "/assets/d/v07/lantern-road-v1.webp", p = (e) => c.append(Y("p", e)), m = () => {
		a?.protected && c.append(Y("p", "护炉契保住了这次契印；本局不会再次保印，未完成的约定仍如实留下。", "v4-protection-receipt"));
	}, h = (e, r, i = c) => {
		if (!e.length) return;
		let a = Y("div", void 0, "v4-delivery-works");
		for (let i of e) {
			let e = Y("figure", void 0, "v4-journey-work");
			e.dataset.piece = i.id, e.dataset.rulesVersion = n.rulesVersion, e.append(t.thumb(i), Y("figcaption", `${_[i.recipe].name} · ${Z(i.value)}估值 · 等级${i.level} · 连锻${i.bursts}次 · 第${i.suppliedDay}天来料${i.suppliedDay < r ? "，此前留剑" : "，本日新剑"}${i.cracked ? " · 有裂纹" : " · 无裂纹"}`)), a.append(e);
		}
		i.append(a);
	}, g = () => {
		let e = r.next;
		if (!e) return;
		let i = Y("section", void 0, "v4-next-journey");
		i.append(Y("h3", `明天：${e.commission.title}`), Y("p", e.commission.request));
		for (let t of e.commission.routes) i.append(Y("p", L(t)));
		if (i.append(Y("p", `明日旧剑${e.oldCount}柄＋新坯${e.newCount}柄，共${e.totalCount}柄。新坯普通底价各${Z(e.normalBase)}。${e.inheritanceBonus ? `第一柄新坯另有余温铁夹来料，实际底价${Z(e.firstBase)}。` : ""}`)), n.pending.supplyPct === 120 && i.append(Y("p", `护送的20%来料加成已计入上面的底价，只用于明日实际领到的${e.newCount}柄新坯；留剑不吃这份加成。`)), (n.pending.loan || n.pending.shelter) && i.append(Y("p", `明日第一柄新坯${n.pending.loan ? "带上借锤，前三记普通锤的正收益额多10%" : ""}${n.pending.loan && n.pending.shelter ? "；" : ""}${n.pending.shelter ? "受炉棚照应，当天裂损率降低3个百分点" : ""}。这些效果不作用于同行旧剑，也不会因取下旧剑多领一柄。`)), e.reserve) {
			let r = n.blades.find((t) => t.id === e.reserve.id);
			if (r) {
				i.append(t.thumb(r), Y("p", `架上${_[r.recipe].name}：当前估值${Z(r.value)} → 明日${Z(e.reserve.value)}；${e.reserve.cracked ? "裂纹保留" : "无裂纹"}，锤势${e.reserve.charge}/6。留剑少领一柄新坯，明日取下也不补发。`));
				let n = e.reserve.assessment.routes.filter((e) => e.matches);
				i.append(Y("p", n.length ? `这柄留剑已符合明日${n.map((t) => e.commission.routes.find((e) => e.id === t.id).count > 1 ? "其中一柄的要求" : "一柄交付要求").join("、")}，明日取回后可交。` : `这柄留剑尚不能交明日的单：${e.reserve.assessment.routes.map((e) => e.missing.join("、")).join("；或")}。`));
			}
		} else i.append(Y("p", "没有留剑，可领三柄新坯；若现在留一柄，会变成旧剑1＋新坯2。需要旧剑时，纸单上的新剑替代路线仍然可做。"));
		e.merchant && i.append(Y("p", "行脚商人将到炉边，可用等级≥3、未挂剑架的剑换手艺；铜钱可准备后续铁料或修补契印。")), c.append(i);
	}, v = (e = c) => {
		if (!r.modifications.length) return;
		let n = Y("div", void 0, "v4-journey-modifications");
		for (let e of r.modifications) {
			let r = Y("section", void 0, "v4-equipped-modification");
			r.append(t.prop(e.id), Y("h3", e.name + " · 已装好"), Y("p", e.text)), n.append(r);
		}
		e.append(n);
	}, b = (e) => {
		let n = e === 1 ? "护刃" : "重锋", r = !t.collection.pending && !t.collection.problem && t.collection.data.chapters.includes(e);
		p(t.temporary ? "本次是不保存试玩，新的章节成果不会写入炉谱；离开前可导出这次行程。已有炉谱记录保持原样。" : r ? `炉谱已记下第${e === 1 ? "一" : "二"}章。下次启程可自由使用${n}。` : "这次章节成果等待安全保存，请查看保存详情；当前行程与已选炉具保持原样。");
	};
	if (s === "delivery" && t.delivery) {
		let e = sr(n, t.delivery.commissionId), i = e.commission;
		c.dataset.commission = String(i.id), c.dataset.receipt = e.complete ? "complete" : "partial", u = e.complete ? i.title : `${i.title} · 已交付${e.progressText}`, d = e.image, p(e.complete ? i.success : `已经交付${e.progressText}，尚未完成这站委托。合格兵器不能重复计数。`);
		let a = e.complete ? e.pieceIds : e.matchedPieceIds;
		if (h([.../* @__PURE__ */ new Set([...t.delivery.pieceIds, ...a])].filter((e) => a.includes(e)).map((e) => n.blades.find((t) => t.id === e)), e.day), i.routes.length > 1 || i.routes.some((e) => e.count > 1)) {
			for (let t of e.routes) p(`${t.description}：已交付${t.count}/${t.required}${t.id === e.routeId ? " · 以此路线完成" : ""}`);
			e.complete || p(i.routes.length > 1 ? "任一路线凑齐即可；两条路线的剑数不能相加。已送出的剑不会退回，剩下的剑仍可选择继续打造或收工。" : "还要另一柄各自合格的剑。已送出的剑已记在纸单上，不能用同一柄再交一次。");
		}
		if (i.id === 11) {
			let t = e.matchedBlades.filter((t) => !e.pieceIds.includes(t.id));
			e.complete && t.length && (p("此前交过的新剑也已送出；本次由旧剑路线接完，不计作两柄新剑完成。"), h(t, e.day));
		}
		i.id === 12 && p("护灯剑验收完成。回炉边收工后，才会按沿途真实完成的约定判定这次结局。"), p(`已交给${i.name}。交出的剑不会再回到剑架、回收或换取手艺。`), p(`本日累计交剑实收${Z(n.daySales)}铜钱：已领酬劳${Z(r.market.baseFeesPaid)}，品质奖及余剑出售${Z(n.daySales - r.market.baseFeesPaid)}。今日收购钱袋还剩${Z(r.market.remaining)}铜钱；图中的作品估值用于验剑，本日收入按实收记录入账。`), l.push(t.action("回到铁砧", t.leaveScene, !0));
	} else if (s === "intro") {
		u = r.chapter.title, d = r.chapter.id === 3 ? lr + "mountain-pass-arrival-v1.webp" : r.chapter.id === 2 ? "/assets/d/v07-chapter2/twin-stations-dark-v1.webp" : "/assets/d/v07/lantern-road-v1.webp", p(r.chapter.opening), p(r.commission.request);
		for (let e of r.commission.routes) p(e.description);
		let e = n.blades.find((e) => e.id === n.reserveId);
		e ? (c.append(t.thumb(e)), p(`剑架上同行的${_[e.recipe].name}，现在估值${Z(e.value)}。先取回，再决定交付还是续锻。`)) : p(r.commission.routes.some((e) => e.age === "new") ? "未留旧剑也能继续：可以用纸单上的新剑路线接替这一程。" : `这一炉有${r.blades.filter((e) => e.blade.suppliedDay === r.day).length}柄新坯、${r.blades.filter((e) => e.blade.suppliedDay < r.day).length}柄沿途旧剑，共三槽；先看纸单，再决定这一程的打法。`), r.chapter.id === 3 && p(`最后一位商人今天到来。炉具与沿途学会的手艺仍在；最终护灯剑需要：${L(S[11].routes[0])}。`), l.push(t.action("回到铁砧", t.leaveScene, !0));
	} else if (s === "opening") {
		u = y[0].title, p(y[0].opening), p(nr), t.throughDay === 4 && p("这次先走第一章四天：接下四份委托，收工后选择第一件炉具改造。首章完成会保存这次行程与炉谱，后续章节接入后再从这里继续。"), p(r.commission.request);
		for (let e of r.commission.routes) p(e.description);
		p("左键敲击，见好就交。每次收工只按真实完成情况判定契印。"), l.push(t.commandAction("点火开炉", { type: "continue" }), t.commandAction("跳过开场", { type: "continue" }, !1));
	} else if (s === "receipt" && a) {
		let e = sr(n, a.commissionId);
		if (u = n.day === 4 ? "第一程，走完了" : n.day === 8 ? "第二程，走完了" : a.met ? "这一站的约定，做到了" : "带着遗憾，继续上路", d = e.image, p(e.commission[a.met ? "success" : "failure"]), p(`交剑 ${Z(a.sales)}铜钱 · 回收 ${Z(a.recovered)}铜钱 · 契印 ${a.sealsAfter}/3`), p(`交剑实收含酬劳${Z(a.baseFees)}＋品质奖及余剑出售${Z(a.sales - a.baseFees)}。当日收购钱袋共支出${Z(a.marketSpent)}铜钱，包含品质奖、余剑出售与回收；作品估值用于验剑，铜钱按回执入账。`), a.protected && p("护炉契保住了这次契印；本局不会再次保印。"), a.reserveId) {
			let e = n.blades.find((e) => e.id === a.reserveId);
			e && (c.append(t.thumb(e)), p(`留下${_[e.recipe].name} · 当前估值${Z(e.value)}。`));
		}
		if (n.day === 4 && (p(`第一章委托完成 ${i.completed}/4；渡口${i.chapterEndMet ? "已恢复巡守" : "仍有未竟的约定"}。`), v(), b(1), p(y[1].opening)), n.day === 8 && (p(`双驿实际交付 ${e.progressText} · 第二章完成 ${i.completed}/4。`), h(e.matchedBlades, e.day), v(), b(2), p(y[2].opening)), e.commissionId === 11) {
			for (let t of e.routes) p(`${t.description}：实际交付${t.count}/${t.required}${t.id === e.routeId ? " · 完成路线" : ""}`);
			let t = e.matchedBlades.filter((t) => !e.pieceIds.includes(t.id));
			e.complete && t.length && p(`此前已送出的${t.length}柄新剑仍如实记账；本单由旧剑路线完成，不另算一次两柄新剑完成。`);
		}
		g(), l.push(t.commandAction("沿灯路，去下一天", { type: "advance" }), t.action("翻开炉谱", t.book), t.action(n.day === 8 ? "带着炉谱，再启一程" : "回标题", t.toTitle)), (n.day === 4 || n.day === 8) && l.push(t.action("导出这次行程", t.exportRun));
	} else if (s === "chapter") {
		let e = sr(n, n.commissionOrder[i.endDay - 1]);
		if (d = e.image, u = r.chapter.id === 1 ? a?.met ? "渡口重新亮了" : "炉火还在，渡口仍有缺口" : e.complete ? "风雪双驿，灯火相连" : e.count ? "一站有灯，一站仍在风雪里" : "双驿仍在等剑", p(e.commission[a?.met ? "success" : "failure"]), r.chapter.id === 2 && (p(`双驿实际交付 ${e.progressText}；两柄剑必须分别合格。`), h(e.matchedBlades, e.day)), p(`本章完成 ${i.completed}/4 项委托，仍有${n.seals}枚契印。${a?.met ? "这一程的约定已经做成。" : "未完成的约定如实留下，炉火存续仍可改造。"}`), m(), r.modifications.length) {
			let e = Y("details", void 0, "v5-journey-details");
			e.append(Y("summary", "第一程装好的炉具，仍同行")), v(e), c.append(e);
		}
		c.append(Y("h3", n.day === 8 ? "入山口前，再改第二件炉具" : "给下一程，改一件炉具")), n.day === 8 && p("从尚未装过的炉具中再选一件，两件效果会一同带入最后四天。保留眼前的第一件，不需要用它换新。");
		let o = Y("div", void 0, "v4-choice-grid v4-modification-choices");
		for (let e of r.chapterChoices) {
			let n = Y("article", void 0, "v4-card");
			n.dataset.modification = e.id;
			let r = Y("div", void 0, "v4-modification-plinth");
			r.append(t.prop(e.id)), n.append(r, Y("h3", e.name), Y("p", e.text), t.commandAction(`装上${e.name}`, {
				type: "chooseModification",
				modification: e.id
			})), o.append(n);
		}
		c.append(o), l.push(t.action("先看看炉谱", t.book), t.action("回标题，保留选择", t.toTitle));
	} else if (s === "complete") {
		let e = sr(n, n.commissionOrder[i.endDay - 1]);
		u = t.throughDay === 4 ? i.chapterEndMet ? "第一章，渡口重新亮了" : "第一章，炉火仍在" : "第二程，走完了", d = e.image, p(e.commission[i.chapterEndMet ? "success" : "failure"]), p(`${t.throughDay === 4 ? "渡口约定" : "双驿实际交付"} ${e.progressText} · 第${t.throughDay === 4 ? "一" : "二"}章完成 ${i.completed}/4 · 契印 ${n.seals}/3`), a && p(`今天交剑实收${Z(a.sales)}铜钱（酬劳${Z(a.baseFees)}＋品质奖及余剑出售${Z(a.sales - a.baseFees)}），回收${Z(a.recovered)}；今日收购钱袋共支出${Z(a.marketSpent)}。`), p(t.throughDay === 4 ? "本次旅程开放第一章，四天与已选炉具都已留在行程。第二章开放后，可在这里接续。" : "前两程已收好。后续灯路开放后，可在这里接续，尚未抵达十二灯结局。"), b(r.chapter.id), r.modifications.length && p("已装炉具：" + r.modifications.map((e) => e.name + " · " + e.text).join("；")), m(), h(e.matchedBlades, e.day), v(), l.push(t.action("翻开炉谱", t.book, !0), t.action(t.throughDay === 4 ? "回路口，保留首章进度" : "带着炉谱，再启一程", t.toTitle), t.action("导出这次行程", t.exportRun));
	} else if (s === "ending" || s === "defeat") {
		let e = cr(n), i = Y("section", void 0, "v4-ending-memories");
		u = e.title, d = e.image, c.dataset.ending = e.phase, p(e.text), p(`走到第${n.day}天 · 实际完成 ${e.completed}/12 项委托 · 契印 ${n.seals}/3`);
		let a = t.action("听听三人的后话", () => {
			i.scrollIntoView({ block: "start" }), i.querySelector("summary")?.focus({ preventScroll: !0 });
		});
		a.classList.add("v4-ending-listen"), c.append(a), e.phase === "defeat" ? p("契印已用尽，这次行程在这里停下。未抵达的约定保持空白；已有作品与成长不会被写成丢失。") : e.finalBladeMade ? p(e.phase === "victory" ? "山口护灯剑已验收，关键的灯路接通了。其他失约仍保留在沿途记录中。" : "山口护灯剑已经做成；沿途仍有未完成的关键约定或完成数量不足，因此这次是灯下归途。") : p("山口护灯剑尚未做成；这次归途保留已经完成的作品与手艺。");
		let o = e.missingCritical.map((t) => e.lamps.find((e) => e.day === t));
		if (o.length && p("尚未完成的关键约定：" + o.map((e) => `第${e.day}天 · ${e.commission.title}${e.status === "unreached" ? "（未抵达）" : ""}`).join("；") + "。"), e.completed < 10 && p(`距至少完成10项的约定，还差${10 - e.completed}项；这次结局按已经完成的记录保留。`), e.finalBladeMade) {
			let t = e.lamps.find((e) => e.commissionId === 12);
			c.append(Y("h3", "这次真正交出的护灯剑")), h(t.blades, t.day);
		}
		let m = Y("details", void 0, "v5-journey-details");
		m.append(Y("summary", "这一程的手艺与入袋账")), v(m), m.append(Y("p", `来料升级${r.growth.upgradeCount}次 · 当前铁坯底价${Z(r.growth.supplyBase)} · 可用配方：${r.recipes.map((e) => e.name).join("、")}。`)), m.append(Y("p", `本次配方熟练：${e.mastery.length ? e.mastery.map((e) => _[e].name).join("、") : "尚未取得"}；手艺见闻：${e.traits.length ? e.traits.map((e) => f[e].name).join("、") : "尚未取得"}。`)), m.append(Y("p", `沿途交剑实收${Z(n.history.reduce((e, t) => e + t.sales, 0))}铜钱，其中酬劳${Z(n.history.reduce((e, t) => e + t.baseFees, 0))}；回收实收${Z(n.history.reduce((e, t) => e + t.recovered, 0))}。各日收购钱袋合计支出${Z(n.history.reduce((e, t) => e + t.marketSpent, 0))}，不是额外收入。此刻钱包${Z(n.coins)}铜钱，已计入事件收支、备料与修印。`)), m.append(Y("p", "这里的作品来自本次v0.8经营行程；旧行程导入的作品在炉谱中保留各自来源，不改成本次打造。")), c.append(m), p(t.temporary ? "本次是不保存试玩，新的作品、章节与成长不会写入炉谱；离开前请导出这次行程。已有炉谱记录保持原样。" : t.collection.pending || t.collection.problem ? "部分新成长还没有安全保存，请先查看保存详情或导出行程。" : "安全保存的作品、章节、配方熟练与手艺见闻都留在炉谱，可在下一程查看。"), i.append(Y("h3", "灯下，三人的后话"));
		for (let t of e.people) {
			let e = Y("details", void 0, "v4-ending-person");
			e.dataset.customer = t.customer, e.append(Y("summary", `${t.name} · 完成${t.completed} · 失约${t.missed} · 未抵达${t.unreached}`)), e.append(Y("p", t.afterword));
			for (let n of t.records) {
				let t = Y("section", void 0, "v4-ending-memory");
				if (t.dataset.commission = String(n.commissionId), t.dataset.result = n.status, t.append(Y("h4", `第${n.day}天 · ${n.commission.title} · ${n.status === "met" ? "约定已成" : n.status === "missed" ? "留下遗憾" : "尚未抵达"}`)), t.append(Y("p", n.status === "unreached" ? "这一站还没有走到，炉谱不替这次行程编写结果。" : n.commission[n.met ? "success" : "failure"])), n.matchedBlades.length) {
					t.append(Y("p", n.met ? `完成路线：${n.routes.find((e) => e.id === n.routeId).description}` : `实际交付：${n.progressText}，尚未凑齐合格数量。`)), h(n.met ? n.blades : n.matchedBlades, n.day, t);
					let e = n.met ? n.matchedBlades.filter((e) => !n.pieceIds.includes(e.id)) : [];
					e.length && (t.append(Y("p", "此前另有匹配交付，已送出且不重复计入完成收据。")), h(e, n.day, t));
				}
				e.append(t);
			}
			i.append(e);
		}
		c.append(i), t.collection.data.challenge && !t.collection.pending && !t.collection.problem && t.startChallenge && l.push(t.action("行脚挑战，再走一程", t.startChallenge, !0)), l.push(t.action(s === "defeat" ? "看看留下的炉谱" : "翻开完整炉谱", t.book, l.length === 0), t.action("回到路口，再开一炉", t.toTitle), t.action("导出这次行程", t.exportRun));
	} else s === "future" ? (u = "这份后续行程，已为你留住", p(`当前档在第${n.day}天。本次页面开放到第${t.throughDay}天；当前进度保持原样，可导出后在包含后续章节的版本继续。`), l.push(t.action("查看炉谱", t.book, !0), t.action("导出行程", t.exportRun), t.action("回标题", t.toTitle))) : (u = r.commission.title, p(r.commission.request), l.push(t.action("回到铁砧", t.leaveScene, !0)));
	if (a && [
		"receipt",
		"chapter",
		"complete",
		"ending",
		"defeat"
	].includes(s)) for (let e of n.eventHistory.filter((e) => e.day === a.day)) {
		let r = Y("section", void 0, "v4-event-receipt"), i = e.id === "donation" ? "明天实际发出的新坯底价增加20%；留剑时两柄，否则三柄，同行旧剑不加这份来料。" : e.id === "loan" ? "借锤的钱已记清，明日第一柄新坯的前三记普通锤增加正收益；不会施加到同行旧剑。" : e.id === "shelter" ? "炉棚补好了，明日第一柄新坯在当天少3个百分点裂损率；同行旧剑不额外受益。" : x[e.id].result, a = s === "defeat" && [
			"donation",
			"loan",
			"shelter"
		].includes(e.id) ? i + "这次行程已经停下，原定次日的效果尚未发生；已经交出的剑或花费仍按原收据保留。" : i;
		if (r.append(Y("h3", x[e.id].name + " · " + (e.choice === "accept" ? "已接受" : "已婉拒")), t.prop(e.id), Y("p", e.choice === "accept" ? a : "保留了眼前的剑与铜钱，没有追加代价。")), e.coins && r.append(Y("p", `${e.coins > 0 ? "收入" : "花费"} ${Z(Math.abs(e.coins))}铜钱`)), e.pieceId) {
			let i = n.blades.find((t) => t.id === e.pieceId);
			i && r.append(t.thumb(i), Y("p", `这柄${_[i.recipe].name}已换出，不再计入交付或留剑。`));
		}
		c.append(r);
	}
	return c.dataset.chapter = String(r.chapter.id), d.includes("twin-stations-") && c.classList.add("v4-twin-outcome"), d.startsWith(lr) && c.classList.add("v4-scene-panorama"), {
		title: u,
		body: c,
		actions: l,
		image: d,
		mode: s
	};
}
//#endregion
//#region src/presentation-v5/collection-ui.ts
var dr = (e) => e.toLocaleString("zh-CN"), fr = (e) => e.rulesVersion === "forge-v4" ? "旧行程作品" : "本次经营作品";
function pr(e) {
	let t = Y("small", fr(e), "v5-source-label");
	return t.dataset.rulesVersion = e.rulesVersion, t;
}
function mr(e, t) {
	let n = Y("div", void 0, "v4-book");
	n.append(Y("p", `已入册 ${e.works.length}/12 件委托作品 · 走完章节 ${e.chapters.length}/3`)), e.works.length && n.append(Y("p", "每件作品保留原行程的估值与来源。翻开作品，可以回看当时的打造与交付。", "v5-book-provenance")), (t.pending || t.problem) && n.append(Y("p", "部分新成果尚待安全保存，请查看保存详情。", "v4-collection-warning"));
	let r = Y("p", e.chapters.length ? e.chapters.map((e) => y[e - 1].title + " · 已走完").join(" / ") : "灯路从第一炉开始，真正走完的章节会留在这里。");
	n.append(r);
	let i = Y("section", void 0, "v4-collection-recipes");
	i.append(Y("h3", "留下的配方与手艺"));
	for (let t of m) {
		let n = t === "light" || e.chapters.includes(t === "guard" ? 1 : 2), r = Y("p");
		r.dataset.mastery = t, r.append(Y("b", _[t].name + "："), Y("span", n ? "可自由使用" : "随主线借用后解锁；走完相应章节即可自由使用"), Y("small", e.mastery.includes(t) ? "名器熟练已留名" : "交出等级≥9的合格名器，可留下熟练记录")), i.append(r);
	}
	let a = Y("details", void 0, "v4-collection-traits");
	a.append(Y("summary", `手艺见闻 · ${e.traits.length}/6`));
	let o = Y("div", void 0, "v4-choice-grid");
	for (let t of p) {
		let n = e.traits.includes(t), r = Y("article", void 0, "v4-card");
		r.dataset.discovery = t, r.append(ln(t), Y("h3", f[t].name + (n ? " · 已见闻" : " · 尚未学过")), Y("p", f[t].text)), o.append(r);
	}
	a.append(o), i.append(a), n.append(i);
	let s = Y("div", void 0, "v4-book-grid");
	for (let n of S) {
		let r = e.works.find((e) => e.commissionId === n.id), i = Y("article", void 0, "v4-card");
		if (i.dataset.record = String(n.id), i.append(Y("h3", `${n.id}. ${n.title}`)), r) {
			i.dataset.rulesVersion = r.rulesVersion, i.append(pr(r));
			for (let e of r.blades) i.append(t.thumb(e));
			i.append(Y("p", r.blades.map((e) => `${_[e.recipe].name} · 估值 ${dr(e.value)}`).join(" / ")), Y("small", `${n.name}的委托 · 第${r.day}天交付`), t.action("翻看这件作品", () => t.viewWork(n.id)));
		} else i.append(Y("p", "尚未留名"), Y("small", n.request.replaceAll("昨日", "此前")));
		s.append(i);
	}
	return n.append(s, Y("h3", "下一程，换一种打造计划")), n.append(Y("p", e.challenge ? "十二灯复明的旅程已经留名。行脚挑战会重排章内委托，商人仍在第3、6、9天到访；配方与手艺需要重新安排。" : "完成“十二灯复明”结局后开启行脚挑战；已经取得的章节与作品会一直留下。")), e.challenge && n.append(t.action("开启行脚挑战", t.challenge, !0, t.pending || t.problem || !t.canStart)), n;
}
function hr(e, t, n) {
	let r = S[e.commissionId - 1], i = r.routes.find((t) => t.id === e.routeId), a = Y("article", void 0, "v4-work-page");
	a.dataset.rulesVersion = e.rulesVersion;
	let o = Y("img");
	n(o, ar(r.id, {
		complete: !0,
		routeId: e.routeId,
		count: e.blades.length,
		required: i.count
	}), "/assets/d/v07/lantern-road-v1.webp"), o.alt = r.title + "的用途场景", a.append(pr(e), Y("p", e.rulesVersion === "forge-v4" ? "这件作品来自旧行程，估值与打造记录按原样入册。" : "这件作品来自三柄行囊的经营行程，估值与打造记录按原样入册。", "v5-book-provenance"), Y("p", r.success), Y("h3", "这一程的约定"), Y("p", L(i)), Y("p", `${r.name} · 第${e.day}天交付 · ${e.blades.length === 1 ? "一柄剑，接住了约定" : "两柄剑，各自送到等剑的人手里"}`));
	for (let n of e.blades) {
		let r = Y("section", void 0, "v4-work-receipt");
		r.dataset.piece = n.id, r.append(t(n), Y("h3", `${_[n.recipe].name} · ${dr(n.value)}估值`), Y("p", `等级 ${n.level} · 普通锤 ${n.hits}次 · 安全连锻 ${n.bursts}次 · ${n.cracked ? "有裂纹" : "无裂纹"}`), Y("p", `第${n.suppliedDay}天来料${n.suppliedDay < e.day ? "，作为旧剑接续这一程" : "，当日打造交付"} · 来料底价 ${dr(n.base)} · 曾达估值 ${dr(n.peak)}`)), a.append(r);
	}
	let s = Y("details", void 0, "v4-work-scene");
	return s.append(Y("summary", "看看它去了哪里"), o), a.append(s, Y("small", "炉谱记下了各委托的最佳成品。带上沿途学会的配方，再启一程，试试新的打造计划。")), a;
}
//#endregion
//#region src/presentation-v5/artwork-recovery.ts
function gr(e, t) {
	let n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new WeakMap(), a = !1, o = 0, s = (t) => new URL(t, e.ownerDocument.baseURI).href, c = () => {
		a || t.changed();
	}, l = () => e.querySelectorAll("img[data-artwork-source]"), u = (e, t) => !a && i.get(e) === t && s(e.getAttribute("src") ?? "") === t.expected;
	function d(e, n, r) {
		let o = s(n.failed ? r : n.source), l = i.get(e);
		if (l?.source === n && l.fallback === r && l.expected === o && s(e.getAttribute("src") ?? "") === o) return;
		let f = {
			source: n,
			fallback: r,
			expected: o,
			loading: !n.failed
		};
		if (i.set(e, f), e.dataset.artworkSource = s(n.canonical), e.onload = null, e.onerror = null, n.failed) e.src = r;
		else {
			let i = () => {
				u(e, f) && f.loading && f.expected === s(n.source) && e.complete && e.naturalWidth !== 0 && (f.loading = !1, e.onload = null, e.onerror = null, c());
			}, o = () => {
				if (!u(e, f) || !f.loading || f.expected !== s(n.source) || !e.complete || e.naturalWidth > 0) return;
				f.loading = !1;
				let i = !n.failed;
				n.failed = !0, d(e, n, r), i && !a && t.failed(), c();
			};
			e.onload = i, e.onerror = o, e.src = n.source, e.complete && queueMicrotask(() => {
				e.naturalWidth > 0 ? i() : o();
			});
		}
	}
	function f(e, t, r) {
		if (a) return;
		let i = s(t), o = n.get(i);
		o || (o = {
			canonical: t,
			source: t,
			failed: !1
		}, n.set(i, o)), d(e, o, r);
	}
	function p() {
		let e = r.size > 0;
		for (let t of l()) {
			let n = i.get(t);
			n?.loading && u(t, n) && n.expected === s(n.source.source) && (e = !0);
		}
		return {
			loading: e,
			failed: [...n.values()].filter((e) => e.failed).map((e) => e.canonical)
		};
	}
	function m() {
		if (!a) {
			for (let [s, u] of n) {
				if (!u.failed || r.has(s)) continue;
				let n = new Image(), f = new URL(u.canonical, e.ownerDocument.baseURI);
				f.searchParams.set("artRetry", `${Date.now()}-${++o}`);
				let p = f.href, m = null, h = !1, g = { clear() {
					n.onload = null, n.onerror = null, m !== null && clearTimeout(m), m = null, n.removeAttribute("src");
				} }, _ = (n) => {
					if (!(a || h || r.get(s) !== g)) {
						if (h = !0, g.clear(), r.delete(s), n) {
							if (u.source = p, u.failed = !1, f.origin === new URL(e.ownerDocument.baseURI).origin) for (let e of l()) {
								let t = i.get(e);
								t?.source === u && e.dataset.artworkSource === s && d(e, u, t.fallback);
							}
						} else u.failed = !0, t.failed();
						c();
					}
				};
				n.onload = () => {
					n.complete && n.naturalWidth > 0 && _(!0);
				}, n.onerror = () => {
					n.complete && n.naturalWidth === 0 && _(!1);
				}, r.set(s, g), m = setTimeout(() => _(!1), 8e3), n.src = p, n.complete && queueMicrotask(() => {
					n.naturalWidth > 0 ? _(!0) : _(!1);
				});
			}
			c();
		}
	}
	function h() {
		if (!a) {
			a = !0;
			for (let e of l()) i.has(e) && (e.onload = null, e.onerror = null);
			for (let e of r.values()) e.clear();
			r.clear(), n.clear(), i = /* @__PURE__ */ new WeakMap();
		}
	}
	return {
		image: f,
		status: p,
		retry: m,
		dispose: h
	};
}
//#endregion
//#region src/presentation-v5/payment-copy.ts
var Q = (e) => e.toLocaleString("zh-CN");
function _r(e, t) {
	let n = `整单酬劳 ${Q(e.market.baseFee)}铜钱 · 已领 ${Q(e.market.baseFeesPaid)}铜钱`, r = e.commission.routes.some((e) => e.count > 1), i = {
		valueLabel: "作品估值",
		valueHint: "估值用来验剑，铜钱按右侧报价入袋。",
		orderPay: n,
		orderExplanation: e.commission.progress.complete ? "本单酬劳已按交剑进度领取；余剑出售不再领取这份酬劳。" : r ? "整单酬劳按合格交剑进度分次领取；“本柄酬劳”是这次交剑可领的份额。" : "整单酬劳是这份约定的基础付款，品质加赏另计。",
		detailsSummary: "估值、酬劳与实收"
	}, a = e.blades.find((e) => e.blade.id === t), o = (e, t, n) => ({
		...i,
		quote: {
			kind: e,
			buttonText: t,
			breakdown: e === "reserved" ? "先取回，再查看本次收款" : e === "empty" ? "选中一柄剑，查看收款" : e === "exhausted" ? "暂不能出售，可查看去向" : "当前无法交付，可查看原因",
			explanation: n,
			details: [],
			amount: null,
			pieceValue: a?.quote.pieceValue ?? null
		}
	});
	if (!a) return o("empty", "先选一柄剑", "选中一柄剑后，再看这次能收多少铜钱。");
	if (a.reserved) return o("reserved", "先从剑架取回", "这柄在剑架上；取回后才显示本次可交付或出售的实收。");
	let s = a.quote;
	if (!s.allowed) return s.error === "market_exhausted" ? o("exhausted", "今日收购余款已用尽", "这柄余剑暂不能出售，可查看留剑或回收安排。") : o("unavailable", s.error === "record_limit" ? "先查看行程与导出" : "回到炉前再安排", "这次不能交付或出售，请先查看当前行程与保存状态。");
	if (s.matched) {
		let t = s.threshold === null ? "超出订单估值门槛的部分" : `超出订单估值门槛 ${Q(s.threshold)}的部分`;
		return {
			...i,
			quote: {
				kind: "commission",
				amount: s.amount,
				pieceValue: s.pieceValue,
				buttonText: `交给${e.commission.name} · 实收${Q(s.amount)}铜钱`,
				breakdown: `本柄酬劳${Q(s.baseFeeDelta)}＋品质加赏${Q(s.qualityBonus)}＝${Q(s.amount)}铜钱`,
				explanation: "估值用来核对订单；铜钱按本柄酬劳与品质加赏结算。",
				details: [
					`作品估值 ${Q(s.pieceValue)}，用于检查订单门槛，不会整笔变成铜钱。`,
					`整单酬劳 ${Q(e.market.baseFee)}铜钱，已领 ${Q(e.market.baseFeesPaid)}铜钱；本次交剑领取其中 ${Q(s.baseFeeDelta)}铜钱。`,
					`${t}按1/5折为品质加赏，向下取整；加赏受今日收购余款 ${Q(e.market.remaining)}铜钱限制，本柄加赏为 ${Q(s.qualityBonus)}铜钱。`,
					"收购余款只限制品质加赏与余剑收购，不扣减本柄应领的委托酬劳。"
				]
			}
		};
	}
	return {
		...i,
		quote: {
			kind: "sale",
			amount: s.amount,
			pieceValue: s.pieceValue,
			buttonText: `卖给行会 · 实收${Q(s.amount)}铜钱`,
			breakdown: `余剑出售 · 本次实收${Q(s.amount)}铜钱`,
			explanation: "按估值的1/4折价出售，受今日收购余款限制，不计主委托。",
			details: [
				`作品估值 ${Q(s.pieceValue)}；余剑按估值的1/4换铜钱，向下取整。`,
				`今日收购余款 ${Q(e.market.remaining)}铜钱；本次按正式报价实收 ${Q(s.amount)}铜钱，最多收到这笔余款。`,
				e.commission.progress.complete ? "今天的主委托已交妥，这柄作为余剑出售，不再领取整单酬劳。" : "这柄作为余剑出售，不计作主委托交剑，也不领取委托酬劳。"
			]
		}
	};
}
//#endregion
//#region src/presentation-v5/app.ts
var $ = (e) => e.toLocaleString("zh-CN"), vr = {
	waiting: "声音尚未启用，可点“试听敲击声”重试；锻造仍可继续。",
	ready: "声音已就绪。",
	muted: "当前已静音或音量为零，仍可看见锻造结果。",
	blocked: "浏览器暂未允许声音，可点“试听敲击声”重试；锻造仍可继续。",
	unavailable: "当前声音不可用，可重试试听；锻造仍可继续。"
}, yr = {
	market_exhausted: "今日收购钱袋用完了，剑仍在。可留给明天、献成器换手艺，或明确回收。",
	blade_unworked: "献剑需等级至少3，大成可增加两级，不是必须敲三次。",
	legacy_changed: "旧炉谱或当前行程已变化，请重新预览后再确认。",
	legacy_unavailable: "这份旧炉谱暂不可读取，可查看另一份来源；原件仍保留。",
	readonly: "另一窗口正在保存。关闭占用页后，可在保存详情中读取最新。",
	not_active: "页面已停用，请重新读取最新进度。",
	locks_unsupported: "当前无法取得保存锁，可明确选择不保存试玩。",
	save_conflict: "磁盘进度已变化，请先导出，再读取最新或保留当前局不保存续玩。",
	save_unavailable: "主档暂不可读取，可检查备份或不保存试玩。",
	collection_pending: "新取得的成长尚未安全保存。请先重试本局和炉谱，或导出当前成果。",
	collection_unavailable: "炉谱暂未保存，请在保存详情中查看原因并重试。",
	insufficient_coins: "铜钱不足，这次没有扣款。",
	invalid_replacement: "先选择换下哪门手艺。",
	at_cap: "这柄剑已经成器，可以交剑或留到明天。",
	record_limit: "操作记录已到安全上限，仍可交剑、回收和收工。",
	stale_session: "页面身份已变化，请重新查看这次选择。",
	stale_revision: "进度已更新，请重新操作。",
	confirmation_required: "替换当前进度需要明确确认。",
	recipe_locked: "首锤后配方已经定下。",
	reserved_piece: "先从剑架取回，再加工或交付。",
	challenge_locked: "完成完整旅程后才可开启行脚挑战。",
	session_busy: "本次结果正在收妥，请稍后再试。"
}, br = {
	storage_read_failed: "读取被拒绝",
	storage_write_failed: "写入失败",
	storage_conflict: "磁盘内容已变化",
	unsupported_schema: "版本较新或不兼容",
	unsupported_rules: "使用其他规则",
	invalid_json: "文件内容损坏",
	invalid_state: "进度未通过回放校验",
	invalid_timestamp: "保存时间无效",
	save_too_large: "存档过大",
	serialization_failed: "无法生成存档",
	recovery_required: "发现旧备份，需要明确恢复",
	run_unsaved: "请先保存当前局，再保存新成长",
	run_changed: "当前局已被其他窗口更新"
};
function xr(e, t) {
	e.innerHTML = un, en(e);
	let n = e.firstElementChild, r = (t) => {
		let n = e.querySelector("#" + t);
		if (!n) throw Error("Missing " + t);
		return n;
	}, i = (e) => r(e), a = r("v4-dialog"), o = r("v4-stage-image"), s = (e, t) => {
		let n = t.replaceAll("身价", "估值").replaceAll("金币", "铜钱"), i = r(e);
		i.textContent !== n && (i.textContent = n);
	}, c = (e, t) => {
		r(e).hidden = !t;
	}, l = Yt(() => localStorage), u = Qt(void 0, rn), d = matchMedia("(prefers-reduced-motion: reduce)"), p = t.getSnapshot(), m = t.getCollectionSnapshot(), h = l.getSnapshot(), g = !1, b = "title", x = !1, C = !1, w = !1, E = 0, D = "", O = "", k = "", ee = "", A = "", te = "title", ne = null, j = "", re = "", M = null, ie = null, N = null, ae = null, oe = null, se = null, ce = null, P = null, le = null, ue = null, de = 0, pe = [], F = u.getStatus(), me = !1, he = 0, ge = "", _e = null, ve = !1, ye = 0, be = /* @__PURE__ */ new Set(), xe = /* @__PURE__ */ new Set(), Se = /* @__PURE__ */ new WeakMap(), Ce = gr(e, {
		changed: Ge,
		failed: Ke
	}), we = () => h.value.reducedMotion || d.matches, I = () => p.state, Te = () => I()?.blades.find((e) => e.id === D) ?? null, Ee = () => `${I()?.runId ?? ""}/${p.generation}/${E}`, L = () => !g && b === "game" && !x && !C && p.active && !p.conflict && (p.mode === "writer" || p.mode === "memory"), R = (e) => s("v4-status", e);
	function De() {
		return {
			title: "炉火还在，已经为你暂停",
			copy: "刚才未完成的输入与动效已取消，已接受的成果保持。",
			action: "resume",
			label: "继续这一炉"
		};
	}
	function Oe(e = !0) {
		de++;
		for (let e of be) clearTimeout(e);
		be.clear();
		for (let e of xe) e.cancel();
		xe.clear(), N?.cancel(), ae?.cancel(), oe?.cancel(), se?.cancel();
		let t = P;
		if (P = null, w = !1, pe = [], t) {
			let e = Te();
			s("v4-value", e ? $(e.value) : "—"), s("v4-craft-record", e ? `等级 ${e.level} · 已完成安全连锻 ${e.bursts}次` : "");
			let t = I();
			t && at(t);
		}
		e && (ie = null, le = null), u.silence();
	}
	function ke(e, t) {
		let n = de, r = setTimeout(() => {
			be.delete(r), !g && n === de && e();
		}, t);
		be.add(r);
	}
	function Ae() {
		let e = I();
		D = e?.blades.find((t) => t.status === "active" && t.id !== e.reserveId)?.id ?? e?.reserveId ?? "";
	}
	function B(e, t, n = !1, r = !1) {
		let i = Y("button", e, n ? "v4-primary" : "v4-secondary");
		return i.type = "button", i.disabled = r, i.onkeydown = (e) => {
			e.repeat && (e.key === "Enter" || e.code === "Space") && e.preventDefault();
		}, i.onclick = t, i;
	}
	function je(e, t, n = !0) {
		let r = {
			runId: I()?.runId,
			revision: I()?.revision,
			generation: p.generation
		}, i = B(e, () => {
			g || (r.runId !== I()?.runId || r.revision !== I()?.revision || r.generation !== p.generation ? G("stale_session") : q(t));
		}, n);
		return i.dataset.economic = "true", i;
	}
	function Me(e) {
		let t = Y("canvas", void 0, "v4-card-art");
		return t.width = 220, t.height = 170, t.dataset.prop = e, t.setAttribute("aria-hidden", "true"), N?.paintProp(t, e), t;
	}
	function V(e) {
		let t = Y("canvas", void 0, "v4-blade-thumb");
		return t.width = 240, t.height = 88, t.dataset.blade = e.id, Se.set(t, e), t.setAttribute("aria-hidden", "true"), N?.paintThumb(t, e), t;
	}
	function Ne() {
		for (let t of e.querySelectorAll("canvas[data-prop]")) N?.paintProp(t, t.dataset.prop);
		for (let t of e.querySelectorAll("canvas[data-blade]")) {
			let e = Se.get(t);
			e && N?.paintThumb(t, e);
		}
	}
	function Pe() {
		u.identify(Ee()), u.configure(h.value), u.setMode(b === "game" && !C && !x && !document.hidden && p.active ? "game" : "silent");
	}
	function H(e = !0) {
		let n = j;
		n === "legacy-import" && t.cancelLegacyImport(), a.open && a.close(), x = !1, j = "", E++, Oe(!1), n === "pause" && e && (C = !1), J();
		let o = ne;
		ne = null, queueMicrotask(() => {
			if (g || x) return;
			let e = (e) => !!e && e.isConnected && !e.matches(":disabled") && !e.closest("[hidden]") && e.getClientRects().length > 0, t = b === "title" ? i("v4-start") : te === "workshop" ? i("v4-strike") : r("v4-stage-actions").querySelector("button:not(:disabled)") ?? r("v4-stage-title");
			e(o) ? o.focus({ preventScroll: !0 }) : e(t) ? t.focus({ preventScroll: !0 }) : i("v4-save-open").focus({ preventScroll: !0 });
		});
	}
	function U(e, t, n, i = "choice") {
		x && H(), ne = document.activeElement instanceof HTMLElement ? document.activeElement : null, Oe(), E++, x = !0, j = i, Pe(), a.dataset.kind = i, s("v4-dialog-title", e), r("v4-dialog-body").replaceChildren(typeof t == "string" ? Y("p", t) : t), r("v4-dialog-actions").replaceChildren(...n.map((e) => {
			let t = B(e.label, e.run, !!e.primary, !!e.disabled);
			return e.id && (t.id = e.id), t;
		})), a.showModal(), r("v4-dialog-body").scrollTop = 0, r("v4-dialog-actions").querySelector("button:not(:disabled)")?.focus({ preventScroll: !0 }), Ne();
	}
	function W(e, t, n) {
		let r = {
			generation: p.generation,
			runId: I()?.runId,
			revision: I()?.revision
		};
		U(e, t, [{
			label: "再想想",
			run: () => H()
		}, {
			label: "确认",
			primary: !0,
			run: () => {
				let e = r.generation === p.generation && r.runId === I()?.runId && r.revision === I()?.revision;
				H(), e ? n() : R(yr.stale_session);
			}
		}], "confirm");
	}
	function G(e) {
		R(yr[e] ?? "这次选择没有成立，请查看当前目标与保存状态。");
	}
	function Fe(e, t) {
		let n = new Blob([e], { type: "application/json" }), r = URL.createObjectURL(n), i = Y("a");
		i.href = r, i.download = t, i.click(), setTimeout(() => URL.revokeObjectURL(r), 1e3);
	}
	function Ie() {
		let e = t.exportRun();
		e ? Fe(e, `灯炉行程-${I().runId}.json`) : R("尚未启程，没有当前局可导出。");
	}
	function Le() {
		Fe(t.exportCollection(), "灯炉炉谱.json");
	}
	function Re() {
		let t = $n(() => localStorage), n = Object.values(t.slots).filter((e) => !e.ok).length;
		Fe(JSON.stringify(t, null, 2), "灯炉磁盘局档原文.json");
		let r = n ? `已生成原文文件，但有${n}个位置读取失败；文件中已分别标记，允许读取后可重试。` : "已生成主档与备份的原文文件；这是留存原文，不是可直接续玩的行程。";
		R(r);
		let i = e.querySelector("#v5-raw-export-status");
		i && (i.textContent = r);
	}
	function K(t) {
		let n = (t === D ? r("v4-blade") : I()?.reserveId === t ? r("v4-reserve-slot").querySelector("canvas") : e.querySelector(`#v4-inventory button[data-piece="${t}"] canvas`))?.getBoundingClientRect();
		return n && n.width > 0 && n.height > 0 ? {
			left: n.left,
			top: n.top,
			width: n.width,
			height: n.height
		} : null;
	}
	function q(e, n = null) {
		if (!L() || w) return R("先回到炉前，再作这次选择。"), !1;
		let r = I();
		if (!r) return !1;
		let i = "pieceId" in e ? r.blades.find((t) => t.id === e.pieceId) : void 0, a = i ? n ?? K(i.id) : null;
		se?.cancel(), P = e.type === "strike" && i ? {
			runId: r.runId,
			revision: r.revision + 1,
			generation: p.generation,
			epoch: E,
			pieceId: i.id,
			value: i.value,
			level: i.level
		} : null;
		let o = t.dispatch({
			runId: r.runId,
			expectedRevision: r.revision,
			action: e
		}, p.generation);
		if (!o.ok) return P = null, G(o.error), J(), !1;
		let s = Gn(o.events, o.state, r);
		if (M = s?.subject ? {
			...s,
			subject: {
				...s.subject,
				generation: p.generation
			}
		} : s, o.events.some((e) => e.type === "Opened") && (M = {
			title: "炉火点着了",
			copy: "左键点剑身落锤。纸单下会写出实际收款，合格后再交给来客。",
			action: "none",
			label: ""
		}), o.events.some((e) => e.type === "Advanced")) {
			let e = z(o.state);
			M = e.merchant ? {
				title: "行脚商人到了",
				copy: "可以用一柄余剑换手艺，或为后续来料作准备。先看清今天要交什么。",
				action: "shop",
				label: "看看炉边摊"
			} : {
				title: "新的一天，新的约定",
				copy: e.commission.request,
				action: "none",
				label: ""
			};
		}
		let c = o.events.find((e) => e.type === "Strike");
		if (c?.type === "Strike") {
			pe = [];
			let e = z(r).blades.find((e) => e.blade.id === c.pieceId)?.willCommission;
			if (!s && !e && z(o.state).blades.find((e) => e.blade.id === c.pieceId)?.willCommission) {
				let e = z(o.state), t = e.commission.progress, n = e.commission.routes.some((e) => e.count > 1), r = t.routes.some((e) => e.required > 1 && e.count === e.required - 1);
				M = {
					title: "这柄剑，已经合格了",
					copy: n ? e.commission.id === 11 ? "这柄剑符合接力的一条路线；旧剑一柄或新剑两柄分别计数。" : r ? "交出这一柄，双驿需要的两柄就齐了。" : "先交出这一柄，再准备另一柄。两柄各自合格，才算完成。" : "现在交给来客，就能保住这一站。也可以继续锻，承担下一锤的风险。",
					action: "deliver",
					label: `交给${e.commission.name}`,
					subject: {
						runId: o.state.runId,
						day: o.state.day,
						revision: o.state.revision,
						pieceId: c.pieceId,
						generation: p.generation
					}
				};
			}
			w = !0;
			let t = ++de, n = o.state.blades.find((e) => e.id === c.pieceId);
			N?.draw(n), N?.play(c, ue, () => {
				g || t !== de || (w = !1, P = null, Te()?.status !== "active" && Ae(), J());
			}, r.blades.find((e) => e.id === c.pieceId));
			let i = c.hits.at(-1);
			i && R(`${c.burst ? "安全连锻 ×" + c.hits.length : "落锤"} · ${i.result === "great" ? "大成" : i.result === "crack" ? "出现裂纹" : i.result === "broken" ? "断剑回收" : "锻成"} · 这一记后估值 ${$(i.after)}`);
		} else {
			Oe(), (e.type === "advance" || Te()?.status !== "active" || e.type === "reserve" && o.state.reserveId === D) && Ae(), e.type === "reserve" && r.reserveId === e.pieceId && o.state.reserveId !== e.pieceId && (D = e.pieceId);
			let t = o.events.find((e) => e.type === "MainCompleted"), n = o.events.find((e) => e.type === "Delivered");
			if (t?.type === "MainCompleted" && n?.type === "Delivered") le = {
				runId: o.state.runId,
				day: o.state.day,
				commissionId: t.commissionId,
				pieceIds: t.pieceIds,
				amount: n.amount,
				baseFee: n.baseFeeDelta,
				bonus: n.qualityBonus
			}, M = null, u.acceptedCue("met");
			else if (n?.type === "Delivered") {
				if (n.matched) {
					let e = sr(o.state, z(o.state).commission.id);
					M = {
						title: "先送到了一柄",
						copy: `这柄实收${$(n.amount)}铜钱（酬劳${$(n.baseFeeDelta)}＋品质加赏${$(n.qualityBonus)}）。已交${e.progressText}，再安排余下的合格剑。`,
						action: "journey",
						label: "看看已交的剑"
					};
				}
				u.acceptedCue("delivery");
			} else o.events.some((e) => e.type === "Disposed") ? u.acceptedCue("recycle") : o.events.some((e) => [
				"Trait",
				"Upgraded",
				"Repaired",
				"Modification"
			].includes(e.type)) ? u.acceptedCue("purchase") : o.events.some((e) => e.type === "Settled") && u.acceptedCue(o.state.history.at(-1)?.met ? "met" : "missed");
			if (e.type === "advance") {
				let e = r.blades.find((e) => e.id === r.reserveId), t = o.state.blades.find((e) => e.id === r.reserveId);
				e && t && t.value > e.value && o.state.modifications.includes("warmRack") && (pe = ["warmRack"], M = {
					title: "旧剑还温着",
					copy: `余温架让留剑从${$(e.value)}变成${$(t.value)}；裂纹与锤势保持。取回后再决定交给谁。`,
					action: "journey",
					label: "看看这一程"
				}), o.state.day === 3 && (M = {
					title: "商人在炉边等你",
					copy: "等级至少3的成器可换手艺；铜钱可备来料或补契印。今天还有一封炉边来信。",
					action: "shop",
					label: "看看商人的摊子"
				}), o.state.day === 7 && (M = {
					title: "阿禾的雪中来信",
					copy: y[1].letter,
					action: "journey",
					label: "展开灯路回顾"
				}), o.state.day === 11 && (M = {
					title: "山口送来的最后一封信",
					copy: y[2].letter,
					action: "journey",
					label: "展开灯路回顾"
				}), (r.day === 4 && o.state.day === 5 || r.day === 8 && o.state.day === 9) && Xe({
					kind: "intro",
					revision: o.state.revision
				});
			}
		}
		if (J(), ze(r, o.state, o.events), i && o.events.some((e) => e.type === "Delivered")) {
			let e = o.events.find((e) => e.type === "Delivered");
			e?.type === "Delivered" && se?.transfer({
				blade: i,
				source: a,
				target: e.matched ? "customer" : "shop",
				copy: e.matched ? `交到${z(o.state).commission.name}手中 · +${$(e.amount)}铜钱` : `行会收下 · +${$(e.amount)}铜钱`
			});
		} else i && e.type === "reserve" && o.state.reserveId === i.id ? se?.transfer({
			blade: i,
			source: a,
			target: "rack",
			copy: o.state.day === 12 ? "暂放本局剑架，不带入新局" : "这柄留给明天"
		}) : i && e.type === "buy" && se?.transfer({
			blade: i,
			source: a,
			target: "shop",
			copy: `换得${f[e.traitId].name}`
		});
		return !0;
	}
	function ze(t, n, i) {
		if (we() || document.hidden) return;
		let a = [];
		t.coins !== n.coins && a.push(r("v4-coins")), t.seals !== n.seals && a.push(r("v4-seals"));
		for (let r of i) if (r.type === "Trait" && r.traitId && !t.traits.includes(r.traitId) && n.traits.includes(r.traitId)) {
			let t = e.querySelector(`[data-trait="${r.traitId}"]`);
			t && a.push(t);
		}
		(t.upgradeCount !== n.upgradeCount || t.crackGuard !== n.crackGuard || JSON.stringify(t.pending) !== JSON.stringify(n.pending)) && a.push(r("v4-modifications"));
		for (let e of a) try {
			let t = e.animate([
				{ filter: "brightness(1)" },
				{
					filter: "brightness(1.8)",
					offset: .3
				},
				{ filter: "brightness(1)" }
			], {
				duration: 700,
				easing: "ease-out"
			});
			xe.add(t), t.finished.then(() => xe.delete(t), () => xe.delete(t));
		} catch {}
	}
	function Be(e) {
		w || x || oe?.isDragging() || (ae?.cancel(), N?.cancel(), se?.cancel(), M?.subject && M.subject.pieceId !== e && (M = null), E++, D = e, J(), i("v4-strike").focus({ preventScroll: !0 }));
	}
	function Ve(e) {
		let t = I(), n = P;
		t && n && w && n.runId === t.runId && n.revision === t.revision && n.generation === p.generation && n.epoch === E && n.pieceId === e.pieceId && (P = {
			...n,
			value: e.hit.after,
			level: e.hit.level
		}, pe = [...new Set(e.hit.triggers)], s("v4-value", $(e.hit.after)), s("v4-craft-record", `等级 ${e.hit.level} · 已完成安全连锻 ${e.after.bursts}次`), at(t), se?.contact(e));
	}
	function He() {
		Oe(), E++, O = "", Te()?.status !== "active" && Ae(), J();
	}
	function Ue(t = u.getStatus()) {
		if (g) return;
		let n = t !== F;
		F = t;
		let r = e.querySelector("#v4-audio-status");
		r && (r.dataset.state = t, r.textContent = vr[t]), n && (t === "blocked" || t === "unavailable") && j !== "settings" && R(vr[t]);
	}
	function We() {
		let e = N?.assetStatus(), t = Ce.status();
		return {
			loading: !!e?.loading || ve || t.loading,
			failed: [
				...e?.failed ?? [],
				..._e ? [_e] : [],
				...t.failed
			]
		};
	}
	function Ge() {
		if (g) return;
		let t = We();
		t.failed.length && (me = !0);
		let n = e.querySelector("#v4-art-status");
		if (n) {
			me && (n.dataset.hadProblem = "true");
			let e = t.loading ? "loading" : t.failed.length ? "failed" : "ready";
			n.dataset.state = e, n.hidden = n.dataset.hadProblem !== "true";
			let i = n.querySelector("#v4-art-copy"), a = n.querySelector("#v4-art-retry");
			if (i && (i.textContent = e === "loading" ? "正在重新装入画稿，锻造仍可继续。" : e === "failed" ? "部分画稿尚未装入，可以重试；锻造结果和进度保持。" : "画稿已重新点亮，可以回炉边继续。"), a) {
				let n = e === "ready" && document.activeElement === a;
				a.disabled = t.loading, a.hidden = e === "ready", n && j === "settings" && r("v4-dialog-actions").querySelector(".v4-primary")?.focus({ preventScroll: !0 });
			}
		}
		me && !t.loading && !t.failed.length && (me = !1, R("画稿已重新点亮。"));
	}
	function Ke() {
		g || (me = !0, R("部分画稿尚未装入，可在设置里重试；文字、数值与锻造仍可使用。"), Ge());
	}
	function qe(e, t = !1) {
		if (g) return;
		let n = ++he;
		ve = !0, _e = null;
		let r = t ? `${e}${e.includes("?") ? "&" : "?"}retry=${++ye}` : e, i = () => {
			!g && n === he && ve && (ve = !1, _e = null, Ge());
		};
		o.onload = i, o.onerror = () => {
			g || n !== he || (ve = !1, _e = e, o.onload = null, o.onerror = null, o.src = "/assets/d/forge-backdrop-v2.webp", Ke());
		}, o.src = r, o.complete && o.naturalWidth > 0 && i(), Ge();
	}
	function Je(e) {
		ge !== e && (ge = e, qe(e));
	}
	function Ye() {
		let e = We();
		if (g || e.loading) return;
		let t = _e;
		t && t === ge && qe(t, !0), N?.retryAssets(), Ce.retry(), Ge();
	}
	function Xe(e) {
		ie = e, E++, Pe(), e.kind === "intro" && !we() && ke(() => {
			ie = null, E++, O = "", J();
		}, 4200);
	}
	function Ze(e) {
		let t = JSON.stringify([
			e.runId,
			e.revision,
			p.generation,
			p.active,
			p.mode,
			p.conflict,
			ie,
			m.pending,
			m.problem,
			m.data
		]);
		if (O === t) return;
		O = t;
		let n = ur(e, {
			throughDay: 12,
			temporary: p.mode === "memory",
			...ie?.kind === "delivery" ? { delivery: {
				commissionId: ie.commissionId,
				pieceIds: ie.pieceIds
			} } : {},
			...ie?.kind === "intro" ? { chapterIntro: !0 } : {},
			collection: {
				data: m.data,
				pending: m.pending,
				problem: m.problem ?? null
			},
			action: B,
			commandAction: je,
			thumb: V,
			prop: Me,
			leaveScene: He,
			book: Tt,
			toTitle: lt,
			exportRun: Ie,
			...p.active && !p.conflict && (p.mode === "writer" || p.mode === "memory") ? { startChallenge: () => pt("challenge") } : {}
		}), i = r("v4-stage-copy"), a = JSON.stringify([
			e.runId,
			e.revision,
			p.generation,
			n.mode
		]), o = i.dataset.journeyPage === a ? i.scrollTop : 0;
		if (s("v4-stage-title", n.title), i.replaceChildren(n.body), i.dataset.journeyPage = a, i.scrollTop = o, r("v4-stage-actions").replaceChildren(...n.actions), Je(n.image), r("v4-stage").dataset.scene = n.mode, r("v4-stage").dataset.chapter = String(z(e).chapter.id), Ne(), (n.mode === "delivery" || n.mode === "intro") && !we() && !document.hidden) try {
			let e = r("v4-stage-image").animate([{
				opacity: .35,
				transform: "translateY(6px)"
			}, {
				opacity: 1,
				transform: "translateY(0)"
			}], {
				duration: 420,
				easing: "ease-out"
			});
			xe.add(e), e.finished.then(() => xe.delete(e), () => xe.delete(e));
		} catch {}
		queueMicrotask(() => {
			if (!g && !x && O === t) {
				let e = r("v4-stage-title");
				e.tabIndex = -1, e.focus({ preventScroll: !0 });
			}
		});
	}
	function Qe(e) {
		let t = le, n = t?.runId === e.runId && t.day === e.day && e.phase === "workshop";
		if (c("v4-inline-delivery", !!n), !n || !t) return;
		let i = sr(e, t.commissionId), a = r("v4-inline-image");
		s("v4-inline-title", i.complete ? `${i.commission.name}接过了剑` : "先送到了一柄"), s("v4-inline-copy", i.complete ? i.commission.success : `已经交付${i.progressText}，再安排下一柄合格的剑。`), a.dataset.source !== i.image && (a.dataset.source = i.image, Ce.image(a, i.image, "/assets/d/forge-backdrop-v2.webp")), a.alt = i.commission.title + "的实际交付", s("v5-inline-payment", `实收 ${$(t.amount)} 铜钱 · 酬劳${$(t.baseFee)}＋品质加赏${$(t.bonus)}`), s("v4-inline-review", e.gift === "available" ? "收下第一门手艺" : "看看灯路");
	}
	function $e(e) {
		let t = I();
		if (!t || !L() || w || te !== "workshop" || t.phase !== "workshop" || e.runId !== t.runId || e.revision !== t.revision || e.generation !== p.generation || e.epoch !== E) return null;
		let n = t.blades.find((t) => t.id === e.pieceId);
		return n?.status === "active" && n.id !== t.reserveId ? n : null;
	}
	function et(e, t) {
		let n = $e(e), r = I();
		if (!n || !r) return {
			allowed: !1,
			label: "这次选择已变化，请重新拿起眼前的剑。"
		};
		let i = z(r), a = i.blades.find((e) => e.blade.id === n.id);
		return t === "rack" ? {
			allowed: !0,
			label: i.next ? r.reserveId ? "换这柄留剑：明日一旧两新，不补第四柄" : "留给明天：一旧两新，占一柄新坯位" : "暂放本局剑架，不带入新局"
		} : a?.willCommission ? {
			allowed: !0,
			label: `交给${i.commission.name} · 实收${$(a.quote.amount)}铜钱`
		} : {
			allowed: !1,
			label: i.commission.progress.complete ? "今天的约定已经完成。想换旅费，可点“卖给行会”。" : a?.assessment.routes.map((e) => e.missing.join("、")).filter(Boolean).join("；") || "这柄还不合纸单，再锻一锤或换柄剑。"
		};
	}
	function tt(e, t, n) {
		let r = $e(e), i = I();
		if (!r || !i) return;
		let a = et(e, t);
		a.allowed ? t === "customer" ? q({
			type: "deliver",
			pieceId: r.id
		}, n) : nt(r.id, n) : (M = {
			title: "再看一眼纸单",
			copy: a.label,
			action: "none",
			label: "",
			subject: {
				runId: i.runId,
				day: i.day,
				revision: i.revision,
				pieceId: r.id,
				generation: p.generation
			}
		}, R(a.label), st());
	}
	function nt(e, t) {
		let n = I(), r = n?.blades.find((t) => t.id === e);
		if (!n || !r || r.status !== "active") return;
		let i = n.blades.find((e) => e.id === n.reserveId);
		n.day === 12 && n.reserveId !== r.id ? W("暂放在本局剑架？", "这是最后一炉，没有次日新坯。挂架只保留在本局行程，不会带入新局；收工时也不会自动回收这柄。可以先返回安排交付、出售或回收。", () => q({
			type: "reserve",
			pieceId: r.id
		}, t)) : i && i.id !== r.id ? W("换一柄留剑？", `架上的${_[i.recipe].name}（${$(i.value)}）回到炉边，改留这柄${_[r.recipe].name}（${$(r.value)}）。两柄不会同时留到明天；留一柄就只发两柄新坯。`, () => q({
			type: "reserve",
			pieceId: r.id
		}, t)) : q({
			type: "reserve",
			pieceId: r.id
		}, t);
	}
	function rt(t) {
		let n = t.blades.filter((e) => e.status === "active" && e.id !== t.reserveId), i = JSON.stringify([
			t.runId,
			p.generation,
			D,
			t.reserveId,
			n.map((e) => [
				e.id,
				e.recipe,
				e.value,
				e.level,
				e.cracked
			])
		]);
		if (i !== k) {
			k = i;
			let e = document.createDocumentFragment();
			for (let t of n) {
				let n = B(`${_[t.recipe].name} · ${$(t.value)}`, () => Be(t.id));
				n.dataset.piece = t.id, n.setAttribute("aria-pressed", String(t.id === D)), n.prepend(V(t)), t.cracked && n.append(Y("small", "已有裂纹")), e.append(n);
			}
			r("v4-inventory").replaceChildren(e);
			let a = t.blades.find((e) => e.id === t.reserveId), o = r("v4-reserve-slot");
			if (a) {
				let e = B(`取回 ${_[a.recipe].name} · ${$(a.value)}`, () => q({
					type: "reserve",
					pieceId: a.id
				}));
				e.prepend(V(a)), o.replaceChildren(e);
			} else o.replaceChildren(Y("span", t.day === 12 ? "最后一炉，不跨局留剑" : "留一柄，给明天"));
		}
		for (let t of e.querySelectorAll("#v4-inventory button,#v4-reserve-slot button")) t.disabled = !L() || w;
	}
	function it(e) {
		let t = z(e), n = Te(), a = t.blades.find((e) => e.blade.id === n?.id), o = !!a?.canStrike && L() && !w, l = P?.runId === e.runId && P.revision === e.revision && P.generation === p.generation && P.epoch === E && P.pieceId === n?.id ? P : null, u = Hn(t, n?.id ?? null), d = Un(t);
		s("v4-plan-line", u.headline), s("v4-plan-copy", u.copy), r("v4-plan-line").parentElement.dataset.tone = u.tone, s("v4-next-plan", d.reserve?.tone === "ready" ? "明日已有合用的剑" : t.next ? "明日打算" : "最后一炉的打算"), i("v4-next-plan").disabled = w, s("v4-shop-help", t.merchant ? "成器可换手艺 · 等级至少3" : ""), s("v5-rack-title", t.next ? "留一把，待明日" : "本局暂放的剑"), r("v4-reserve-zone").setAttribute("aria-label", t.next ? "留给明天的剑" : "本局暂放的剑"), s("v5-slot-plan", t.next ? t.next.oldCount ? "明日：旧剑1 ＋ 新坯2" : "明日：新坯3" : "最后一炉，没有次日来料"), r("v5-slot-plan").title = t.next ? "明日共三柄；留一柄旧剑会少一柄新坯，取下后不补发。" : "这是最后一炉，剑架上的剑不会带入新局。", s("v4-day", `${e.mode === "challenge" ? "行脚挑战 · " : ""}第${e.day}天 · ${t.chapter.title.split(" · ")[1] ?? t.chapter.title}${rr(e.day) ? " · 关键约定" : ""}`), s("v4-goal-name", t.commission.title), ce?.render(t, n?.id ?? null, `${e.runId}/${p.generation}`), s("v4-seals", `${e.seals}/3`), s("v4-coins", $(e.coins)), s("v4-value", n ? $(l?.value ?? n.value) : "—"), s("v4-condition", n ? `${_[n.recipe].name} · ${n.status === "broken" ? "断裂" : n.cracked ? "已有裂纹" : "无裂纹"}` : "铁砧已空，安排这一炉收工"), s("v4-craft-record", n ? `等级 ${l?.level ?? n.level} · 已完成安全连锻 ${n.bursts}次` : ""), s("v4-risk", a ? a.odds.burst ? "下一锤安全连锻，不会裂" : `下一锤裂损 ${a.odds.crack / 10}%${n?.cracked ? " · 再裂会断" : " · 首裂会掉价"}` : e.reserveId === n?.id ? "这柄在剑架上，先取回再加工" : "余剑已安排，可收工"), r("v4-charge").replaceChildren(Y("span", a?.odds.burst ? "锤势已满" : `锤势 ${n?.charge ?? 0}/6`), ...Array.from({ length: 6 }, (e, t) => {
			let r = Y("i");
			return r.classList.toggle("filled", t < (n?.charge ?? 0)), r;
		})), i("v4-hit").disabled = !L(), i("v4-hit").setAttribute("aria-busy", String(w)), i("v4-strike").disabled = !L();
		let f = a?.canStrike ? a.odds.burst ? "安全连锻" : "落锤" : a?.reserved ? "先取回剑" : "收工", m = i("v4-strike");
		m.dataset.label !== f && (m.dataset.label = f, m.replaceChildren(document.createTextNode(f), Y("span", a?.canStrike ? "左键剑身 / 空格" : a?.reserved ? "到左侧剑架取回" : "这一炉已安排好"))), m.setAttribute("aria-busy", String(w));
		let h = a?.quote, g = _r(t, n?.id ?? null);
		s("v5-value-meaning", g.valueHint), s("v5-order-pay", g.orderPay), r("v5-order-pay").title = g.orderExplanation, s("v4-deliver", g.quote.buttonText);
		let v = i("v5-delivery-quote");
		v.dataset.copy !== g.quote.breakdown && (v.dataset.copy = g.quote.breakdown, v.replaceChildren(Y("span", g.quote.breakdown), Y("small", "看报价说明 ›"))), v.title = g.quote.explanation, i("v4-deliver").disabled = !L() || w || !h?.allowed, i("v4-deliver").setAttribute("aria-describedby", "v5-delivery-quote"), c("v5-arrange", h?.error === "market_exhausted"), i("v5-arrange").disabled = !L() || w, s("v4-reserve", e.reserveId === n?.id ? "取回留剑" : t.next ? "留给明天" : "暂放本局剑架"), i("v4-reserve").disabled = !L() || w || n?.status !== "active", i("v4-scrap").disabled = !L() || w || !a || a.reserved, i("v4-settle").disabled = !L() || w, s("v4-customer-name", t.commission.name), s("v4-talk", t.commission.progress.complete ? t.commission.success : t.commission.request), r("v4-customer-figure").dataset.customer = t.commission.customer, r("v4-customer-figure").dataset.pose = t.commission.progress.complete ? "receiving" : "waiting", c("v4-shop", !!t.merchant), i("v4-shop").disabled = !L() || w, c("v4-event-open", t.event?.status === "available"), t.event && s("v4-event-open", `炉边来事 · ${t.event.name}`), i("v4-event-open").disabled = !L() || w;
		let y = JSON.stringify([
			e.runId,
			n?.id,
			n?.hits,
			n?.recipe,
			t.recipes.map((e) => e.id),
			L(),
			w
		]);
		if (y !== ee) {
			ee = y;
			let e = r("v4-recipes");
			a?.canChangeRecipe && t.recipes.length > 1 ? e.replaceChildren(...t.recipes.map((e) => {
				let t = B(e.name, () => q({
					type: "setRecipe",
					pieceId: n.id,
					recipe: e.id
				}), !1, !L() || w || e.id === n.recipe);
				return t.dataset.recipe = e.id, t.setAttribute("aria-pressed", String(e.id === n.recipe)), t;
			})) : e.replaceChildren();
		}
		r("v4-workshop").dataset.mainComplete = String(t.commission.progress.complete);
		let b = r("v4-ember-meter");
		b.dataset.ready = String(!!a?.odds.burst), b.dataset.charge = String(n?.charge ?? 0), b.setAttribute("aria-valuenow", String(n?.charge ?? 0)), b.setAttribute("aria-valuetext", a?.odds.burst ? "下一锤安全连锻" : `锤势${n?.charge ?? 0}，满六格后连锻`);
		for (let e of b.querySelectorAll("[data-ember-index]")) e.dataset.lit = String(Number(e.dataset.emberIndex) < (n?.charge ?? 0));
		s("v4-settle", t.commission.progress.complete ? e.day === 12 ? "收炉，提灯归家" : "收炉，准备启程" : "收工，封炉"), rt(e), at(e), Qe(e), se?.syncHeld(e), N?.draw(n), ae?.refresh(), !o && n?.status === "broken" && (i("v4-hit").disabled = !0);
	}
	function at(e) {
		let t = z(e), n = JSON.stringify([
			e.runId,
			e.traits,
			e.gift,
			e.pardonUsed,
			e.modifications,
			e.upgradeCount,
			e.day,
			e.pending,
			e.dayBuffs,
			e.crackGuard,
			e.blades.filter((t) => t.suppliedDay === e.day && t.slot === 1).map((e) => [e.hits, e.status]),
			pe,
			L(),
			w
		]);
		if (n === A) return;
		A = n, r("v4-traits").replaceChildren(...t.traits.map((e) => {
			let t = pe.includes(e.id), n = B(e.name, () => {
				let n = Wn(e.id, z(I())), r = Y("div");
				r.append(Y("p", e.text), Y("h3", n.headline), Y("p", n.copy)), t && r.append(Y("p", "这门手艺在上一记中实际生效。")), U(e.name, r, [{
					label: "回铁砧",
					run: () => H()
				}]);
			});
			return n.dataset.trait = e.id, n.dataset.used = String(e.used), e.used && n.append(Y("small", "本局已用")), n.dataset.triggered = String(t), n.title = e.text, n.prepend(ln(e.id)), t && n.append(Y("small", "本锤生效")), n;
		}));
		let i = r("v4-gift");
		i.replaceChildren(), t.gift.status === "available" && i.append(B("首赠 · 选手艺", gt, !0, !L() || w)), r("v4-modifications").replaceChildren(...t.modifications.map((e) => {
			let t = B(e.name, () => U(e.name, e.text, [{
				label: "收好",
				run: () => H()
			}]));
			return t.dataset.modification = e.id, t.dataset.triggered = String(pe.includes(e.id)), t.prepend(Me(e.id)), t;
		}));
		let a = [], o = e.blades.find((t) => t.suppliedDay === e.day && t.slot === 1), s = o ? `${_[o.recipe].name}（第${o.suppliedDay}天来料）` : "本日首柄新坯";
		e.upgradeCount && a.push({
			id: "donation",
			label: `备料${e.upgradeCount}次`,
			copy: `来料升级已累计${e.upgradeCount}次，眼前剑不变。${t.next ? `明日普通新坯底价${$(t.next.normalBase)}，第一新坯含余温为${$(t.next.firstBase)}。` : "已是最后一炉，没有下一批来料。"}`,
			pending: !1
		}), e.crackGuard ? a.push({
			id: "credit",
			label: "保价待用",
			copy: "下一次完好剑首裂保住估值，仍会留下裂纹；再次裂损仍会断。首裂时正式消耗。",
			pending: !1
		}) : pe.includes("credit") && a.push({
			id: "credit",
			label: "保价已用",
			copy: "这记首裂实际用掉保价，保住了本次估值；裂纹仍在，再裂仍会断。这不是一份新的待用资格。",
			pending: !1
		});
		for (let t of [!1, !0]) {
			let n = t ? e.pending : e.dayBuffs, r = t ? "明日" : "此炉";
			n.supplyPct === 120 && a.push({
				id: "donation",
				label: `${r}加料`,
				copy: t ? "护送加料待明日发坯：新坯底价＋20%，留剑则两柄，否则三柄；不作用于旧剑。" : "今日新坯已按20%加料发出，底价已包含这份加成；同行旧剑没有额外增值。",
				pending: t
			}), n.loan && a.push({
				id: "loan",
				label: t ? "借锤待明日" : o && o.hits >= 3 ? "借锤已用完" : "此炉借锤",
				copy: t ? "明日第一柄新坯前三记普通锤正收益＋10%，同行旧剑不受益。" : `${s}的前三记普通锤正收益＋10%。${o?.status === "active" ? `已经敲了${Math.min(o.hits, 3)}/3记；安全连锻不消耗普通锤次数。` : "这柄已离开铁砧。"}`,
				pending: t
			}), n.shelter && a.push({
				id: "shelter",
				label: `${r}炉棚`,
				copy: t ? "明日第一柄新坯当天裂损率降低3个百分点，同行旧剑不受益。" : `${s}当天裂损率降低3个百分点，已计入该柄新坯的风险报价。${o?.status === "active" ? "" : "这柄已离开铁砧。"}`,
				pending: t
			});
		}
		for (let e of a) {
			let t = B(e.label, () => U(e.label, e.copy, [{
				label: "回铁砧",
				run: () => H()
			}]));
			t.dataset.effect = e.id, t.dataset.pending = String(e.pending), t.dataset.triggered = String(pe.includes(e.id)), t.prepend(Me(e.id)), r("v4-modifications").append(t);
		}
	}
	function ot() {
		let e = I(), t = M?.subject;
		return !t || !!e && t.runId === e.runId && t.day === e.day && t.revision === e.revision && (t.generation === void 0 || t.generation === p.generation);
	}
	function st() {
		if (ot() || (M = null), M?.action === "deliver") {
			let e = I() ? z(I()).blades.find((e) => e.blade.id === M?.subject?.pieceId) : null;
			(!e?.willCommission || e.reserved) && (M = null);
		}
		let t = !!M && b === "game" && (te === "workshop" || C);
		c("v4-notice", t), e.firstElementChild?.setAttribute("data-has-notice", String(t)), M && (i("v4-notice-action").disabled = ![
			"book",
			"journey",
			"inspect",
			"resume",
			"none"
		].includes(M.action) && (!L() || w), s("v4-notice-title", M.title), s("v4-notice-copy", M.copy), s("v4-notice-action", M.label), i("v4-notice-action").hidden = M.action === "none");
	}
	function ct() {
		let e = [];
		return p.mode === "memory" ? e.push("本次不保存，关闭页面会失去当前试玩") : p.mode === "readonly" ? e.push("另一窗口正在保存，本页只读") : p.mode === "unsupported" ? e.push("未取得保存锁，可不保存试玩") : p.mode === "error" ? e.push("保存权获取失败，可重试读取最新，或明确不保存试玩") : p.conflict ? e.push("磁盘进度已更新，请先导出") : p.dirty ? e.push("当前行程尚未保存") : p.load?.main.status === "invalid" || p.load?.main.status === "unavailable" ? e.push("主档" + (br[p.load.main.error] ?? "不可读取")) : p.load?.main.status === "empty" && p.load.backup.status === "valid" && e.push("发现可恢复的局备份"), (m.pending || m.problem) && e.push("炉谱" + (m.problem ? br[m.problem] ?? "待保存" : "待保存")), p.lastSave?.ok && p.lastSave.backupWarning && e.push("本局已存，备份未更新"), m.lastSave?.ok && m.lastSave.backupWarning && e.push("炉谱已存，备份未更新"), h.problem && e.push("声音与动效设置尚未保存"), e;
	}
	function J() {
		if (g) return;
		let t = r("v5-old-v4");
		try {
			let e = Ht(localStorage.getItem(Bt));
			t.textContent = e.status === "valid" ? `继续旧版十二灯 · 第${e.state.day}天` : "旧版十二灯行程";
		} catch {
			t.textContent = "旧版十二灯行程";
		}
		let n = te, a = I(), o = b === "game" && a && ir(a, 12) === "workshop" && !ie;
		te = b === "title" ? "title" : o ? "workshop" : "stage", e.firstElementChild?.setAttribute("data-screen", te), e.firstElementChild?.setAttribute("data-chapter", a ? String(z(a).chapter.id) : "1"), c("v4-title", b === "title"), c("v4-workshop", !!o), c("v4-stage", b === "game" && !o && !!a), c("v4-tools", !0), c("v4-menu", b === "game"), c("v4-book", b === "game"), c("v4-settings", b === "game"), i("v4-continue").hidden = !a, i("v4-continue").disabled = !p.active, i("v4-start").disabled = !p.active || p.conflict || !["writer", "memory"].includes(p.mode) || p.mode !== "memory" && m.pending || p.mode !== "memory" && p.load?.main.status === "unavailable", s("v4-start", a ? "另启一程" : "启程"), c("v4-title-challenge", m.data.challenge), i("v4-title-challenge").disabled = i("v4-start").disabled || m.pending || !!m.problem;
		let l = ct();
		if (c("v4-save-banner", l.length > 0), s("v4-save-summary", l.join(" · ")), s("v4-save-open", l.length ? "保存详情 !" : a ? "进度已收好" : "本机存档"), o && a) {
			let e = Te();
			(!e || e.finalizedDay !== null && e.finalizedDay < a.day) && Ae(), it(a);
		} else b === "game" && a && Ze(a);
		for (let t of e.querySelectorAll("#v4-stage [data-economic]")) t.disabled = !L() || w;
		b === "game" && !x && !document.hidden && (C ? M = De() : M?.action === "resume" && (M = null)), st(), Pe(), Ne(), o && n !== "workshop" && queueMicrotask(() => {
			!g && !x && !C && te === "workshop" && b === "game" && i("v4-strike").focus({ preventScroll: !0 });
		});
	}
	function lt() {
		Oe(), E++, b = "title", C = !1, O = "", x && H(), J(), i("v4-start").focus({ preventScroll: !0 });
	}
	function ut() {
		I() && (Oe(), E++, b = "game", C = !1, O = "", Ae(), J(), u.gesture());
	}
	function dt(e = "story") {
		return {
			runId: crypto.randomUUID(),
			seed: re.trim() || `灯路-${crypto.randomUUID().slice(0, 8)}`,
			mode: e
		};
	}
	function pt(e = "story") {
		if (g) return;
		if (e === "challenge" && (!m.data.challenge || m.pending || m.problem)) {
			G(m.pending ? "collection_pending" : "challenge_locked"), (m.pending || m.problem) && Nt();
			return;
		}
		let n = dt(e), r = (e = !1) => {
			let r = t.startNewGame(n, {
				generation: p.generation,
				confirmed: e
			});
			r.ok ? (M = null, ut()) : (G(r.error), r.error === "collection_pending" && Nt());
		}, i = p.load?.main;
		I() || i?.status === "invalid" || p.load?.backup.status === "valid" ? W(e === "challenge" ? "带着炉谱，开启行脚挑战？" : "另启一程？", `${e === "challenge" ? "挑战会重排章内委托，沿用相同锻造规则。" : ""}当前新经营行程会被替换，合法旧主档会保留为备份。旧版十二灯行程保持原样，可从旧入口续玩；先导出想保留的进度。${i?.status === "invalid" ? " 当前损坏或较新版主档不会自动保留到备份，请先到保存详情导出磁盘局档原文。" : ""}`, () => r(!0)) : r();
	}
	function mt() {
		let e = I();
		if (!e) return;
		let t = z(e).settlement, n = Y("div");
		n.append(Y("p", t.complete ? "今日主委托已完成。" : t.protected ? "护炉契这次只保住契印，不补回未完成的约定；本局护印机会随后用尽。" : `尚未完成主委托，收工后契印为${t.sealsAfter}/3。`)), rr(e.day) && !t.complete && n.append(Y("p", "今天是关键约定。现在收工会留下失约的缺口；之后补回契印或完成其他单，也补不上这一站，无法达成“十二灯复明”。")), t.sealsAfter === 0 ? n.append(Y("p", "契印将归零，本局在这里停下；真实交付和成长留在这次行程，结束后可查看或导出。")) : e.day === 12 ? n.append(Y("p", "这是最后一站；收工后按沿途关键约定、至少10项完成和剩余契印判定这次结局。")) : t.complete || n.append(Y("p", `仍可带着${t.sealsAfter}枚契印去下一天；这次失约会保留在灯路回顾里。`)), n.append(Y("p", `余下${t.remaining.length}柄共回收${$(t.recovered)}铜钱；今日收购剩余${$(z(e).market.remaining)}。`));
		for (let r of t.recoveries) {
			let t = e.blades.find((e) => e.id === r.pieceId);
			n.append(Y("p", `${_[t.recipe].name} · 估值${$(t.value)} → 回收${$(r.amount)}${r.amount === 0 ? "（钱袋已空，仍会交出）" : ""}`));
		}
		let r = z(e).next;
		r && n.append(Y("h3", `明日：${r.commission.title}`), Y("p", r.reserve ? `留这柄${_[r.reserve.recipe].name}，明日一旧剑＋两新坯；${r.reserve.assessment.qualifies ? "已合一柄要求" : "还不合这张纸单，可返回调整"}。` : "没有留剑，明日三柄新坯。"), Y("p", "取下或处置旧剑后，不会额外补发第四柄。")), W("收好这一炉", n, () => q({ type: "settle" }));
	}
	function ht(e, t, n, r, i = "首赠免费，不交剑、不花铜钱。") {
		let a = I();
		if (!a) return;
		let o = Y("div");
		o.append(typeof n == "string" ? Y("p", n) : n, Y("h3", `新手艺 · ${f[e].name}`), ln(e), Y("p", f[e].text));
		let s = Y("div", void 0, "v4-choice-grid");
		for (let n of a.traits) {
			let r = Y("article", void 0, "v4-card");
			r.append(ln(n), Y("h3", f[n].name), Y("p", f[n].text), B(`换下${f[n].name}`, () => W("确定换手艺？", `${i} ${f[n].name}将离开行囊，换成${f[e].name}。已经使用的本局护印不会恢复。`, () => q(t(n))))), s.append(r);
		}
		o.append(s), U("行囊已满，换下哪一门？", o, [{
			label: r,
			run: () => H()
		}], "replacement");
	}
	function gt() {
		let e = I();
		if (!e || !z(e).gift.canClaim) return;
		let t = ["steady", "ember"].filter((t) => !e.traits.includes(t));
		if (!t.length) {
			W("赠礼折成旅费", "两门赠礼手艺都已学会，领取40铜钱。", () => q({
				type: "claimGift",
				traitId: null
			}));
			return;
		}
		let n = (e) => {
			let t = I();
			t && (t.traits.length === 3 ? ht(e, (t) => ({
				type: "claimGift",
				traitId: e,
				replaceId: t
			}), "这是一份未领的首赠，换槽不交剑、不花铜钱，也不会重置本局已用护印。", "稍后再领") : (H(), q({
				type: "claimGift",
				traitId: e
			})));
		}, r = Y("div", void 0, "v4-choice-grid"), i = z(e);
		for (let e of t) {
			let t = Wn(e, i), a = Y("article", void 0, "v4-card");
			a.append(ln(e), Y("h3", f[e].name), Y("p", f[e].text), Y("b", t.headline), Y("p", t.copy), B(`学会${f[e].name}`, () => n(e), !0)), r.append(a);
		}
		U("第一门手艺，自己挑", r, [{
			label: "稍后再领",
			run: () => H()
		}], "gift");
	}
	function _t(e = D) {
		let t = I();
		if (!t) return;
		let n = z(t), r = An(n, e), i = n.blades.find((t) => t.blade.id === e), a = Y("div");
		a.append(Y("p", n.commission.progress.complete ? n.commission.success : n.commission.request), Y("p", r.summary));
		for (let e of r.routes) {
			let n = Y("section", void 0, "v4-commission-detail");
			n.append(Y("h3", e.label), Y("p", e.requirement), Y("p", `${e.deliveredIds.length}/${e.required} 已交${e.inactive ? " · 另一条已完成，无需再交" : ""}`));
			for (let r of e.deliveredIds) {
				let e = t.blades.find((e) => e.id === r);
				e && n.append(V(e));
			}
			e.selected && !r.complete && n.append(Y("p", e.selected.matches ? e.selected.copy : e.selected.missing.join("、"))), a.append(n);
		}
		a.append(Y("p", `今日酬劳${$(n.market.baseFee)}，已收${$(n.market.baseFeesPaid)}；行会收购钱袋还余${$(n.market.remaining)}。`)), i && a.append(Y("h3", "当前查看的这柄"), V(i.blade), Y("p", `${_[i.blade.recipe].name} · 估值${$(i.blade.value)}${i.reserved ? " · 挂在留剑架上" : ""}`));
		let o = [{
			label: "回铁砧",
			run: () => H()
		}];
		if (i?.willCommission && !i.reserved) {
			let r = {
				runId: t.runId,
				revision: t.revision,
				generation: p.generation
			};
			o.push({
				label: `交给${n.commission.name} · 实收${$(i.quote.amount)}铜钱`,
				primary: !0,
				disabled: !p.active || p.conflict || !["writer", "memory"].includes(p.mode) || C,
				run: () => {
					let t = r.runId === I()?.runId && r.revision === I()?.revision && r.generation === p.generation;
					H();
					let n = I(), i = n ? z(n).blades.find((t) => t.blade.id === e) : null;
					t && i?.willCommission && !i.reserved ? q({
						type: "deliver",
						pieceId: e
					}) : G("stale_session");
				}
			});
		} else a.append(Y("p", i?.reserved ? "先从剑架取回，才能交付。" : "不合委托的剑仍可明确卖给行会，出售不会点亮今天这一站。"));
		U(n.commission.name + "的心愿", a, o, "commission");
	}
	function vt(e, t = D) {
		let n = I(), r = n?.blades.find((e) => e.id === t);
		if (!n || !r || r.status !== "active" || n.reserveId === r.id) {
			R("先从剑架选一柄未保留的剑。");
			return;
		}
		let i = z(n).blades.find((e) => e.blade.id === r.id)?.barter;
		if (!i?.allowed) {
			G(i?.error ?? "blade_unworked");
			return;
		}
		let a = r.id, o = Xn(e, z(n), r.id), s = Y("div");
		s.append(...Yn(z(n), r.id).opportunity.map((e) => Y("p", e)), V(r), Y("p", `用这柄${_[r.recipe].name}（估值${$(r.value)}）换${f[e].name}，不再兼作交付或留剑。`), Y("b", o.headline), Y("p", o.copy)), n.traits.length === 3 ? ht(e, (t) => ({
			type: "buy",
			pieceId: a,
			traitId: e,
			replaceId: t
		}), s, "不换，保留剑", `交出这柄${_[r.recipe].name}（估值${$(r.value)}），不能再交差、卖钱或留给明日。`) : W("用剑换手艺", s, () => q({
			type: "buy",
			pieceId: a,
			traitId: e
		}));
	}
	function yt() {
		let e = I();
		if (!e) return;
		let t = z(e), n = sr(e, t.commission.id === 11 && !t.commission.progress.complete && t.commission.progress.routes.some((e) => e.count > 0) ? 11 : e.day >= 9 ? 12 : e.day >= 5 ? 8 : 4), r = Y("div", void 0, "v4-journey-review");
		r.append(Y("p", nr));
		let i = Y("figure"), a = Y("img");
		Ce.image(a, n.image, "/assets/d/forge-backdrop-v2.webp"), a.alt = n.commission.title + " · " + (n.complete ? "委托已完成" : `实际交付 ${n.progressText}`), a.dataset.journeyScene = "true", a.className = "v4-partial-journey-image", i.append(a, Y("figcaption", `${n.commission.title} · ${n.complete ? "已完成" : n.progressText}`)), r.append(i);
		let o = Y("div", void 0, "v4-journey-works");
		for (let e of n.matchedBlades) {
			let t = Y("div", void 0, "v4-journey-work");
			t.append(V(e), Y("p", `${_[e.recipe].name} · 估值${$(e.value)} · 已交付`)), o.append(t);
		}
		r.append(o);
		let s = Y("ol", void 0, "v4-journey-lamps");
		for (let n = 1; n <= 12; n++) {
			let r = S[e.commissionOrder[n - 1] - 1], i = e.history.find((e) => e.day === n), a = n === e.day, o = Y("li");
			if (o.dataset.day = String(n), o.dataset.result = i ? i.met ? "met" : "missed" : a ? "current" : "future", o.append(Y("b", `第${n}天 · ${r.title}`), Y("span", i ? i.met ? "已经履约" : "留下遗憾" : a ? t.commission.progress.complete ? "今日委托已完成" : t.commission.progress.routes.map((e) => `${e.count}/${e.required}`).join(" 或 ") : "尚未抵达")), n <= e.day) {
				let t = sr(e, r.id), n = Y("details", void 0, "v4-journey-deliveries");
				n.dataset.commission = String(r.id), n.append(Y("summary", "查看这一站的交剑"), ...t.routes.map((e) => Y("p", `${e.description} · 已交 ${e.count}/${e.required}`)));
				for (let e of t.matchedBlades) {
					let r = Y("div", void 0, "v4-journey-work");
					r.dataset.piece = e.id, r.append(V(e), Y("p", `${_[e.recipe].name} · ${$(e.value)} · ${t.pieceIds.includes(e.id) ? "本次完成收据" : t.complete ? "此前另有匹配交付" : "已经交付，尚未凑齐"}`)), n.append(r);
				}
				t.matchedBlades.length || n.append(Y("p", "没有计入这站委托的交付。")), o.append(n);
			}
			s.append(o);
		}
		if (r.append(s), e.day >= 3 && r.append(Y("h3", "阿禾捎来的第一封信"), Y("p", y[0].letter)), e.day >= 7 && r.append(Y("h3", "阿禾的雪中来信"), Y("p", y[1].letter)), e.day >= 11 && r.append(Y("h3", "山口送来的最后一封信"), Y("p", y[2].letter)), t.next && e.day < 12 && (r.append(Y("h3", `下一天 · ${t.next.commission.title}`), Y("p", t.next.commission.request), Y("p", `明日${t.next.oldCount}柄旧剑＋${t.next.newCount}柄新坯，共${t.next.totalCount}柄；新坯底价${$(t.next.normalBase)}，首柄实际${$(t.next.firstBase)}。取下旧剑不补发。`)), t.next.reserve)) {
			let n = e.blades.find((e) => e.id === t.next.reserve.id);
			n && r.append(V(n), Y("p", `留剑届时估值${$(t.next.reserve.value)} · ${t.next.reserve.cracked ? "仍带裂纹" : "无裂纹"} · 锤势${t.next.reserve.charge}/6`));
		}
		e.modifications.length && r.append(Y("h3", "已经装好的炉具"), ...e.modifications.map((e) => Y("p", `${v[e].name} · ${v[e].text}`))), U(`灯路回顾 · ${t.chapter.title}`, r, [{
			label: "回铁砧",
			primary: !0,
			run: () => H()
		}], "journey");
	}
	function bt(t = I()?.reserveId ?? D) {
		let n = I();
		if (!n) return;
		let r = z(n), i = Un(r), a = Y("div", void 0, "v5-carry-plan");
		if (a.append(Y("p", i.headline)), !r.next) {
			a.append(Y("p", i.copy)), U("最后一炉的打算", a, [{
				label: "回炉边，自己拿主意",
				primary: !0,
				run: () => H()
			}], "tomorrow");
			return;
		}
		let o = r.next, s = Y("details");
		s.append(Y("summary", `第${o.day}天 · ${o.commission.title} · 查看完整纸单`), Y("p", o.commission.request), ...i.routes.map((e) => Y("p", e.description))), a.append(s);
		let c = Y("div", void 0, "v5-carry-choices"), l = Y("div", void 0, "v5-carry-preview"), u = {
			runId: n.runId,
			revision: n.revision,
			generation: p.generation
		}, d = r.blades.some((e) => e.blade.id === t) ? t : null, f = /* @__PURE__ */ new Map(), m = () => u.runId === I()?.runId && u.revision === I()?.revision && u.generation === p.generation, h = () => {
			c.querySelector("[data-carry-none]")?.setAttribute("aria-pressed", String(d === null));
			for (let [e, t] of f) t.setAttribute("aria-pressed", String(e === d));
			l.replaceChildren();
			let t = d ? qn(r, d, n.journal.length >= T) : null, i = Y("div", void 0, "v5-packing-slots");
			if (t) {
				let e = Y("div");
				e.append(V(t.blade), Y("b", `${_[t.blade.recipe].name} · 旧剑`), Y("span", `${$(t.valueNow)} → ${$(t.valueNext)}`)), i.append(e);
			}
			for (let e = 0; e < (t ? 2 : 3); e++) {
				let t = Y("div", void 0, "v5-new-blank");
				t.append(Y("b", "新坯"), Y("span", `底价 ${$(e === 0 ? o.firstBase : o.normalBase)}`)), i.append(t);
			}
			l.append(Y("h3", t ? "一柄旧剑 ＋ 两柄新坯" : "三柄新坯"), i, Y("p", t ? t.copy : "不挂留剑，明日领三柄新坯。取下或处置旧剑后也不会补第四柄。")), t && l.append(Y("p", t.matching ? "按确定的次日估值，已经合一柄要求；启程后仍需实际交剑。" : `明日尚缺：${t.missing.join("；")}`));
			let a = e.querySelector("#v5-pack-confirm");
			a && (a.hidden = t ? t.id === n.reserveId : !n.reserveId, a.textContent = t ? n.reserveId ? "换这柄装箱" : "把这柄装箱" : "取下旧剑，改领三新坯", a.disabled = !!t && !t.canReserve || !p.active || p.conflict || !["writer", "memory"].includes(p.mode)), t?.id === n.reserveId && l.append(Y("p", "这柄已挂架。返回炉边可取回，明日新坯仍共两柄。")), Ne();
		}, g = B("不带旧剑", () => {
			d = null, h();
		});
		g.dataset.carryNone = "true", c.append(g);
		for (let e of r.blades) {
			let t = e.blade, n = B(`${_[t.recipe].name} · ${$(t.value)}${e.reserved ? " · 已挂架" : ""}`, () => {
				d = t.id, h();
			});
			n.dataset.carryPiece = t.id, n.prepend(V(t)), f.set(t.id, n), c.append(n);
		}
		r.blades.length || a.append(Y("p", "今日兵器已安排完，明日领三柄新坯。")), a.append(c, l), U(`明日装箱 · 第${i.day}天`, a, [{
			label: "回炉边，自己拿主意",
			run: () => H()
		}, {
			label: "把这柄装箱",
			id: "v5-pack-confirm",
			primary: !0,
			run: () => {
				if (!m()) {
					H(), G("stale_session");
					return;
				}
				let e = d ? qn(r, d, n.journal.length >= T) : null;
				H(), e?.canReserve ? nt(e.id) : !e && n.reserveId && q({
					type: "reserve",
					pieceId: n.reserveId
				});
			}
		}], "tomorrow"), h();
	}
	function xt(e = D) {
		let t = I();
		if (!t) return;
		let n = z(t);
		if (!n.merchant) return;
		let r = {
			upgraded: t.upgraded,
			repaired: t.repaired,
			recordLimited: t.journal.length >= T
		}, i = {
			runId: t.runId,
			revision: t.revision,
			generation: p.generation
		}, a = () => i.runId === I()?.runId && i.revision === I()?.revision && i.generation === p.generation;
		U("行脚商人的炉边摊", Qn(n, {
			selectedPieceId: e,
			thumb: V,
			action: B,
			growthControls: r,
			buy: (e, t) => {
				a() ? vt(e, t) : G("stale_session");
			},
			upgrade: () => {
				if (!a()) {
					G("stale_session");
					return;
				}
				let e = Jn(n, r).upgrade;
				W("为下一炉备料", `${e.currentBase} → ${e.afterBase}。${e.copy}`, () => q({ type: "upgrade" }));
			},
			repair: () => {
				if (!a()) {
					G("stale_session");
					return;
				}
				let e = Jn(n, r).repair;
				W("修补契印", `${e.sealsBefore}/3 → ${e.sealsAfter}/3。${e.copy}`, () => q({ type: "repair" }));
			}
		}), [{
			label: "回铁砧",
			run: () => H()
		}], "shop");
	}
	function St() {
		let e = I(), t = Te();
		if (!e || !t) return;
		let n = z(e), r = n.blades.find((e) => e.blade.id === t.id);
		if (!r) return;
		let i = Y("div", void 0, "v5-arrange");
		i.append(V(t), Y("h3", `${_[t.recipe].name} · 估值${$(t.value)}`), Y("p", `今日收购钱袋${$(n.market.remaining)}/${$(n.market.budget)}铜钱。作品再贵，也只按剩余钱袋付款；主委托基础酬劳独立。`));
		let a = [{
			label: "先留在铁砧",
			run: () => H()
		}], o = {
			runId: e.runId,
			revision: e.revision,
			generation: p.generation
		}, s = (e) => {
			let t = o.runId === I()?.runId && o.revision === I()?.revision && o.generation === p.generation;
			H(), t ? e() : G("stale_session");
		};
		if (n.next && !r.reserved) {
			let r = qn(n, t.id, e.journal.length >= T);
			r && i.append(Y("p", r.copy)), a.push({
				label: "看看明日装箱",
				run: () => s(() => bt(t.id))
			});
		}
		n.merchant && (i.append(Y("p", r.barter.allowed ? "这柄已成器，可以献剑换手艺；不消耗收购钱袋。" : "献剑换手艺需等级至少3；挂架的剑要先取回。")), a.push({
			label: "去炉边摊比较",
			run: () => s(() => xt(t.id))
		})), r.reserved || a.push({
			label: `回收这柄 · 实得${$(r.recovery)}`,
			run: () => s(() => Ct(t.id))
		}), i.append(Y("p", "收工也会回收未挂架的余剑。回收为0时仍会交出剑；取消后仍可继续打造。")), U("钱袋封口了，安排这柄剑", i, a, "arrange");
	}
	function Ct(e = D) {
		let t = I(), n = t?.blades.find((t) => t.id === e);
		if (!t || !n) return;
		let r = z(t).blades.find((e) => e.blade.id === n.id);
		r && !r.reserved && W("回收这柄剑？", `这柄当前回收实得${$(r.recovery)}铜钱，受今日收购钱袋限制；回收后交出兵器，不计主委托，也不能再锻。`, () => q({
			type: "scrap",
			pieceId: n.id
		}));
	}
	function wt() {
		let e = I();
		if (!e) return;
		let t = z(e), n = t.event;
		if (!n || n.status !== "available") return;
		let a = (e) => n.id === "loan" || n.id === "shelter" ? e.replace(/(明天|明日)第一柄(?!新坯)/g, "$1第一柄新坯") : e, o = {
			...n,
			request: a(n.request),
			result: a(n.result)
		}, s = Y("div");
		s.append(Me(o.id), Y("p", o.request), Y("p", `接受后：${o.result}`));
		let c = [{
			label: "暂不决定",
			run: () => H()
		}, {
			label: "拒绝，保留眼前资源",
			run: () => {
				H(), q({
					type: "chooseEvent",
					choice: "decline"
				});
			}
		}], l = (n) => {
			let r = fe(e, n);
			if (!r.allowed) {
				R("当前对象或铜钱不满足这次选择。");
				return;
			}
			let i = n ? e.blades.find((e) => e.id === n) : null, a = Y("div");
			i && a.append(V(i), Y("p", `所选${_[i.recipe].name}估值${$(i.value)}。交出后不再兼作交付或留剑。`)), a.append(Y("p", o.result + (r.cost ? ` 支付${$(r.cost)}铜钱。` : ""))), o.id === "salvage" && t.next?.commission.routes.some((e) => e.age === "old") && a.append(Y("p", "明天的纸单含旧剑路线；换出后需另备留剑，或采用纸单上的其他路线。")), W(o.name, a, () => q({
				type: "chooseEvent",
				choice: "accept",
				...n ? { pieceId: n } : {}
			}));
		};
		if (o.piece !== "none") {
			let t = Y("div", void 0, "v4-choice-grid"), n = e.blades.filter((t) => t.status === "active" && (o.piece === "reserve" ? e.reserveId === t.id : e.reserveId !== t.id));
			for (let r of n) {
				let n = Y("div", void 0, "v4-card");
				n.dataset.eventPiece = r.id, n.append(V(r), Y("p", `${r.suppliedDay < e.day ? "此前留下" : "今日来料"} · ${r.cracked ? "已有裂纹" : "完好"} · 锤势${r.charge}/6`), B(`选这柄 · ${_[r.recipe].name} ${$(r.value)}`, () => l(r.id))), t.append(n);
			}
			if (!n.length) {
				let n = e.blades.some((t) => t.status === "active" && t.id !== e.reserveId);
				o.piece === "reserve" && n ? (t.append(Y("p", "剑架上还没有剑。可以先回铁砧选一柄愿意换出的余剑，点“留给明天”挂上剑架，再回来交换；今日铁坯也可以挂上。不想换时可拒绝。")), c.unshift({
					label: "回铁砧选剑挂上",
					primary: !0,
					run: () => {
						H(), queueMicrotask(() => {
							g || x || b !== "game" || I()?.phase !== "workshop" || !L() || ((Te()?.status === "active" && !i("v4-reserve").disabled ? i("v4-reserve") : r("v4-inventory").querySelector("button:not(:disabled)"))?.focus({ preventScroll: !0 }), R("选一柄余剑，点“留给明天”挂上剑架，再回旧刃回收确认交换。"));
						});
					}
				})) : t.append(Y("p", o.piece === "reserve" ? "剑架和铁砧上都没有可换出的剑，可以拒绝这次交换。" : "没有可交出的余剑，可以拒绝这次邀请。"));
			}
			s.append(t);
		} else {
			let t = fe(e);
			s.append(B(t.cost ? `接受 · ${$(t.cost)}铜钱` : "接受这次选择", () => l(), !0, !t.allowed)), t.allowed || s.append(Y("p", t.error === "already_owned" ? "已有尚未消耗的保价资格。" : "铜钱不足，可以保留当前资源。"));
		}
		U(o.name, s, c, "event");
	}
	function Tt() {
		U("炉谱 · 带得走的手艺", mr(m.data, {
			pending: m.pending,
			problem: !!m.problem,
			canStart: !i("v4-start").disabled,
			thumb: V,
			action: B,
			viewWork: Ot,
			challenge: () => pt("challenge")
		}), [
			{
				label: "收好炉谱",
				run: () => H()
			},
			{
				label: "旧炉谱主册导入",
				run: () => Et("main")
			},
			{
				label: "查看旧备份炉谱",
				run: () => Et("backup")
			},
			{
				label: "导出炉谱",
				run: Le
			}
		], "collection");
	}
	function Et(e) {
		x && H();
		let n = t.previewLegacyImport(e);
		if (!n.ok) {
			G(n.error), U("这份旧炉谱暂未读到", "旧原件仍保留，可以选择另一份来源。", [{
				label: "回炉谱",
				run: Tt
			}, {
				label: e === "main" ? "查看旧备份" : "查看旧主册",
				run: () => Et(e === "main" ? "backup" : "main")
			}], "legacy-unavailable");
			return;
		}
		let r = n.preview, i = Y("div", void 0, "v5-import-preview");
		i.append(Y("p", `来源：旧炉谱${r.source === "main" ? "主册" : "备份"} · ${new Date(r.savedAt).toLocaleString("zh-CN")}`), Y("h3", `将带回${r.collection.chapters.length}章见闻、${r.collection.works.length}件作品`), Y("p", `合并后炉谱保留${r.merged.works.length}/12件最佳作品${r.merged.challenge ? "，行脚挑战已解锁" : ""}。同一委托只留较高估值，旧作品仍标记旧行程来源。`), Y("p", "这里只合并解锁与作品，不带入旧铜钱、契印、来料升级或局内兵器；当前行程的开局资格保持，下一次启程才使用已保存的新资格。"));
		let a = Dt(r.collection), o = Dt(r.merged), s = Y("section", void 0, "v5-import-unlocks");
		s.append(Y("h3", "这份旧册的具体解锁"), Y("p", "章节：" + (r.collection.chapters.map((e) => y[e - 1].title).join("；") || "尚无")), Y("p", "按此册可用配方：" + a.recipes.map((e) => _[e].name).join("、")), Y("p", "配方熟练：" + (r.collection.mastery.map((e) => _[e].name).join("、") || "尚无")), Y("p", "手艺见闻：" + (r.collection.traits.map((e) => f[e].name).join("、") || "尚无")), Y("p", `这份旧册的行脚挑战：${r.collection.challenge ? "已解锁" : "未解锁"}`), Y("p", `合并后可用配方：${o.recipes.map((e) => _[e].name).join("、")}；行脚挑战${o.challenge ? "已解锁" : "未解锁"}。`)), i.append(s);
		let c = Y("details");
		c.append(Y("summary", "逐件看看将导入的作品"));
		for (let e of r.collection.works) {
			let t = Y("section", void 0, "v4-commission-detail");
			t.append(Y("h3", `${e.commissionId}. ${S[e.commissionId - 1].title}`), Y("p", "旧行程作品 · " + e.blades.map((e) => `${_[e.recipe].name} 估值${$(e.value)}`).join(" / ")));
			for (let n of e.blades) t.append(V(n));
			c.append(t);
		}
		i.append(c);
		let l = [{
			label: "暂不导入",
			run: () => H()
		}, {
			label: "确认导入这份炉谱",
			primary: !0,
			disabled: !m.writable,
			run: () => {
				let n = t.importLegacyCollection({
					generation: r.generation,
					confirmed: !0,
					previewId: r.id
				});
				H(), n.ok ? (R("这份旧炉谱已合入。当前局保持原样，下次启程使用新资格。"), Tt()) : n.error === "legacy_changed" || n.error === "stale_session" ? (R(yr.legacy_changed), U("旧炉谱已更新，请再看一次", "刚才显示的来源或当前行程已变化，没有导入未展示的新内容。", [{
					label: "回炉谱",
					run: Tt
				}, {
					label: "重新预览",
					primary: !0,
					run: () => Et(e)
				}], "legacy-changed")) : (G(n.error), Nt());
			}
		}];
		m.writable || i.append(Y("p", p.dirty ? "请先保存当前行程，再确认导入。" : "当前不能持久导入，可在保存详情中取得保存权；不保存模式仍可查看。", "v4-collection-warning")), U("把旧炉谱带上路", i, l, "legacy-import");
	}
	function Ot(e) {
		let t = m.data.works.find((t) => t.commissionId === e);
		t ? U(S[e - 1].title + " · 留名作品", hr(t, V, Ce.image), [{
			label: "回到炉谱",
			run: Tt
		}, {
			label: "收好作品",
			run: () => H()
		}], "collection-work") : Tt();
	}
	function At() {
		let e = I();
		if (!e) return;
		let t = _r(z(e), Te()?.id ?? null), n = Y("div", void 0, "v5-payment-detail");
		n.append(Y("h3", t.quote.breakdown), Y("p", t.quote.explanation), Y("p", t.orderPay), Y("p", t.orderExplanation));
		for (let e of t.quote.details) n.append(Y("p", e));
		U("估值与这次收款", n, [{
			label: "明白了，回炉边",
			run: () => H()
		}], "payment");
	}
	function jt() {
		let e = Y("div"), t = Y("input"), n = Y("input"), r = Y("input");
		t.type = "checkbox", t.checked = h.value.muted, n.type = "range", n.min = "0", n.max = "100", n.value = String(h.value.volume), r.type = "checkbox", r.checked = h.value.reducedMotion;
		for (let [i, a] of [
			["静音", t],
			["敲击音量", n],
			["减弱动效", r]
		]) {
			let t = Y("label", void 0, "v4-setting-row");
			t.append(Y("span", i), a), e.append(t);
		}
		t.onchange = () => l.update({ muted: t.checked }), n.oninput = () => l.update({ volume: Number(n.value) }), r.onchange = () => l.update({ reducedMotion: r.checked });
		let i = Y("p");
		i.id = "v4-preference-status";
		let a = Y("p");
		a.id = "v4-audio-status", a.setAttribute("role", "status");
		let o = Y("section");
		o.id = "v4-art-status", o.hidden = !0;
		let s = Y("p");
		s.id = "v4-art-copy", s.setAttribute("role", "status");
		let c = B("重试画稿", Ye);
		c.id = "v4-art-retry", o.append(s, c), e.append(i, a, B("试听敲击声", () => {
			u.silence(), u.setMode("preview"), u.preview();
		}), o), U("声音与动效", e, [{
			label: "保存失败时重试",
			run: () => {
				l.retry(), Mt();
			}
		}, {
			label: "收好",
			primary: !0,
			run: () => H()
		}], "settings"), Mt(), Ue(), Ge();
	}
	function Mt() {
		let t = e.querySelector("#v4-preference-status");
		t && (t.textContent = h.problem ? "设置尚未保存，可重试；不会回滚游戏进度。" : `设置已保留${d.matches ? " · 系统减弱动效已启用" : ""}`);
	}
	function Nt(e) {
		let n = Y("div", void 0, "v4-summary-list"), r = I(), i = p.load, a = m.load;
		if (e) {
			let t = Y("p", e);
			t.id = "v5-recovery-status", t.setAttribute("role", "alert"), n.append(t);
		}
		let o = (e) => {
			try {
				return {
					ok: !0,
					raw: localStorage.getItem(e)
				};
			} catch {
				return { ok: !1 };
			}
		}, s = o(Pt), c = o(ft), l = s.ok ? It(s.raw) : null, u = c.ok ? kt(c.raw) : null, d = (e, t) => {
			let n = o(e);
			return n.ok && n.raw === t ? !0 : (Nt("备份已变化或暂不可读取。请核对现有来源后，再决定恢复。"), !1);
		};
		n.append(Y("h3", "当前行程"), Y("p", ct().join(" · ") || "这里可以查看本机行程与炉谱。")), i?.main.status === "valid" && n.append(Y("p", `主档：第${i.main.state.day}天 · ${$(i.main.state.coins)}铜钱 · ${new Date(i.main.savedAt).toLocaleString("zh-CN")}`));
		let f = p.active && p.mode === "writer";
		n.append(B("重试保存本局", () => {
			let e = t.retrySave(p.generation);
			e.ok ? R("本局已保存。") : G(e.error), H(), Nt();
		}, !1, !f || p.conflict || !r), B("重试保存炉谱", () => {
			let e = t.retryCollection(p.generation);
			e.ok ? R("炉谱已保存。") : G(e.error), H(), Nt();
		}, !1, !f)), n.append(B("重新取得保存权 / 读取最新", () => W("读取磁盘上的最新行程", p.dirty ? "尚未保存的本局会被磁盘进度替换，请先导出。" : "将重新取得保存权并读取磁盘的最新行程。", () => {
			(async () => {
				if (await t.activate(), g) return;
				let e = t.getSnapshot();
				if (e.mode === "writer" && e.load?.main.status === "valid") {
					let n = t.resume({
						generation: e.generation,
						confirmed: !0
					});
					n.ok || G(n.error);
				}
				J();
			})();
		})), B("导出当前行程", Ie, !1, !r), B("导出炉谱和原文", Le));
		let h = Y("p", "主档损坏或暂不识别时，也可先导出磁盘上的主档与备份原文，再决定恢复或重开。");
		h.id = "v5-raw-export-status", h.setAttribute("role", "status");
		let _ = B("导出磁盘局档原文（主档与备份）", Re);
		if (_.id = "v5-export-raw-run", n.append(_, h), l?.status === "valid" && s.ok) {
			let e = l, r = s.raw;
			n.append(Y("p", `局备份：第${e.state.day}天 · ${$(e.state.coins)}铜钱 · 保存于${new Date(e.savedAt).toLocaleString("zh-CN")}`), B("恢复这份局备份", () => W("恢复局备份", `将用第${e.state.day}天、保存于${new Date(e.savedAt).toLocaleString("zh-CN")}的备份替换当前主档（损坏或本版暂不识别）；原主档原文不会自动备份，可先取消并导出磁盘局档原文。`, () => {
				if (!d("sword-led.save.backup.v5", r)) return;
				let e = t.recoverBackup({
					generation: p.generation,
					confirmed: !0
				});
				e.ok ? ut() : G(e.error);
			}), !1, !f || i?.main.status === "valid"));
		}
		if (u?.status === "valid" && c.ok) {
			let e = u, r = c.raw;
			n.append(Y("p", `炉谱备份：${e.state.works.length}件作品 · 保存于${new Date(e.savedAt).toLocaleString("zh-CN")}`), B("恢复这份炉谱备份", () => W("恢复炉谱备份", `用${e.state.works.length}件作品的合法备份替换当前损坏或不兼容炉谱，并合并已知合法成果。建议先导出原文。`, () => {
				if (!d("sword-led.collection.backup.v2", r)) return;
				let e = t.recoverCollectionBackup({
					generation: p.generation,
					confirmed: !0
				});
				e.ok ? R("炉谱备份已恢复。") : G(e.error);
			}), !1, !f || a?.main.status === "valid" || p.dirty || p.conflict));
		}
		n.append(Y("h3", "不保存试玩"), Y("p", "当前磁盘进度保持原样。明确转为不保存后，关闭/刷新会失去本次内存试玩，请先导出。"), B(r ? "保留当前局，不保存续玩" : "不保存，开一炉试玩", () => W("本次不保存", r ? "保留当前局继续，之后关闭页面会失去未写入磁盘的部分。" : "开始临时主线，不写正式局档或炉谱。", () => {
			let e = t.useMemory(r ? null : dt(), {
				generation: p.generation,
				confirmed: !0
			});
			e.ok ? ut() : G(e.error);
		})), B("不保存，另开一炉", () => W("另开临时旅程", "当前内存进度会被临时新局替换，磁盘原档仍保留；请先导出。", () => {
			let e = t.useMemory(dt(), {
				generation: p.generation,
				confirmed: !0
			});
			e.ok ? ut() : G(e.error);
		}))), U("把行程收好", n, [{
			label: "回到当前页面",
			primary: !0,
			run: () => H()
		}], "save");
	}
	function Ft() {
		C = !0, Oe(), U("炉火为你留着", "暂停时不会落锤或消耗资源。", [
			{
				label: "继续锻造",
				primary: !0,
				run: () => H()
			},
			{
				label: "灯路回顾",
				run: yt,
				id: "v4-journey-open"
			},
			{
				label: "回标题",
				run: lt
			},
			{
				label: "看看保存状态",
				run: () => Nt()
			}
		], "pause");
	}
	function Lt() {
		let e = I(), t = Te();
		return !e || !t || !L() || w || oe?.isDragging() || te !== "workshop" || !z(e).blades.find((e) => e.blade.id === t.id)?.canStrike ? null : {
			runId: e.runId,
			revision: e.revision,
			generation: p.generation,
			epoch: E,
			pieceId: t.id,
			mode: "standard",
			periodMs: 1,
			rulesVersion: e.rulesVersion
		};
	}
	function Rt() {
		let e = I();
		return !e || !L() || w || oe?.isDragging() || te !== "workshop" || Lt() ? null : {
			runId: e.runId,
			revision: e.revision,
			generation: p.generation,
			epoch: E,
			pieceId: "navigation",
			mode: "standard",
			periodMs: 1,
			rulesVersion: e.rulesVersion
		};
	}
	N = Sn(e, {
		reduced: we,
		cue: (e) => u.acceptedCue(e),
		ready: () => {
			J(), Ne(), Ge();
		},
		problem: Ke,
		contact: Ve
	}), se = wn(e, {
		reduced: we,
		paintBlade: (e, t) => N?.paintThumb(e, t)
	}), ce = jn(e, { thumb: (e) => {
		let t = I()?.blades.find((t) => t.id === e);
		return t ? V(t) : null;
	} }), oe = Mn(e, {
		capture: (e) => {
			let t = I();
			if (!t) return null;
			let n = {
				runId: t.runId,
				revision: t.revision,
				generation: p.generation,
				epoch: E,
				pieceId: e
			};
			return $e(n) ? n : null;
		},
		preview: et,
		commit: tt
	}), ae = Wt([i("v4-hit"), i("v4-strike")], {
		context: Lt,
		navigationContext: Rt,
		navigate: () => {
			let e = Te();
			e && I()?.reserveId === e.id ? (R(I()?.day === 12 ? "先从剑架取回安排交付、出售或回收；本局剑架不会带入新局。" : "先从剑架取回，或选择收工把它留给明天。"), i("v4-reserve").focus({ preventScroll: !0 })) : mt();
		},
		commit: (e, t) => {
			Ut(e, Lt()) && (ue = t, u.gesture(), q({
				type: "strike",
				pieceId: e.pieceId
			}));
		},
		aim: (e) => {
			L() && !w && !oe?.isDragging() && N?.aim(e);
		},
		preparing: (e) => N?.preparing(e)
	}), i("v4-start").onclick = () => pt(), i("v4-title-challenge").onclick = () => pt("challenge"), i("v4-continue").onclick = ut, r("v4-seed").value = re, r("v4-seed").oninput = (e) => {
		re = e.currentTarget.value;
	};
	for (let e of ["v4-title-collection", "v4-book"]) i(e).onclick = Tt;
	for (let e of ["v4-title-settings", "v4-settings"]) i(e).onclick = jt;
	i("v5-delivery-quote").onclick = At;
	for (let e of ["v4-save-open", "v4-save-details"]) i(e).onclick = () => Nt();
	i("v4-menu").onclick = () => b === "title" ? ut() : Ft(), i("v4-shop").onclick = () => xt(), i("v4-event-open").onclick = wt, i("v4-customer-open").onclick = () => _t(), i("v4-deliver").onclick = () => {
		let e = Te();
		e && q({
			type: "deliver",
			pieceId: e.id
		});
	}, i("v4-reserve").onclick = () => {
		let e = Te();
		e && nt(e.id);
	}, i("v4-scrap").onclick = () => Ct(), i("v4-settle").onclick = mt, i("v4-next-plan").onclick = () => bt(), i("v5-arrange").onclick = St, i("v4-inline-review").onclick = () => {
		let e = I(), t = le;
		e && t && (e.gift === "available" ? gt() : (Xe({
			kind: "delivery",
			revision: e.revision,
			commissionId: t.commissionId,
			pieceIds: t.pieceIds
		}), J()));
	}, i("v4-inline-dismiss").onclick = () => {
		le = null, c("v4-inline-delivery", !1);
	}, i("v4-notice-dismiss").onclick = () => {
		M = null, st();
	}, i("v4-notice-action").onclick = () => {
		let e = M;
		if (!e || !ot()) M = null, st();
		else if (e.action === "resume") C = !1, M = null, J();
		else if (e.action === "gift") gt();
		else if (e.action === "settle") mt();
		else if (e.action === "next") {
			if (!L() || w) return;
			Oe(!1), E++, M = null, Ae(), J(), i("v4-strike").focus({ preventScroll: !0 });
		} else if (e.action === "deliver") {
			let t = I(), n = e.subject?.pieceId, r = t ? z(t).blades.find((e) => e.blade.id === n) : null;
			n && r?.willCommission && !r.reserved ? q({
				type: "deliver",
				pieceId: n
			}) : (M = null, st(), R("这柄的状态已变化，请重新查看纸单。"));
		} else e.action === "inspect" ? _t(e.subject?.pieceId) : e.action === "book" ? Tt() : e.action === "shop" ? xt() : e.action === "journey" && yt();
	}, a.addEventListener("cancel", (e) => {
		e.preventDefault(), H();
	});
	let zt = () => {
		document.hidden ? (Oe(), E++, C = b === "game", x && H(!1), u.setMode("silent")) : (C && (M = De()), J());
	}, Vt = (e) => {
		e.repeat && (e.key === "Enter" || e.code === "Space") ? e.preventDefault() : e.key === "Escape" && !x && b === "game" && (e.preventDefault(), Ft());
	}, Gt = (t) => {
		e.firstElementChild?.setAttribute("data-input-mode", t.type === "pointerdown" ? "pointer" : "keyboard"), b === "game" && !x && u.gesture();
	}, Kt = (e) => {
		(e.key === "sword-led.settings.v1" || e.key === null) && l.reload();
	}, qt = () => {
		Oe(!1), E++, J(), Mt();
	}, Jt = () => {
		Oe(!1), E++, j === "legacy-import" && (t.cancelLegacyImport(), H(!1), R("旧炉谱预览已收起，导入前请重新查看。")), J();
	};
	document.addEventListener("visibilitychange", zt), e.addEventListener("keydown", Vt), e.addEventListener("pointerdown", Gt, { capture: !0 }), e.addEventListener("keydown", Gt, { capture: !0 }), window.addEventListener("storage", Kt), window.addEventListener("blur", Jt), d.addEventListener("change", qt);
	let Xt = l.subscribe((e) => {
		let t = e.value.reducedMotion !== h.value.reducedMotion;
		h = e, t && (Oe(!1), E++), J(), Mt();
	}), Zt = t.subscribe((e) => {
		let n = e.generation !== p.generation || e.state?.runId !== p.state?.runId;
		p = e, n && (Oe(), M = null, E++, O = "", k = "", ee = "", A = "", x && H(), Te() || Ae()), m = t.getCollectionSnapshot(), J();
	}), $t = t.subscribeCollection((e) => {
		m = e, J();
	}), tn = u.subscribe(Ue);
	return J(), t.activate(), { async dispose() {
		g || (g = !0, Oe(), Zt(), $t(), Xt(), tn(), Ce.dispose(), he++, o.onload = null, o.onerror = null, ae?.dispose(), oe?.dispose(), se?.dispose(), ce?.dispose(), N?.dispose(), d.removeEventListener("change", qt), document.removeEventListener("visibilitychange", zt), window.removeEventListener("storage", Kt), window.removeEventListener("blur", Jt), e.removeEventListener("keydown", Vt), e.removeEventListener("pointerdown", Gt, { capture: !0 }), e.removeEventListener("keydown", Gt, { capture: !0 }), await Promise.allSettled([t.dispose(), u.dispose()]), e.firstElementChild === n && e.replaceChildren());
	} };
}
//#endregion
//#region tests/fixtures/v5/t03-lifecycle-entry.ts
var Sr = null;
window.t03Lifecycle = {
	mount() {
		if (Sr) throw Error("Dispose the previous real mount before mounting again");
		let e = document.querySelector("#app");
		if (!e) throw Error("Missing lifecycle root");
		Sr = xr(e, zt(window));
	},
	async dispose() {
		let e = Sr;
		Sr = null, e && await e.dispose();
	}
};
//#endregion
