# 两锻造按钮contextmenu监听生命周期：最小消费者草稿

未执行，仅修改隔离candidate；当前源/tests/config/dist/harness未改。只补既有`v5 twenty actual same-realm mounts dispose their listeners and pending presentation`一例，仍10逻辑、20轮；其余九例逐字不变。原每轮真实UI操作、合法strike观察、pending/WAAPI、800ms＋500ms及connected/global清单门均保留。

复用现有T03Runtime active注册清单：

- mount前保存contextmenu baseline。
- 每次mount/继续/设置往返后，应精确为baseline加`button#v4-hit`和`button#v4-strike`两项，type=contextmenu、capture=false、connected=true。重复注册或扩大到全局/其他节点会不相等。
- dispose后的样本筛出**全部**active contextmenu项，不过滤connected，必须回baseline；每轮artifact保留mounted与afterDispose清单。

探针本身强持有旧targets用于报告。此处只检验新监听器的显式移除契约，不由detached对象存在推断可回收性、堆增长或内存泄漏；原泛化生命周期判据仍只把global/media/audio或connected清单作为那项泄漏证据。没有新JSHandle、全局引用、observer或synthetic/native contextmenu派发。

此补丁不承担“阻止原生OS菜单”的证明；root已获得原完整case主线程采样线索，真实右键/原case复验由root另协调。baseline当前还没有这两个产品监听，故此是面向待合入target-only修补的消费者草稿，不能对当前冻结旧harness宣称通过。

只改`tests/release-v5/resilience.spec.ts`候选。现有harness entry和probe API足够，无须给生产入口加hook。产品修补激活、原consumer实际terminal以后，root须用实际新源重编harness并分别绑定entry/app/direct-input及harness JS/CSS身份，再做严格检查/既有case消费；旧harness通过不填新监听。

文件：originals/完整原件、candidate/完整候选、contextmenu-lifecycle.UNEXECUTED.patch、manifest.json（原/候选/patch逐项bytes/SHA）。原件SHA为`dc47a55c2148469e64c9b011c00ce7bfedf365046e03994b77eb9cbe4236d94d`。没有执行SDK、浏览器、构建、编译或新用例；不改预算或抹原红。root负责之后激活/运行。
