# Original V3 close: one guarded native sample

Reviewed control copied byte-for-byte to root-control.py before execution, SHA256 d9d84025168c95c8e56fe0cfe1034047778903b19bfdd1dfc558d25a604fdbaa. Python AST valid; no test/browser execution at preparation. Earlier c36 copy guard refused the changed draft and created/executed no copy.

Runs only the unchanged original v3-chromium left-down case, headed and original 180000ms budget. The first root Target.disposeBrowserContext request is observed via its real protocol ID. After 3 seconds pending, exact launch binary, unique temporary profile, live PID/start identity and ancestry to this consumer are verified twice. One normal /usr/bin/sample for 2 seconds is issued only while the same request remains pending. No page/input/clock/close API, kill, timeout change or rerun is added. Native consumer exit is passed through; skipped sampling remains skipped. Raw stdout, ps evidence, sample, actual observer result and original report/artifacts are preserved.

Outer root run-frozen/execute wrapper owns consumer terminal status and source/runtime begin/end identity. This is causal diagnosis, not a product repair or an automatic conversion of the original failed case.
