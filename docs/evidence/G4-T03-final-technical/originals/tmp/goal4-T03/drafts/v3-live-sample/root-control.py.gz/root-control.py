#!/usr/bin/env python3
"""UNEXECUTED single original V3 consumer + one guarded owned Chrome main-process sample."""
import argparse
import datetime
import json
import os
from pathlib import Path
import re
import selectors
import subprocess
import sys
import time

repo = Path(__file__).resolve().parents[4]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--report', required=True, type=Path)
parser.add_argument('--artifacts', required=True, type=Path)
parser.add_argument('--out', required=True, type=Path)
args = parser.parse_args()
def target(path):
    path = (repo / path).resolve()
    if not path.is_relative_to(repo / 'tmp'):
        parser.error('All outputs must be fresh paths beneath repository tmp.')
    return path
report, artifacts, out = map(target, (args.report, args.artifacts, args.out))
if any(path.exists() for path in (report, artifacts, out)) or len({report, artifacts, out}) != 3:
    parser.error('Report, artifacts and control output must be distinct fresh paths.')
out.mkdir(parents=True)
report.parent.mkdir(parents=True, exist_ok=True)
expected_executable = '/Users/gordon/Library/Caches/ms-playwright/chromium-1248/chrome-mac-x64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'
started = time.monotonic()
def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
def event(kind, **data):
    row = {'at':utc(), 'elapsedSeconds':time.monotonic()-started, 'type':kind, **data}
    with (out/'control-events.jsonl').open('a') as stream:
        stream.write(json.dumps(row, ensure_ascii=False)+'\n')
    print('LIVE_SAMPLE '+json.dumps(row, ensure_ascii=False), flush=True)
def save(name, value):
    (out/name).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')
command = ['rtk','proxy','env','DEBUG=pw:api,pw:protocol,pw:browser', 'V5_LEGACY_REPORT='+str(report),
           'npx','playwright','test','--config','playwright.v5-t03-legacy.config.ts',
           '--project=v3-chromium','--grep','left-down on the actual sword commits once','--headed','--output',str(artifacts)]
event('consumer.start', command=command, cwd=str(repo))
child = subprocess.Popen(command, cwd=repo, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, bufsize=0)
event('consumer.spawned', pid=child.pid)
assert child.stdout is not None
os.set_blocking(child.stdout.fileno(), False)
selector = selectors.DefaultSelector()
selector.register(child.stdout, selectors.EVENT_READ)
raw = (out/'consumer-stdout.raw').open('wb')
ansi = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
wire = re.compile(r'pw:protocol\s+(SEND\s*►|◀\s*RECV)\s*')
launching, launches, first, decision = [], [], None, None
buffer, eof = b'', False
ps_evidence = []
sample_process, sample_handles, sample_receipt = None, [], None

def line_received(line):
    global first
    clean = ansi.sub('', line.decode('utf-8', errors='replace')).rstrip('\r\n')
    if 'pw:browser <launching>' in clean:
        actual_command = clean.split('pw:browser <launching>',1)[1].strip()
        executable = actual_command.split(' --',1)[0]
        profiles = re.findall(r'(?:^|\s)--user-data-dir=(\S+)', actual_command)
        launching.append(dict(command=actual_command, executable=executable, profiles=profiles))
    match = re.search(r'pw:browser <launched> pid=(\d+)', clean)
    if match:
        launch = dict(pid=int(match.group(1)), launch=launching[-1] if launching else None)
        launches.append(launch)
        event('chrome.launch-observed', **launch)
    match = wire.search(clean)
    if not match:
        return
    try:
        message, _ = json.JSONDecoder().raw_decode(clean[match.end():])
    except ValueError:
        return  # The exact original bytes remain in consumer-stdout.raw, including any truncated debug row.
    if not isinstance(message, dict):
        return
    sent = match.group(1).startswith('SEND')
    if sent and first is None and message.get('method') == 'Target.disposeBrowserContext':
        first = dict(id=message.get('id'), sessionId=message.get('sessionId',''), contextId=message.get('params',{}).get('browserContextId'), seenAt=time.monotonic(), replied=False)
        event('dispose.first-send', request={key:value for key,value in first.items() if key != 'seenAt'})
    elif not sent and first is not None and message.get('id') == first['id'] and message.get('sessionId','') == first['sessionId']:
        first['replied'] = True
        event('dispose.same-request-reply', id=first['id'], sessionId=first['sessionId'], error=message.get('error'), afterSendSeconds=time.monotonic()-first['seenAt'])

def drain():
    global buffer, eof
    while not eof:
        try:
            data = os.read(child.stdout.fileno(), 65536)
        except BlockingIOError:
            return
        if not data:
            eof = True
            selector.unregister(child.stdout)
            if buffer:
                line_received(buffer)
                buffer = b''
            return
        raw.write(data)
        raw.flush()
        sys.stdout.buffer.write(data)
        sys.stdout.buffer.flush()
        buffer += data
        while b'\n' in buffer:
            line, buffer = buffer.split(b'\n', 1)
            line_received(line)

def ps_row(pid):
    command = ['rtk','proxy','env','LC_ALL=C','/bin/ps','-ww','-p',str(pid),'-o','pid=','-o','ppid=','-o','stat=','-o','lstart=','-o','comm=']
    result = subprocess.run(command, cwd=repo, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    ps_evidence.append(dict(at=utc(),command=command,actualExitCode=result.returncode,stdout=result.stdout.decode(errors='replace'),stderr=result.stderr.decode(errors='replace')))
    text = result.stdout.decode('utf-8', errors='replace')
    pieces = text.strip().split(None,8)
    if result.returncode or len(pieces) != 9:
        raise RuntimeError('ps identity unavailable: '+repr(dict(command=command,exit=result.returncode,stdout=text,stderr=result.stderr.decode(errors='replace'))))
    row = dict(pid=int(pieces[0]), ppid=int(pieces[1]), state=pieces[2], lstart=' '.join(pieces[3:8]), executable=pieces[8], raw=text)
    if row['pid'] != pid or 'Z' in row['state']:
        raise RuntimeError('ps identity is not a live expected PID: '+repr(row))
    return row

def ps_args(pid):
    command = ['rtk','proxy','/bin/ps','-ww','-p',str(pid),'-o','args=']
    result = subprocess.run(command, cwd=repo, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    ps_evidence.append(dict(at=utc(),command=command,actualExitCode=result.returncode,stdout=result.stdout.decode(errors='replace'),stderr=result.stderr.decode(errors='replace')))
    if result.returncode:
        raise RuntimeError('ps argv unavailable: '+result.stderr.decode(errors='replace'))
    return result.stdout.decode('utf-8', errors='replace').strip()

def ownership_guard():
    if len(launches) != 1:
        raise RuntimeError('Expected exactly one same-run Chrome main launch, observed '+str(len(launches)))
    launch = launches[0]
    if not launch['launch'] or launch['launch']['executable'] != expected_executable or len(launch['launch']['profiles']) != 1:
        raise RuntimeError('Launch executable/profile is not the single expected owned Chrome')
    pid, profile = launch['pid'], launch['launch']['profiles'][0]
    if pid in (os.getpid(), child.pid) or not Path(profile).name.startswith('playwright_chromiumdev_profile-') or not Path(profile).is_dir():
        raise RuntimeError('Expected a distinct owned Chrome PID and Playwright temporary profile')
    chain, current, visited = [], pid, set()
    while current not in visited and len(chain) < 32:
        visited.add(current)
        row = ps_row(current)
        chain.append(row)
        if current == child.pid:
            break
        if row['ppid'] <= 1:
            raise RuntimeError('Chrome ancestry does not reach this consumer subprocess')
        current = row['ppid']
    if not chain or chain[-1]['pid'] != child.pid:
        raise RuntimeError('Could not prove same-run process ancestry')
    initial = chain[0]
    if initial['executable'] != expected_executable:
        raise RuntimeError('ps exact executable mismatch')
    argv = ps_args(pid)
    if not argv.startswith(expected_executable+' ') or re.findall(r'(?:^|\s)--user-data-dir=(\S+)',argv) != [profile] or re.search(r'(?:^|\s)--type=',argv):
        raise RuntimeError('ps executable/profile/main-process argv mismatch')
    # Recheck the target immediately before the final live/reply guard; never follow a reused/reparented PID.
    final, final_argv = ps_row(pid), ps_args(pid)
    if any(final[key] != initial[key] for key in ('pid','ppid','lstart','executable')) or final_argv != argv:
        raise RuntimeError('Chrome identity changed during guard')
    return dict(pid=pid, profile=profile, ancestry=chain, finalIdentity=final, argv=argv)

def skip(reason, **data):
    global decision
    decision = dict(status='skipped', reason=reason, at=utc(), **data)
    save('sampling-decision.json', decision)
    event('sampling.skipped', **decision)

def maybe_sample():
    global decision, sample_process, sample_handles, sample_receipt
    if decision is not None or first is None:
        return
    if first['replied']:
        skip('first-dispose-already-replied')
        return
    if child.poll() is not None:
        skip('consumer-already-terminal')
        return
    if time.monotonic()-first['seenAt'] < 3:
        return
    # One decision/attempt only. A failed ownership check never triggers a different target or retry.
    decision = dict(status='guarding', at=utc())
    try:
        if type(first['id']) is not int or first['sessionId'] != '' or not isinstance(first['contextId'], str):
            raise RuntimeError('First dispose is not an identified root Chromium context request')
        try:
            guard = ownership_guard()
        finally:
            save('ps-guard.json',ps_evidence)
        drain()
        if child.poll() is not None or first['replied']:
            skip('reply-or-terminal-during-ownership-guard', guard=guard)
            return
        if len(launches) != 1:
            skip('ambiguous-launch-during-guard', guard=guard)
            return
        command = ['rtk','proxy','/usr/bin/sample',str(guard['pid']),'2','-file',str(out/'sample.raw.txt')]
        stdout, stderr = (out/'sample.stdout.raw').open('wb'), (out/'sample.stderr.raw').open('wb')
        sample_handles = [stdout, stderr]
        sample_receipt = dict(status='starting', command=command, target=guard, request={key:value for key,value in first.items() if key != 'seenAt'}, startedAt=utc(), startedElapsedSeconds=time.monotonic()-started, consumerLiveAtStart=True, actualExitCode=None)
        sample_process = subprocess.Popen(command, cwd=repo, stdout=stdout, stderr=stderr)
        sample_receipt.update(status='running', samplePid=sample_process.pid)
        decision = dict(status='sample-invoked', at=utc(), targetPid=guard['pid'])
        save('sample.receipt.json',sample_receipt)
        save('sampling-decision.json',decision)
        event('sample.invoked', targetPid=guard['pid'], samplePid=sample_process.pid, command=command)
    except Exception as error:
        for handle in sample_handles:
            handle.close()
        if sample_receipt is not None:
            sample_receipt.update(status='launch-failed', error=repr(error), completedAt=utc())
            save('sample.receipt.json', sample_receipt)
        skip('ownership-or-sample-launch-failed', error=repr(error))

def collect_sample():
    if sample_process is not None and sample_receipt['status'] == 'running' and sample_process.poll() is not None:
        for handle in sample_handles:
            handle.close()
        sample_receipt.update(status='terminal',actualExitCode=sample_process.returncode,completedAt=utc(),completedElapsedSeconds=time.monotonic()-started,consumerLiveAtCompletion=child.poll() is None,disposeRepliedAtCompletion=bool(first and first['replied']))
        save('sample.receipt.json',sample_receipt)
        event('sample.completed', actualExitCode=sample_process.returncode, disposeRepliedAtCompletion=sample_receipt['disposeRepliedAtCompletion'])

while child.poll() is None or not eof:
    selector.select(timeout=.05)
    drain()
    maybe_sample()
    collect_sample()
returncode = child.wait()
drain()
if decision is None:
    skip('no-dispose-observed' if first is None else 'consumer-terminal-before-eligible-live-window')
if sample_process is not None and sample_process.poll() is None:
    sample_process.wait()  # Wait only for the one normal observer command; never signal the native consumer/browser.
collect_sample()
raw.close()
selector.close()
event('consumer.returned', nativeReturnCode=returncode, note='Original report/artifacts and timeout semantics unchanged; no rerun, key/page call, context-close call or kill added.')
sys.exit(returncode if returncode >= 0 else 128-returncode)
