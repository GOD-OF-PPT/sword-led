# 静态右键菜单与context.close：两条件A/B（未执行）

仅新建隔离草稿；原四叶和两叶真实加载草稿均保留停写。没有运行脚本/语法编译、浏览器、SDK或构建，没有改共享文件。root负责执行包装、真实exit、协议日志和指纹。

固定两条件，无Clock、Audio、游戏、存档或WebLocks：

1. `defaultMenuAllowed`：同一静态`#start`按钮先真实left click准备，再真实right click；目标contextmenu只观察，不prevent。
2. `preventOnStart`：完全相同的left/right；唯一差异是在`#start`自己的contextmenu监听中调用preventDefault。

每叶新建同原chromium-1248/156.0.8078.4的自有headed browser/context，串行运行；小型自有loopback静态页复用四叶基础。两边均同步记录contextmenu的isTrusted、button、cancelable、defaultPreventedBefore和defaultPrevented；期望真实right为trusted/button2且原先未prevent，处理后分别false/true。来源事件经预装Node console observer进入Node Promise；没有evaluate制造或派发事件。

最后一次页面快照发生在右击前。右击后**不再evaluate、聚焦、截图、发Escape/其他键、额外左击或通过其他输入关菜单**；只读取已到达Node的事件证据，然后执行原关闭观察。defaultPrevented=false仅说明默认菜单未被页面拦截，不把它虚称为OS菜单已经被截图确认。右动作或事件未完成分别记setup-incomplete，不能声称是有效关闭对照。

context.close仍只调用一次，立即保留原Promise并双分支记录；Node真时钟锚定5000ms观察pending，不reject/取消原Promise。随后只正常关闭该叶唯一自有browser，记录context是否在browser.close开始后才首次settle；该时间先后不自动证明OS菜单根因。browser.close拒绝会落盘当前叶/partial再stop；一直pending则保留正常等待和marker，不kill/二次close或进入下一叶。

用法由root统一冻结/包装（未执行，数据目录必须全新）：

```sh
rtk proxy env DEBUG=pw:api,pw:protocol,pw:browser node tmp/goal4-T03/drafts/v3-contextmenu-close/run-contextmenu-close.mjs --out tmp/goal4-T03/contextmenu-close-01-data
```

只输出事件/逐叶/partial/result诊断JSON；root保留真实launch/PID/协议和实际进程回执。requestedExitCode0表示两叶准备成功且context在观察窗内settle；1表示至少一叶在5000ms观察点仍pending；2表示准备/清理/runner错误。5000ms仅此小诊断的观察窗口，原游戏180000ms及任何性能门不改。

若单因素差异重现，它提供右键默认行为与Chrome销毁阻塞的直接对照线索，仍需root按实证决定产品改动。若未重现，也不能写原完整V3 inputcase已修。没有扩大矩阵、开关音频/Clock、用Escape关菜单求绿或新增业务责任。SHA256SUMS绑定脚本和说明。
