// UNEXECUTED two-condition static contextmenu/Chrome close diagnostic. No Clock, native audio, game or domain SDK.
import assert from 'node:assert/strict';
import {appendFileSync,existsSync,mkdirSync,writeFileSync} from 'node:fs';
import {createServer} from 'node:http';
import {dirname,resolve,relative} from 'node:path';
import {fileURLToPath} from 'node:url';
import {parseArgs} from 'node:util';
import {chromium,devices} from '@playwright/test';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'../../../..');
const {values}=parseArgs({options:{out:{type:'string'},'expected-executable':{type:'string'},'expected-version':{type:'string',default:'156.0.8078.4'}},strict:true});
assert(values.out,'Required --out fresh directory beneath repository tmp');
const out=resolve(root,values.out),withinTmp=relative(resolve(root,'tmp'),out);
assert(withinTmp&&!withinTmp.startsWith('..')&&!withinTmp.startsWith('/'),'Output must remain beneath repository tmp');
assert(!existsSync(out),'Refusing to overwrite an existing output directory');
const expectedExecutable=values['expected-executable']??'/Users/gordon/Library/Caches/ms-playwright/chromium-1248/chrome-mac-x64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing';
const executable=chromium.executablePath();assert.equal(executable,expectedExecutable,'Use the exact Chromium executable from protocol01');
assert((process.env.DEBUG??'').includes('pw:browser')&&(process.env.DEBUG??'').includes('pw:protocol'),'Set DEBUG=pw:api,pw:protocol,pw:browser to preserve actual launch/close evidence');
const conditions=[{name:'defaultMenuAllowed',prevent:false},{name:'preventOnStart',prevent:true}];
const observationMs=5000,start=process.hrtime.bigint(),events=[],results=[];
mkdirSync(out,{recursive:true});
const now=()=>Number(process.hrtime.bigint()-start)/1e6;
const errorText=error=>({name:error?.name??typeof error,message:error?.message??String(error),stack:error?.stack??null});
function record(condition,type,data={}){const row={sequence:events.length,wallAt:new Date().toISOString(),nodeMs:now(),condition,type,...data};events.push(row);appendFileSync(resolve(out,'events.jsonl'),JSON.stringify(row)+'\n');process.stdout.write('CLOSE_MIN '+JSON.stringify(row)+'\n');return row;}
function save(name,value){writeFileSync(resolve(out,name),JSON.stringify(value,null,2)+'\n');}
function track(condition,name,invoke){
 const state={name,status:'pending',startedAt:now(),settledAt:null,error:null};record(condition,name+'.start');
 let original;try{original=invoke();}catch(error){original=Promise.reject(error);}
 const settled=Promise.resolve(original).then(value=>{state.status='resolved';state.settledAt=now();record(condition,name+'.resolved',{startedAt:state.startedAt,settledAt:state.settledAt});return{state,value};},error=>{state.status='rejected';state.settledAt=now();state.error=errorText(error);record(condition,name+'.rejected',{startedAt:state.startedAt,settledAt:state.settledAt,error:state.error});return{state,value:null};});
 return{original,settled,state};
}
async function observe(condition,operation,label){
 let timer;const remainingMs=Math.max(0,observationMs-(now()-operation.state.startedAt)),timed=new Promise(resolveTimer=>{timer=setTimeout(()=>resolveTimer({settled:false,at:now()}),remainingMs);});
 const result=await Promise.race([operation.settled.then(()=>({settled:true,at:now()})),timed]);clearTimeout(timer);
 const observation={targetObservationMs:observationMs,observedAt:result.at,elapsedMs:result.at-operation.state.startedAt,settled:result.settled,status:operation.state.status};record(condition,label,observation);return observation;
}
async function requireSetup(condition,operation){const observed=await observe(condition,operation,operation.state.name+'.setup-observation');assert(observed.settled&&operation.state.status==='resolved',operation.state.name+' did not settle successfully: setup-incomplete');return operation.settled;}
const html=String.raw`<!doctype html><meta charset="utf-8"><title>Owned contextmenu close diagnostic</title><style>body{font:16px sans-serif;margin:32px}button{min-width:240px;min-height:48px}</style><button id="start">Prepare fixed condition</button><p id="status">Waiting for one trusted left click</p><script>
(()=>{
 const prevent=new URL(location.href).searchParams.get('prevent')==='1',button=document.querySelector('#start');
 const probe={prevent,left:null,ready:null,menus:[]};window.contextMenuCloseProbe=probe;
 probe.snapshot=()=>({prevent,left:probe.left,menus:probe.menus.map(row=>({...row})),visibilityState:document.visibilityState,hidden:document.hidden,hasFocus:document.hasFocus(),pageNow:performance.now(),pageDate:Date.now()});
 button.addEventListener('click',event=>{probe.left={trusted:event.isTrusted,button:event.button,activation:{isActive:navigator.userActivation.isActive,hasBeenActive:navigator.userActivation.hasBeenActive}};probe.ready=event.isTrusted&&event.button===0?Promise.resolve({prepared:true,...probe.left}):Promise.reject(new Error('Expected one trusted left preparation'));document.querySelector('#status').textContent='Left preparation complete';},{once:true});
 button.addEventListener('contextmenu',event=>{
  const defaultPreventedBefore=event.defaultPrevented;if(prevent)event.preventDefault();
  const row={type:'contextmenu',trusted:event.isTrusted,button:event.button,cancelable:event.cancelable,defaultPreventedBefore,defaultPrevented:event.defaultPrevented,preventRequested:prevent,pageNow:performance.now(),pageDate:Date.now()};probe.menus.push(row);console.debug('CONTEXTMENU_CLOSE '+JSON.stringify(row));
 });
})();
</script>`;
record(null,'run.start',{pid:process.pid,command:process.argv,debug:process.env.DEBUG,conditions,observationMs,executable,expectedVersion:values['expected-version'],headless:false});
const server=createServer((request,response)=>{if(request.url==='/favicon.ico'){response.writeHead(204);response.end();return;}response.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});response.end(html);});
await new Promise((resolveListen,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolveListen);});
const address=server.address();assert(address&&typeof address==='object');const baseURL='http://127.0.0.1:'+address.port;
let exitCode=0;
try{
 for(const condition of conditions){
  const name=condition.name;let browser=null,context=null,page=null,close=null,ready=null,right=null,menu=null,resolveMenu=null,setupError=null,lastPageSnapshotBeforeRight=null,contextMenuEvent=null,preClose=null,closeObservation=null,browserClose=null;const menuEvents=[];
  record(name,'condition.start',{preventDefaultOnStart:condition.prevent,baseURL,headless:false,executable});
  try{
   browser=await chromium.launch({headless:false});const browserVersion=browser.version();record(name,'browser.launched',{browserVersion,executable,ownership:'New chromium.launch result for this condition only; no connect/reuse or foreign process.'});assert.equal(browserVersion,values['expected-version']);
   browser.on('disconnected',()=>record(name,'browser.disconnected'));
   context=await browser.newContext({...devices['Desktop Chrome'],viewport:{width:1280,height:720},deviceScaleFactor:1});context.on('close',()=>record(name,'context.close-event'));
   page=await context.newPage();page.on('close',()=>record(name,'page.close-event'));page.on('crash',()=>record(name,'page.crash'));
   page.on('pageerror',error=>record(name,'page.error',{error:errorText(error)}));
   page.on('console',message=>{const text=message.text();if(text.startsWith('CONTEXTMENU_CLOSE ')){const value=JSON.parse(text.slice('CONTEXTMENU_CLOSE '.length));menuEvents.push(value);record(name,'contextmenu.event',{value});if(resolveMenu)resolveMenu(value);}});
   await page.goto(baseURL+'/?prevent='+(condition.prevent?'1':'0'));await page.bringToFront();await page.locator('#start').click();
   ready=track(name,'left.ready',()=>page.evaluate(()=>{const ready=window.contextMenuCloseProbe.ready;if(!ready)throw new Error('Left preparation Promise missing');return ready;}));await requireSetup(name,ready);assert.equal((await ready.settled).value.trusted,true);assert.equal((await ready.settled).value.button,0);
   lastPageSnapshotBeforeRight=await page.evaluate(()=>window.contextMenuCloseProbe.snapshot());record(name,'before-right-click',{lastPageSnapshotBeforeRight});
   menu=track(name,'contextmenu.observed',()=>new Promise(resolveEvent=>{resolveMenu=resolveEvent;}));
   right=track(name,'right-click',()=>page.locator('#start').click({button:'right'}));await requireSetup(name,right);await requireSetup(name,menu);contextMenuEvent=(await menu.settled).value;
   assert.equal(contextMenuEvent.trusted,true);assert.equal(contextMenuEvent.button,2);assert.equal(contextMenuEvent.cancelable,true);assert.equal(contextMenuEvent.defaultPreventedBefore,false);assert.equal(contextMenuEvent.defaultPrevented,condition.prevent);
   // Deliberately issue no page evaluation, focus, key, extra left click, screenshot or cleanup input after the right click.
   preClose={lastPageSnapshotBeforeRight,contextMenuEvent,scope:'Contextmenu evidence arrives through the preinstalled Node console observer; no page command after right-click besides context/browser close.'};
   record(name,'pre-context-close',{preClose});
  }catch(error){setupError=errorText(error);exitCode=2;record(name,'setup-incomplete',{error:setupError});}
  finally{
   if(context){close=track(name,'context.close',()=>context.close());closeObservation=await observe(name,close,'context.close-observation');if(!closeObservation.settled&&exitCode===0)exitCode=1;if(close.state.status==='rejected')exitCode=2;}
   if(browser){
    const contextPending=close?.state.status==='pending';record(name,'before-owned-browser-close',{contextPending,contextStatus:close?.state.status??'not-created'});
    browserClose=track(name,'browser.close',()=>browser.close());
    const marker=setTimeout(()=>record(name,'browser.close-still-pending-at5000',{status:browserClose.state.status,note:'Only normal owned browser.close is retained; no kill, second close or next condition while cleanup remains pending.'}),observationMs);
    try{await browserClose.settled;}finally{clearTimeout(marker);}
    if(browserClose.state.status!=='resolved'){
     exitCode=2;const failedCleanup={condition,setupComplete:setupError===null,setupError,preClose,menuEvents,right:right?.state??null,menu:menu?.state??null,contextClose:close?.state??null,contextCloseObservation:closeObservation,browserClose:browserClose.state,ready:ready?.state??null,cleanupComplete:false};results.push(failedCleanup);save(name.replace('+','-')+'.json',failedCleanup);save('partial-results.json',{scope:'Stopped after owned browser cleanup rejected; never launch the next condition with an unconfirmed process.',conditionsRecorded:results.length,results});throw new Error('Owned browser.close rejected; stop before another browser condition');
    }
    const afterBrowser=close?await observe(name,close,'context.close-after-browser-cleanup-observation'):null;
    const temporal={pendingWhenBrowserCloseBegan:contextPending,contextSettledAt:close?.state.settledAt??null,browserCloseBeganAt:browserClose.state.startedAt,contextFirstObservedSettledAfterBrowserCloseBegan:!!(contextPending&&close?.state.settledAt!==null&&close?.state.settledAt>=browserClose.state.startedAt),afterBrowser,note:'Observed temporal order only; a single two-condition contextmenu diagnostic does not prove device or general causal root.'};record(name,'cleanup-order',temporal);
    if(close?.state.status==='pending')throw new Error('Owned browser closed but retained context.close is still pending; stop before another browser condition');
   }
  }
  const result={condition,setupComplete:setupError===null,setupError,preClose,menuEvents,right:right?.state??null,menu:menu?.state??null,contextClose:close?.state??null,contextCloseObservation:closeObservation,browserClose:browserClose?.state??null,ready:ready?.state??null};results.push(result);save(name.replace('+','-')+'.json',result);save('partial-results.json',{scope:'Static contextmenu A/B only; original game/input outcomes unchanged',completedConditions:results.length,results});record(name,'condition.complete',{setupComplete:result.setupComplete});
 }
}catch(error){exitCode=2;record(null,'runner-error',{error:errorText(error)});}
finally{
 await new Promise((resolveClose,reject)=>server.close(error=>error?reject(error):resolveClose()));
 const summary={scope:'Exactly two static right-click conditions; only target contextmenu preventDefault differs. No Clock/audio/game/domain SDK or original-game fix claim',conditionsRequested:conditions,conditionsRecorded:results.length,conditionsCompleted:results.filter(row=>row.cleanupComplete!==false&&row.browserClose?.status==='resolved').length,conditionsWithValidSetup:results.filter(row=>row.setupComplete).length,results,contextObservationMs:observationMs,contextDeadlineScope:'Node pending observation only, not original game/performance budget',events:events.length,requestedExitCode:exitCode};save('result.json',summary);record(null,'run.body-complete',{requestedExitCode:exitCode,note:'Root execution wrapper owns actual process terminal/exit and source fingerprints.'});process.exitCode=exitCode;
}
