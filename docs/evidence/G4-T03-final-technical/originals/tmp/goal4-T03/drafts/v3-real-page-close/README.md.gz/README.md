# 真实V3页加载＋关闭：两叶诊断（未执行）

独立草稿，仅`noClock`和`Clock`两个固定条件。每叶新建自有headed Chromium/context，版本156.0.8078.4及原chromium-1248 executable保持；不复用用户浏览器。root另起并绑定build22不可变静态预览，脚本只接收明确`--url http://127.0.0.1:4247/v3.html?mode=3`，不构建、不起server、不使用假HTML。URL与`#v3-hit`证明实际V3入口可用；预览快照的发布/字节身份由root外部回执承担。

复用四叶脚本的关闭记录，小幅收窄：

- noClock：真实goto、前置自有窗口、等待`#v3-hit`可见且enabled、记录实际原文，然后关闭。
- Clock：先install自动运行，再做相同真实加载/可见enabled/原文准备；最后pauseAt(Node Date.now()+1000)、runFor350，并保持paused到关闭。暂停后只同步读取页面，不作RAF ready轮询，不恢复Clock。

两叶均无pointer/键盘/锤击或偏好操作，不调用领域port，不注入状态或原生音频API。页面源码自己的正常自动开局原样运行；读取main `sword-led.save.v3`、backup `sword-led.save.backup.v3`、settings `sword-led.settings.v1`三个槽，保存原始字符串及轻量envelope identity。JSON.parse仅用于观察身份，没有加载SDK/正式回放或声称存档已正式验证。就绪与关闭前的raw是否逐字一致会记录，但脚本不重写原文。

context.close仍只调用一次，立即保留原Promise并记录resolve/reject；Node真时钟从调用起5000ms观察pending，非原游戏180000ms/性能门。pending时使用唯一自有browser.close正常清理，记录context是否只在browser.close开始后才响应。browser.close拒绝先保存当前叶/partial再stop，不启动下一browser；一直pending则保留正常等待和marker，不kill/重复close。准备未完成明确setup-incomplete，不能当有效关闭结果。

用法供root统一冻结/包装执行（**本轮未运行或语法编译**；目录必须新建）：

```sh
rtk proxy env DEBUG=pw:api,pw:protocol,pw:browser node tmp/goal4-T03/drafts/v3-real-page-close/run-real-v3-close.mjs --url 'http://127.0.0.1:4247/v3.html?mode=3' --out tmp/goal4-T03/real-v3-close-01-data
```

只输出events.jsonl、两叶loaded/结果JSON、partial-results.json和result.json；root保留实际launch/协议日志、指纹与实际进程回执。requestedExitCode0仅表示两叶准备有效且关闭在观察窗内settle；1表示观察点至少一叶仍pending；2表示准备/清理/runner错误。窗口实际elapsed原样记录，所有结果都不能充当原完整inputcase修复或T03完成。

没有加第三叶、WebLocks控制、nativeAudio测试、额外等待、全矩阵或新框架。真实页本身包含的资源/保存权正常运行，不以测试替身删除它们。原四叶脚本及所有首红保持原件。SHA256SUMS绑定本草稿脚本/说明。
