// UNEXECUTED two-condition real V3 load/close diagnostic. No hammer input, preference changes or domain/native API injection.
import assert from 'node:assert/strict';
import {appendFileSync,existsSync,mkdirSync,writeFileSync} from 'node:fs';
import {dirname,resolve,relative} from 'node:path';
import {fileURLToPath} from 'node:url';
import {parseArgs} from 'node:util';
import {chromium,devices,expect} from '@playwright/test';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'../../../..');
const {values}=parseArgs({options:{out:{type:'string'},url:{type:'string'},'expected-executable':{type:'string'},'expected-version':{type:'string',default:'156.0.8078.4'}},strict:true});
assert(values.out,'Required --out fresh directory beneath repository tmp');
assert(values.url,'Required --url for root-owned immutable V3 preview');
const targetURL=new URL(values.url);
assert(targetURL.protocol==='http:'&&targetURL.hostname==='127.0.0.1'&&targetURL.port==='4247'&&targetURL.pathname==='/v3.html'&&targetURL.searchParams.toString()==='mode=3'&&!targetURL.username&&!targetURL.password&&!targetURL.hash,'Use the explicit root-owned http://127.0.0.1:4247/v3.html?mode=3 URL');
const out=resolve(root,values.out),withinTmp=relative(resolve(root,'tmp'),out);
assert(withinTmp&&!withinTmp.startsWith('..')&&!withinTmp.startsWith('/'),'Output must remain beneath repository tmp');
assert(!existsSync(out),'Refusing to overwrite an existing output directory');
const expectedExecutable=values['expected-executable']??'/Users/gordon/Library/Caches/ms-playwright/chromium-1248/chrome-mac-x64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing';
const executable=chromium.executablePath();assert.equal(executable,expectedExecutable,'Use the exact Chromium executable from protocol01');
assert((process.env.DEBUG??'').includes('pw:browser')&&(process.env.DEBUG??'').includes('pw:protocol'),'Set DEBUG=pw:api,pw:protocol,pw:browser to preserve actual launch/close evidence');
const conditions=[{name:'noClock',clock:false},{name:'Clock',clock:true}];
const observationMs=5000,start=process.hrtime.bigint(),events=[],results=[];
mkdirSync(out,{recursive:true});
const now=()=>Number(process.hrtime.bigint()-start)/1e6;
const errorText=error=>({name:error?.name??typeof error,message:error?.message??String(error),stack:error?.stack??null});
function record(condition,type,data={}){const row={sequence:events.length,wallAt:new Date().toISOString(),nodeMs:now(),condition,type,...data};events.push(row);appendFileSync(resolve(out,'events.jsonl'),JSON.stringify(row)+'\n');process.stdout.write('CLOSE_MIN '+JSON.stringify(row)+'\n');return row;}
function save(name,value){writeFileSync(resolve(out,name),JSON.stringify(value,null,2)+'\n');}
function track(condition,name,invoke){
 const state={name,status:'pending',startedAt:now(),settledAt:null,error:null};record(condition,name+'.start');
 let original;try{original=invoke();}catch(error){original=Promise.reject(error);}
 const settled=Promise.resolve(original).then(value=>{state.status='resolved';state.settledAt=now();record(condition,name+'.resolved',{startedAt:state.startedAt,settledAt:state.settledAt});return{state,value};},error=>{state.status='rejected';state.settledAt=now();state.error=errorText(error);record(condition,name+'.rejected',{startedAt:state.startedAt,settledAt:state.settledAt,error:state.error});return{state,value:null};});
 return{original,settled,state};
}
async function observe(condition,operation,label){
 let timer;const remainingMs=Math.max(0,observationMs-(now()-operation.state.startedAt)),timed=new Promise(resolveTimer=>{timer=setTimeout(()=>resolveTimer({settled:false,at:now()}),remainingMs);});
 const result=await Promise.race([operation.settled.then(()=>({settled:true,at:now()})),timed]);clearTimeout(timer);
 const observation={targetObservationMs:observationMs,observedAt:result.at,elapsedMs:result.at-operation.state.startedAt,settled:result.settled,status:operation.state.status};record(condition,label,observation);return observation;
}
async function requireSetup(condition,operation){const observed=await observe(condition,operation,operation.state.name+'.setup-observation');assert(observed.settled&&operation.state.status==='resolved',operation.state.name+' did not settle successfully: setup-incomplete');return operation.settled;}
async function readRealPage(page){return page.evaluate(()=>{
 const hit=document.querySelector('#v3-hit'),strike=document.querySelector('#v3-strike');
 const raw={main:localStorage.getItem('sword-led.save.v3'),backup:localStorage.getItem('sword-led.save.backup.v3'),settings:localStorage.getItem('sword-led.settings.v1')};
 let saveIdentity=null,parseError=null;try{if(raw.main){const envelope=JSON.parse(raw.main);saveIdentity={schemaVersion:envelope.schemaVersion,rulesVersion:envelope.rulesVersion,runId:envelope.state?.runId,revision:envelope.state?.revision,phase:envelope.state?.phase};}}catch(error){parseError=String(error);}
 return{url:location.href,readyState:document.readyState,pageNow:performance.now(),pageDate:Date.now(),visibilityState:document.visibilityState,hidden:document.hidden,hasFocus:document.hasFocus(),ua:navigator.userAgent,dpr:devicePixelRatio,width:innerWidth,height:innerHeight,hit:{connected:!!hit?.isConnected,enabled:hit instanceof HTMLButtonElement&&!hit.disabled,visible:!!hit&&hit.getClientRects().length>0},strikeBusy:strike?.getAttribute('aria-busy')??null,raw,saveIdentity,parseError};
});}
record(null,'run.start',{pid:process.pid,command:process.argv,debug:process.env.DEBUG,conditions,observationMs,url:targetURL.href,executable,expectedVersion:values['expected-version'],headless:false});
let exitCode=0;
try{
 for(const condition of conditions){
  const name=condition.name;let browser=null,context=null,page=null,close=null,ready=null,setupError=null,loaded=null,preClose=null,closeObservation=null,browserClose=null;
  record(name,'condition.start',{clock:condition.clock,url:targetURL.href,headless:false,executable});
  try{
   browser=await chromium.launch({headless:false});const browserVersion=browser.version();record(name,'browser.launched',{browserVersion,executable,ownership:'New chromium.launch result for this condition only; no connect/reuse or foreign process.'});assert.equal(browserVersion,values['expected-version']);
   browser.on('disconnected',()=>record(name,'browser.disconnected'));
   context=await browser.newContext({...devices['Desktop Chrome'],viewport:{width:1280,height:720},deviceScaleFactor:1});context.on('close',()=>record(name,'context.close-event'));
   page=await context.newPage();page.on('close',()=>record(name,'page.close-event'));page.on('crash',()=>record(name,'page.crash'));
   page.on('pageerror',error=>record(name,'page.error',{error:errorText(error)}));
   if(condition.clock){const install=track(name,'clock.install',()=>page.clock.install());await requireSetup(name,install);}
   ready=track(name,'page.load-and-ready',async()=>{await page.goto(targetURL.href);await page.bringToFront();await page.locator('#v3-hit').waitFor({state:'visible'});await expect(page.locator('#v3-hit')).toBeEnabled();return readRealPage(page);});
   await requireSetup(name,ready);loaded=(await ready.settled).value;assert.equal(loaded.url,targetURL.href);assert.equal(loaded.hit.enabled,true);assert.equal(loaded.hit.visible,true);assert.equal(typeof loaded.raw.main,'string');assert(loaded.raw.main.length>0,'Actual V3 primary raw is required');
   save(name+'-loaded.json',loaded);record(name,'real-page-ready',{loaded});
   if(condition.clock){
    const before=await readRealPage(page),target=new Date(Date.now()+1000);const pause=track(name,'clock.pauseAt',()=>page.clock.pauseAt(target));await requireSetup(name,pause);record(name,'clock.pauseAt-values',{target:target.toISOString(),before,after:await readRealPage(page)});
    const run=track(name,'clock.runFor350',()=>page.clock.runFor(350));await requireSetup(name,run);record(name,'clock.runFor350-values',{after:await readRealPage(page),remainsPaused:true,clockResumeCalled:false});
   }
   preClose=await readRealPage(page);assert.equal(preClose.hit.enabled,true);assert.equal(preClose.url,targetURL.href);assert.equal(typeof preClose.raw.main,'string');record(name,'raw-comparison',{rawUnchangedFromReady:JSON.stringify(loaded.raw)===JSON.stringify(preClose.raw),scope:'Raw byte observation only; no SDK validation or save rewrite.'});
   record(name,'pre-context-close',{preClose});
  }catch(error){setupError=errorText(error);exitCode=2;record(name,'setup-incomplete',{error:setupError});}
  finally{
   if(context){close=track(name,'context.close',()=>context.close());closeObservation=await observe(name,close,'context.close-observation');if(!closeObservation.settled&&exitCode===0)exitCode=1;if(close.state.status==='rejected')exitCode=2;}
   if(browser){
    const contextPending=close?.state.status==='pending';record(name,'before-owned-browser-close',{contextPending,contextStatus:close?.state.status??'not-created'});
    browserClose=track(name,'browser.close',()=>browser.close());
    const marker=setTimeout(()=>record(name,'browser.close-still-pending-at5000',{status:browserClose.state.status,note:'Only normal owned browser.close is retained; no kill, second close or next condition while cleanup remains pending.'}),observationMs);
    try{await browserClose.settled;}finally{clearTimeout(marker);}
    if(browserClose.state.status!=='resolved'){
     exitCode=2;const failedCleanup={condition,setupComplete:setupError===null,setupError,loaded,preClose,contextClose:close?.state??null,contextCloseObservation:closeObservation,browserClose:browserClose.state,ready:ready?.state??null,cleanupComplete:false};results.push(failedCleanup);save(name.replace('+','-')+'.json',failedCleanup);save('partial-results.json',{scope:'Stopped after owned browser cleanup rejected; never launch the next condition with an unconfirmed process.',conditionsRecorded:results.length,results});throw new Error('Owned browser.close rejected; stop before another browser condition');
    }
    const afterBrowser=close?await observe(name,close,'context.close-after-browser-cleanup-observation'):null;
    const temporal={pendingWhenBrowserCloseBegan:contextPending,contextSettledAt:close?.state.settledAt??null,browserCloseBeganAt:browserClose.state.startedAt,contextFirstObservedSettledAfterBrowserCloseBegan:!!(contextPending&&close?.state.settledAt!==null&&close?.state.settledAt>=browserClose.state.startedAt),afterBrowser,note:'Observed temporal order only; a single two-condition real-page diagnostic does not prove device or general causal root.'};record(name,'cleanup-order',temporal);
    if(close?.state.status==='pending')throw new Error('Owned browser closed but retained context.close is still pending; stop before another browser condition');
   }
  }
  const result={condition,setupComplete:setupError===null,setupError,loaded,preClose,contextClose:close?.state??null,contextCloseObservation:closeObservation,browserClose:browserClose?.state??null,ready:ready?.state??null};results.push(result);save(name.replace('+','-')+'.json',result);save('partial-results.json',{scope:'Independent real V3 load/close diagnostic; original full input case outcomes unchanged',completedConditions:results.length,results});record(name,'condition.complete',{setupComplete:result.setupComplete});
 }
}catch(error){exitCode=2;record(null,'runner-error',{error:errorText(error)});}
finally{
 const summary={scope:'Exactly two fixed real V3 page load conditions; no hammer input, preference changes, domain/native API injection or original full-input-case fix claim',conditionsRequested:conditions,conditionsRecorded:results.length,conditionsCompleted:results.filter(row=>row.cleanupComplete!==false&&row.browserClose?.status==='resolved').length,conditionsWithValidSetup:results.filter(row=>row.setupComplete).length,results,contextObservationMs:observationMs,contextDeadlineScope:'Node pending observation only, not original game/performance budget',events:events.length,requestedExitCode:exitCode};save('result.json',summary);record(null,'run.body-complete',{requestedExitCode:exitCode,note:'Root execution wrapper owns actual process terminal/exit and source fingerprints.'});process.exitCode=exitCode;
}
