from pathlib import Path
import json,hashlib,subprocess,datetime
base=Path('tmp/goal4-T03');baseline=json.loads((base/'baseline.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();exception=json.loads((base/'preservation-exception.json').read_text());counts={};changed=[]
for group in ['oldSource','coreV5','protected']:
 unchanged=0
 for e in baseline[group]:
  b=Path(e['path']).read_bytes()
  if group=='oldSource' and e['path']==exception['source']:
   original=Path(exception['originalCopy']).read_bytes();assert sha(original)==e['sha256']==exception['beforeSha256'];detail0=original.replace(b'if(consume===surface){',b'if(consume===surface&&event.detail!==0){');menu=exception['menuRepair'];assert sha(detail0)==menu['beforeMenuSha256'];assert Path(menu['beforeMenuCopy']).read_bytes()==detail0;expected=detail0.replace(b'  const leave=()=>host.aim(null);',b'  const leave=()=>host.aim(null);\n  const contextmenu=(event:Event)=>event.preventDefault();').replace(b"surface.addEventListener('pointerleave',leave);",b"surface.addEventListener('pointerleave',leave);surface.addEventListener('contextmenu',contextmenu);").replace(b"surface.removeEventListener('pointerleave',leave);",b"surface.removeEventListener('pointerleave',leave);surface.removeEventListener('contextmenu',contextmenu);");assert b==expected and sha(b)==exception['afterSha256'];changed.append({'path':e['path'],'beforeSha256':e['sha256'],'afterSha256':sha(b),'reason':'Confirmed detail0 activation correction plus native contextmenu suppression scoped to existing forge controls with paired removal; all original input/rule semantics retained.'})
  elif group=='oldSource' and e['path']=='src/platform/audio.ts':
   audio=json.loads((base/'audio-preservation-exception.json').read_text());assert sha(Path(audio['originalCopy']).read_bytes())==e['sha256']==audio['beforeSha256'];assert sha(b)==audio['afterSha256'];changed.append({'path':e['path'],'beforeSha256':e['sha256'],'afterSha256':sha(b),'reason':'Confirmed crossed-epoch native resume ownership bug. Exact original and patched bytes separately bound; no rules or cue changes.'})
  elif group=='oldSource' and e['path']=='src/presentation-v4/forge.ts':
   forge=json.loads((base/'forge-preservation-exception.json').read_text());assert sha(Path(forge['originalCopy']).read_bytes())==e['sha256']==forge['beforeSha256'];assert sha(b)==forge['afterSha256'];changed.append({'path':e['path'],'beforeSha256':e['sha256'],'afterSha256':sha(b),'reason':'Confirmed repeated paints and actual high-DPR native rendering costs; one renderer last-pixel cache preserves original miss path and every pixel/contact/source/size invalidation.'})
  elif group=='coreV5' and e['path']=='src/core-v5/game.ts':
   core=json.loads((base/'core-allocation-exception.json').read_text());assert sha(Path(core['originalCopy']).read_bytes())==e['sha256']==core['beforeSha256'];assert sha(b)==core['afterSha256'];changed.append({'path':e['path'],'beforeSha256':e['sha256'],'afterSha256':sha(b),'reason':'Actual long-journal load overhead; immutable historical-action sharing in a new journal array, full body clone/validation/freeze/semantics retained. Golden old/new parity required.'})
  else:assert sha(b)==e['sha256'],e['path'];unchanged+=1
 counts[group]=unchanged
sdk={p:e for p,e in baseline['runtime'].items() if p.endswith('.js') and '/assets/' not in p};assert len(sdk)==9
for p,e in sdk.items():
 if p=='dist/sword-led-v5.js':
  core=json.loads((base/'core-allocation-exception.json').read_text());assert sha(Path(core['goldenSDK']).read_bytes())==e['sha256']==core['goldenSDKsha256'];assert sha(Path(p).read_bytes())==core['newSDKsha256'];assert core['newSDKsha256']!=e['sha256']
 else:assert sha(Path(p).read_bytes())==e['sha256'],p
ref=subprocess.check_output(['rtk','proxy','git','rev-parse','codex/workshop-scene-full-evidence'],text=True).strip();assert ref==baseline['backupRef']
for p in Path('dist').rglob('*.js'):
 data=p.read_text()
 for probe in ['t03Runtime','t03Lifecycle','v5ReleaseAudio']:assert probe not in data,(str(p),probe)
r={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ok':True,'unchanged':{**counts,'SDK':len(sdk)-1},'explicitSharedPresentationException':changed,'backupRef':ref,'noTestProbeInProduct':True};(base/'preserved.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps(r,ensure_ascii=False))
