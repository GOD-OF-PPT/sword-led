# T01–T03联合review／debug收尾草稿

本稿只读汇总原五项、批准内容、实际运行及字节边界，供root在原v3完整用例／OS采样真实终态后补最终关闭结论。**目前不是T03完成回执，不预填尚未取得的采样或关闭结果。** 未运行SDK、浏览器、构建或新增验证门；未改正式源码／消费者／docs。

## 当前结论与原目标

T01真实键盘十二天及T02完整现代PC路径已交付；T03已完成大部分专项修缮和分批验证。当前联合静态复核未发现新增的产品、代码或安全必修项，没有尚未执行但被遗忘的整组现代矩阵。现行数值门已有原身份与必要差分验证，**旧v3 Chromium完整输入用例的context销毁仍是未通过的关闭检查**。原81ms应交付下文有界调查结论，保留原失败与未知部分，不能冒称原尖峰已修或继续盲跑。

原五项仍完整：游戏设计与GitHub交付；UI／内核／架构和三候选及选定派生；流程／可玩性复核；先内核再全UI；现代PC网页。权威入口为`docs/game-design.md`、`implementation-plan.md`、`architecture.md`、`ui-design.md`、`v0.8-workshop-economy-proposal.md`及`v0.8-twelve-lights-guide.md`。原始批准保存在`docs/decisions`及`docs/evidence/v08-approval`；三套A/B/C、初选B、后来D与指定近景稿保原实际选择顺序，派生清单仍在`design/concepts`和`design/d`，不改写成D属于最初三候选。

正式v5包含三章十二天、三配方、六手艺、两次章末改造、商人／事件、三结局、炉谱与真实资格挑战；标题、开炉、落锤、交付／出售／回收、留剑、商人满槽替换、事件、收工、结局、重开、暂停、故障恢复与原文导出都有接线。已做的静态检查没有发现新TODO占位或缺UI出口；旧throughDay4通用分支不等于当前只开放四天。没有新增玩法、价格、钱包、RNG、规则／存档版本、引擎、手机或低版兼容范围，也无重新索取同一v0.8／D批准的依据。

## 实施修缮及其实际依据

真实首红推动了这些最小改动：pointercancel后的独立detail0不再被兼容click吞；三附属画稿在设置中报告／重试，关闭modal不丢来源失败；BFCache回来保留暂停出口并纠正此前日已终结的选剑；当前字体／纸墨／风险／按钮达到原可读性门。Continue真实手势启声，shared audio按context／epoch／请求所有权管理pending和有界cue，取消不补旧声；设置中明确第二次试听先撤销旧试听所有权再发新请求。

绘制缓存仅跳相同canvas／完整像素输入／尺寸／DPR／asset状态，miss保持原画法及contact；真实旧新Canvas像素／alpha／metadata／几何对照有单独结果。长journal只改变事务分配，完整逐条重建校验仍在；golden02实际4908边／25路径／32检查点／174所有权检查同值，不冒称算法变成O(n)或golden能证明浏览器性能。

用户原话已澄清为“身价、酬劳和实收的显示关系让人困惑”。当前界面显示作品估值、整单酬劳／已领，以及本柄酬劳＋品质加赏＝实收；双柄读正式baseFeeDelta，说明只读quote。付款04两PC尺寸核普通10、委托120、day8的158／127和说明零写，root实际看图并修宽屏铜钱换行。此修补与随后试听重试都已真实发布；**不把已修具体反馈推断成用户接受整体趣味性／听感**。可选再反馈未答也不是新增审批或独立工作许可前提。

## 实际证据身份与覆盖

| 实际批次／责任 | 结论及保留边界 |
| --- | --- |
| T01／T02 | T01当前键盘链1项及独立回放／发布，T02两批64逻辑×6共384次、0skip/flaky及两批独立原文回放。源码1b8143…／04c794…及各自发布回执保留，不把旧构建改称最新全矩阵 |
| 系统native04 | 系统Chrome自建窗口／临时profile六项6/6；真实最小化／可信persisted与同堆／writer和dirty-memory原文／旧输入零覆写。随后唯一v5产品差分是既有试听回调，不触这些机制；保原版本＋明确差分依据 |
| 非声音current02 | 有窗口21逻辑×6＝126，125过1红，417源／82产物结束一致；8资源动效生命周期、5可读性、8真实性能。原输入24／受控Hz18、near-limit和2049的12次结果保原身份，core同值／像素／稳定保存机制支撑已记录差分依据，不机械重走384 |
| 音频02及正确完成轴 | 原23×6＝138为137过1红，保旧复合注入身份。改成原真实手势调用native、仅延迟结果后，title固定3/3、八受影响旧逻辑＋新试听重试共九逻辑×六项目54/54；57份operation／SHA独立核对。其他15逻辑90次原通过保身份，不拼成一次“最新138全绿”或物理扬声器认证 |
| 当前性能校准 | 原FF2／1920极长档三输入各6Accepted，callback p95=8/7/6、max14/24/21、contact≤138，load上界874/628/626ms。原同项目四连锻另一次通过，仍三合法恢复／3Accepted／12contact／≥60真实应用callback。两批结束418／82一致；不覆盖未来所有设备或抹旧81／profile红 |
| 保存／独立回放 | golden02保完整核心语义与输入隔离；replay-current01实际0，5471合法state／1512保存／828capture全等，373不同state／21炉谱，所读原件和9SDK前后SHA不变。未遇2049或collection-export槽，明确不冒称本批覆盖这些负样本分支；对应旧UI／golden证据另列 |
| 冷首屏／可读性／生命周期 | 实际冷页图片2,557,210B≤3MiB、当时四JS gzip100,698B≤150KiB；原12px／4.5／44门和两尺寸实际图／滚动范围保留。20往返和20同realm mount保原harness身份，不能把source review当新实测 |
| legacy18 | 原14过4红，三个v2late故障定位修正后目标三引擎均过原旧声0／新声3门；v3 Chromium完整body完成而context teardown180s仍失败。旧v4两尺寸锤面／慢帧等已有实际六项，不扩成旧47重测 |

原预算不变：callback样本≥60、p95<16.7ms，max≥50ms必须定位；短handler p95<50/max<100，长<100/<200；input→Accepted≤150、普通contact≤200、load≤3000；20往返后800＋500ms无应用rAF／pending／运行scene动画／active音源。保首锤、Continue冷成本、完整raw；四连锻原本没有普通contact200门，不偷加也不偷删。受控Hz不是物理刷新率／GPU认证。

## 原81ms有界调查的精确结项文字

**原“max≥50ms必须定位”的触发器与门值保持。** non-audio-current02的FF DPR2／1920／1890journal／pointer第4锤尾记录81ms回调wall cost，原用例继续以失败留存；已确定其为回调内区段而非帧等待误计，页面可见有焦点。该历史样本当时没有执行栈、CPU samples或可用LongTasks，无法事后恢复单次函数self CPU／DOM写／GC／OS／协议各占多少。

后续预定一次原生profile02没有重现81ms，但取得有效GeckoMain／CPU／JS／marker：本次30／31ms定位到watch→结束重投影，clientWidth强制样式／布局有栈；具体哪次DOM写使其失效仍未知。实际profile和安装版expect源码又证实未满足busy matcher会采集ARIA／可见性／布局，测量中有观察器工作。该次profile的p9517与contact228红仍保留，不作为无profile基线。经有据校准后，当前无profile普通／四连锻在原门内，raw采集RPC仍存在。

**因此调查工作可如实交回为：“已完成有界定位与观测校准；原81ms位于已确认的收尾回调区段，相关观察器布局／协议干扰机制已被实际证实，但原尖峰自身的函数CPU原因无法由留存字段追溯。旧失败不改，当前校准方法的数值结果单独成立。”** 这不是宣称原81完整根因定位成功、纯test-only、已修复或放宽50ms门；“调查已完成到证据可达边界”与“原样本根因未定”必须同时记录。追加盲跑不能重建过去的栈，不把根因未知变成无限重复条件；将来有效当前样本再到50ms仍按原门定位。原始json／profile／源码／校准差分与SHA全部保留，不能只交新绿。

## 旧v3关闭调查与当前不做的猜测修补

原完整用例已重复在root dispose请求中挂到browser.close，缺口未闭。finally恢复Clock实际4.85ms完成仍超时，所以该候选已撤回。静态none／Clock／Audio／both四条件均28–44ms关闭，仅说明该最小组合不足以复现。

最新两组均actual0、setup2/2且结束指纹一致：`contextmenu-close-01`默认59.049／prevent52.357ms；`real-v3-close-01`真实v3无Clock85.586／Clock53.346ms。它们没有复现原完整输入用例，当时未据猜测增加监听；不能据两绿把原关闭红改绿。

随后原未改case的一次live OS sample实际0，guard确认owned Chrome17272／精确exe与profile／本consumer祖先链。dispose149发送3秒后仍未回，采样开始和完成时consumer均live／同请求未回；1244个main-thread样本共同位于NSMenu→NSContextMenuTrackingSession→NSMenuTrackingSession菜单嵌套事件循环，1238叶在mach_msg。control之后记录同请求在179.426秒后才回复、consumer native1。这个新直接栈使目标内菜单抑制有了修补依据；先前短静态序列未复现不否定完整输入序列的实际栈。Chrome未完全符号化，尚未解开内部dispose逐函数原因，也没有修补后原case结果，不预填“已修”。独立核对见`tmp/G4-T03-live-menu-sample-independent-review.md`；root下一只做target-only最小候选与原V3／V5右左边界／20mount定向，不扩静态矩阵。

## 代码、安全、保护与harness

联合review覆盖C端路径／提示、保存来源、声音与图片所有权、缓存失效、listener／rAF／dispose、下载及依赖。付款只读正式quote；命令仍绑定run／revision／generation，旧保存确认复读已展示raw；外来文字经textContent，固定模板不拼用户HTML；JSON受plain／大小／整数／深度与完整回放约束；本地Blob下载及时revoke。未新增依赖、凭据、远程API或生产测试hook。当前代码／安全审查mustfix=none，不把静态无问题当声音／内存／主观体验证明。

本次字节复核为110旧源＋input/audio/forge三有据例外，6core＋game分配例外，8SDK＋v5SDK例外，85原件与0316e071…保留ref保持；四例外的原件和afterSHA均匹配。当前82产物与已发布build22不可变快照逐字节相同，后续诊断没有生产delta。记录见`tmp/goal4-T03/t03-closure-audit-bindings.json`。

harness entry／JS006b9dfc…／CSS7fb28d9a…与实际non-audio-current02相同；其app输入58da…，试听修补版46c0…唯一差分是在原试听callback先调用已有silence，没有新listener／timer／缓存或dispose分支，共享audio／forge同字节。因此旧20mount结果可按该明确差分保留；**不写成当前app已重编／重做20mount通过**。若激活新的contextmenu listener，则必须重编当前harness并完成已定的两个注册／销毁核；旧单回调差分桥不能替这个新清理责任。

T03需在最后真实关闭结论、该有界调查交付、原身份清单、源码／保护／harness差分、归档及真实推送回执完整后再记录结项状态。当前源码2fd17e1与回执a4b622已真实交付，330份校准证据无损入Git；试玩仍同build22。新增关闭证据与最终正文尚无本稿可引用的发布回执，不提前写已推送。T04全目标最终审计与真实体验仍另任务，T03审查完成亦不等于整个goal完成。
