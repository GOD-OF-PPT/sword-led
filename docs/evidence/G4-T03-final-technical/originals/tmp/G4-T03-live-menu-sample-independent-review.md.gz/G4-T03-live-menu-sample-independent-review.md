# 原v3完整用例：live菜单栈独立核对

只读核`legacy-live-sample-01-data`四份原件及当前输入源码；没有启动采样／consumer／浏览器／构建，也未改冻结源／测试。**结论：本次真实挂起已直接定位到owned Chrome主线程的原生context-menu跟踪嵌套循环；target-only preventDefault最小候选有据，无静态阻断。尚未证明该修补已解决原完整用例。**

## 身份与时序

`sample.receipt.json`实际sample exit0，目标17272为Google Chrome for Testing156.0.8078.4。launch和两次ps复核的精确exe、临时profile `…chromiumdev_profile-JWo6WV`、父PID17271及lstart06:13:45一致；祖先链17272→17271→17242→17223→17222，末端对应本次control创建的原consumer子进程。8份ps记录均exit0；不是用户现有Chrome或外部窗口。

control单调时钟：dispose149／root session／context `EB1D5C2A21594E5C676C9875CF98E6BF` 在9.450s首次发送；12.721s实际启动一次`sample <ownedPID> 2`；20.382s sample完成，consumer在采样开始／完成均live、相同dispose仍未回复。因此采样不能是最初3秒无回复的原因，sample0也不等于consumer通过。读取时control已追加：同149在188.876s才成功回复（发送后179.426s），consumer在189.498s返回native1；外层最终指纹另由root回执，本文不代填。

## 实际栈与可证限界

raw第24行main thread有1244个统计样本，84–90行共享完整前缀：

`NSMenu _popUpContextMenu:withEvent:forView:withFont:` → `NSCocoaMenuImpl` → `_NSPopUpMenu` → `NSContextMenuImpl presentPopup` → `NSContextMenuTrackingSession startMonitoringEvents:` → `NSMenuTrackingSession startMonitoringEvents:` → `startRunningMenuEventLoop:` → AppKit取事件／CFRunLoop。

其中1238个样本的末端是mach_msg／mach_msg2_trap，其余分支有timer／runloop工作。这证明**本次dispose尚未完成时，主线程持续处于原生菜单跟踪调用栈**；不是仅凭“case曾右击”推测菜单、Audio或Clock。1244是统计样本数，不等于1244ms连续CPU；命令请求2秒，整体采样命令7.667秒含附着／采集／分析，不能据此计算完整180秒CPU占比。

Chrome框架大部分仅ChromeMain＋offset，未远程符号化；没有本地JS／NSEvent参数把这条栈唯一映射到某个事件ID，也未取得Chromium内dispose无法继续的逐函数原因。因此可说“真实挂起位置为原生菜单tracking loop”，不能写成已经证明所有设备／全部Chromium关闭问题同因或改动后必绿。原case唯一明确right-click和源码0处contextmenu拦截与该栈一致。先前静态default／prevent、真实页面load／Clock均快速关闭，只说明那些较短序列未复现，不否定此完整输入序列的直接栈；不必为此扩静态矩阵。

## 最小候选与原验证审查

同一稳定contextmenu handler只挂两个forge surface并preventDefault；dispose以同target／handler／capture成对移除。保持原pointerdown／right早退／left capture／consume／detail0／键盘／host／领域与保存路径，不加window/document拦截、stopPropagation、主动focus／cancel、延迟或菜单dismiss。v3/v4/v5都用该共享bind；这个有据输入表示修补不需要新玩法批准。原direct-input例外应绑定原字节、扩展精确差分及afterSHA，不能继续断言仅旧detail0一行变更。

root提出的定向集合合适：原未删body的V3三引擎（Chromium headed，原180秒关闭）；V5既有右键0／左拖1边界去除Escape/resume掩盖并记录真实trusted／cancelable／defaultPrevented；现有20mount核新两个listener注册与dispose。B实际生命周期patch已只读审，无阻断：每mount精确baseline＋hit/strike两个capturefalse/connectedtrue，dispose后**全部**contextmenu记录含detached回baseline，原20次／真实Accepted／pending／WAAPI／800＋500ms不变。它核显式移除契约，不把probe强持有的detached节点叫内存泄漏。

新listener必须由当前source重编harness后再消费，entry/app/direct-input/JS/CSS绑定新指纹；旧006b9dfc…不能替新注册证明。该定向验证不替原OS菜单证明；原V3真实关闭终态才回答修补效果。无需全384／音频／性能矩阵；若出现新实际回归再按依赖处理，不预填通过。

原件SHA256：sample.raw.txt `c217ea5af5ad417b300a1be1fe6e2aba240f73a19f910603fd126f6a70409f47`；sample.receipt.json `18158e91e62441b0749ab6c4990eab667e84c24a3f865c4dded97a8c8d8640ca`；ps-guard.json `e4e96997fc32d9cff8d83dca3c2365a8f2bc5c2fff38096239a8e21c1a8c9144`；control-events.jsonl `5e1ef9987469d183f165b3b53e9d9368470887a2f58f6fa834fa2ff703c7eee0`。
