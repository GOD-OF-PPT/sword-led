# contextmenu充分条件后的最小验证与81ms调查交付

只读准备，**静态A/B尚未作为已执行结果引用**；未改源／测试，未运行consumer／构建／SDK。仅在root实际A/B证明允许默认菜单会使owned context关闭挂起、同条件preventDefault可关闭后，以下才成为有据的修补／验证方案。静态充分条件仍不自动证明原游戏唯一根因。

## 最小改动与已有验证集合

`bindDirectStrikeInput`只由v3/v4/v5 app调用（各传剑身与主落锤两个button）。最小候选是同一个稳定handler在**这些surface自身**监听contextmenu并preventDefault；不在window/document上拦全页菜单，不stopPropagation，不调用host／cancel／focus／capture，不改pointer、键盘、consume或身份票据。dispose在同一surface、同一handler、同一capture选项上成对remove；不用定时器或新资源。右键仍零命令，左键与辅助detail0仍原语义。

| 必需证据类型，可复用已有case | 最小有界消费／静态核对 |
| --- | --- |
| 原故障是否解除＋左键兼容 | 优先原 `tests/e2e/v3-impact.spec.ts:13` 既有case，保body／右键／Clock／左键、拖移、双击、Space及原180s teardown。Chromium必须headed，原先通过的Firefox/WebKit仍作为共享输入定向回归，合为原三项目责任；保前后指纹与正常owned close。不能删右键、加Escape／额外左键dismiss或放宽关闭门求绿 |
| v5实际接线、右键零写＋后续左拖仅一次 | 复用 `v5-input-completeness.spec.ts:6` 的现有边界，保真实raw／正式SDK等值、右键0命令、后续左拖1Accepted及两PC尺寸输出；一个headed Chromium接线见证即可，不机械重做六项目完整旅程。该旧case:13–14会主动Escape／恢复，**原样通过不足以证明菜单已被产品抑制**；产品target收到的trusted contextmenu应由不改结果的bubble观察记录defaultPrevented=true，再开始独立左键步骤，不把消费脚本的dismiss当修补证明 |
| v4共享表示层不受左键影响 | 复用 `v4-forge.spec.ts:19` 已有实际剑身左击／两PC尺寸／真实锤面contact case作一个Chromium接线见证。新handler不触时序、键盘、Canvas或cue，已有三引擎v3回归覆盖EventTarget分支；无证据要求再跑旧47／384／全部音频或性能矩阵 |
| contextmenu listener生命周期 | 用现有20次same-realm mount/dispose case核当前编译harness；**先重编实际当前mount输入并绑定JS/CSS/source SHA**，不能拿旧 `006b9dfc…` bundle证明新handler。利用既有listener inventory读出每次mount仅两个surface的contextmenu注册、dispose后恢复baseline；同时保既有pending／rAF／动画800＋500ms与正式状态门。旧节点被probe强持有不叫泄漏，但它的新contextmenu注册仍应被dispose显式移除。可在同一既有case补此定向记录，不新增一组20次或新测试量承诺 |

以上为四种证据，可在已有定向执行中合并；不是新全矩阵或DPR承诺。若原v3仍红，保原红并停止把静态A/B当修复完成，按新的实际证据判断。若修补成立，只扩展已有direct-input必要例外，原件不动、afterSHA与精确差分更新；原110旧源／其余两UI例外、6core＋game例外、8SDK＋v5例外、85美术/ref继续逐层报告。当前preserve.py对direct-input只允许旧detail0一行替换，新增监听后必须有据更新该断言／例外记录，不能忽略其失败或仍称“仅一行变更”。

## 原81ms目前能交付的调查结论

1. **旧样本已确定的位置与状态：** non-audio-current02、FF DPR2、1920合法极长档、pointer第4锤尾，记录的是回调内wall cost81ms，不是请求到交付的帧间隔；页面可见有焦点、p95=11ms、其余加载／输入／handler／contact原门通过。原数据、源／consumer／runtime、原失败保持。
2. **已实际定位的机制：** 后续原生profile02有有效内容GeckoMain／CPU／JS／marker，30／31ms发生在watch→结束重投影，clientWidth触发同步Styles/Reflow有栈。安装版expect源码和该次实际profile都证实：未满足busy matcher会做ARIA／可见性／布局工作，动画期间有真实协议观察成本。这是消费者校准的证据，不是原81ms唯一原因证明。
3. **当前门的实际结论：** 去掉反复失败matcher，读取已有MO idle标记、保后置属性／raw RPC／所有原预算后，预定一次无profile FF2 pressure1920普通三路径和原四连锻各已通过。它们是新consumer身份下当前数值门的结果，没有改产品性能代码；不是原81ms被修好，也不是旧profile红转绿。
4. **历史不可追溯部分：** 旧81ms当时没有执行栈、CPU samples或可用LongTasks，无法事后从wall时间拆出精确函数self CPU、某次DOM写、GC、OS调度或协议各占多少。后来单次profile没有重现81ms；增加盲跑不能重建过去的栈。不得声称81ms纯test-only／纯产品、不得从一次无新尖峰推断永久消失。

准确交付措辞可为：**“已完成这次历史尖峰的有界调查：位置、可见性、原预算与观察器干扰机制已核；原81ms自身的函数CPU原因无法由留存字段追溯。原红保留，当前校准观测满足原数值门。”** 保留plan原50ms调查门和这份结论，若将来新的有效当前样本再到50ms即按原门定位；不为无法追溯的历史样本额外要求无限重跑、猜测性cache、门槛提高或新审批。T03最终记录应把“历史调查的证据上限”和“当前产品数值结果”分开，不能把任一层改写成未取得的事实。
